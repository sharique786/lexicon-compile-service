package com.db.macs3.ecomms.spectre.translator;

/**
 * Sealed result type for one {@link TermSyntaxTranslator#translate} call.
 *
 * <p>JDK 21 sealed interface with two permitted records. Use pattern matching switch:
 * <pre>
 * switch (result) {
 *   case TranslationResult.Success s -> use(s.hsPattern(), s.hsFlags());
 *   case TranslationResult.Error   e -> log(e.message());
 * }
 * </pre>
 *
 * <h2>AND NOT: the two-pattern contract</h2>
 * <p>When a term uses {@code AND NOT}, {@link Success#hsPattern()} alone is
 * NOT the full picture — Hyperscan cannot express "absent from the whole
 * message" in a single pattern (no negative lookaround support). A term
 * with {@link Success#requiresExclusionCheck()} true carries a SECOND,
 * independently Hyperscan-valid pattern in {@link Success#exclusionPattern()}.
 * The term is correctly matched only when:
 * <pre>
 *   hsPattern DOES match the message   AND
 *   exclusionPattern does NOT match the message
 * </pre>
 * Both patterns are Hyperscan-validated at compile time (see
 * {@code HyperscanCompiler}), so a caller can compile and scan them exactly
 * like any other pattern — the only extra step is combining the two
 * boolean results with AND-NOT logic after scanning, in application code.
 * See the project README for a concrete example.
 */
public sealed interface TranslationResult
        permits TranslationResult.Success, TranslationResult.Error {

    /** Returns true when translation succeeded. */
    boolean isSuccess();

    /**
     * Successful translation.
     *
     * @param hsPattern              the Hyperscan-scanned PCRE pattern. For a
     *                               plain term or an AND term, this is the
     *                               COMPLETE picture — no further checks needed.
     *                               For an AND NOT term, this is only the
     *                               REQUIRED half; see class Javadoc.
     * @param hsFlags                bitmask: 1=CASELESS, 32=UTF8, 64=UCP
     * @param requiresExclusionCheck true when this term used AND NOT — the
     *                               caller MUST also check {@link #exclusionPattern()}
     * @param exclusionPattern       non-null iff {@code requiresExclusionCheck} is
     *                               true — an independently Hyperscan-valid pattern
     *                               that must NOT match the same message
     */
    record Success(
            String  hsPattern,
            int     hsFlags,
            boolean requiresExclusionCheck,
            String  exclusionPattern
    ) implements TranslationResult {

        /** @return true always */
        public boolean isSuccess() { return true; }
    }

    /**
     * Failed translation.
     *
     * @param message human-readable error
     */
    record Error(String message) implements TranslationResult {

        /** @return false always */
        public boolean isSuccess() { return false; }
    }

    /** Factory: successful translation with no AND-NOT exclusion. */
    static TranslationResult success(String pattern, int flags) {
        return new Success(pattern, flags, false, null);
    }

    /** Factory: successful translation WITH an AND-NOT exclusion pattern. */
    static TranslationResult successWithExclusion(String pattern, int flags, String exclusionPattern) {
        return new Success(pattern, flags, true, exclusionPattern);
    }

    /** Factory: failed translation. */
    static TranslationResult error(String message) {
        return new Error(message);
    }
}
