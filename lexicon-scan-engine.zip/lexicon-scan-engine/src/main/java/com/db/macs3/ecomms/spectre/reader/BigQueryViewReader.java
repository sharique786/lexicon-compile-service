package com.db.macs3.ecomms.spectre.reader;

import com.db.macs3.ecomms.spectre.model.FeatureDecisionRow;
import com.db.macs3.ecomms.spectre.model.ScanEngineArgs;
import com.google.cloud.bigquery.*;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Responsible for:
 * <ol>
 *   <li>Creating (or replacing) the BigQuery pre-computed join view that joins
 *       {@code spectre-audit.language-feature-decision} with
 *       {@code spectre-audit.feature-master}, filtered to lexicon-relevant features.</li>
 *   <li>Reading that view as a Spark {@link Dataset} of {@link FeatureDecisionRow}s,
 *       one row per (message_id, feature_name) pair.</li>
 * </ol>
 *
 * <h2>View SQL logic</h2>
 * <ul>
 *   <li>From {@code feature-master}, we keep only rows where
 *       {@code feature_type IN ('lexicon', 'Composite')}.</li>
 *   <li>For {@code feature_type = 'lexicon'}: the feature definition comes from
 *       the {@code feature_definition} column directly.</li>
 *   <li>For {@code feature_type = 'Composite'}: we UNNEST the {@code sub_features}
 *       array and take only those sub-features where
 *       {@code sub_feature.type = 'lexicon'}, using the sub-feature's definition.</li>
 *   <li>The result is joined with {@code language-feature-decision} on
 *       {@code process_id = policy_engine_id} and matching feature name.</li>
 * </ul>
 */
@Component
public class BigQueryViewReader {

    private static final Logger log = LoggerFactory.getLogger(BigQueryViewReader.class);

    private static final String VIEW_DESCRIPTION =
        "Pre-computed join of language-feature-decision × feature-master " +
        "filtered to lexicon and Composite feature types. " +
        "Created by Lexicon Scan Engine at job startup.";

    private final BigQuery bigQueryClient;

    public BigQueryViewReader() {
        this.bigQueryClient = BigQueryOptions.getDefaultInstance().getService();
    }

    /** Package-private constructor for unit testing. */
    BigQueryViewReader(BigQuery bigQueryClient) {
        this.bigQueryClient = bigQueryClient;
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Creates (or replaces) the BQ view, then reads it as a Spark Dataset.
     *
     * @param spark Spark session
     * @param args  job runtime arguments
     * @return one row per (message_id, feature_name) combination, scoped to lexicon features
     */
    public Dataset<FeatureDecisionRow> createViewAndRead(SparkSession spark, ScanEngineArgs args) {
        log.info("Creating BQ view: {}", args.bqViewRef());
        createOrReplaceView(args);
        log.info("BQ view created. Reading as Spark Dataset...");
        return readView(spark, args);
    }

    // ── View creation ─────────────────────────────────────────────────────────

    /**
     * Issues a {@code CREATE OR REPLACE VIEW} DDL via the BigQuery Java client.
     * Running DDL via the BQ API is faster than running it through Spark's BQ connector.
     *
     * @param args runtime arguments carrying project, dataset, table references
     */
    public void createOrReplaceView(ScanEngineArgs args) {
        String viewQuery = buildViewSql(args);
        log.debug("View SQL:\n{}", viewQuery);

        TableId viewId = TableId.of(args.getBqProject(), args.getBqDataset(),
                                     ScanEngineArgs.BQ_VIEW_NAME);
        ViewDefinition viewDef = ViewDefinition.newBuilder(viewQuery)
                                               .setUseLegacySql(false)
                                               .build();
        TableInfo tableInfo = TableInfo.newBuilder(viewId, viewDef)
                                       .setDescription(VIEW_DESCRIPTION)
                                       .build();

        // createOrUpdate: try to update first (idempotent), create if not exists
        try {
            bigQueryClient.update(tableInfo);
            log.info("BQ view updated: {}", args.bqViewRef());
        } catch (BigQueryException e) {
            if (e.getCode() == 404) {
                bigQueryClient.create(tableInfo);
                log.info("BQ view created: {}", args.bqViewRef());
            } else {
                throw new RuntimeException("Failed to create/update BQ view: " + args.bqViewRef(), e);
            }
        }
    }

    /**
     * Reads the created view as a {@code Dataset<FeatureDecisionRow>} using Spark's
     * BigQuery connector.
     *
     * @param spark Spark session
     * @param args  runtime arguments
     * @return dataset of feature decision rows
     */
    public Dataset<FeatureDecisionRow> readView(SparkSession spark, ScanEngineArgs args) {
        Dataset<Row> rawDf = spark.read()
                .format("bigquery")
                .option("project",     args.getBqProject())
                .option("table",       args.bqViewRef())
                .option("filter",      "process_id = '" + args.getProcessId() + "'")
                .load();

        log.info("BQ view schema: {}", rawDf.schema().treeString());

        return rawDf.map(
                (MapFunction<Row, FeatureDecisionRow>) BigQueryViewReader::rowToFeatureDecision,
                Encoders.bean(FeatureDecisionRow.class)
        );
    }

    // ── SQL construction ──────────────────────────────────────────────────────

    /**
     * Builds the CREATE OR REPLACE VIEW SQL.
     *
     * <p>The SQL flattens the nested REPEATED fields in both BigQuery tables
     * and joins them so each output row represents one (message, lexicon_feature) pair.
     *
     * @param args runtime arguments (for table references)
     * @return the full SQL string
     */
    public String buildViewSql(ScanEngineArgs args) {
        return "CREATE OR REPLACE VIEW `" + args.bqViewRef() + "` AS\n" +
               "\n" +
               "WITH\n" +
               "\n" +
               "-- Step 1: Flatten features ARRAY from language-feature-decision\n" +
               "-- One row per (message_id, feature_name)\n" +
               "lfd_flat AS (\n" +
               "    SELECT\n" +
               "        lfd.process_id,\n" +
               "        lfd.message_id,\n" +
               "        lfd.run_date,\n" +
               "        lfd.sent_date,\n" +
               "        feat.type             AS feature_type,\n" +
               "        feat.id               AS feature_id,\n" +
               "        feat.name             AS feature_name,\n" +
               "        feat.feature_op       AS feature_operator,\n" +
               "        COALESCE(feat.is_noise_reduction, FALSE) AS is_noise_reduction\n" +
               "    FROM `" + ScanEngineArgs.BQ_LANGUAGE_FEATURE_DEC + "` lfd,\n" +
               "    UNNEST(lfd.features) AS feat\n" +
               "),\n" +
               "\n" +
               "-- Step 2a: Direct 'lexicon' type features — definition from feature_definition\n" +
               "fm_direct_lexicon AS (\n" +
               "    SELECT\n" +
               "        fm.policy_engine_id,\n" +
               "        fm.feature_name,\n" +
               "        fm.feature_definition AS resolved_feature_definition\n" +
               "    FROM `" + ScanEngineArgs.BQ_FEATURE_MASTER + "` fm\n" +
               "    WHERE fm.feature_type = 'lexicon'\n" +
               "),\n" +
               "\n" +
               "-- Step 2b: Composite features — unnest sub_features, keep only lexicon sub-types\n" +
               "--          definition from sub_feature.definition\n" +
               "fm_composite_lexicon AS (\n" +
               "    SELECT\n" +
               "        fm.policy_engine_id,\n" +
               "        sf.name               AS feature_name,\n" +
               "        sf.definition         AS resolved_feature_definition\n" +
               "    FROM `" + ScanEngineArgs.BQ_FEATURE_MASTER + "` fm,\n" +
               "    UNNEST(fm.sub_features) AS sf\n" +
               "    WHERE fm.feature_type = 'Composite'\n" +
               "    AND   sf.type = 'lexicon'\n" +
               "),\n" +
               "\n" +
               "-- Step 2c: Union both sources\n" +
               "fm_all AS (\n" +
               "    SELECT * FROM fm_direct_lexicon\n" +
               "    UNION ALL\n" +
               "    SELECT * FROM fm_composite_lexicon\n" +
               ")\n" +
               "\n" +
               "-- Step 3: Final join — all LFD columns + resolved feature definition from FM\n" +
               "SELECT\n" +
               "    lfd.process_id,\n" +
               "    lfd.message_id,\n" +
               "    lfd.run_date,\n" +
               "    lfd.sent_date,\n" +
               "    lfd.feature_type,\n" +
               "    lfd.feature_id,\n" +
               "    lfd.feature_name,\n" +
               "    lfd.feature_operator,\n" +
               "    lfd.is_noise_reduction,\n" +
               "    fm.resolved_feature_definition AS fm_feature_definition\n" +
               "FROM lfd_flat lfd\n" +
               "INNER JOIN fm_all fm\n" +
               "    ON  lfd.process_id   = fm.policy_engine_id\n" +
               "    AND lfd.feature_name = fm.feature_name\n";
    }

    // ── Row mapping ───────────────────────────────────────────────────────────

    private static FeatureDecisionRow rowToFeatureDecision(Row row) {
        return FeatureDecisionRow.of(
                getStringOrNull(row, "process_id"),
                getStringOrNull(row, "message_id"),
                getStringOrNull(row, "run_date"),
                getStringOrNull(row, "sent_date"),
                getStringOrNull(row, "feature_type"),
                row.isNullAt(row.fieldIndex("feature_id")) ? null : row.getLong(row.fieldIndex("feature_id")),
                getStringOrNull(row, "feature_name"),
                getStringOrNull(row, "feature_operator"),
                !row.isNullAt(row.fieldIndex("is_noise_reduction")) && row.getBoolean(row.fieldIndex("is_noise_reduction")),
                getStringOrNull(row, "fm_feature_definition")
        );
    }

    private static String getStringOrNull(Row row, String fieldName) {
        int idx = row.fieldIndex(fieldName);
        return row.isNullAt(idx) ? null : row.getString(idx);
    }
}
