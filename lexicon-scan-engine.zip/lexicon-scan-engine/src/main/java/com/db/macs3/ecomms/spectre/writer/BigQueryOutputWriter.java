package com.db.macs3.ecomms.spectre.writer;

import com.db.macs3.ecomms.spectre.model.ScanEngineArgs;
import com.db.macs3.ecomms.spectre.model.ScanOutputRow;
import org.apache.spark.sql.*;
import org.apache.spark.sql.functions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

/**
 * Writes scan results to the BigQuery output tables.
 *
 * <h2>Output tables</h2>
 * <ol>
 *   <li>{@code spectre-audit.lexicon_hit_summary} — one row per (message, feature) hit</li>
 *   <li>{@code spectre-audit.pipeline_stage_audit} — one row per job execution stage</li>
 *   <li>{@code spectre-audit.pipeline_record_audit} — one row per processed message</li>
 * </ol>
 *
 * <h2>Write mode</h2>
 * <p>All writes use {@code APPEND} mode to preserve existing data.
 * The BQ write is partitioned by {@code run_date} for efficient downstream queries.
 *
 * <h2>BigQuery Spark connector options</h2>
 * <p>The connector writes using the BigQuery Storage Write API
 * ({@code writeMethod=STORAGE_WRITE_API}), which is significantly faster than
 * the legacy Stream API and avoids quota limits on large result sets.
 */
@Component
public class BigQueryOutputWriter {

    private static final Logger log = LoggerFactory.getLogger(BigQueryOutputWriter.class);

    // Write mode for all output tables
    private static final String WRITE_METHOD = "STORAGE_WRITE_API";

    /**
     * Writes the main hit summary rows to {@code spectre-audit.lexicon_hit_summary}.
     *
     * <p>Only rows where {@code hit_count_of_terms > 0} are written — messages
     * where the scan produced no matches are not written to the hit table but
     * are still recorded in the record audit table.
     *
     * @param scanResults the full scan result dataset
     * @param args        runtime arguments (project, pipeline_exec_id, etc.)
     */
    public void writeHitSummary(Dataset<ScanOutputRow> scanResults, ScanEngineArgs args) {
        Dataset<Row> hitsOnly = scanResults.toDF()
                .filter(functions.col("hitCountOfTerms").gt(0));

        long hitCount = hitsOnly.count();
        log.info("Writing {} hit records to {}", hitCount, ScanEngineArgs.BQ_OUTPUT_HIT_SUMMARY);

        if (hitCount == 0) {
            log.info("No hits produced — skipping write to lexicon_hit_summary");
            return;
        }

        hitsOnly.write()
                .format("bigquery")
                .option("project",      args.getBqProject())
                .option("table",        ScanEngineArgs.BQ_OUTPUT_HIT_SUMMARY)
                .option("writeMethod",  WRITE_METHOD)
                .option("partitionField", "run_date")
                .mode(SaveMode.Append)
                .save();

        log.info("Hit summary write complete: {} rows to {}", hitCount, ScanEngineArgs.BQ_OUTPUT_HIT_SUMMARY);
    }

    /**
     * Writes stage-level audit data. One row per pipeline execution stage.
     *
     * @param spark      the active SparkSession (for creating an in-memory Dataset)
     * @param args       runtime arguments
     * @param jobStart   when the job started (for duration calculation)
     * @param inputCount how many feature decision rows were read
     */
    public void writeStageAudit(SparkSession spark,
                                 ScanEngineArgs args,
                                 Timestamp jobStart,
                                 long inputCount) {
        log.info("Writing stage audit to {}", ScanEngineArgs.BQ_OUTPUT_STAGE_AUDIT);

        Map<String, Object> stageAuditData = new HashMap<>();
        stageAuditData.put("pipeline_exec_id", args.getPipelineExecId());
        stageAuditData.put("process_id",        args.getProcessId());
        stageAuditData.put("policy_engine_id",  args.getPolicyEngineId());
        stageAuditData.put("stage_name",        "LEXICON_SCAN");
        stageAuditData.put("trigger_type",      args.getTriggerType());
        stageAuditData.put("run_date",          args.getRunDate());
        stageAuditData.put("records_read",      inputCount);
        stageAuditData.put("start_ts",          jobStart.toString());
        stageAuditData.put("end_ts",            new Timestamp(System.currentTimeMillis()).toString());
        stageAuditData.put("stage_status",      "SUCCESS");

        // Create a single-row Dataset for the audit record
        Dataset<Row> auditDf = spark.createDataFrame(
                java.util.Collections.singletonList(
                    org.apache.spark.sql.RowFactory.create(
                        args.getPipelineExecId(), args.getProcessId(), args.getPolicyEngineId(),
                        "LEXICON_SCAN", args.getTriggerType(), args.getRunDate(),
                        inputCount, jobStart.toString(),
                        new Timestamp(System.currentTimeMillis()).toString(), "SUCCESS"
                    )
                ),
                buildStageAuditSchema()
        );

        auditDf.write()
               .format("bigquery")
               .option("project",     args.getBqProject())
               .option("table",       ScanEngineArgs.BQ_OUTPUT_STAGE_AUDIT)
               .option("writeMethod", WRITE_METHOD)
               .mode(SaveMode.Append)
               .save();

        log.info("Stage audit written");
    }

    /**
     * Writes per-message-level audit records.
     *
     * <p>One row per (message_id, pipeline_exec_id) pair, indicating which messages
     * were processed and their overall status.
     *
     * @param scanResults the scan results Dataset (contains all processed messages)
     * @param args        runtime arguments
     */
    public void writeRecordAudit(Dataset<ScanOutputRow> scanResults, ScanEngineArgs args) {
        log.info("Writing record audit to {}", ScanEngineArgs.BQ_OUTPUT_RECORD_AUDIT);

        // Aggregate per message: collect feature names and determine status
        Dataset<Row> recordAudit = scanResults.toDF()
                .groupBy(
                    functions.col("messageId"),
                    functions.col("runDate")
                )
                .agg(
                    functions.collect_list("featureName").alias("features_applied_list"),
                    functions.sum("hitCountOfTerms").alias("total_hits"),
                    functions.max("processTs").alias("process_ts")
                )
                .withColumn("pipeline_exec_id", functions.lit(args.getPipelineExecId()))
                .withColumn("status", functions.lit("PROCESSED"))
                .withColumn("features_applied",
                    functions.to_json(functions.col("features_applied_list")))
                .drop("features_applied_list");

        long recordCount = recordAudit.count();
        log.info("Writing {} record audit rows to {}",
                 recordCount, ScanEngineArgs.BQ_OUTPUT_RECORD_AUDIT);

        recordAudit.write()
                   .format("bigquery")
                   .option("project",     args.getBqProject())
                   .option("table",       ScanEngineArgs.BQ_OUTPUT_RECORD_AUDIT)
                   .option("writeMethod", WRITE_METHOD)
                   .option("partitionField", "runDate")
                   .mode(SaveMode.Append)
                   .save();

        log.info("Record audit write complete: {} rows", recordCount);
    }

    // ── Schema helpers ────────────────────────────────────────────────────────

    private org.apache.spark.sql.types.StructType buildStageAuditSchema() {
        return new org.apache.spark.sql.types.StructType()
                .add("pipeline_exec_id", org.apache.spark.sql.types.DataTypes.StringType, true)
                .add("process_id",       org.apache.spark.sql.types.DataTypes.StringType, true)
                .add("policy_engine_id", org.apache.spark.sql.types.DataTypes.StringType, true)
                .add("stage_name",       org.apache.spark.sql.types.DataTypes.StringType, true)
                .add("trigger_type",     org.apache.spark.sql.types.DataTypes.StringType, true)
                .add("run_date",         org.apache.spark.sql.types.DataTypes.StringType, true)
                .add("records_read",     org.apache.spark.sql.types.DataTypes.LongType,   true)
                .add("start_ts",         org.apache.spark.sql.types.DataTypes.StringType, true)
                .add("end_ts",           org.apache.spark.sql.types.DataTypes.StringType, true)
                .add("stage_status",     org.apache.spark.sql.types.DataTypes.StringType, true);
    }
}
