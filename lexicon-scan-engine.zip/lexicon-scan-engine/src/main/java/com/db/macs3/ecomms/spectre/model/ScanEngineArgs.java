package com.db.macs3.ecomms.spectre.model;

/**
 * Typed container for the runtime arguments passed to the Lexicon Scan Engine
 * from the Airflow DAG via Dataproc job submission.
 *
 * <p>Runtime args (from workflow diagram):
 * <ul>
 *   <li>{@code --processId}       — process_id shared with NLF Engine</li>
 *   <li>{@code --pipelineExecId}  — pipeline execution instance identifier</li>
 *   <li>{@code --policyEngineId}  — policy engine instance identifier</li>
 *   <li>{@code --triggerType}     — POLICY_TEST | POLICY_DEPLOYMENT</li>
 *   <li>{@code --runDate}         — run date in yyyy-MM-dd format</li>
 *   <li>{@code --hdbGcsBucket}    — GCS bucket containing .hdb files</li>
 *   <li>{@code --hdbGcsPrefix}    — GCS prefix path for .hdb files</li>
 *   <li>{@code --msgGcsBucket}    — GCS bucket containing AVRO message files</li>
 *   <li>{@code --msgGcsPrefix}    — GCS prefix path for AVRO message files</li>
 *   <li>{@code --bqProject}       — GCP project for BigQuery operations</li>
 *   <li>{@code --bqDataset}       — BigQuery dataset for view creation</li>
 * </ul>
 */
public class ScanEngineArgs {

    // ── Job identity ──────────────────────────────────────────────────────────
    private final String processId;
    private final String pipelineExecId;
    private final String policyEngineId;
    private final String triggerType;   // POLICY_TEST | POLICY_DEPLOYMENT
    private final String runDate;       // yyyy-MM-dd

    // ── GCS paths ─────────────────────────────────────────────────────────────
    /** Bucket containing pre-compiled Hyperscan .hdb files. */
    private final String hdbGcsBucket;
    /** Prefix (folder) within hdbGcsBucket, e.g. "hyperscan-databases". */
    private final String hdbGcsPrefix;

    /** Bucket containing AVRO message files from Msg Transformer. */
    private final String msgGcsBucket;
    /**
     * Prefix for AVRO files; may contain partitions:
     * e.g. "messages/RUN_DATE=2026-06-25/PIPELINE_EXEC_ID=abc123/"
     */
    private final String msgGcsPrefix;

    // ── BigQuery ──────────────────────────────────────────────────────────────
    /** GCP project ID for all BigQuery operations. */
    private final String bqProject;
    /**
     * Dataset where the scan engine's working view will be created.
     * Output tables are in spectre-audit dataset by convention.
     */
    private final String bqDataset;

    // ── Constants ─────────────────────────────────────────────────────────────
    public static final String TRIGGER_TEST       = "POLICY_TEST";
    public static final String TRIGGER_DEPLOYMENT = "POLICY_DEPLOYMENT";

    // BigQuery source table full references
    public static final String BQ_FEATURE_MASTER        = "spectre-audit.feature-master";
    public static final String BQ_LANGUAGE_FEATURE_DEC  = "spectre-audit.language-feature-decision";
    public static final String BQ_VIEW_NAME             = "v_lexicon_scan_engine_input";
    public static final String BQ_OUTPUT_HIT_SUMMARY    = "spectre-audit.lexicon_hit_summary";
    public static final String BQ_OUTPUT_STAGE_AUDIT    = "spectre-audit.pipeline_stage_audit";
    public static final String BQ_OUTPUT_RECORD_AUDIT   = "spectre-audit.pipeline_record_audit";
    public static final String BQ_OUTPUT_PIPELINE_EVENT = "ecomms.ecomms_pipeline_invext";

    private ScanEngineArgs(Builder builder) {
        this.processId      = builder.processId;
        this.pipelineExecId = builder.pipelineExecId;
        this.policyEngineId = builder.policyEngineId;
        this.triggerType    = builder.triggerType;
        this.runDate        = builder.runDate;
        this.hdbGcsBucket   = builder.hdbGcsBucket;
        this.hdbGcsPrefix   = builder.hdbGcsPrefix;
        this.msgGcsBucket   = builder.msgGcsBucket;
        this.msgGcsPrefix   = builder.msgGcsPrefix;
        this.bqProject      = builder.bqProject;
        this.bqDataset      = builder.bqDataset;
    }

    /**
     * Parses a standard {@code --key value} command-line argument array
     * into a {@link ScanEngineArgs} instance.
     *
     * @param args the raw {@code main(String[] args)} array from Spark submit
     * @return a fully populated {@code ScanEngineArgs}
     * @throws IllegalArgumentException if a required argument is missing
     */
    public static ScanEngineArgs parse(String[] args) {
        Builder builder = new Builder();
        for (int i = 0; i < args.length - 1; i++) {
            switch (args[i]) {
                case "--processId":       builder.processId(args[++i]);      break;
                case "--pipelineExecId":  builder.pipelineExecId(args[++i]); break;
                case "--policyEngineId":  builder.policyEngineId(args[++i]); break;
                case "--triggerType":     builder.triggerType(args[++i]);     break;
                case "--runDate":         builder.runDate(args[++i]);         break;
                case "--hdbGcsBucket":    builder.hdbGcsBucket(args[++i]);   break;
                case "--hdbGcsPrefix":    builder.hdbGcsPrefix(args[++i]);   break;
                case "--msgGcsBucket":    builder.msgGcsBucket(args[++i]);   break;
                case "--msgGcsPrefix":    builder.msgGcsPrefix(args[++i]);   break;
                case "--bqProject":       builder.bqProject(args[++i]);      break;
                case "--bqDataset":       builder.bqDataset(args[++i]);      break;
                default:
                    // ignore unknown flags silently — allows pass-through from DAG
            }
        }
        return builder.build();
    }

    /** @return the full GCS URI for a given .hdb file: {@code gs://bucket/prefix/featureName.hdb} */
    public String hdbGcsUri(String featureName) {
        String prefix = hdbGcsPrefix.endsWith("/") ? hdbGcsPrefix : hdbGcsPrefix + "/";
        return "gs://" + hdbGcsBucket + "/" + prefix + featureName + ".hdb";
    }

    /** @return the GCS path prefix for AVRO messages, including run_date partition. */
    public String avroGcsPath() {
        return "gs://" + msgGcsBucket + "/" + msgGcsPrefix;
    }

    /** @return the fully-qualified BigQuery view reference: {@code project.dataset.view} */
    public String bqViewRef() {
        return bqProject + "." + bqDataset + "." + BQ_VIEW_NAME;
    }

    // ── Accessors ─────────────────────────────────────────────────────────────

    public String getProcessId()      { return processId; }
    public String getPipelineExecId() { return pipelineExecId; }
    public String getPolicyEngineId() { return policyEngineId; }
    public String getTriggerType()    { return triggerType; }
    public String getRunDate()        { return runDate; }
    public String getHdbGcsBucket()   { return hdbGcsBucket; }
    public String getHdbGcsPrefix()   { return hdbGcsPrefix; }
    public String getMsgGcsBucket()   { return msgGcsBucket; }
    public String getMsgGcsPrefix()   { return msgGcsPrefix; }
    public String getBqProject()      { return bqProject; }
    public String getBqDataset()      { return bqDataset; }

    @Override
    public String toString() {
        return "ScanEngineArgs{" +
               "processId='"      + processId      + "', " +
               "pipelineExecId='" + pipelineExecId + "', " +
               "policyEngineId='" + policyEngineId + "', " +
               "triggerType='"    + triggerType    + "', " +
               "runDate='"        + runDate        + "', " +
               "hdbGcsBucket='"   + hdbGcsBucket  + "', " +
               "hdbGcsPrefix='"   + hdbGcsPrefix  + "', " +
               "msgGcsBucket='"   + msgGcsBucket  + "', " +
               "msgGcsPrefix='"   + msgGcsPrefix  + "', " +
               "bqProject='"      + bqProject      + "', " +
               "bqDataset='"      + bqDataset      + '\'' +
               '}';
    }

    // ── Builder ───────────────────────────────────────────────────────────────

    public static class Builder {
        private String processId;
        private String pipelineExecId;
        private String policyEngineId;
        private String triggerType;
        private String runDate;
        private String hdbGcsBucket;
        private String hdbGcsPrefix;
        private String msgGcsBucket;
        private String msgGcsPrefix;
        private String bqProject;
        private String bqDataset;

        public Builder processId(String v)      { this.processId = v;      return this; }
        public Builder pipelineExecId(String v) { this.pipelineExecId = v; return this; }
        public Builder policyEngineId(String v) { this.policyEngineId = v; return this; }
        public Builder triggerType(String v)    { this.triggerType = v;    return this; }
        public Builder runDate(String v)        { this.runDate = v;        return this; }
        public Builder hdbGcsBucket(String v)   { this.hdbGcsBucket = v;   return this; }
        public Builder hdbGcsPrefix(String v)   { this.hdbGcsPrefix = v;   return this; }
        public Builder msgGcsBucket(String v)   { this.msgGcsBucket = v;   return this; }
        public Builder msgGcsPrefix(String v)   { this.msgGcsPrefix = v;   return this; }
        public Builder bqProject(String v)      { this.bqProject = v;      return this; }
        public Builder bqDataset(String v)      { this.bqDataset = v;      return this; }

        public ScanEngineArgs build() {
            requireNonBlank(processId,      "processId");
            requireNonBlank(pipelineExecId, "pipelineExecId");
            requireNonBlank(policyEngineId, "policyEngineId");
            requireNonBlank(triggerType,    "triggerType");
            requireNonBlank(runDate,        "runDate");
            requireNonBlank(hdbGcsBucket,   "hdbGcsBucket");
            requireNonBlank(hdbGcsPrefix,   "hdbGcsPrefix");
            requireNonBlank(msgGcsBucket,   "msgGcsBucket");
            requireNonBlank(msgGcsPrefix,   "msgGcsPrefix");
            requireNonBlank(bqProject,      "bqProject");
            requireNonBlank(bqDataset,      "bqDataset");
            return new ScanEngineArgs(this);
        }

        private void requireNonBlank(String value, String name) {
            if (value == null || value.isBlank()) {
                throw new IllegalArgumentException("Required argument missing or blank: --" + name);
            }
        }
    }
}
