package com.db.macs3.ecomms.spectre.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.List;

/**
 * Compilation outcome for a single lexicon term.
 *
 * <h2>Null field semantics</h2>
 * <ul>
 *   <li>{@code translatedPattern} — null/absent only when translation failed before any
 *       pattern could be produced (see {@code translationError}); for a PASS term, always
 *       present with at least one entry — see below</li>
 *   <li>{@code errorLog} — non-null only for Hyperscan-stage failures</li>
 *   <li>{@code translationError} — non-null only for translation-stage failures</li>
 *   <li>{@code exclusionPattern} — non-null only when {@code requiresExclusionCheck} is true</li>
 *   <li>{@code hyperscanExpressionId} — non-null only on a {@code /compile/bundle}
 *       response (see below); always null for {@code /compile} and {@code /compile/csv},
 *       which never build a combined Hyperscan database</li>
 * </ul>
 * At most one of {@code errorLog} / {@code translationError} is non-null.
 * Both are null when {@code compilationStatus} is {@code PASS}.
 *
 * <h2>{@code translatedPattern} and {@code exclusionPattern} are always lists</h2>
 * <p>Every lexicon term — however structurally complex, and whether or not
 * it uses {@code AND NOT} — is represented uniformly: {@code translatedPattern}
 * holds the required side's independently Hyperscan-valid pattern(s), one
 * entry for a term simple enough to compile as a single pattern, two or
 * more for a term too structurally complex for that (see
 * {@code PatternComplexityAnalyzer} / {@code PatternDecomposer}) — decomposed
 * into independent leaf patterns instead of being rejected outright. There
 * is no separate "was this decomposed" boolean any more: a caller checks
 * {@code translatedPattern.size()}. The same applies to
 * {@code exclusionPattern} for an AND NOT term's excluded side.
 *
 * <p><b>Multiple entries are a real precision trade-off — always check
 * {@code warnings}.</b> Decomposition discards the original NEAR/FOLLOWEDBY
 * proximity and ordering constraints entirely: the leaf patterns are
 * combined with pure boolean AND ("all of these appear somewhere in the
 * message"), not with any positional relationship. {@code warnings} always
 * carries an explicit entry whenever this trade-off applies to either side,
 * so no caller can silently treat a decomposed match as a genuine proximity
 * match.
 *
 * <h2>AND NOT has two different correct implementations, for two different callers</h2>
 * <p>{@code translatedPattern} and {@code exclusionPattern} are independently
 * Hyperscan-valid pattern lists (Hyperscan cannot express "absent from the
 * whole message" in a single pattern — no negative lookaround support).
 * What a caller does with them differs by which endpoint it used:
 *
 * <ul>
 *   <li><b>{@code /compile} and {@code /compile/csv}</b> — the caller (e.g.
 *       the Lexicon Scanner Service) reads the JSON, compiles every pattern
 *       in both lists itself, and combines the boolean results in
 *       application code: matched iff EVERY entry of {@code translatedPattern}
 *       matches AND the excluded condition (every entry of {@code exclusionPattern}
 *       found — pure AND, same convention as the required side) is NOT fully
 *       satisfied.</li>
 *   <li><b>{@code /compile/bundle}</b> — the returned {@code .hdb} file is
 *       often the ONLY artifact a consumer reads (e.g. the Lexicon Scan
 *       Engine's Dataproc job loads the database and scans messages against
 *       it directly, with no JSON in the loop at all). For this endpoint,
 *       every pattern in both lists is compiled into the combined database
 *       as QUIET sub-expressions feeding a native Hyperscan LOGICAL
 *       COMBINATION ({@code HS_FLAG_COMBINATION}) — Hyperscan itself
 *       evaluates the full boolean condition during the scan and reports a
 *       match ONLY at {@code hyperscanExpressionId}, with no separate
 *       application-level combination step needed downstream. See
 *       {@code HyperscanCombinationHandler} and {@code LexiconCompileBundleService}.</li>
 * </ul>
 *
 * <h2>{@code hyperscanExpressionId} is always the term's own term number</h2>
 * <p>On a {@code /compile/bundle} response, every PASS term's reportable
 * Hyperscan expression id — whether it needed a combination or not — is
 * ALWAYS its own term number (parsed from its {@code termId}'s {@code ::<n>}
 * suffix). This is deliberate: a downstream consumer that already knows a
 * term's number (from the lexicon rule definition itself) can predict which
 * expression id to watch for WITHOUT reading this JSON at all — the
 * {@code .hdb} file is self-sufficient. Every QUIET sub-expression a
 * combination needs (decomposition leaves, the exclusion pattern(s)) is
 * assigned an id from a separate allocated range that never collides with
 * any term number — see {@code HyperscanCombinationHandler}.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record TermCompilationResult(

        @JsonProperty("termId")
        String termId,

        @JsonProperty("termDescription")
        String termDescription,

        @JsonProperty("compilationStatus")
        CompilationStatus compilationStatus,

        /**
         * The required side's independently Hyperscan-validated pattern(s) —
         * see class Javadoc. Non-null and non-empty for a PASS term; null
         * for a FAILED term where translation never produced a pattern at
         * all (may still be non-null, for visibility, when the failure was
         * a Hyperscan-stage rejection of an attempted pattern).
         */
        @JsonProperty("translatedPattern")
        List<String> translatedPattern,

        /**
         * Hyperscan error message when a pattern was syntactically valid
         * PCRE but Hyperscan's compiler still rejected it — the main
         * pattern, the exclusion pattern, or a decomposed leaf of either
         * side (the message says which). Null for PASS terms and for
         * translation-stage failures.
         */
        @JsonProperty("errorLog")
        String errorLog,

        /**
         * Error from the operator-language translator, when the term's text
         * could not be converted into a PCRE pattern at all (e.g. missing
         * operand for NEAR{n}), OR when a side was over budget AND had no
         * NEAR/FOLLOWEDBY structure left to decompose, OR when even a
         * decomposed leaf was itself over budget on its own — see
         * {@code PatternDecomposer}. Null for PASS terms and for
         * Hyperscan-stage failures.
         */
        @JsonProperty("translationError")
        String translationError,

        /**
         * Hyperscan compile-flag bitmask applied to the pattern(s).
         * {@code 1}=CASELESS, {@code 32}=UTF8, {@code 64}=UCP.
         * {@code 0} indicates translation never completed.
         */
        @JsonProperty("hyperscanFlags")
        int hyperscanFlags,

        /**
         * {@code true} when the term used {@code AND NOT} — see the
         * two-implementations note in class Javadoc for what the caller
         * does with this depending on which endpoint produced this result.
         * Always {@code false} for failed terms and for terms using only
         * {@code AND} (which is fully expressed by {@code translatedPattern}
         * alone — see {@code PatternCodeGenerator} class Javadoc).
         */
        @JsonProperty("requiresExclusionCheck")
        boolean requiresExclusionCheck,

        /**
         * Independently Hyperscan-valid pattern(s) that must NOT (collectively,
         * per the AND convention described in class Javadoc) match the same
         * message for this term to be considered matched. Non-null and
         * non-empty iff {@code requiresExclusionCheck} is true; null otherwise.
         */
        @JsonProperty("exclusionPattern")
        List<String> exclusionPattern,

        /**
         * Non-fatal issues worth surfacing to the caller — never null, may
         * be empty. Always includes an explicit entry whenever decomposition
         * applied to either side (see class Javadoc), and whenever the term
         * relied on chained NEAR/FOLLOWEDBY without explicit parentheses
         * (see {@code ExpressionParser}). Present regardless of
         * {@code compilationStatus}, though in practice only PASS terms
         * currently produce any.
         */
        @JsonProperty("warnings")
        List<String> warnings,

        /**
         * On a {@code /compile/bundle} response only: this term's own term
         * number — see class Javadoc "hyperscanExpressionId is always the
         * term's own term number". Always null outside {@code /compile/bundle},
         * and always null for FAILED terms (nothing was compiled into the
         * database for them).
         */
        @JsonProperty("hyperscanExpressionId")
        Integer hyperscanExpressionId,

        @JsonProperty("compiledAt")
        @JsonFormat(shape = JsonFormat.Shape.STRING)
        Instant compiledAt

) {
    // ── Factory methods ───────────────────────────────────────────────────────

    /**
     * Creates a PASS result. {@code translatedPattern} and (when
     * {@code requiresExclusionCheck}) {@code exclusionPattern} may each have
     * one entry (simple term) or several (decomposed) — see class Javadoc.
     * {@code warnings} may be empty.
     */
    public static TermCompilationResult pass(TypedCompileRequest.TermInput input,
                                              List<String> translatedPattern,
                                              int hyperscanFlags,
                                              boolean requiresExclusionCheck,
                                              List<String> exclusionPattern,
                                              List<String> warnings) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.PASS,
                translatedPattern, null, null,
                hyperscanFlags, requiresExclusionCheck, exclusionPattern,
                warnings == null ? List.of() : List.copyOf(warnings),
                null, Instant.now());
    }

    /** Convenience overload for a PASS result with no AND-NOT exclusion and no warnings. */
    public static TermCompilationResult pass(TypedCompileRequest.TermInput input,
                                              List<String> translatedPattern,
                                              int hyperscanFlags) {
        return pass(input, translatedPattern, hyperscanFlags, false, null, List.of());
    }

    /**
     * Creates a FAILED result where Hyperscan rejected a pattern — the main
     * pattern, the exclusion pattern, or a decomposed leaf of either side
     * (the message says which).
     *
     * @param translatedPattern the pattern(s) attempted, for visibility — may be null
     *                          if the failure was in the exclusion side specifically
     */
    public static TermCompilationResult failedHyperscan(TypedCompileRequest.TermInput input,
                                                          List<String> translatedPattern,
                                                          String errorLog,
                                                          int hyperscanFlags) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.FAILED,
                translatedPattern, errorLog, null,
                hyperscanFlags, false, null, List.of(),
                null, Instant.now());
    }

    /**
     * Creates a FAILED result where the term's syntax could not be translated
     * into a PCRE pattern at all — including the narrower decomposition-failure
     * cases (no proximity structure left to decompose; a leaf itself over
     * budget) — see {@code TermSyntaxTranslator}. Hyperscan was never invoked.
     */
    public static TermCompilationResult failedTranslation(TypedCompileRequest.TermInput input,
                                                            String translationError) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.FAILED,
                null, null, translationError,
                0, false, null, List.of(),
                null, Instant.now());
    }

    /**
     * Returns a copy of this (PASS) result with {@link #hyperscanExpressionId}
     * set — used only by {@code LexiconCompileBundleService}, which always
     * sets it to the term's own term number (see class Javadoc).
     */
    public TermCompilationResult withHyperscanExpressionId(int id) {
        return new TermCompilationResult(
                termId, termDescription, compilationStatus,
                translatedPattern, errorLog, translationError,
                hyperscanFlags, requiresExclusionCheck, exclusionPattern, warnings,
                id, compiledAt);
    }

    public boolean isPass()   { return CompilationStatus.PASS   == compilationStatus; }
    public boolean isFailed() { return CompilationStatus.FAILED == compilationStatus; }
}
