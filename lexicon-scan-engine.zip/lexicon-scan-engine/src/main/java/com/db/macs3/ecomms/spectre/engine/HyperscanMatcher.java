package com.db.macs3.ecomms.spectre.engine;

import com.db.macs3.ecomms.spectre.model.TermMatch;
import com.gliwka.hyperscan.wrapper.Database;
import com.gliwka.hyperscan.wrapper.Match;
import com.gliwka.hyperscan.wrapper.Scanner;
import org.apache.spark.broadcast.Broadcast;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Executor-side Hyperscan scanning component.
 *
 * <h2>Lifecycle on each executor JVM</h2>
 * <p>This class is designed to run inside a Spark {@code MapPartitionsFunction}.
 * On each executor, it manages:
 * <ol>
 *   <li><b>Database cache</b> (static, JVM-level): Hyperscan {@link Database} objects
 *       are deserialized from the broadcast byte arrays on first use and cached in a
 *       static {@link ConcurrentHashMap}. This cache is shared across all Spark tasks
 *       running on the same executor JVM, so each .hdb file is deserialized at most
 *       once per executor regardless of how many tasks run there.</li>
 *   <li><b>Scanner management</b> (per-partition): Each call to {@link #scan(String, String, Broadcast)}
 *       creates a short-lived {@link Scanner}, allocates its scratch space,
 *       performs the scan, and closes the Scanner. Scanners hold native memory
 *       (via JNI) and must be closed promptly to avoid memory leaks.</li>
 * </ol>
 *
 * <h2>Thread safety</h2>
 * <p>{@link Database} objects are thread-safe for concurrent {@link Scanner#scan} calls
 * once loaded. The static cache uses {@link ConcurrentHashMap#computeIfAbsent} which
 * is atomic — only one thread will deserialize each database, even under concurrent
 * access from multiple tasks on the same executor.
 *
 * <h2>Why static?</h2>
 * <p>Spark tasks sharing an executor JVM share the same classloader and static fields.
 * By making {@code DB_CACHE} static, we ensure that a 200 MB .hdb file (for example)
 * is only deserialized once per executor, not once per Spark partition. For a cluster
 * with 50 executors and 200 partitions, this reduces deserialization work from 200×
 * to 50×, and eliminates 150 extra copies of the native database in native heap.
 *
 * <h2>Closing behaviour</h2>
 * <p>The Database cache is intentionally NOT closed at the end of each partition —
 * the cache contents should persist for the executor JVM lifetime. Only Scanner
 * objects (lightweight, per-scan) are closed after each scan.
 */
public class HyperscanMatcher implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final Logger log = LoggerFactory.getLogger(HyperscanMatcher.class);

    /**
     * Executor JVM-level cache of Hyperscan Database objects.
     *
     * <p><b>Key</b>: feature name (= .hdb file name without extension)
     * <b>Value</b>: deserialized Hyperscan Database
     *
     * <p>ConcurrentHashMap ensures thread safety. computeIfAbsent is atomic,
     * so exactly one thread will call Database.load() per feature name even
     * under concurrent partition processing.
     */
    private static final ConcurrentHashMap<String, Database> DB_CACHE =
            new ConcurrentHashMap<>(32);

    /**
     * Scans the given text against the Hyperscan database identified by featureName,
     * using the broadcast byte array to deserialize (and cache) the Database on first use.
     *
     * <p>Returns an empty list when:
     * <ul>
     *   <li>{@code text} is null or blank</li>
     *   <li>No .hdb bytes are available for {@code featureName} in the broadcast</li>
     *   <li>The scan produces no matches</li>
     * </ul>
     *
     * @param featureName      the lexicon feature whose .hdb should be scanned against
     * @param text             the text to scan (message body or attachment content)
     * @param broadcastHdbBytes Spark broadcast carrying featureName → raw .hdb bytes
     * @return list of matches in ascending start-index order, empty if none
     */
    public List<TermMatch> scan(String featureName,
                                 String text,
                                 Broadcast<Map<String, byte[]>> broadcastHdbBytes) {
        if (text == null || text.isBlank()) {
            log.trace("Skipping scan for '{}': text is null or blank", featureName);
            return List.of();
        }

        Database db = getOrLoadDatabase(featureName, broadcastHdbBytes);
        if (db == null) {
            // No HDB available — warning already logged by getOrLoadDatabase
            return List.of();
        }

        return performScan(featureName, db, text);
    }

    /**
     * Retrieves a cached Hyperscan Database, or deserializes it from the broadcast
     * bytes on first access.
     *
     * @param featureName      key for the DB_CACHE and broadcast map
     * @param broadcastHdbBytes the broadcast variable containing raw .hdb bytes
     * @return the Database, or null if no bytes exist for this featureName
     */
    private Database getOrLoadDatabase(String featureName,
                                        Broadcast<Map<String, byte[]>> broadcastHdbBytes) {
        // computeIfAbsent is atomic: only ONE thread deserializes per featureName
        return DB_CACHE.computeIfAbsent(featureName, name -> {
            Map<String, byte[]> hdbMap = broadcastHdbBytes.value();
            byte[] bytes = hdbMap.get(name);

            if (bytes == null || bytes.length == 0) {
                log.warn("No .hdb bytes found for feature '{}' — skipping scan", name);
                // We cannot store null in ConcurrentHashMap; use a sentinel approach:
                // Return null here and handle the ABSENT case in the computeIfAbsent caller.
                // ConcurrentHashMap will NOT cache a null return — good: next call retries.
                return null;
            }

            try {
                log.info("Deserializing Hyperscan DB for '{}' ({} KB) on executor",
                         name, bytes.length / 1024);
                Database database = Database.load(new ByteArrayInputStream(bytes));
                log.info("Hyperscan DB loaded and cached for '{}' — DB size: {} bytes",
                         name, database.getSize());
                return database;
            } catch (IOException e) {
                log.error("Failed to deserialize Hyperscan DB for '{}': {}", name, e.getMessage(), e);
                throw new RuntimeException("Failed to load Hyperscan database for feature: " + name, e);
            }
        });
    }

    /**
     * Performs the actual Hyperscan scan and converts raw {@link Match} objects
     * to {@link TermMatch} domain objects with delta calculation.
     *
     * <p>A new {@link Scanner} is created per call (per-text-segment). The Scanner
     * holds a native scratch buffer; it must be closed after use to release native
     * memory. We use try-with-resources for this.
     *
     * @param featureName label for logging
     * @param db          the Hyperscan Database to scan against
     * @param text        the text to scan
     * @return list of TermMatch objects in encounter order
     */
    private List<TermMatch> performScan(String featureName, Database db, String text) {
        List<TermMatch> results = new ArrayList<>();

        try (Scanner scanner = new Scanner()) {
            // allocScratch allocates native scratch memory sized for this specific db.
            // This is cheap compared to the scan itself but must not be skipped.
            scanner.allocScratch(db);

            List<Match> matches = scanner.scan(db, text);

            if (matches.isEmpty()) {
                log.trace("No matches for feature '{}' in text of length {}", featureName, text.length());
                return results;
            }

            log.debug("Feature '{}': {} raw matches in text of length {}",
                      featureName, matches.size(), text.length());

            // Calculate delta: the gap between the end of the previous match
            // and the start of the current match within this text segment.
            long previousMatchEnd = 0L;
            for (Match match : matches) {
                long start = match.getStartPosition();
                long end   = match.getEndPosition();
                int  exprId = match.getMatchedExpression() != null
                              ? match.getMatchedExpression().getId()
                              : -1;
                String matchedText = match.getMatchedString();

                long delta = results.isEmpty() ? 0L : (start - previousMatchEnd);
                results.add(TermMatch.of(exprId, matchedText, start, end, delta));
                previousMatchEnd = end;
            }

        } catch (Exception e) {
            log.error("Hyperscan scan error for feature '{}': {}", featureName, e.getMessage(), e);
            // Do not propagate: a scan failure for one feature should not fail
            // the entire partition. Log the error and return whatever was collected.
        }

        return results;
    }

    /**
     * Returns the current number of databases loaded in the executor-level cache.
     * Useful for monitoring and logging.
     *
     * @return count of cached Database objects
     */
    public static int cachedDatabaseCount() {
        return DB_CACHE.size();
    }

    /**
     * Clears the database cache. Should NOT be called in normal operation —
     * databases should remain cached for the executor JVM lifetime.
     * Provided for testing and exceptional cleanup scenarios only.
     */
    public static void clearCache() {
        DB_CACHE.clear();
        log.info("Hyperscan database cache cleared");
    }
}
