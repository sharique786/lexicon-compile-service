package com.db.macs3.ecomms.spectre.translator;

import java.util.List;

/**
 * Abstract syntax tree for a parsed lexicon term, produced by
 * {@link ExpressionParser} and consumed by {@link PatternCodeGenerator}.
 *
 * <p>Working with an explicit tree — rather than generating pattern
 * fragments directly while parsing, as the previous implementation did —
 * is what makes "brackets resolve first, then NEAR/FOLLOWEDBY/AND/OR" a
 * structural property of the code rather than something that has to be
 * gotten right by careful ordering of string operations. A node's children
 * are, by construction, exactly the fully-resolved contents of whatever
 * parentheses enclosed them; nesting depth in the tree mirrors nesting
 * depth in the source term exactly, at any depth.
 */
sealed interface Ast {

    /** {@code A OR B OR C} — alternation. */
    record Or(List<Ast> operands) implements Ast {}

    /** {@code A AND B AND C} — all operands must be present (enforced by scan-time post-filter). */
    record And(List<Ast> operands) implements Ast {}

    /**
     * {@code A AND NOT B} (and its chained form {@code A AND NOT B AND NOT C}).
     * {@code required} must be present; every entry in {@code excluded} must be absent.
     */
    record AndNot(Ast required, List<Ast> excluded) implements Ast {}

    /** {@code A NEAR{n} B} — bidirectional proximity. */
    record Near(Ast left, Ast right, int distance) implements Ast {}

    /** {@code A FOLLOWEDBY{n} B} — directional proximity, A before B. */
    record FollowedBy(Ast left, Ast right, int distance) implements Ast {}

    /** Standalone prefix {@code NOT X} / {@code !X} (outside of an AND NOT). */
    record Not(Ast operand) implements Ast {}

    /** A single unquoted word — may contain a {@code *} wildcard and/or a literal {@code ?}. */
    record Word(String text) implements Ast {}

    /**
     * Multiple unquoted words that appeared together inside one set of
     * parentheses with no operator between them, e.g. {@code (bomb this place)}
     * — a literal multi-word phrase. Each word is still wildcard-aware
     * (e.g. {@code (chimp* attack)} is valid).
     */
    record Phrase(List<String> words) implements Ast {}

    /** A double-quoted phrase — always literal; {@code *} and {@code ?} inside are NOT special. */
    record QuotedPhrase(String text) implements Ast {}
}
