package com.db.macs3.ecomms.spectre.translator;

import java.util.ArrayList;
import java.util.List;

/**
 * Walks an {@link Ast} and generates the Hyperscan PCRE pattern string,
 * accumulating flags and AND/AND-NOT operand metadata into a {@link ParseContext}.
 *
 * <h2>Word encoding is now a single pass (the direct fix for the wildcard bug)</h2>
 * <p>The previous implementation had three separate word-encoding methods —
 * {@code escapeSpecialChars}, {@code translateWildcard}, {@code convertMixedContent}
 * — selected by a chain of {@code if} checks in a specific order. A word
 * containing BOTH a wildcard AND a non-ASCII character (e.g. German
 * {@code verschwör*}) hit the non-ASCII branch first, which returned before
 * the wildcard branch was ever reached — the wildcard was left as a literal
 * {@code *} in the output pattern, which Hyperscan/PCRE then interprets as
 * "repeat the previous character zero or more times", producing a
 * dramatically different (and often invalid or oversized) pattern.
 * {@link #encodeWord} replaces all three with one codepoint-by-codepoint
 * scan that handles wildcard, literal {@code ?}, emoji, non-ASCII, and PCRE
 * metacharacter escaping uniformly, in one place — a word's script has no
 * bearing on whether its wildcard gets converted.
 *
 * <h2>{@code ?} is always literal</h2>
 * <p>Per the Natural-Language-term requirement, a bare {@code ?} (e.g.
 * {@code he?d}) is escaped to {@code \?} — treated as a literal
 * question-mark character to match, never as the PCRE "optional" quantifier.
 *
 * <h2>Quoted phrases escape {@code *} and {@code ?} too</h2>
 * <p>{@link #encodeQuotedPhrase} is deliberately a different, stricter pass
 * than {@link #encodeWord}: quotes signal "match this exactly", so a
 * {@code *} inside a quoted phrase is a literal asterisk to match, NOT a
 * wildcard — the opposite of {@code *} in a bare word.
 */
final class PatternCodeGenerator {

    /** PCRE metacharacters that always need escaping (excludes {@code *} and {@code ?}, handled specially). */
    private static final String PCRE_META = "\\.^$|+()[]{}<>";

    private PatternCodeGenerator() {}

    /**
     * Generates the Hyperscan pattern for {@code ast}, mutating {@code ctx}
     * with discovered flags and required/excluded operand metadata.
     */
    static String generate(Ast ast, ParseContext ctx) {
        return switch (ast) {
            case Ast.Or or -> generateOr(or, ctx);
            case Ast.And and -> generateAnd(and, ctx);
            case Ast.AndNot andNot -> generateAndNot(andNot, ctx);
            case Ast.Near near -> generateNear(near, ctx);
            case Ast.FollowedBy fb -> generateFollowedBy(fb, ctx);
            case Ast.Not not -> generateNot(not, ctx);
            case Ast.Word w -> encodeWord(w.text(), ctx);
            case Ast.Phrase p -> generatePhrase(p, ctx);
            case Ast.QuotedPhrase q -> encodeQuotedPhrase(q.text(), ctx);
        };
    }

    // ── Operator code generation ─────────────────────────────────────────────

    private static String generateOr(Ast.Or or, ParseContext ctx) {
        List<String> parts = new ArrayList<>(or.operands().size());
        for (Ast operand : or.operands()) {
            parts.add(generate(operand, ctx));
        }
        return "(?:" + String.join("|", parts) + ")";
    }

    /**
     * AND → {@code (?:A|B|C)} (OR pre-scan pattern) with DOTALL flag.
     * Hyperscan cannot express variable-length positive lookaheads, so the
     * OR pattern is what Hyperscan actually scans for; {@code requiresAndPostFilter}
     * plus each operand recorded via {@link ParseContext#addRequiredOperand}
     * tells the scan engine to verify ALL operands are present before alerting.
     */
    private static String generateAnd(Ast.And and, ParseContext ctx) {
        ctx.setHasAndOp();
        List<String> parts = new ArrayList<>(and.operands().size());
        for (Ast operand : and.operands()) {
            String pat = generate(operand, ctx);
            parts.add(pat);
            ctx.addRequiredOperand(pat);
        }
        return "(?:" + String.join("|", parts) + ")";
    }

    /**
     * AND NOT → returns the REQUIRED side's pattern as the Hyperscan scan
     * expression (same reasoning as AND: no negative lookbehind in Hyperscan).
     * Every excluded operand's pattern is generated and recorded via
     * {@link ParseContext#addExcludedOperand} — this is the fix for the gap
     * where the previous implementation parsed the NOT side "to validate
     * syntax and accumulate flags" but never actually kept its pattern
     * anywhere, so the scan engine had no way to enforce the exclusion at all.
     */
    private static String generateAndNot(Ast.AndNot andNot, ParseContext ctx) {
        ctx.setHasAndOp();
        String requiredPat = generate(andNot.required(), ctx);
        ctx.addRequiredOperand(requiredPat);
        for (Ast excluded : andNot.excluded()) {
            String exclPat = generate(excluded, ctx);
            ctx.addExcludedOperand(exclPat);
        }
        return requiredPat;
    }

    /** Standalone prefix NOT/! — returns the operand pattern; scan engine inverts the hit. */
    private static String generateNot(Ast.Not not, ParseContext ctx) {
        ctx.setHasAndOp();
        return generate(not.operand(), ctx);
    }

    private static String generateNear(Ast.Near near, ParseContext ctx) {
        String leftPat  = generate(near.left(), ctx);
        String rightPat = generate(near.right(), ctx);
        ctx.setHasProximityOp();
        MultiLanguagePatternBuilder.BuildResult r =
                MultiLanguagePatternBuilder.buildNear(leftPat, rightPat, near.distance());
        propagateProximityFlags(r, ctx);
        return r.pattern();
    }

    private static String generateFollowedBy(Ast.FollowedBy fb, ParseContext ctx) {
        String leftPat  = generate(fb.left(), ctx);
        String rightPat = generate(fb.right(), ctx);
        ctx.setHasProximityOp();
        MultiLanguagePatternBuilder.BuildResult r =
                MultiLanguagePatternBuilder.buildFollowedBy(leftPat, rightPat, fb.distance());
        propagateProximityFlags(r, ctx);
        return r.pattern();
    }

    private static void propagateProximityFlags(MultiLanguagePatternBuilder.BuildResult r, ParseContext ctx) {
        if ((r.recommendedHsFlags() & ParseContext.HS_FLAG_UTF8) != 0) {
            ctx.setNeedsUtf8();
        }
    }

    // ── Leaf code generation ──────────────────────────────────────────────────

    /**
     * Multiple bare words that appeared together inside one set of parens
     * with no operator between them, e.g. {@code (bomb this place)}. Each
     * word is independently wildcard/emoji/literal-? aware; words are joined
     * with a single literal space, matching the existing quoted-phrase
     * whitespace convention (exact single-space match, not a flexible
     * {@code \s+} gap — this is deliberately a phrase, not a proximity operator).
     */
    private static String generatePhrase(Ast.Phrase phrase, ParseContext ctx) {
        List<String> encoded = new ArrayList<>(phrase.words().size());
        for (String word : phrase.words()) {
            encoded.add(encodeWord(word, ctx));
        }
        return String.join(" ", encoded);
    }

    /**
     * Encodes one bare (unquoted) word into its PCRE fragment. Single
     * codepoint-by-codepoint pass — see class Javadoc for why this replaces
     * three separately-ordered methods from the previous implementation.
     */
    static String encodeWord(String word, ParseContext ctx) {
        StringBuilder patternBuilder = new StringBuilder(word.length() * 2);
        int charIndex = 0;
        while (charIndex < word.length()) {
            int codePoint = word.codePointAt(charIndex);
            int charCountForCodePoint = Character.charCount(codePoint);

            if (codePoint == '*') {
                patternBuilder.append("\\S*");
            } else if (codePoint == '?') {
                // Always literal — never a live PCRE quantifier (requirement:
                // '?' between words in a Natural Language term is literal text).
                patternBuilder.append("\\?");
            } else if (isEmojiCodePoint(codePoint)) {
                patternBuilder.append(String.format("\\x{%X}", codePoint));
                ctx.setNeedsUtf8();
            } else if (codePoint > 0x7F) {
                patternBuilder.appendCodePoint(codePoint); // literal non-ASCII; UTF8 flag handles matching
                ctx.setNeedsUtf8();
            } else {
                char asciiChar = (char) codePoint;
                if (PCRE_META.indexOf(asciiChar) >= 0) {
                    patternBuilder.append('\\');
                }
                patternBuilder.append(asciiChar);
            }
            charIndex += charCountForCodePoint;
        }
        return patternBuilder.toString();
    }

    /**
     * Encodes a double-quoted phrase's inner text. Unlike {@link #encodeWord},
     * {@code *} and {@code ?} are escaped as ordinary literal characters here
     * (never wildcard-expanded or left as live quantifiers) — quotes mean
     * "match this exactly".
     */
    static String encodeQuotedPhrase(String text, ParseContext ctx) {
        StringBuilder patternBuilder = new StringBuilder(text.length() * 2);
        int charIndex = 0;
        while (charIndex < text.length()) {
            int codePoint = text.codePointAt(charIndex);
            int charCountForCodePoint = Character.charCount(codePoint);

            if (isEmojiCodePoint(codePoint)) {
                patternBuilder.append(String.format("\\x{%X}", codePoint));
                ctx.setNeedsUtf8();
            } else if (codePoint > 0x7F) {
                patternBuilder.appendCodePoint(codePoint);
                ctx.setNeedsUtf8();
            } else {
                char asciiChar = (char) codePoint;
                if (PCRE_META.indexOf(asciiChar) >= 0 || asciiChar == '*' || asciiChar == '?') {
                    patternBuilder.append('\\');
                }
                patternBuilder.append(asciiChar);
            }
            charIndex += charCountForCodePoint;
        }
        return patternBuilder.toString();
    }

    /**
     * Returns {@code true} if the Unicode codepoint belongs to an emoji block.
     * Same coverage as the previous implementation (emoticons, symbols,
     * transport, flags, supplemental blocks).
     */
    static boolean isEmojiCodePoint(int codePoint) {
        return (codePoint >= 0x1F600 && codePoint <= 0x1F64F)
                || (codePoint >= 0x1F300 && codePoint <= 0x1F5FF)
                || (codePoint >= 0x1F680 && codePoint <= 0x1F6FF)
                || (codePoint >= 0x1F700 && codePoint <= 0x1F77F)
                || (codePoint >= 0x1F780 && codePoint <= 0x1F7FF)
                || (codePoint >= 0x1F800 && codePoint <= 0x1F8FF)
                || (codePoint >= 0x1F900 && codePoint <= 0x1F9FF)
                || (codePoint >= 0x1FA00 && codePoint <= 0x1FA6F)
                || (codePoint >= 0x1FA70 && codePoint <= 0x1FAFF)
                || (codePoint >= 0x2600  && codePoint <= 0x26FF)
                || (codePoint >= 0x2700  && codePoint <= 0x27BF)
                || (codePoint >= 0xFE00  && codePoint <= 0xFE0F)
                || (codePoint >= 0x1F1E0 && codePoint <= 0x1F1FF)
                || (codePoint >= 0x1F100 && codePoint <= 0x1F1FF);
    }
}
