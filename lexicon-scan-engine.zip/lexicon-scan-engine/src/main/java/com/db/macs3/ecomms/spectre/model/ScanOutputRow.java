package com.db.macs3.ecomms.spectre.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * One row in the {@code spectre-audit.lexicon_hit_summary} BigQuery output table.
 *
 * <p>Produced by {@link com.db.macs3.ecomms.spectre.engine.LexiconScanPartitionFunction}
 * and written by {@link com.db.macs3.ecomms.spectre.writer.BigQueryOutputWriter}.
 *
 * <p>Schema (all columns):
 * <pre>
 * message_id            STRING    NOT NULL
 * run_date              STRING    NOT NULL   (partition column, yyyy-MM-dd)
 * sent_date             STRING
 * policy_engine_id      STRING    NOT NULL
 * pipeline_exec_id      STRING    NOT NULL
 * feature_name          STRING    NOT NULL   (= .hdb file name without extension)
 * feature_type          STRING               (lexicon | Composite)
 * is_noise_reduction    BOOLEAN
 * feature_operator      STRING               (OR | AND | null)
 * lexicon_terms_hit     STRING               (comma-separated expression IDs that matched)
 * total_count_of_terms  INTEGER              (total expressions in the .hdb)
 * hit_count_of_terms    INTEGER              (number of expressions that matched)
 * hit_details           STRING               (JSON — see HitDetails structure)
 * process_ts            TIMESTAMP NOT NULL
 * </pre>
 */
public class ScanOutputRow implements Serializable {

    private static final long serialVersionUID = 1L;

    private String    messageId;
    private String    runDate;
    private String    sentDate;
    private String    policyEngineId;
    private String    pipelineExecId;
    private String    featureName;
    private String    featureType;
    private boolean   isNoiseReduction;
    private String    featureOperator;

    /** Comma-separated list of expression IDs (0-based) that produced at least one match. */
    private String    lexiconTermsHit;

    /** Total number of expressions compiled into the .hdb database. */
    private int       totalCountOfTerms;

    /** Number of distinct expressions that produced at least one match. */
    private int       hitCountOfTerms;

    /**
     * JSON string describing exactly WHERE each term matched in the message body
     * and each attachment.  Structure:
     * <pre>
     * {
     *   "msg": {
     *     "matches": [
     *       {"term_id": "...", "match_text": "...", "start_index": 0, "end_index": 3, "delta": 0}
     *     ]
     *   },
     *   "attachment-0": { "matches": [...] },
     *   "attachment-1": { "matches": [...] }
     * }
     * </pre>
     */
    private String    hitDetails;

    /** Wall-clock time the scan completed on the executor. */
    private Timestamp processTs;

    // ── No-arg constructor ────────────────────────────────────────────────────
    public ScanOutputRow() {}

    // ── Getters / Setters ─────────────────────────────────────────────────────

    public String    getMessageId()                 { return messageId; }
    public void      setMessageId(String v)         { this.messageId = v; }

    public String    getRunDate()                   { return runDate; }
    public void      setRunDate(String v)           { this.runDate = v; }

    public String    getSentDate()                  { return sentDate; }
    public void      setSentDate(String v)          { this.sentDate = v; }

    public String    getPolicyEngineId()            { return policyEngineId; }
    public void      setPolicyEngineId(String v)    { this.policyEngineId = v; }

    public String    getPipelineExecId()            { return pipelineExecId; }
    public void      setPipelineExecId(String v)    { this.pipelineExecId = v; }

    public String    getFeatureName()               { return featureName; }
    public void      setFeatureName(String v)       { this.featureName = v; }

    public String    getFeatureType()               { return featureType; }
    public void      setFeatureType(String v)       { this.featureType = v; }

    public boolean   isNoiseReduction()             { return isNoiseReduction; }
    public void      setNoiseReduction(boolean v)   { this.isNoiseReduction = v; }

    public String    getFeatureOperator()           { return featureOperator; }
    public void      setFeatureOperator(String v)   { this.featureOperator = v; }

    public String    getLexiconTermsHit()           { return lexiconTermsHit; }
    public void      setLexiconTermsHit(String v)   { this.lexiconTermsHit = v; }

    public int       getTotalCountOfTerms()         { return totalCountOfTerms; }
    public void      setTotalCountOfTerms(int v)    { this.totalCountOfTerms = v; }

    public int       getHitCountOfTerms()           { return hitCountOfTerms; }
    public void      setHitCountOfTerms(int v)      { this.hitCountOfTerms = v; }

    public String    getHitDetails()                { return hitDetails; }
    public void      setHitDetails(String v)        { this.hitDetails = v; }

    public Timestamp getProcessTs()                 { return processTs; }
    public void      setProcessTs(Timestamp v)      { this.processTs = v; }

    @Override
    public String toString() {
        return "ScanOutputRow{messageId='" + messageId +
               "', featureName='" + featureName +
               "', hitCount=" + hitCountOfTerms +
               "/" + totalCountOfTerms + '}';
    }
}
