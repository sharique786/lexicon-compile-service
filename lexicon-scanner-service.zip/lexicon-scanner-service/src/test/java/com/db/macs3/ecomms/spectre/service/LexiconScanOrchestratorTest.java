package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.client.LexiconCompileClient;
import com.db.macs3.ecomms.spectre.model.Models.CompiledTerm;
import com.db.macs3.ecomms.spectre.model.Models.CompileServiceResponse;
import com.db.macs3.ecomms.spectre.model.Models.MatchHighlight;
import com.db.macs3.ecomms.spectre.model.Models.RawMatch;
import com.db.macs3.ecomms.spectre.model.Models.ScanResponse;
import com.db.macs3.ecomms.spectre.model.Models.TermScanResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link LexiconScanOrchestrator}.
 *
 * <p>All three collaborators ({@link LexiconCompileClient}, {@link HyperscanScanService},
 * {@link MatchHighlightService}) are mocked with Mockito so tests run in isolation
 * without any network or Hyperscan native library calls.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("LexiconScanOrchestrator")
class LexiconScanOrchestratorTest {

    @Mock private LexiconCompileClient compileClient;
    @Mock private HyperscanScanService scanService;
    @Mock private MatchHighlightService highlightService;

    private LexiconScanOrchestrator orchestrator;

    @BeforeEach
    void setUp() {
        orchestrator = new LexiconScanOrchestrator(compileClient, scanService, highlightService);
    }

    // ── Happy path ────────────────────────────────────────────────────────────

    @Test
    @DisplayName("scan() returns SUCCESS status with matched term count")
    void scan_happyPath_successStatus() {
        String message = "insider trading is illegal";

        when(compileClient.compile(anyList(), anyString())).thenReturn(passResponse());
        when(scanService.compileAndScan(anyList(), eq(message)))
                .thenReturn(List.of(new RawMatch(0, 7, 0)));
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), eq(message)))
                .thenReturn(Map.of(0, List.of(new MatchHighlight(0, 7, "insider"))));
        when(highlightService.buildHighlightedHtml(eq(message), anyList()))
                .thenReturn("<mark>insider</mark> trading is illegal");

        ScanResponse response = orchestrator.scan(List.of("insider AND trading"), message, "test");

        assertThat(response.status()).isEqualTo("SUCCESS");
        assertThat(response.totalTerms()).isEqualTo(1);
        assertThat(response.matchedTerms()).isEqualTo(1);
        assertThat(response.hasMatches()).isTrue();
        assertThat(response.htmlHighlightedMessage()).contains("<mark>");
    }

    @Test
    @DisplayName("scan() returns zero matchedTerms when nothing matches")
    void scan_noMatch_zeroMatchedTerms() {
        String message = "hello world";

        when(compileClient.compile(anyList(), anyString())).thenReturn(passResponse());
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), eq(message)))
                .thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList()))
                .thenReturn("hello world");

        ScanResponse response = orchestrator.scan(List.of("insider AND trading"), message, null);

        assertThat(response.matchedTerms()).isEqualTo(0);
        assertThat(response.hasMatches()).isFalse();
    }

    @Test
    @DisplayName("scan() counts failedTerms correctly when compile service reports failures")
    void scan_withFailedTerms_countsFailures() {
        String message = "some message";

        when(compileClient.compile(anyList(), anyString())).thenReturn(mixedResponse());
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), eq(message)))
                .thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList()))
                .thenReturn("some message");

        ScanResponse response = orchestrator.scan(List.of("good term", "bad term"), message, null);

        assertThat(response.failedTerms()).isEqualTo(1);
        assertThat(response.warnings()).isNotEmpty();
        assertThat(response.warnings().get(0)).contains("failed pattern compilation");
    }

    @Test
    @DisplayName("scan() produces TermScanResult with FAILED status for failed compile terms")
    void scan_failedTerm_termResultStatusIsFailed() {
        String message = "some message";

        when(compileClient.compile(anyList(), anyString())).thenReturn(failedResponse());
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), eq(message)))
                .thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList()))
                .thenReturn("some message");

        ScanResponse response = orchestrator.scan(List.of("bad term"), message, null);

        assertThat(response.termResults()).hasSize(1);
        TermScanResult tr = response.termResults().get(0);
        assertThat(tr.compilationStatus()).isEqualTo("FAILED");
        assertThat(tr.hasMatches()).isFalse();
        assertThat(tr.compilationError()).isNotBlank();
    }

    @Test
    @DisplayName("scan() adds postFilterNote for requiresAndPostFilter terms")
    void scan_andTerm_hasPostFilterNote() {
        String message = "insider information shared";

        when(compileClient.compile(anyList(), anyString())).thenReturn(andTermResponse());
        when(scanService.compileAndScan(anyList(), eq(message)))
                .thenReturn(List.of(new RawMatch(0, 7, 0)));
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), eq(message)))
                .thenReturn(Map.of(0, List.of(new MatchHighlight(0, 7, "insider"))));
        when(highlightService.buildHighlightedHtml(eq(message), anyList()))
                .thenReturn("<mark>insider</mark> information shared");

        ScanResponse response = orchestrator.scan(List.of("insider AND information"), message, null);

        TermScanResult tr = response.termResults().get(0);
        assertThat(tr.requiresAndPostFilter()).isTrue();
        assertThat(tr.postFilterNote()).isNotBlank();
        assertThat(tr.postFilterNote()).contains("AND/NOT semantics");
    }

    @Test
    @DisplayName("scan() returns ERROR status when compile client throws exception")
    void scan_compileClientException_returnsErrorStatus() {
        when(compileClient.compile(anyList(), anyString()))
                .thenThrow(new LexiconCompileClient.LexiconCompileException("Service unavailable"));

        ScanResponse response = orchestrator.scan(List.of("insider AND trading"),
                "some message", null);

        assertThat(response.status()).isEqualTo("ERROR");
        assertThat(response.errorMessage()).contains("Service unavailable");
    }

    @Test
    @DisplayName("scan() calls compile client exactly once with the provided term list")
    void scan_callsCompileClientOnce() {
        String message = "test";
        when(compileClient.compile(anyList(), anyString())).thenReturn(passResponse());
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), eq(message))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        orchestrator.scan(List.of("insider AND trading"), message, "my-rule");

        verify(compileClient).compile(List.of("insider AND trading"), "my-rule");
    }

    @Test
    @DisplayName("scan() skips Hyperscan when there are no PASS terms")
    void scan_noPassTerms_skipsScanService() {
        String message = "test";
        when(compileClient.compile(anyList(), anyString())).thenReturn(failedResponse());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), eq(message))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        orchestrator.scan(List.of("bad term"), message, null);

        // scanService should NOT be called when there are no PASS terms
        verify(scanService, org.mockito.Mockito.never()).compileAndScan(anyList(), anyString());
    }

    @Test
    @DisplayName("scan() includes scanDurationMs in the response")
    void scan_includesScanDuration() {
        String message = "test";
        when(compileClient.compile(anyList(), anyString())).thenReturn(passResponse());
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), eq(message))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        ScanResponse response = orchestrator.scan(List.of("insider AND trading"), message, null);

        assertThat(response.scanDurationMs()).isGreaterThanOrEqualTo(0);
    }

    // ── Compile response fixtures ─────────────────────────────────────────────

    private CompileServiceResponse passResponse() {
        return new CompileServiceResponse("test-rule", 1, 1, 0, false, List.of(
                new CompileServiceResponse.TermResult(
                        "test-rule::1", "insider AND trading", "Compliance Scan",
                        "PASS", "(?:insider|trading)", 3, true, null, null, null)
        ));
    }

    private CompileServiceResponse andTermResponse() {
        return new CompileServiceResponse("test-rule", 1, 1, 0, false, List.of(
                new CompileServiceResponse.TermResult(
                        "test-rule::1", "insider AND information", "Compliance Scan",
                        "PASS", "(?:insider|information)", 3, true, null, null, null)
        ));
    }

    private CompileServiceResponse failedResponse() {
        return new CompileServiceResponse("test-rule", 1, 0, 1, true, List.of(
                new CompileServiceResponse.TermResult(
                        "test-rule::1", "bad term", "Compliance Scan",
                        "FAILED", null, 0, false, "Hyperscan compile error", null, null)
        ));
    }

    private CompileServiceResponse mixedResponse() {
        return new CompileServiceResponse("test-rule", 2, 1, 1, true, List.of(
                new CompileServiceResponse.TermResult(
                        "test-rule::1", "good term", "Compliance Scan",
                        "PASS", "(?:good|term)", 1, false, null, null, null),
                new CompileServiceResponse.TermResult(
                        "test-rule::2", "bad term", "Compliance Scan",
                        "FAILED", null, 0, false, "Compile error", null, null)
        ));
    }
}
