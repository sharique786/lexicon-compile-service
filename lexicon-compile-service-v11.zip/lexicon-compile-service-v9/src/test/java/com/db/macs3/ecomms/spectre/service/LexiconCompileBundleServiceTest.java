package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.hyperscan.HyperscanCombinationHandler;
import com.db.macs3.ecomms.spectre.hyperscan.HyperscanCompiler;
import com.db.macs3.ecomms.spectre.model.CompilationStatus;
import com.db.macs3.ecomms.spectre.model.CompileResponse;
import com.db.macs3.ecomms.spectre.model.TermCompilationResult;
import com.db.macs3.ecomms.spectre.model.TermType;
import com.db.macs3.ecomms.spectre.model.TypedCompileRequest;
import com.db.macs3.ecomms.spectre.translator.TermSyntaxTranslator;
import com.gliwka.hyperscan.wrapper.Database;
import com.gliwka.hyperscan.wrapper.Match;
import com.gliwka.hyperscan.wrapper.Scanner;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Unit tests for {@link LexiconCompileBundleService} — the {@code /compile/bundle}
 * endpoint's orchestration logic (Natural Language/Regex branching + combined database).
 *
 * <p>No Spring context — uses real {@code TermSyntaxTranslator} and
 * {@code HyperscanCompiler} directly, exactly like {@link LexiconCompileServiceTest}.
 *
 * <h2>The current id scheme: a term's reportable expression is ALWAYS its own term number</h2>
 * <p>Every PASS term's {@code hyperscanExpressionId} — whether it compiles as
 * a single plain pattern or needs a QUIET/COMBINATION structure (AND NOT
 * and/or decomposition) — is always its own term number. Every auxiliary
 * QUIET sub-expression a combination needs is assigned an ALLOCATED id
 * instead (never the term number) — see {@link HyperscanCombinationHandler}
 * class Javadoc. This is different from an earlier version of this class,
 * where the required side's single pattern used the term number and the
 * combination itself got an allocated id — meaning the reportable id used
 * to vary by term complexity. It no longer does.
 */
@DisplayName("LexiconCompileBundleService Tests")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class LexiconCompileBundleServiceTest {

    private LexiconCompileBundleService bundleService;

    @BeforeEach
    void setUp() {
        var compiler   = new HyperscanCompiler();
        var translator = new TermSyntaxTranslator(compiler);
        compiler.selfTest();
        var compileService = new LexiconCompileService(translator, compiler, new SimpleMeterRegistry());
        var handler        = new HyperscanCombinationHandler(compiler);
        bundleService = new LexiconCompileBundleService(compileService, compiler, handler, new SimpleMeterRegistry());
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private TypedCompileRequest request(String ruleName, TermType termType, TermSpec... specs) {
        var req = new TypedCompileRequest();
        req.setRequestId(UUID.randomUUID().toString());
        req.setLexiconRuleName(ruleName);
        req.setTermType(termType);
        List<TypedCompileRequest.TermInput> terms = new ArrayList<>();
        for (int i = 0; i < specs.length; i++) {
            terms.add(new TypedCompileRequest.TermInput(
                    ruleName + "::" + (i + 1), specs[i].description));
        }
        req.setTerms(terms);
        return req;
    }

    // Convenience: Natural Language or Regex helpers just carry description
    private record TermSpec(String description) {}
    private static TermSpec term(String desc) { return new TermSpec(desc); }

    /** Shorthand: all-Natural-Language request */
    private TypedCompileRequest naturalLanguage(String ruleName, String... descs) {
        TermSpec[] specs = new TermSpec[descs.length];
        for (int i = 0; i < descs.length; i++) specs[i] = term(descs[i]);
        return request(ruleName, TermType.NATURAL_LANGUAGE, specs);
    }

    /** Shorthand: all-Regex request */
    private TypedCompileRequest regex(String ruleName, String... descs) {
        TermSpec[] specs = new TermSpec[descs.length];
        for (int i = 0; i < descs.length; i++) specs[i] = term(descs[i]);
        return request(ruleName, TermType.REGEX, specs);
    }

    /** Scans {@code text} against {@code db} and returns the matched expression ids. */
    private List<Integer> scanMatchesIds(Database db, String text) {
        List<Integer> ids = new ArrayList<>();
        try (Scanner scanner = new Scanner()) {
            scanner.allocScratch(db);
            for (Match match : scanner.scan(db, text)) {
                ids.add(match.getMatchedExpression().getId());
            }
        }
        return ids;
    }

    private static final String NESTED_TOO_COMPLEX_TERM =
            "(((wordA word B OR wordC* wordD OR wordE* wordF OR wordG) FOLLOWEDBY{4} "
            + "(wordH* OR wordI wordJ* wordK OR wordL* wordM OR wordN)) FOLLOWEDBY{4} "
            + "(wordO* OR wordP* wordQ OR wordR* wordS OR wordT))";

    // ── Spec example from the requirements ────────────────────────────────────

    @Test @Order(1)
    @DisplayName("Spec example: Natural Language request → PASS, combined DB built, request_id/termType echoed")
    void specExampleNaturalLanguage() {
        var req = naturalLanguage("lexicon_research_1",
                "(manipulate) NEAR{5} ((price) OR (spread) OR (stock))");
        String sentRequestId = req.getRequestId();

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isTrue();
        assertThat(bundle.hyperscanDatabaseBytes()).isNotEmpty();
        assertThat(bundle.databaseNote()).isNull();
        assertThat(bundle.jsonResponse().requestId()).isEqualTo(sentRequestId);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Natural Language");
    }

    @Test @Order(2)
    @DisplayName("Spec example: Regex request → PASS, combined DB built, request_id/termType echoed")
    void specExampleRegex() {
        var req = regex("lexicon_research_1", "(?:price|spread|stock)");
        String sentRequestId = req.getRequestId();

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isTrue();
        assertThat(bundle.jsonResponse().requestId()).isEqualTo(sentRequestId);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Regex");
    }

    // ── JSON shape ──────────────────────────────────────────────────────────

    @Test @Order(10)
    @DisplayName("JSON response: request_id and termType present; hyperscanVersion absent (bundle-specific shape)")
    void jsonShapeMatchesCompile() {
        var req = naturalLanguage("shape_test", "price OR spread");
        var bundle = bundleService.buildBundle(req);

        CompileResponse json = bundle.jsonResponse();
        assertThat(json.lexiconRuleName()).isEqualTo("shape_test");
        assertThat(json.engineMode()).isEqualTo("HYPERSCAN_NATIVE");
        assertThat(json.requestId()).isEqualTo(req.getRequestId());
        assertThat(json.termType()).isEqualTo("Natural Language");
        assertThat(json.hyperscanVersion()).isNull();
        assertThat(json.results()).hasSize(1);
        assertThat(json.results().get(0).termId()).isEqualTo("shape_test::1");
    }

    // ── Natural Language term branch ──────────────────────────────────────────────────

    @Test @Order(20)
    @DisplayName("Natural Language term: NEAR{5} translated exactly like /compile")
    void naturalLanguageTermTranslated() {
        var req = naturalLanguage("std_test", "(manipulate) NEAR{5} (price)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.translatedPattern()).hasSize(1);
        assertThat(result.translatedPattern().get(0)).contains("manipulate").contains("price");
        assertThat(result.translatedPattern().get(0)).contains("\\s+\\S+");
    }

    @Test @Order(21)
    @DisplayName("Natural Language term with invalid syntax → FAILED with translationError, no DB entry")
    void naturalLanguageTermTranslationFailure() {
        var req = naturalLanguage("std_fail_test", "NEAR{5} (price)"); // missing left operand
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.FAILED);
    }

    // ── Regex term branch ────────────────────────────────────────────────────────

    @Test @Order(30)
    @DisplayName("Regex term: raw PCRE compiled verbatim, NOT passed through the translator")
    void regexTermCompiledVerbatim() {
        var req = regex("nlt_test", "(?:price|spread|stock)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.translatedPattern()).hasSize(1);
        assertThat(result.translatedPattern().get(0)).isEqualTo("(?:price|spread|stock)");
    }

    @Test @Order(31)
    @DisplayName("Regex term with invalid regex syntax → FAILED with Hyperscan errorLog")
    void regexTermInvalidRegex() {
        var req = regex("nlt_invalid_test", "[unclosed");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.FAILED);
        assertThat(result.errorLog()).isNotBlank();
        assertThat(result.requiresExclusionCheck()).isFalse();
    }

    @Test @Order(32)
    @DisplayName("Regex term with non-Latin script gets UTF8/UCP flags automatically")
    void regexTermNonLatinFlags() {
        var req = regex("nlt_korean_test", "(?:내부자|거래)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.hyperscanFlags() & 32).isEqualTo(32); // UTF8
        assertThat(result.hyperscanFlags() & 64).isEqualTo(64); // UCP
    }

    @Test @Order(33)
    @DisplayName("Regex term with operator-language syntax (not a real regex) is treated literally, never translated")
    void regexTermNeverTranslated() {
        var req = regex("nlt_literal_test", "price NEAR.{5} stock");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.translatedPattern()).hasSize(1);
        assertThat(result.translatedPattern().get(0)).isEqualTo("price NEAR.{5} stock");
    }

    // ── All-Regex and all-Natural-Language scenarios ────────────────────────────────────

    @Test @Order(40)
    @DisplayName("All-Regex request: every term compiled verbatim, DB contains all")
    void allRegexRequest() {
        var req = regex("all_nlt_test",
                "(?:price|spread)", "(?:insider|tip)", "manipulat\\w+");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(3);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Regex");
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(41)
    @DisplayName("All-Natural Language request: behaves identically to /compile for every term")
    void allNaturalLanguageRequest() {
        var req = naturalLanguage("all_std_test",
                "price OR spread",
                "don't FOLLOWEDBY{3} compliance",
                "insider AND announcement");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(3);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Natural Language");
        assertThat(bundle.hasDatabase()).isTrue();
    }

    // ── Mixed pass/fail scenarios ──────────────────────────────

    @Test @Order(50)
    @DisplayName("Mixed PASS/FAILED within a Regex request: combined DB built from PASS subset only, with id gaps")
    void mixedPassFailedDbBuiltFromPassOnly() throws IOException {
        var req = regex("mixed_test",
                "(?:price|spread)",     // term number 1 — PASS
                "[unclosed",             // term number 2 — FAILED
                "(?:insider|tip)");      // term number 3 — PASS

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(2);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().results().get(1).compilationStatus())
                .isEqualTo(CompilationStatus.FAILED);
        assertThat(bundle.hasDatabase()).isTrue();

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            assertThat(scanMatchesIds(db, "price")).contains(1);
            assertThat(scanMatchesIds(db, "insider")).contains(3);
        }
    }

    @Test @Order(51)
    @DisplayName("Zero PASS terms: no database built, clear explanatory note returned")
    void zeroPassTermsNoDatabase() {
        var req = regex("zero_pass_test", "[unclosed", "[also_unclosed");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isFalse();
        assertThat(bundle.hyperscanDatabaseBytes()).isNull();
        assertThat(bundle.databaseNote()).isNotBlank();
        assertThat(bundle.databaseNote()).contains("zero terms reached PASS");
    }

    // ── Combined database integrity (round-trip load + scan) ───────────────────

    @Test @Order(60)
    @DisplayName("Combined DB round-trip: save() then load() reconstructs a working multi-pattern database")
    void combinedDatabaseRoundTrip() throws IOException {
        var req = regex("roundtrip_test",
                "(?:price|spread|stock)",
                "(?:insider|tip)");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.hasDatabase()).isTrue();

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            List<Integer> priceMatches   = scanMatchesIds(db, "the price went up");
            List<Integer> insiderMatches = scanMatchesIds(db, "an insider tip was shared");

            assertThat(priceMatches).contains(1);
            assertThat(insiderMatches).contains(2);
        }
    }

    @Test @Order(61)
    @DisplayName("Expression id equals the term's PARSED TERM NUMBER (from termId's '::n' suffix), " +
                 "not its array position in the request")
    void expressionIdEqualsTermNumber() throws IOException {
        var req = regex("id_mapping_test",
                "alpha_pattern",   // termId "id_mapping_test::1" -> term number 1
                "beta_pattern",    // termId "id_mapping_test::2" -> term number 2
                "gamma_pattern");  // termId "id_mapping_test::3" -> term number 3
        var bundle = bundleService.buildBundle(req);

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            assertThat(scanMatchesIds(db, "alpha_pattern")).containsExactly(1);
            assertThat(scanMatchesIds(db, "beta_pattern")).containsExactly(2);
            assertThat(scanMatchesIds(db, "gamma_pattern")).containsExactly(3);
        }
    }

    // ── AND NOT: native Hyperscan logical combination ─────────────────

    @Test @Order(70)
    @DisplayName("AND NOT term: hyperscanExpressionId is the term's OWN term number — not an allocated " +
                 "auxiliary id — this is what makes the .hdb file self-sufficient with no JSON needed")
    void andNotTerm_getsOwnTermNumberAsExpressionId() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE,
                term("((don't forward) AND NOT (compliance OR legal))"));

        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.requiresExclusionCheck()).isTrue();
        assertThat(result.translatedPattern()).hasSize(1);
        assertThat(result.translatedPattern().get(0)).isEqualTo("don't forward");
        assertThat(result.exclusionPattern()).hasSize(1);
        assertThat(result.exclusionPattern().get(0)).contains("compliance").contains("legal");

        // termId "test-rule::1" -> term number 1. The combination (the term's reportable
        // expression) is ALWAYS the term number — required/excluded QUIET sub-expressions
        // get allocated ids instead (2, 3 for this single-term request).
        assertThat(result.hyperscanExpressionId()).isEqualTo(1);

        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(71)
    @DisplayName("A plain term (no AND NOT) gets hyperscanExpressionId equal to its own term number, " +
                 "not its array position")
    void plainTerm_getsOwnTermNumberAsExpressionId() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE, term("insider OR trading"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.requiresExclusionCheck()).isFalse();
        assertThat(result.hyperscanExpressionId()).isEqualTo(1);
    }

    @Test @Order(72)
    @DisplayName("Plain AND (no NOT) also gets its own term number as expression id — self-contained, no combination needed")
    void plainAndTerm_selfContained_ownTermNumberAsExpressionId() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE, term("price AND rigging"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.requiresExclusionCheck()).isFalse();
        assertThat(result.hyperscanExpressionId()).isEqualTo(1);
    }

    @Test @Order(73)
    @DisplayName("Mixed request: plain terms and an AND NOT term ALL get their own term number as expression id")
    void mixedRequest_correctIdsForEachTerm() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE,
                term("insider OR trading"),          // term number 1, plain
                term("price AND rigging"),            // term number 2, plain (self-contained AND)
                term("confidential AND NOT public")); // term number 3, AND NOT

        var bundle = bundleService.buildBundle(req);
        var results = bundle.jsonResponse().results();

        assertThat(results).allMatch(TermCompilationResult::isPass);
        // Every PASS term's reportable id is its own term number — always, regardless
        // of whether it needed a combination. No allocated auxiliary id is ever reportable.
        assertThat(results.get(0).hyperscanExpressionId()).isEqualTo(1);
        assertThat(results.get(1).hyperscanExpressionId()).isEqualTo(2);
        assertThat(results.get(2).hyperscanExpressionId()).isEqualTo(3);
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(74)
    @DisplayName("FAILED terms have no hyperscanExpressionId — nothing was compiled into the database for them")
    void failedTerm_hasNoExpressionId() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE, term("\"unclosed quote"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.isFailed()).isTrue();
        assertThat(result.hyperscanExpressionId()).isNull();
    }

    @Test @Order(75)
    @DisplayName("Chained AND NOT (A AND NOT B AND NOT C) still produces exactly one combination, at the term's own number")
    void chainedAndNot_stillOneCombinationId() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE,
                term("(a) AND NOT (b) AND NOT (c)"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.requiresExclusionCheck()).isTrue();
        assertThat(result.hyperscanExpressionId()).isEqualTo(1);
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(76)
    @DisplayName("REGEX-type terms never require exclusion checks — no combination expression involved")
    void regexTerm_neverRequiresExclusionCheck() {
        var req = request("test-rule", TermType.REGEX, term("(?:insider|trading)"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.requiresExclusionCheck()).isFalse();
        assertThat(result.hyperscanExpressionId()).isEqualTo(1);
    }

    // ── trackMatchPosition: SOM_LEFTMOST opt-out for "Pattern too large" mitigation ──

    @Test @Order(80)
    @DisplayName("trackMatchPosition omitted (default): combined database still compiles and matches correctly")
    void trackMatchPositionOmitted_stillWorks() throws IOException {
        var req = regex("som_default_test", "(?:price|spread|stock)");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.hasDatabase()).isTrue();
        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            assertThat(scanMatchesIds(db, "the price went up")).containsExactly(1);
        }
    }

    @Test @Order(81)
    @DisplayName("trackMatchPosition=false: combined database still compiles and matches correctly, " +
                 "without SOM_LEFTMOST")
    void trackMatchPositionFalse_stillCompilesAndMatches() throws IOException {
        var req = new TypedCompileRequest();
        req.setRequestId("som-opt-out-test");
        req.setLexiconRuleName("som_opt_out_test");
        req.setTermType(TermType.REGEX);
        req.setTrackMatchPosition(false);
        req.setTerms(List.of(new TypedCompileRequest.TermInput("t::1", "(?:price|spread|stock)")));

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.hasDatabase()).isTrue();
        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            assertThat(scanMatchesIds(db, "the price went up")).containsExactly(1);
        }
    }

    @Test @Order(82)
    @DisplayName("trackMatchPosition=false with an AND NOT term: still correctly excludes/matches")
    void trackMatchPositionFalse_andNotStillCorrect() throws IOException {
        var req = new TypedCompileRequest();
        req.setRequestId("som-opt-out-andnot-test");
        req.setLexiconRuleName("som_opt_out_andnot_test");
        req.setTermType(TermType.NATURAL_LANGUAGE);
        req.setTrackMatchPosition(false);
        req.setTerms(List.of(new TypedCompileRequest.TermInput(
                "t::1", "((don't forward) AND NOT (compliance OR legal))")));

        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.isPass()).isTrue();
        assertThat(bundle.hasDatabase()).isTrue();
        // termId "t::1" -> term number 1 -> hyperscanExpressionId is always the term number.
        assertThat(result.hyperscanExpressionId()).isEqualTo(1);

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            // Required pattern present, exclusion ALSO present -> combination (id 1) must NOT fire.
            assertThat(scanMatchesIds(db, "Please don't forward this message to compliance or legal"))
                    .doesNotContain(1);
        }
    }

    // ── Decomposition: over-complex terms compiled as leaves + native COMBINATION ──

    @Test @Order(90)
    @DisplayName("DECOMPOSITION: a term too complex for one pattern compiles as independent QUIET " +
                 "leaves plus one native COMBINATION expression, instead of failing")
    void decomposedTerm_compilesAsLeavesPlusCombination() throws IOException {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE, term(NESTED_TOO_COMPLEX_TERM));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.isPass()).isTrue();
        assertThat(result.translatedPattern()).hasSize(3); // decomposed into 3 leaves
        assertThat(bundle.hasDatabase()).isTrue();
        assertThat(result.hyperscanExpressionId()).isEqualTo(1); // still the term's own number
    }

    @Test @Order(91)
    @DisplayName("DECOMPOSITION + AND NOT, excluded side decomposed: the combination formula applies " +
                 "De Morgan's law correctly — OR of negated leaves, not AND of negated leaves")
    void decomposedExcludedSide_appliesDeMorgansLawCorrectly() throws IOException {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE,
                term("insider AND NOT (" + NESTED_TOO_COMPLEX_TERM + ")"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.isPass()).isTrue();
        assertThat(result.translatedPattern()).hasSize(1);   // required side simple
        assertThat(result.exclusionPattern()).hasSize(3);     // excluded side decomposed
        assertThat(bundle.hasDatabase()).isTrue();

        // Semantic correctness, not just structural: "insider" present but the WHOLE excluded
        // condition (all 3 decomposed leaves) also present -> must NOT match, since AND NOT's
        // excluded side is "all these leaves found", and this message contains all of them.
        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            String messageContainingEverything =
                    "insider wordG wordN wordT"; // matches required + all 3 excluded leaves
            assertThat(scanMatchesIds(db, messageContainingEverything))
                    .as("required present AND all excluded leaves present -> must NOT match")
                    .doesNotContain(result.hyperscanExpressionId());

            String messageMissingOneExcludedLeaf =
                    "insider wordG wordN"; // required + 2 of 3 excluded leaves (missing wordT-side)
            assertThat(scanMatchesIds(db, messageMissingOneExcludedLeaf))
                    .as("required present AND only SOME excluded leaves present (not all) -> MUST match, "
                        + "since the excluded condition (ALL leaves) was not fully satisfied")
                    .contains(result.hyperscanExpressionId());
        }
    }

    @Test @Order(92)
    @DisplayName("DECOMPOSITION + AND NOT, required side decomposed: combination ANDs every required " +
                 "leaf then negates the (non-decomposed) excluded id")
    void decomposedRequiredSide_withSimpleExcluded() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE,
                term("(" + NESTED_TOO_COMPLEX_TERM + ") AND NOT excluded"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.isPass()).isTrue();
        assertThat(result.translatedPattern()).hasSize(3);
        assertThat(result.exclusionPattern()).hasSize(1);
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(93)
    @DisplayName("DECOMPOSITION on both sides of an AND NOT term compiles successfully")
    void decomposedBothSides() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE,
                term("(" + NESTED_TOO_COMPLEX_TERM + ") AND NOT ("
                        + NESTED_TOO_COMPLEX_TERM.replace("word", "term") + ")"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.isPass()).isTrue();
        assertThat(result.translatedPattern()).hasSize(3);
        assertThat(result.exclusionPattern()).hasSize(3);
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(94)
    @DisplayName("A simple AND NOT term's exclusionPattern is unaffected by the decomposition feature — " +
                 "still a single-entry list with the pre-decomposition pattern text")
    void simpleAndNot_unaffectedByDecompositionFeature() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE,
                term("((don't forward) AND NOT (compliance OR legal))"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.translatedPattern()).hasSize(1);
        assertThat(result.exclusionPattern()).hasSize(1);
        assertThat(result.exclusionPattern().get(0)).isEqualTo("(?:(?:compliance|legal))");
    }

    // ── HyperscanCombinationHandler-specific: the COMBINATION/QUIET flag constraint ──

    @Test @Order(100)
    @DisplayName("A combination expression's flags are EXACTLY {COMBINATION} — never CASELESS/UTF8/UCP/" +
                 "DOTALL/SOM_LEFTMOST mixed in, matching Hyperscan's own constraint on combination expressions")
    void combinationExpressionFlagsAreExactlyCombination() throws IOException {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE, term("insider AND NOT compliance"));
        bundleService.buildBundle(req);

        List<com.gliwka.hyperscan.wrapper.Expression> compiled = Database.lastCompiledExpressions;
        var combo = compiled.stream().filter(e -> e.getId() == 1).findFirst().orElseThrow();
        assertThat(combo.getFlags()).hasSize(1);
        assertThat(combo.getFlags().toString()).contains("COMBINATION");
    }

    @Test @Order(101)
    @DisplayName("Every QUIET sub-expression a combination needs is assigned an id from the allocated " +
                 "range, never the term's own term number")
    void quietSubExpressionsNeverUseTermNumber() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE, term("insider AND NOT compliance"));
        bundleService.buildBundle(req);

        List<com.gliwka.hyperscan.wrapper.Expression> compiled = Database.lastCompiledExpressions;
        // termId "test-rule::1" -> term number 1; the combination (id 1) is the only
        // non-QUIET expression. Every OTHER expression must be QUIET and NOT use id 1.
        assertThat(compiled.stream()
                .filter(e -> e.getId() != 1)
                .allMatch(e -> e.getFlags().toString().contains("QUIET")))
                .isTrue();
        assertThat(compiled.stream().filter(e -> e.getId() == 1).count()).isEqualTo(1);
    }

    // ── Term id validation: malformed / duplicate term numbers rejected up front ──

    @Test @Order(110)
    @DisplayName("A termId not ending in '::<n>' is rejected with InvalidTermIdException before any term is compiled")
    void malformedTermIdRejected() {
        var req = new TypedCompileRequest();
        req.setRequestId(UUID.randomUUID().toString());
        req.setLexiconRuleName("bad_id_rule");
        req.setTermType(TermType.NATURAL_LANGUAGE);
        req.setTerms(List.of(new TypedCompileRequest.TermInput("not_a_valid_term_id", "price OR spread")));

        assertThatThrownBy(() -> bundleService.buildBundle(req))
                .isInstanceOf(com.db.macs3.ecomms.spectre.model.InvalidTermIdException.class)
                .hasMessageContaining("not_a_valid_term_id");
    }

    @Test @Order(111)
    @DisplayName("Two terms sharing the same term number are rejected with InvalidTermIdException, " +
                 "since they would collide at the same Hyperscan expression id")
    void duplicateTermNumberRejected() {
        var req = new TypedCompileRequest();
        req.setRequestId(UUID.randomUUID().toString());
        req.setLexiconRuleName("dup_id_rule");
        req.setTermType(TermType.NATURAL_LANGUAGE);
        req.setTerms(List.of(
                new TypedCompileRequest.TermInput("dup_id_rule::1", "price OR spread"),
                new TypedCompileRequest.TermInput("dup_id_rule::1", "insider OR tip"))); // same number "1"

        assertThatThrownBy(() -> bundleService.buildBundle(req))
                .isInstanceOf(com.db.macs3.ecomms.spectre.model.InvalidTermIdException.class)
                .hasMessageContaining("dup_id_rule::1");
    }

    @Test @Order(112)
    @DisplayName("A termId ending in a non-numeric suffix after '::' is rejected, not silently treated as 0")
    void nonNumericSuffixRejected() {
        var req = new TypedCompileRequest();
        req.setRequestId(UUID.randomUUID().toString());
        req.setLexiconRuleName("bad_suffix_rule");
        req.setTermType(TermType.NATURAL_LANGUAGE);
        req.setTerms(List.of(new TypedCompileRequest.TermInput("bad_suffix_rule::abc", "price OR spread")));

        assertThatThrownBy(() -> bundleService.buildBundle(req))
                .isInstanceOf(com.db.macs3.ecomms.spectre.model.InvalidTermIdException.class);
    }

    @Test @Order(113)
    @DisplayName("Valid, non-sequential, sparse term numbers (e.g. 5 and 100) are accepted and each " +
                 "gets its own number as expression id, with the allocator starting safely beyond both")
    void sparseTermNumbersAccepted() {
        var req = new TypedCompileRequest();
        req.setRequestId(UUID.randomUUID().toString());
        req.setLexiconRuleName("sparse_rule");
        req.setTermType(TermType.NATURAL_LANGUAGE);
        req.setTerms(List.of(
                new TypedCompileRequest.TermInput("sparse_rule::5", "price OR spread"),
                new TypedCompileRequest.TermInput("sparse_rule::100", "insider AND NOT disclosed")));

        var bundle = bundleService.buildBundle(req);
        var results = bundle.jsonResponse().results();

        assertThat(results).allMatch(TermCompilationResult::isPass);
        assertThat(results.get(0).hyperscanExpressionId()).isEqualTo(5);
        assertThat(results.get(1).hyperscanExpressionId()).isEqualTo(100); // AND NOT term still uses its own number
        assertThat(bundle.hasDatabase()).isTrue();
    }
}
