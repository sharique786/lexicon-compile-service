package com.db.macs3.ecomms.spectre.engine;

import com.db.macs3.ecomms.spectre.model.FeatureDecisionRow;
import com.db.macs3.ecomms.spectre.model.TermMatch;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link NoiseReductionEvaluator}.
 *
 * <p>Verifies all six cells of the decision matrix:
 * <ul>
 *   <li>NR OR  — any match  → skip standard</li>
 *   <li>NR OR  — none match → process standard</li>
 *   <li>NR AND — all match  → skip standard</li>
 *   <li>NR AND — partial    → process standard</li>
 *   <li>NR AND — none       → process standard</li>
 *   <li>No NR features      → process standard</li>
 * </ul>
 */
@DisplayName("NoiseReductionEvaluator Tests")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class NoiseReductionEvaluatorTest {

    private NoiseReductionEvaluator evaluator;

    @BeforeEach
    void setUp() {
        evaluator = new NoiseReductionEvaluator();
    }

    // ── Helper factories ──────────────────────────────────────────────────────

    private FeatureDecisionRow nrFeature(String name, String operator) {
        return FeatureDecisionRow.of(
                "proc-1", "msg-1", "2026-06-25", "2026-06-25",
                "lexicon", 1L, name, operator, true, null);
    }

    private Map<String, List<TermMatch>> hits(String... featureNames) {
        Map<String, List<TermMatch>> results = new HashMap<>();
        for (String name : featureNames) {
            results.put(name, List.of(TermMatch.of(0, "bomb", 14, 17)));
        }
        return results;
    }

    private Map<String, List<TermMatch>> noHits(String... featureNames) {
        Map<String, List<TermMatch>> results = new HashMap<>();
        for (String name : featureNames) {
            results.put(name, Collections.emptyList());
        }
        return results;
    }

    // ── Empty / null guard ─────────────────────────────────────────────────────

    @Test @Order(1)
    @DisplayName("No NR features → shouldSkipStandard = false")
    void noNrFeatures_neverSkip() {
        assertThat(evaluator.shouldSkipStandardFeatures(Collections.emptyList(), Map.of()))
                .isFalse();
        assertThat(evaluator.shouldSkipStandardFeatures(null, Map.of()))
                .isFalse();
    }

    // ── OR operator ───────────────────────────────────────────────────────────

    @Test @Order(10)
    @DisplayName("NR OR — ANY feature matches → skip standard")
    void nrOr_anyMatch_skip() {
        List<FeatureDecisionRow> nrFeatures = List.of(
                nrFeature("noise_1", "OR"),
                nrFeature("noise_2", "OR")
        );
        // Only noise_1 matches
        Map<String, List<TermMatch>> results = hits("noise_1");
        results.put("noise_2", Collections.emptyList());

        assertThat(evaluator.shouldSkipStandardFeatures(nrFeatures, results)).isTrue();
    }

    @Test @Order(11)
    @DisplayName("NR OR — ALL features match → skip standard")
    void nrOr_allMatch_skip() {
        List<FeatureDecisionRow> nrFeatures = List.of(
                nrFeature("noise_1", "OR"),
                nrFeature("noise_2", "OR")
        );
        assertThat(evaluator.shouldSkipStandardFeatures(nrFeatures, hits("noise_1", "noise_2")))
                .isTrue();
    }

    @Test @Order(12)
    @DisplayName("NR OR — NONE match → process standard")
    void nrOr_noneMatch_doNotSkip() {
        List<FeatureDecisionRow> nrFeatures = List.of(
                nrFeature("noise_1", "OR"),
                nrFeature("noise_2", "OR")
        );
        assertThat(evaluator.shouldSkipStandardFeatures(nrFeatures, noHits("noise_1", "noise_2")))
                .isFalse();
    }

    // ── AND operator ──────────────────────────────────────────────────────────

    @Test @Order(20)
    @DisplayName("NR AND — ALL features match → skip standard")
    void nrAnd_allMatch_skip() {
        List<FeatureDecisionRow> nrFeatures = List.of(
                nrFeature("noise_1", "AND"),
                nrFeature("noise_2", "AND"),
                nrFeature("noise_3", "AND")
        );
        assertThat(evaluator.shouldSkipStandardFeatures(nrFeatures, hits("noise_1", "noise_2", "noise_3")))
                .isTrue();
    }

    @Test @Order(21)
    @DisplayName("NR AND — PARTIAL match (not all) → process standard")
    void nrAnd_partialMatch_doNotSkip() {
        List<FeatureDecisionRow> nrFeatures = List.of(
                nrFeature("noise_1", "AND"),
                nrFeature("noise_2", "AND")
        );
        // Only noise_1 matches
        Map<String, List<TermMatch>> results = hits("noise_1");
        results.put("noise_2", Collections.emptyList());

        assertThat(evaluator.shouldSkipStandardFeatures(nrFeatures, results)).isFalse();
    }

    @Test @Order(22)
    @DisplayName("NR AND — NONE match → process standard")
    void nrAnd_noneMatch_doNotSkip() {
        List<FeatureDecisionRow> nrFeatures = List.of(
                nrFeature("noise_1", "AND"),
                nrFeature("noise_2", "AND")
        );
        assertThat(evaluator.shouldSkipStandardFeatures(nrFeatures, noHits("noise_1", "noise_2")))
                .isFalse();
    }

    // ── Single NR feature (edge case) ─────────────────────────────────────────

    @Test @Order(30)
    @DisplayName("Single NR feature with match → skip standard (regardless of operator)")
    void singleNrFeature_withMatch_skip() {
        List<FeatureDecisionRow> nrFeatures = List.of(nrFeature("noise_1", "OR"));
        assertThat(evaluator.shouldSkipStandardFeatures(nrFeatures, hits("noise_1"))).isTrue();
    }

    @Test @Order(31)
    @DisplayName("Single NR feature with no match → do not skip")
    void singleNrFeature_noMatch_doNotSkip() {
        List<FeatureDecisionRow> nrFeatures = List.of(nrFeature("noise_1", "OR"));
        assertThat(evaluator.shouldSkipStandardFeatures(nrFeatures, noHits("noise_1"))).isFalse();
    }

    // ── resolveOperator ───────────────────────────────────────────────────────

    @Test @Order(40)
    @DisplayName("resolveOperator returns OR for OR features")
    void resolveOperator_or() {
        assertThat(evaluator.resolveOperator(List.of(nrFeature("f1", "OR"), nrFeature("f2", "OR"))))
                .isEqualTo("OR");
    }

    @Test @Order(41)
    @DisplayName("resolveOperator returns AND for AND features")
    void resolveOperator_and() {
        assertThat(evaluator.resolveOperator(List.of(nrFeature("f1", "AND"))))
                .isEqualTo("AND");
    }

    @Test @Order(42)
    @DisplayName("resolveOperator defaults to OR when operator is null/blank")
    void resolveOperator_defaultsToOr() {
        assertThat(evaluator.resolveOperator(List.of(nrFeature("f1", null), nrFeature("f2", ""))))
                .isEqualTo("OR");
    }

    @Test @Order(43)
    @DisplayName("resolveOperator handles null/empty list with OR default")
    void resolveOperator_emptyList() {
        assertThat(evaluator.resolveOperator(Collections.emptyList())).isEqualTo("OR");
        assertThat(evaluator.resolveOperator(null)).isEqualTo("OR");
    }

    // ── featureHasMatch ───────────────────────────────────────────────────────

    @Test @Order(50)
    @DisplayName("featureHasMatch returns true when matches list is non-empty")
    void featureHasMatch_returnsTrue() {
        assertThat(evaluator.featureHasMatch("f1", hits("f1"))).isTrue();
    }

    @Test @Order(51)
    @DisplayName("featureHasMatch returns false when matches list is empty")
    void featureHasMatch_returnsFalse() {
        assertThat(evaluator.featureHasMatch("f1", noHits("f1"))).isFalse();
    }

    @Test @Order(52)
    @DisplayName("featureHasMatch returns false when feature is not in results map")
    void featureHasMatch_featureNotInMap() {
        assertThat(evaluator.featureHasMatch("missing", Map.of())).isFalse();
    }

    // ── countMatchedFeatures ──────────────────────────────────────────────────

    @Test @Order(60)
    @DisplayName("countMatchedFeatures counts only features with at least one match")
    void countMatchedFeatures() {
        List<FeatureDecisionRow> features = List.of(
                nrFeature("f1", "OR"),
                nrFeature("f2", "OR"),
                nrFeature("f3", "OR")
        );
        Map<String, List<TermMatch>> results = hits("f1", "f3");
        results.put("f2", Collections.emptyList());

        assertThat(evaluator.countMatchedFeatures(features, results)).isEqualTo(2);
    }

    // ── Parameterized matrix table validation ──────────────────────────────────

    @ParameterizedTest(name = "[{index}] op={0} allMatch={1} anyMatch={2} → skip={3}")
    @CsvSource({
        "OR,  true,  true,  true",   // OR — all match → skip
        "OR,  false, true,  true",   // OR — any match → skip
        "OR,  false, false, false",  // OR — none match → no skip
        "AND, true,  true,  true",   // AND — all match → skip
        "AND, false, true,  false",  // AND — partial → no skip
        "AND, false, false, false"   // AND — none → no skip
    })
    @Order(70)
    void decisionMatrixParameterized(String operator, boolean allMatch, boolean anyMatch,
                                      boolean expectedSkip) {
        List<FeatureDecisionRow> nrFeatures = List.of(
                nrFeature("f1", operator),
                nrFeature("f2", operator)
        );

        Map<String, List<TermMatch>> results = new HashMap<>();
        if (allMatch) {
            results = hits("f1", "f2");
        } else if (anyMatch) {
            results.put("f1", List.of(TermMatch.of(0, "test", 0, 3)));
            results.put("f2", Collections.emptyList());
        } else {
            results = noHits("f1", "f2");
        }

        assertThat(evaluator.shouldSkipStandardFeatures(nrFeatures, results))
                .isEqualTo(expectedSkip);
    }
}
