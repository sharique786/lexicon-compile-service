package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.model.Models.CompiledTerm;
import com.db.macs3.ecomms.spectre.model.Models.MatchHighlight;
import com.db.macs3.ecomms.spectre.model.Models.RawMatch;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link MatchHighlightService}.
 */
@DisplayName("MatchHighlightService")
class MatchHighlightServiceTest {

    private MatchHighlightService service;

    @BeforeEach
    void setUp() {
        service = new MatchHighlightService();
    }

    // ── groupMatchesByTerm ────────────────────────────────────────────────────

    @Test
    @DisplayName("groups raw matches by expression index correctly")
    void groupMatchesByTerm_groupsCorrectly() {
        String message = "insider trading is illegal";
        byte[] bytes = message.getBytes(StandardCharsets.UTF_8);

        List<CompiledTerm> terms = List.of(
                term(0, "(?:insider)", 1),
                term(1, "(?:trading)", 1));

        // "insider" = chars 0-7, "trading" = chars 8-15 (byte positions same for ASCII)
        List<RawMatch> raw = List.of(
                new RawMatch(0, 7, 0),   // insider, term 0
                new RawMatch(8, 15, 1)); // trading, term 1

        Map<Integer, List<MatchHighlight>> result =
                service.groupMatchesByTerm(raw, terms, message);

        assertThat(result).containsKeys(0, 1);
        assertThat(result.get(0).get(0).matchedText()).isEqualTo("insider");
        assertThat(result.get(1).get(0).matchedText()).isEqualTo("trading");
    }

    @Test
    @DisplayName("empty raw matches returns empty map")
    void groupMatchesByTerm_emptyMatches_emptyMap() {
        Map<Integer, List<MatchHighlight>> result =
                service.groupMatchesByTerm(List.of(), List.of(), "some text");
        assertThat(result).isEmpty();
    }

    // ── buildHighlightedHtml ─────────────────────────────────────────────────

    @Test
    @DisplayName("no matches returns HTML-escaped plain message")
    void buildHighlightedHtml_noMatches_returnsEscapedText() {
        String result = service.buildHighlightedHtml("Hello & World <test>", List.of());
        assertThat(result)
                .isEqualTo("Hello &amp; World &lt;test&gt;")
                .doesNotContain("<mark");
    }

    @Test
    @DisplayName("single match wraps matched text in <mark> with class 'lex-match'")
    void buildHighlightedHtml_singleMatch_wrapsInMark() {
        String message = "insider bought shares";
        MatchHighlight match = new MatchHighlight(0, 7, "insider");

        String html = service.buildHighlightedHtml(message, List.of(match));

        assertThat(html)
                .startsWith("<mark class=\"lex-match\">insider</mark>")
                .endsWith("bought shares");
    }

    @Test
    @DisplayName("match in the middle of text — before and after parts are HTML-escaped")
    void buildHighlightedHtml_matchInMiddle_correctBoundaries() {
        String message = "The insider bought <shares>.";
        MatchHighlight match = new MatchHighlight(4, 11, "insider");

        String html = service.buildHighlightedHtml(message, List.of(match));

        assertThat(html)
                .startsWith("The ")
                .contains("<mark class=\"lex-match\">insider</mark>")
                .contains("bought &lt;shares&gt;.");
    }

    @Test
    @DisplayName("multiple non-overlapping matches are each wrapped in <mark>")
    void buildHighlightedHtml_multipleNonOverlappingMatches() {
        String message = "insider trading is illegal";
        List<MatchHighlight> matches = List.of(
                new MatchHighlight(0, 7, "insider"),
                new MatchHighlight(8, 15, "trading"));

        String html = service.buildHighlightedHtml(message, matches);

        assertThat(html)
                .contains("<mark class=\"lex-match\">insider</mark>")
                .contains("<mark class=\"lex-match\">trading</mark>")
                .doesNotContain("insider trading"); // the plain version should not appear
    }

    @Test
    @DisplayName("overlapping matches are merged — single <mark> span covers both")
    void buildHighlightedHtml_overlappingMatches_merged() {
        String message = "front running scheme";
        // Match 1: "front running" (0-13), Match 2: "running" (6-13) — overlapping
        List<MatchHighlight> matches = List.of(
                new MatchHighlight(0, 13, "front running"),
                new MatchHighlight(6, 13, "running"));

        String html = service.buildHighlightedHtml(message, matches);

        // Should not have nested marks
        assertThat(html).doesNotContain("<mark class=\"lex-match\"><mark");
        assertThat(html).contains("<mark class=\"lex-match\">");
    }

    @Test
    @DisplayName("match at end of text — no trailing content after mark")
    void buildHighlightedHtml_matchAtEnd() {
        String message = "shares trade";
        MatchHighlight match = new MatchHighlight(7, 12, "trade");

        String html = service.buildHighlightedHtml(message, List.of(match));

        assertThat(html)
                .startsWith("shares ")
                .endsWith("<mark class=\"lex-match\">trade</mark>");
    }

    @Test
    @DisplayName("HTML-special characters inside matched text are escaped")
    void buildHighlightedHtml_htmlSpecialCharsInMatch() {
        String message = "Term <insider> here";
        MatchHighlight match = new MatchHighlight(5, 14, "<insider>");

        String html = service.buildHighlightedHtml(message, List.of(match));

        assertThat(html).contains("<mark class=\"lex-match\">&lt;insider&gt;</mark>");
    }

    @Test
    @DisplayName("Korean multi-byte text — match on Korean word produces correct <mark>")
    void buildHighlightedHtml_koreanText_correctHighlight() {
        String message = "내부자 거래 정보";
        // "내부자" = chars 0-2 (3 chars, 9 bytes); "거래" = chars 4-5
        MatchHighlight match = new MatchHighlight(0, 3, "내부자");

        String html = service.buildHighlightedHtml(message, List.of(match));

        assertThat(html)
                .contains("<mark class=\"lex-match\">내부자</mark>")
                .contains(" 거래 정보");
    }

    @Test
    @DisplayName("Arabic text — match on Arabic word produces correct <mark>")
    void buildHighlightedHtml_arabicText_correctHighlight() {
        String message = "معلومات سرية";
        MatchHighlight match = new MatchHighlight(0, 8, "معلومات");

        String html = service.buildHighlightedHtml(message, List.of(match));

        assertThat(html).contains("<mark class=\"lex-match\">معلومات</mark>");
    }

    @Test
    @DisplayName("emoji match — emoji is correctly enclosed in <mark>")
    void buildHighlightedHtml_emojiMatch() {
        String message = "buy 💰 now";
        MatchHighlight match = new MatchHighlight(4, 6, "💰"); // emoji is 2 Java chars (surrogate pair)

        String html = service.buildHighlightedHtml(message, List.of(match));

        assertThat(html)
                .contains("<mark class=\"lex-match\">💰</mark>")
                .startsWith("buy ");
    }

    @Test
    @DisplayName("message is exactly one match — entire message is wrapped")
    void buildHighlightedHtml_wholeMessageMatch() {
        String message = "insider";
        MatchHighlight match = new MatchHighlight(0, 7, "insider");

        String html = service.buildHighlightedHtml(message, List.of(match));

        assertThat(html).isEqualTo("<mark class=\"lex-match\">insider</mark>");
    }

    // ── Private helper ────────────────────────────────────────────────────────

    private CompiledTerm term(int idx, String pattern, int flags) {
        return new CompiledTerm("t::" + idx, "desc-" + idx, pattern, flags, false, idx);
    }
}
