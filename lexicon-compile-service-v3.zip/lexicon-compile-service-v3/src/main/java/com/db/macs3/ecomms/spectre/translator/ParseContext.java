package com.db.macs3.ecomms.spectre.translator;

import java.util.ArrayList;
import java.util.List;

/**
 * Mutable context passed through {@link PatternCodeGenerator} while walking
 * one term's {@link Ast}. Accumulates flags and AND/AND-NOT metadata
 * discovered along the way.
 *
 * <ul>
 *   <li>{@code hasAndOp}       — set when AND/AND NOT/NOT is found → needs HS_FLAG_DOTALL</li>
 *   <li>{@code hasProximityOp} — set when NEAR/FOLLOWEDBY is found → needs HS_FLAG_DOTALL
 *       (multi-line messages: gap must cross newlines)</li>
 *   <li>{@code needsUtf8}      — set when any non-ASCII char is found → needs HS_FLAG_UTF8|UCP</li>
 *   <li>{@code requiredOperands} — patterns that MUST all be present (from AND, and the
 *       positive side of AND NOT) — for scan-time post-filter use</li>
 *   <li>{@code excludedOperands} — patterns that MUST NOT be present (from the NOT side(s)
 *       of AND NOT) — for scan-time post-filter use</li>
 * </ul>
 *
 * <h2>Why required and excluded are now separate lists</h2>
 * <p>The previous implementation had one {@code andOperands} list. For plain
 * AND that was correct (every operand IS required). For AND NOT, though, the
 * NOT-side pattern was parsed only "to validate syntax and accumulate flags"
 * and never actually recorded anywhere — meaning the translator's output
 * carried NO information about what text should trigger exclusion. A scan
 * engine consuming the old output had no way to enforce the NOT half of AND
 * NOT at all. Splitting the lists fixes that: both halves of AND NOT are now
 * present in the result, correctly labelled.
 */
class ParseContext {

    /** HS_FLAG_CASELESS (1) — always applied. */
    static final int HS_FLAG_CASELESS = 1;
    /** HS_FLAG_DOTALL (2) — dot matches newlines; needed for AND/NOT and NEAR/FOLLOWEDBY gaps. */
    static final int HS_FLAG_DOTALL   = 2;
    /** HS_FLAG_UTF8 (32) — treat pattern as UTF-8; needed for non-ASCII content. */
    static final int HS_FLAG_UTF8     = 32;
    /** HS_FLAG_UCP (64) — use Unicode character properties; applied alongside UTF8. */
    static final int HS_FLAG_UCP      = 64;

    private boolean hasAndOp       = false;
    private boolean hasProximityOp = false;
    private boolean needsUtf8      = false;
    private final List<String> requiredOperands = new ArrayList<>();
    private final List<String> excludedOperands = new ArrayList<>();

    /** Mark that an AND / AND NOT / NOT operator was encountered. */
    void setHasAndOp()                    { this.hasAndOp       = true; }

    /** Mark that a NEAR{n} or FOLLOWEDBY{n} operator was encountered. */
    void setHasProximityOp()              { this.hasProximityOp = true; }

    /** Mark that a non-ASCII character was encountered. */
    void setNeedsUtf8()                   { this.needsUtf8      = true; }

    /** Record one pattern that must be PRESENT for the term to match (from AND). */
    void addRequiredOperand(String pattern) { requiredOperands.add(pattern); }

    /** Record one pattern that must be ABSENT for the term to match (from AND NOT). */
    void addExcludedOperand(String pattern) { excludedOperands.add(pattern); }

    boolean isHasAndOp()                  { return hasAndOp; }
    boolean isHasProximityOp()            { return hasProximityOp; }
    boolean isNeedsUtf8()                 { return needsUtf8; }

    /** @return true when AND/AND-NOT/NOT was used (caller should apply post-filter). */
    boolean requiresAndPostFilter()       { return hasAndOp; }

    /** @return immutable copy of required (AND) operand patterns. */
    List<String> getRequiredOperands()    { return List.copyOf(requiredOperands); }

    /** @return immutable copy of excluded (AND NOT) operand patterns. */
    List<String> getExcludedOperands()    { return List.copyOf(excludedOperands); }

    /**
     * Computes the Hyperscan flag bitmask from accumulated context.
     *
     * <ul>
     *   <li>CASELESS (1)  — always</li>
     *   <li>DOTALL   (2)  — if AND/NOT used, OR if NEAR/FOLLOWEDBY used
     *       (gap must span line breaks in multi-line messages)</li>
     *   <li>UTF8    (32)  — if non-ASCII present</li>
     *   <li>UCP     (64)  — alongside UTF8 (makes \\s/\\S honour Unicode,
     *       critical for Arabic, Korean, CJK, Hebrew)</li>
     * </ul>
     */
    int computeFlags() {
        int flags = HS_FLAG_CASELESS;
        if (hasAndOp || hasProximityOp) { flags |= HS_FLAG_DOTALL; }
        if (needsUtf8)                  { flags |= HS_FLAG_UTF8 | HS_FLAG_UCP; }
        return flags;
    }
}
