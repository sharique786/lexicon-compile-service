package com.db.macs3.ecomms.spectre.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.Instant;
import java.util.List;

/**
 * Shared domain models for the Lexicon Scanner Service.
 *
 * <h2>Request models</h2>
 * <ul>
 *   <li>{@link ScanApiRequest} — JSON body for the REST API</li>
 * </ul>
 *
 * <h2>Lexicon Compile Service wire models</h2>
 * <ul>
 *   <li>{@link CompileServiceRequest} / {@link CompileServiceRequest.TermInput}</li>
 *   <li>{@link CompileServiceResponse} / {@link CompileServiceResponse.TermResult}</li>
 * </ul>
 *
 * <h2>Internal pipeline models</h2>
 * <ul>
 *   <li>{@link CompiledTerm}   — a term that compiled successfully, ready for Hyperscan</li>
 *   <li>{@link RawMatch}       — raw Hyperscan match (byte-offset based)</li>
 *   <li>{@link MatchHighlight} — a single match region mapped to char indices</li>
 *   <li>{@link TermScanResult} — aggregated result for one lexicon term</li>
 *   <li>{@link ScanResponse}   — the full response returned to the UI / caller</li>
 * </ul>
 */
public final class Models {

    private Models() {}

    // ══════════════════════════════════════════════════════════════════════════
    // API Request
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * JSON body accepted by {@code POST /api/scan/json}.
     * Multipart form data uses {@code POST /api/scan} with individual fields.
     *
     * @param inputMode   how lexicon terms are supplied ({@code TERMS} or {@code CSV})
     * @param termType    how the term(s) should be interpreted ({@code NATURAL_LANGUAGE} or
     *                    {@code REGEX}); defaults to {@code NATURAL_LANGUAGE} when blank —
     *                    see {@link TermType#fromString(String)}
     * @param messageMode how the message is supplied ({@code TEXT} or {@code FILE})
     * @param terms       newline-separated term descriptions (when inputMode=TERMS)
     * @param csvContent  raw CSV text content (when inputMode=CSV, for JSON requests)
     * @param messageText raw message text (when messageMode=TEXT)
     * @param ruleName    optional rule / session name for the compile request
     * @param disclaimerInputMode how disclaimer text is supplied ({@code NONE}, {@code TEXT}, or {@code CSV});
     *                            defaults to {@code NONE} — see {@link com.db.macs3.ecomms.spectre.model.DisclaimerSource}
     * @param disclaimers          newline-separated disclaimer texts (when disclaimerInputMode=TEXT)
     * @param disclaimerCsvContent raw CSV text content for disclaimers (when disclaimerInputMode=CSV, JSON callers only)
     */
    public record ScanApiRequest(
            String inputMode,
            String termType,
            String messageMode,
            String terms,
            String csvContent,
            String messageText,
            String ruleName,
            String disclaimerInputMode,
            String disclaimers,
            String disclaimerCsvContent
    ) {}

    // ══════════════════════════════════════════════════════════════════════════
    // Lexicon Compile Service wire models
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Request body sent to the Lexicon Compile Service.
     *
     * @param lexiconRuleName logical name for this compilation session
     * @param terms           list of term inputs to compile
     */
    public record CompileServiceRequest(
            String lexiconRuleName,
            List<TermInput> terms
    ) {

        /**
         * One term to compile.
         *
         * @param termId          unique identifier, e.g. {@code scanner::1}
         * @param termDescription the raw operator expression, e.g. {@code insider AND trading}
         * @param riskDriverName  risk category label, e.g. {@code Market Abuse}
         */
        public record TermInput(
                String termId,
                String termDescription,
                String riskDriverName
        ) {}
    }

    /**
     * Full response from the Lexicon Compile Service.
     *
     * <p>Annotated {@code ignoreUnknown = true} because the Compile Service's
     * response has grown new fields over time (e.g. {@code request_id},
     * {@code termType} on the bundle endpoint) — this client only needs the
     * fields declared below and must not break when the upstream service adds more.
     *
     * @param lexiconRuleName rule name echoed from the request
     * @param totalTerms      total number of terms submitted
     * @param passCount       number that compiled successfully
     * @param failedCount     number that failed compilation or translation
     * @param hasFailures     convenience flag — true when failedCount &gt; 0
     * @param results         per-term compilation outcomes
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CompileServiceResponse(
            String lexiconRuleName,
            int totalTerms,
            int passCount,
            int failedCount,
            boolean hasFailures,
            List<TermResult> results
    ) {

        /**
         * Compilation outcome for one term.
         *
         * <p>Field names match the Lexicon Compile Service's current
         * ({@code TermCompilationResult}) response exactly — {@code hsFlags} /
         * {@code requiresAndPostFilter} (this client's previous field names)
         * silently deserialized to {@code 0} / {@code false} once the Compile
         * Service moved to {@code hyperscanFlags} / {@code requiresExclusionCheck}
         * (see the two-pattern AND NOT contract below), because
         * {@code @JsonIgnoreProperties(ignoreUnknown = true)} only protects
         * against the compile service adding fields — it does nothing when a
         * field this client expects gets RENAMED upstream. That silent
         * mismatch is what made AND NOT terms behave as if they had no
         * exclusion at all: {@code exclusionPattern} was never captured, so a
         * term like {@code "schlechter AND NOT (Kein schlechter Preis)"}
         * matched on "schlechter" alone, with the "Kein schlechter Preis"
         * exclusion silently ignored.
         *
         * @param termId                 echoed from the request
         * @param termDescription        echoed from the request
         * @param compilationStatus      {@code "PASS"} or {@code "FAILED"}
         * @param translatedPattern      the REQUIRED side's Hyperscan PCRE pattern (null when FAILED)
         * @param hyperscanFlags         bitmask: 1=CASELESS, 32=UTF8, 64=UCP
         * @param requiresExclusionCheck true for AND NOT terms — {@code exclusionPattern}
         *                               must also be checked; see class Javadoc
         * @param exclusionPattern       independently Hyperscan-valid pattern that must NOT
         *                               match the same message; non-null iff requiresExclusionCheck
         * @param errorLog               Hyperscan compile error (null when PASS)
         * @param translationError       translator error (null when PASS)
         * @param compiledAt             timestamp of compilation
         */
        @JsonIgnoreProperties(ignoreUnknown = true)
        public record TermResult(
                String termId,
                String termDescription,
                String compilationStatus,
                String translatedPattern,
                int hyperscanFlags,
                boolean requiresExclusionCheck,
                String exclusionPattern,
                String errorLog,
                String translationError,
                Instant compiledAt
        ) {
            /** Returns true when this term compiled successfully and has a usable pattern. */
            public boolean isPass() {
                return "PASS".equalsIgnoreCase(compilationStatus);
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Internal pipeline models
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * The result of {@link com.db.macs3.ecomms.spectre.service.HtmlStrippingService#strip}:
     * the original text, the HTML-stripped/whitespace-collapsed text that
     * Hyperscan actually scans, and the index mapping between them.
     *
     * <p>{@code strippedToOriginalIndex[j]} gives the character index in
     * {@link #originalText} that produced the character at index {@code j}
     * in {@link #strippedText}. See {@link #mapSpanToOriginal} for converting
     * a matched span from stripped-text coordinates to original-text coordinates.
     *
     * @param originalText            the message exactly as supplied by the user
     * @param strippedText            HTML-stripped, whitespace-collapsed text (what Hyperscan scans)
     * @param strippedToOriginalIndex per-character offset map, length == strippedText.length()
     */
    public record StrippedMessage(
            String originalText,
            String strippedText,
            int[] strippedToOriginalIndex
    ) {

        /**
         * Maps a {@code [strippedStart, strippedEnd)} span (as reported by
         * Hyperscan against {@link #strippedText}) to the corresponding
         * {@code [originalStart, originalEnd)} span in {@link #originalText}.
         *
         * <p>Convention: {@code originalEnd} is exclusive — one past the
         * original index of the span's last stripped character — matching
         * ordinary Java substring semantics.
         *
         * @param strippedStart start index into {@link #strippedText}, inclusive
         * @param strippedEnd   end index into {@link #strippedText}, exclusive
         * @return a two-element array {@code [originalStart, originalEnd]}
         */
        public int[] mapSpanToOriginal(int strippedStart, int strippedEnd) {
            if (strippedToOriginalIndex.length == 0 || strippedStart >= strippedEnd) {
                return new int[]{0, 0};
            }
            int safeStart = Math.max(0, Math.min(strippedStart, strippedToOriginalIndex.length - 1));
            int safeEnd   = Math.max(safeStart + 1, Math.min(strippedEnd, strippedToOriginalIndex.length));
            int originalStart = strippedToOriginalIndex[safeStart];
            int originalEnd   = strippedToOriginalIndex[safeEnd - 1] + 1;
            return new int[]{originalStart, originalEnd};
        }

        /**
         * Records auto-generate {@code equals()}/{@code hashCode()} using
         * {@link Object#equals} per component — for an {@code int[]} field that
         * means REFERENCE equality, which is almost never what's wanted (two
         * separately-computed but content-identical mappings would compare
         * unequal). Overridden here to use {@link java.util.Arrays} content
         * comparison instead, so {@code StrippedMessage} behaves the way every
         * caller (and every test) reasonably expects it to.
         */
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof StrippedMessage that)) return false;
            return java.util.Objects.equals(originalText, that.originalText)
                    && java.util.Objects.equals(strippedText, that.strippedText)
                    && java.util.Arrays.equals(strippedToOriginalIndex, that.strippedToOriginalIndex);
        }

        @Override
        public int hashCode() {
            int result = java.util.Objects.hash(originalText, strippedText);
            result = 31 * result + java.util.Arrays.hashCode(strippedToOriginalIndex);
            return result;
        }

        @Override
        public String toString() {
            return "StrippedMessage{originalLen=" + (originalText != null ? originalText.length() : 0)
                    + ", strippedLen=" + strippedText.length() + "}";
        }
    }

    /**
     * Result of validating one raw regex pattern directly against Hyperscan
     * (used for {@code TermType.REGEX} terms, which skip the Compile Service
     * entirely — see {@link com.db.macs3.ecomms.spectre.service.HyperscanScanService#validatePattern}).
     *
     * @param pass         true when Hyperscan accepted the pattern
     * @param errorMessage Hyperscan's compile error text; null when {@code pass} is true
     */
    public record PatternValidationResult(
            boolean pass,
            String errorMessage
    ) {}

    /**
     * A lexicon term that passed Hyperscan compilation and is ready to scan.
     *
     * @param termId               unique identifier
     * @param termDescription      original lexicon expression
     * @param translatedPattern    Hyperscan-valid PCRE pattern
     * @param hsFlags              bitmask of Hyperscan expression flags
     * @param requiresAndPostFilter true when the term uses AND/NOT semantics
     * @param expressionIndex      index in the compiled database (maps Match → term)
     */
    public record CompiledTerm(
            String termId,
            String termDescription,
            String translatedPattern,
            int hsFlags,
            boolean requiresAndPostFilter,
            int expressionIndex
    ) {}

    /**
     * A raw match returned by Hyperscan, using byte offsets into the UTF-8 input.
     *
     * @param startByteOffset start of the matched region (bytes into UTF-8 message)
     * @param endByteOffset   end of the matched region (exclusive, bytes)
     * @param expressionIndex index of the matching expression in the compiled database
     */
    public record RawMatch(
            long startByteOffset,
            long endByteOffset,
            int expressionIndex
    ) {}

    /**
     * A single match region mapped to Java {@code String} character indices.
     *
     * @param startCharIndex  start of the match in the message (Java char index)
     * @param endCharIndex    end of the match in the message (exclusive, Java char index)
     * @param matchedText     the extracted substring from the message
     * @param inDisclaimer    true when this match falls entirely within a detected
     *                        disclaimer region — see {@link DisclaimerSpan} and
     *                        {@link com.db.macs3.ecomms.spectre.service.DisclaimerDetectionService}.
     *                        A disclaimer match is still reported (and shown on the UI
     *                        with a "not an alert — found in disclaimer" note) but does
     *                        NOT count toward {@link TermScanResult#hasMatches()} /
     *                        alerting, matching the requirement that boilerplate
     *                        disclaimer text (e.g. the word "confidential" appearing
     *                        in a standard footer) must not trigger a false alert.
     */
    public record MatchHighlight(
            int startCharIndex,
            int endCharIndex,
            String matchedText,
            boolean inDisclaimer
    ) {
        /** @return true when this match should count toward alerting (i.e. NOT disclaimer-only). */
        public boolean countsTowardAlert() {
            return !inDisclaimer;
        }
    }

    /**
     * One occurrence of a user-supplied disclaimer text found within a message,
     * in ORIGINAL-text character coordinates (same convention as {@link MatchHighlight}).
     *
     * @param startCharIndex start of the disclaimer occurrence (inclusive)
     * @param endCharIndex   end of the disclaimer occurrence (exclusive)
     * @param disclaimerText the disclaimer text that was matched (as supplied by the user)
     */
    public record DisclaimerSpan(
            int startCharIndex,
            int endCharIndex,
            String disclaimerText
    ) {}

    /**
     * All scan results aggregated for one lexicon term, against ONE message.
     *
     * @param termId                 unique term identifier
     * @param termDescription        original lexicon expression
     * @param translatedPattern      PCRE pattern used for scanning (the REQUIRED
     *                               side's pattern for an AND NOT term)
     * @param compilationStatus      {@code "PASS"}, {@code "FAILED"}, or {@code "SKIPPED"}
     * @param requiresExclusionCheck true for AND NOT terms — an exclusion pattern
     *                               was independently scanned for; see {@code excludedByAndNot}
     * @param matches                match regions found for the REQUIRED pattern in this
     *                               message (each individually flagged {@link MatchHighlight#inDisclaimer()})
     * @param hasMatches             true when at least one ALERT-worthy match exists —
     *                               false when there are no required-pattern matches, when every
     *                               match is disclaimer-only, OR when {@code excludedByAndNot} is true
     *                               (the exclusion pattern negates the whole term regardless of matches)
     * @param hasDisclaimerOnlyMatches true when every match found for this term/message fell
     *                               within a disclaimer — informational: nothing to alert on,
     *                               but not silently invisible either
     * @param excludedByAndNot       true when this term's exclusion pattern (see
     *                               {@code requiresExclusionCheck}) was found ANYWHERE in this
     *                               message — required-pattern matches are still listed in
     *                               {@code matches} for visibility, but never count toward alerting
     * @param compilationError       error message when compilationStatus is FAILED
     * @param exclusionNote          informational note explaining an AND NOT exclusion when
     *                               {@code excludedByAndNot} is true
     */
    public record TermScanResult(
            String termId,
            String termDescription,
            String translatedPattern,
            String compilationStatus,
            boolean requiresExclusionCheck,
            List<MatchHighlight> matches,
            boolean hasMatches,
            boolean hasDisclaimerOnlyMatches,
            boolean excludedByAndNot,
            String compilationError,
            String exclusionNote
    ) {}

    /**
     * Scan results for exactly one message — one message may be scanned
     * against many terms; this bundles all of them together with the
     * message's own text/highlighting.
     *
     * @param messageId              identifies which message this is — the uploaded
     *                               file's name, or {@code "Pasted Message"} /
     *                               {@code "Message N"} for text-area input
     * @param plainMessage           original message text (for the UI text panel)
     * @param htmlHighlightedMessage HTML with {@code <mark>} tags for matched regions —
     *                               disclaimer-only matches get a visually distinct
     *                               {@code lex-match-disclaimer} CSS class instead of
     *                               {@code lex-match}, so the UI can render them muted
     *                               with a "not an alert" note rather than as a live alert
     * @param disclaimerSpans        disclaimer occurrences detected in this message
     * @param termResults            per-term scan results for this message
     * @param matchedTerms           number of terms with at least one ALERT-worthy match
     *                               (i.e. {@link TermScanResult#hasMatches()} true) in this message
     * @param hasMatches             true when any term has an alert-worthy match in this message
     */
    public record MessageScanResult(
            String messageId,
            String plainMessage,
            String htmlHighlightedMessage,
            List<DisclaimerSpan> disclaimerSpans,
            List<TermScanResult> termResults,
            int matchedTerms,
            boolean hasMatches
    ) {}

    /**
     * Complete scan response returned to the UI and REST callers — covers
     * one or more messages scanned against the same term set.
     *
     * @param scanId               UUID of this scan session
     * @param scanDurationMs       wall-clock time for the full pipeline
     * @param termType             {@code "Natural Language"} or {@code "Regex"} — the request
     *                             type applied to every term in this scan (see {@link TermType})
     * @param totalMessages        number of messages scanned
     * @param totalTerms           number of terms submitted
     * @param totalDisclaimers     number of disclaimer texts supplied (0 if none)
     * @param matchedTerms         number of (message, term) pairs with at least one alert-worthy match,
     *                             summed across all messages
     * @param failedTerms          number of terms that failed compilation (term-level, not per-message)
     * @param hasMatches           true when any message has an alert-worthy match
     * @param messageResults       one entry per scanned message
     * @param warnings             non-fatal informational messages
     * @param status               {@code "SUCCESS"} or {@code "ERROR"}
     * @param errorMessage         populated only when status is {@code "ERROR"}
     */
    public record ScanResponse(
            String scanId,
            long scanDurationMs,
            String termType,
            int totalMessages,
            int totalTerms,
            int totalDisclaimers,
            int matchedTerms,
            int failedTerms,
            boolean hasMatches,
            List<MessageScanResult> messageResults,
            List<String> warnings,
            String status,
            String errorMessage
    ) {

        /** Convenience factory for a successful scan response. */
        public static ScanResponse success(
                String scanId, long durationMs, String termType,
                int totalTerms, int totalDisclaimers, int failedTerms,
                List<MessageScanResult> messageResults, List<String> warnings) {
            int matchedTerms = messageResults.stream().mapToInt(MessageScanResult::matchedTerms).sum();
            boolean hasMatches = messageResults.stream().anyMatch(MessageScanResult::hasMatches);
            return new ScanResponse(
                    scanId, durationMs, termType,
                    messageResults.size(), totalTerms, totalDisclaimers,
                    matchedTerms, failedTerms, hasMatches,
                    messageResults, warnings, "SUCCESS", null
            );
        }

        /** Convenience factory for an error response. */
        public static ScanResponse error(String scanId, String message) {
            return new ScanResponse(
                    scanId, 0, null, 0, 0, 0, 0, 0, false,
                    List.of(), List.of(), "ERROR", message
            );
        }
    }
}
