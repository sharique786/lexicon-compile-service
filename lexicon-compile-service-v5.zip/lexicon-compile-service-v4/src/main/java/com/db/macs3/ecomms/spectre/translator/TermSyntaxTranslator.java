package com.db.macs3.ecomms.spectre.translator;

import com.ibm.icu.text.Normalizer2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Translates lexicon term descriptions (operator language) into
 * Hyperscan-compatible PCRE patterns.
 *
 * <h2>Pipeline</h2>
 * <pre>
 * raw text → preprocess → Tokenizer → List&lt;Token&gt; → ExpressionParser → Ast
 *          → PatternCodeGenerator → (hsPattern, hsFlags, exclusionPattern?)
 * </pre>
 *
 * <p>Each stage is a separate, independently-testable class.
 *
 * <h2>Operator precedence (grammar — see {@link ExpressionParser})</h2>
 * <table>
 * <tr><td>Atom</td><td>word, "quoted phrase", emoji, non-english, wildcard, parens (highest)</td></tr>
 * <tr><td>NEAR{n} / FOLLOWEDBY{n}</td><td>proximity, bounded gap — AT MOST ONE per grammar level</td></tr>
 * <tr><td>AND</td><td>co-occurrence — all operands present, any order, NO distance limit</td></tr>
 * <tr><td>AND NOT</td><td>the required side must be present; the excluded side(s) must be
 *     absent from the whole message — see the two-pattern contract below.
 *     There is no independent NOT operator: {@code NOT} is only ever valid
 *     immediately after {@code AND}.</td></tr>
 * <tr><td>OR</td><td>alternation (lowest)</td></tr>
 * </table>
 *
 * <h2>AND: same technique as NEAR/FOLLOWEDBY, just unbounded</h2>
 * <p>{@code price AND rigging} compiles to a single, fully correct Hyperscan
 * pattern using the same bidirectional-alternation technique NEAR uses for a
 * bounded gap, with the gap made unbounded — see {@link PatternCodeGenerator}
 * class Javadoc. No lookahead, no post-filter, no scan-time cooperation
 * needed from the caller.
 *
 * <h2>AND NOT: a two-pattern contract, not a single regex</h2>
 * <p>Hyperscan cannot express "absent from the whole message" — that is
 * exactly what negative lookaround is for, and Hyperscan supports none.
 * {@code A AND NOT B} therefore returns TWO independently Hyperscan-valid
 * patterns: {@link TranslationResult.Success#hsPattern()} (A) and
 * {@link TranslationResult.Success#exclusionPattern()} (B). The term is
 * correctly matched only when {@code hsPattern} matches the message AND
 * {@code exclusionPattern} does not — see {@link TranslationResult} class
 * Javadoc for the exact contract.
 *
 * <h2>Pattern examples</h2>
 * <pre>
 * (crap OR bad) NEAR{3} (bonus OR comp)
 *   → (?:(?:crap|bad)(?:\s+\S+){0,3}\s+(?:bonus|comp)|(?:bonus|comp)(?:\s+\S+){0,3}\s+(?:crap|bad))
 *
 * (F) FOLLOWEDBY{1} (((me) OR (cking)))
 *   → F(?:\s+\S+){0,1}\s+(?:me|cking)
 *
 * price AND rigging
 *   → hsPattern: (?:price[\s\S]*rigging|rigging[\s\S]*price)
 *   Matches "...price change and market rigging is going on" (both present,
 *   any order, any distance apart). Does NOT match "There's price change"
 *   alone (rigging never appears).
 *
 * ((fix) OR (rig)) FOLLOWEDBY{2} (the rate) AND NOT (fed rate move)
 *   → hsPattern:               (?:fix|rig)(?:\s+\S+){0,2}\s+the rate
 *     requiresExclusionCheck:  true
 *     exclusionPattern:        (?:fed rate move)
 *   The caller must check BOTH: matched iff hsPattern matches AND
 *   exclusionPattern does not — see README "AND NOT: the two-pattern contract".
 *
 * ((he?d kill) OR (she?d kill))
 *   → (?:he\?d kill|she\?d kill)     — '?' is always literal
 *
 * (check her out) OR (chimp*)
 *   → (?:check her out|chimp\S*)
 *
 * 내부자 NEAR{3} 거래    (Korean insider NEAR trading)
 *   → (?:내부자[\s\S]{0,18}거래|거래[\s\S]{0,18}내부자)
 *
 * 💰 OR 🤫
 *   → (?:\x{1F4B0}|\x{1F92B})  (with UTF8+UCP flags)
 * </pre>
 */
@Component
public final class TermSyntaxTranslator {

    private static final Logger log = LoggerFactory.getLogger(TermSyntaxTranslator.class);

    /**
     * Translates one lexicon term description into a Hyperscan PCRE pattern.
     *
     * @param rawExpression the "Term Description" from the CSV/JSON input
     * @return {@link TranslationResult.Success} with the pattern (and, for
     *         AND NOT terms, the exclusion pattern — see class Javadoc), or
     *         {@link TranslationResult.Error} with a specific, actionable error message
     */
    public TranslationResult translate(String rawExpression) {
        if (rawExpression == null || rawExpression.isBlank()) {
            return TranslationResult.error("Term description is null or blank");
        }
        try {
            String preprocessed = preprocess(rawExpression);
            log.debug("Translating: '{}'", preprocessed);

            List<Token> tokens = Tokenizer.tokenize(preprocessed);
            Ast ast = ExpressionParser.parse(tokens, preprocessed);

            ParseContext ctx = new ParseContext();
            String pattern = PatternCodeGenerator.generate(ast, ctx);
            int flags = ctx.computeFlags();

            if (ctx.requiresExclusionCheck()) {
                log.debug("Translated: '{}' -> hsPattern='{}' flags={} exclusionPattern='{}'",
                        rawExpression, pattern, flags, ctx.getExclusionPattern());
                return TranslationResult.successWithExclusion(pattern, flags, ctx.getExclusionPattern());
            }

            log.debug("Translated: '{}' -> hsPattern='{}' flags={}", rawExpression, pattern, flags);
            return TranslationResult.success(pattern, flags);

        } catch (TranslationException te) {
            log.warn("Translation failed for '{}': {}", rawExpression, te.getMessage());
            return TranslationResult.error(te.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error translating '{}': {}", rawExpression, e.getMessage(), e);
            return TranslationResult.error("Unexpected error: " + e.getMessage());
        }
    }

    // ── Pre-processing ────────────────────────────────────────────────────────

    /**
     * Normalises the raw expression before tokenizing:
     * <ol>
     *   <li>Trim whitespace</li>
     *   <li>Unescape CSV double-quote encoding: {@code ""} → {@code "}</li>
     *   <li>Unicode NFC normalisation (ICU4J) for consistent multi-language handling</li>
     * </ol>
     *
     * <p>Outer {@code "..."} wrapping is intentionally NOT stripped here —
     * {@link Tokenizer} recognises a quoted phrase as its own token type,
     * and {@link ExpressionParser}/{@link PatternCodeGenerator} handle its
     * content as always-literal. Stripping quotes at this stage would expose
     * their content to normal tokenization, silently losing the "always
     * literal" guarantee quotes are supposed to provide.
     */
    private String preprocess(String raw) {
        String normalizedText = raw.trim();
        normalizedText = normalizedText.replace("\"\"", "\u0000DQ\u0000");
        normalizedText = normalizedText.replace("\u0000DQ\u0000", "\"");
        try {
            normalizedText = Normalizer2.getNFCInstance().normalize(normalizedText);
        } catch (Exception e) {
            log.debug("ICU4J normalisation skipped: {}", e.getMessage());
        }
        return normalizedText;
    }
}
