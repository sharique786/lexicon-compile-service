package com.db.macs3.ecomms.spectre.engine;

import com.db.macs3.ecomms.spectre.model.FeatureDecisionRow;
import com.db.macs3.ecomms.spectre.model.TermMatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Evaluates the noise-reduction decision matrix for a given message.
 *
 * <p>The engine always processes noise-reduction features FIRST. This class
 * encapsulates the logic that decides — based on noise-reduction scan results —
 * whether standard lexicon features should also be scanned.
 *
 * <h2>Decision matrix</h2>
 * <pre>
 * ┌──────────────────┬──────────┬────────────────────────┬────────────────────────────────┐
 * │ Feature Category │ Operator │ Condition              │ Action                         │
 * ├──────────────────┼──────────┼────────────────────────┼────────────────────────────────┤
 * │ Noise Reduction  │ OR       │ ANY feature matches    │ Skip standard features         │
 * │ Noise Reduction  │ OR       │ NONE match             │ Process standard features      │
 * │ Noise Reduction  │ AND      │ ALL features match     │ Skip standard features         │
 * │ Noise Reduction  │ AND      │ NONE/PARTIAL match     │ Process standard features      │
 * │ Only Standard    │ —        │ —                      │ Always process standard        │
 * └──────────────────┴──────────┴────────────────────────┴────────────────────────────────┘
 * </pre>
 *
 * <p>Notes:
 * <ul>
 *   <li>Noise reduction features that produce ANY match (even one term out of many
 *       in the HDB) count as "matched" for the feature-level evaluation.</li>
 *   <li>The operator (OR/AND) applies across features, not across terms within a feature.</li>
 *   <li>Features without an operator (null/blank) default to OR semantics.</li>
 * </ul>
 */
public class NoiseReductionEvaluator implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final Logger log = LoggerFactory.getLogger(NoiseReductionEvaluator.class);

    private static final String OP_OR  = "OR";
    private static final String OP_AND = "AND";

    /**
     * Determines whether standard lexicon features should be skipped based on
     * the noise-reduction scan results.
     *
     * @param noiseReductionFeatures the noise-reduction features for this message
     *                               (must all have {@code isNoiseReduction == true})
     * @param scanResults            map of featureName → list of matches found;
     *                               features with no matches will have an empty list
     * @return {@code true} if standard features should be SKIPPED,
     *         {@code false} if standard features should be processed
     */
    public boolean shouldSkipStandardFeatures(List<FeatureDecisionRow> noiseReductionFeatures,
                                               Map<String, List<TermMatch>> scanResults) {
        if (noiseReductionFeatures == null || noiseReductionFeatures.isEmpty()) {
            // No noise reduction features → always process standard features
            log.trace("No noise-reduction features; processing standard features");
            return false;
        }

        // Determine the operator — all NR features for a message share the same operator
        // (they belong to the same policy evaluation context)
        String operator = resolveOperator(noiseReductionFeatures);
        log.debug("Noise-reduction evaluation: {} features, operator={}",
                  noiseReductionFeatures.size(), operator);

        // Evaluate whether each noise-reduction feature produced any match
        long matchedFeatureCount = noiseReductionFeatures.stream()
                .filter(feature -> featureHasMatch(feature.getFeatureName(), scanResults))
                .count();

        boolean skipStandard;
        if (OP_AND.equalsIgnoreCase(operator)) {
            // AND: skip standard features only if ALL noise-reduction features matched
            skipStandard = matchedFeatureCount == noiseReductionFeatures.size();
            log.debug("NR AND: {}/{} matched → skipStandard={}",
                      matchedFeatureCount, noiseReductionFeatures.size(), skipStandard);
        } else {
            // OR (or default): skip standard features if ANY noise-reduction feature matched
            skipStandard = matchedFeatureCount > 0;
            log.debug("NR OR: {}/{} matched → skipStandard={}",
                      matchedFeatureCount, noiseReductionFeatures.size(), skipStandard);
        }

        return skipStandard;
    }

    /**
     * Returns {@code true} if the scan results for {@code featureName} contain
     * at least one match.
     *
     * @param featureName the feature to check
     * @param scanResults the map of scan results (featureName → matches)
     * @return {@code true} if there is at least one TermMatch for this feature
     */
    public boolean featureHasMatch(String featureName, Map<String, List<TermMatch>> scanResults) {
        List<TermMatch> matches = scanResults.get(featureName);
        return matches != null && !matches.isEmpty();
    }

    /**
     * Determines the operator to apply across the noise-reduction features.
     *
     * <p>In practice, all noise-reduction features for a given message share the
     * same {@code feature_operator} value because they belong to the same policy
     * engine instance. If values differ (data inconsistency), OR is used as the
     * safe default.
     *
     * @param features list of noise-reduction features
     * @return "OR", "AND", or "OR" as default
     */
    public String resolveOperator(List<FeatureDecisionRow> features) {
        if (features == null || features.isEmpty()) {
            return OP_OR;
        }
        // Use the first non-blank operator value found
        return features.stream()
                .map(FeatureDecisionRow::getFeatureOperator)
                .filter(op -> op != null && !op.isBlank())
                .findFirst()
                .orElseGet(() -> {
                    log.warn("No operator found in noise-reduction features; defaulting to OR");
                    return OP_OR;
                });
    }

    /**
     * Counts how many distinct features (across all features provided) produced
     * at least one match.
     *
     * @param features    the features to check
     * @param scanResults the scan results
     * @return count of features with at least one match
     */
    public long countMatchedFeatures(List<FeatureDecisionRow> features,
                                      Map<String, List<TermMatch>> scanResults) {
        if (features == null) return 0L;
        return features.stream()
                .filter(f -> featureHasMatch(f.getFeatureName(), scanResults))
                .count();
    }
}
