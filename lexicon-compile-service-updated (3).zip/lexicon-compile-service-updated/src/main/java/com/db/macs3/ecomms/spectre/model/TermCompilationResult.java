package com.db.macs3.ecomms.spectre.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;

/**
 * Compilation outcome for a single lexicon term.
 *
 * <p>{@code riskDriverName} has been removed from this record. It was
 * previously echoed back from the request but is no longer part of the
 * request structure.
 *
 * <h2>Null field semantics</h2>
 * <ul>
 *   <li>{@code translatedPattern} — null only when translation failed before
 *       a pattern could even be produced (see {@code translationError})</li>
 *   <li>{@code errorLog} — non-null only for Hyperscan-stage failures</li>
 *   <li>{@code translationError} — non-null only for translation-stage failures</li>
 * </ul>
 * At most one of {@code errorLog} / {@code translationError} is non-null.
 * Both are null when {@code compilationStatus} is {@code PASS}.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record TermCompilationResult(

        @JsonProperty("termId")
        String termId,

        @JsonProperty("termDescription")
        String termDescription,

        @JsonProperty("compilationStatus")
        CompilationStatus compilationStatus,

        @JsonProperty("translatedPattern")
        String translatedPattern,

        /**
         * Hyperscan error message when the pattern was syntactically valid
         * PCRE but Hyperscan's compiler still rejected it.
         * Null for PASS terms and for translation-stage failures.
         */
        @JsonProperty("errorLog")
        String errorLog,

        /**
         * Error from the operator-language translator, when the term's text
         * could not be converted into a PCRE pattern at all (e.g. missing
         * operand for NEAR{n}).
         * Null for PASS terms and for Hyperscan-stage failures.
         */
        @JsonProperty("translationError")
        String translationError,

        /**
         * Hyperscan compile-flag bitmask applied to the pattern.
         * {@code 1}=CASELESS, {@code 2}=DOTALL, {@code 32}=UTF8, {@code 64}=UCP.
         * {@code 0} indicates translation never completed.
         */
        @JsonProperty("hyperscanFlags")
        int hyperscanFlags,

        /**
         * {@code true} when the term used AND semantics. The downstream scan
         * engine must apply a post-filter to verify all AND operands appear
         * in the same message before raising an alert.
         * Always {@code false} for failed terms.
         */
        @JsonProperty("requiresAndPostFilter")
        boolean requiresAndPostFilter,

        @JsonProperty("compiledAt")
        @JsonFormat(shape = JsonFormat.Shape.STRING)
        Instant compiledAt

) {
    // ── Factory methods ───────────────────────────────────────────────────────

    /**
     * Creates a PASS result.
     *
     * @param input               the term from the compile request
     * @param translatedPattern   the Hyperscan PCRE pattern
     * @param hyperscanFlags      bitmask of flags used for compilation
     * @param requiresAndPostFilter whether AND post-filter is needed
     */
    public static TermCompilationResult pass(CompileRequest.TermInput input,
                                              String translatedPattern,
                                              int hyperscanFlags,
                                              boolean requiresAndPostFilter) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.PASS,
                translatedPattern, null, null,
                hyperscanFlags, requiresAndPostFilter,
                Instant.now());
    }

    /**
     * Creates a FAILED result where Hyperscan rejected the translated pattern.
     *
     * @param input             the term from the compile request
     * @param translatedPattern the pattern that Hyperscan rejected
     * @param errorLog          Hyperscan's error message
     * @param hyperscanFlags    the flags that were attempted
     */
    public static TermCompilationResult failedHyperscan(CompileRequest.TermInput input,
                                                         String translatedPattern,
                                                         String errorLog,
                                                         int hyperscanFlags) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.FAILED,
                translatedPattern, errorLog, null,
                hyperscanFlags, false,
                Instant.now());
    }

    /**
     * Creates a FAILED result where the term's syntax could not be translated
     * into a PCRE pattern at all. Hyperscan was never invoked.
     *
     * @param input            the term from the compile request
     * @param translationError the translator's error message
     */
    public static TermCompilationResult failedTranslation(CompileRequest.TermInput input,
                                                           String translationError) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.FAILED,
                null, null, translationError,
                0, false,
                Instant.now());
    }

    public boolean isPass()   { return CompilationStatus.PASS   == compilationStatus; }
    public boolean isFailed() { return CompilationStatus.FAILED == compilationStatus; }
}
