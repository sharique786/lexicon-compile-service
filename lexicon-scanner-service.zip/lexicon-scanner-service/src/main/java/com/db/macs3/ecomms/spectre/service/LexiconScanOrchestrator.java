package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.client.LexiconCompileClient;
import com.db.macs3.ecomms.spectre.model.Models.CompiledTerm;
import com.db.macs3.ecomms.spectre.model.Models.CompileServiceResponse;
import com.db.macs3.ecomms.spectre.model.Models.MatchHighlight;
import com.db.macs3.ecomms.spectre.model.Models.RawMatch;
import com.db.macs3.ecomms.spectre.model.Models.ScanResponse;
import com.db.macs3.ecomms.spectre.model.Models.TermScanResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Orchestrates the full Lexicon Scanner pipeline:
 *
 * <ol>
 *   <li>Calls the Lexicon Compile Service to translate term descriptions into
 *       Hyperscan PCRE patterns ({@link LexiconCompileClient}).</li>
 *   <li>Filters PASS terms and assembles {@link CompiledTerm} list with
 *       sequential expression indices for Hyperscan database construction.</li>
 *   <li>Calls {@link HyperscanScanService} to compile a Hyperscan database
 *       and scan the message text.</li>
 *   <li>Groups raw matches by expression index, converts byte offsets to
 *       char indices, extracts matched substrings
 *       ({@link MatchHighlightService}).</li>
 *   <li>Builds a merged highlighted HTML string and per-term
 *       {@link TermScanResult} records.</li>
 *   <li>Returns a fully populated {@link ScanResponse}.</li>
 * </ol>
 *
 * <h2>AND / NOT post-filter note</h2>
 * <p>Terms with {@code requiresAndPostFilter=true} use an OR pre-scan pattern
 * (e.g. {@code (?:insider|trading)} for {@code insider AND trading}). The
 * scanner records all OR matches but adds an informational note explaining that
 * full AND/NOT semantics are enforced by the alerting scan engine, not here.
 */
@Service
public class LexiconScanOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(LexiconScanOrchestrator.class);

    private static final String POST_FILTER_NOTE =
            "AND/NOT semantics: this result shows OR pre-scan matches. "
            + "Full AND/NOT verification is applied by the alerting scan engine at runtime.";

    private final LexiconCompileClient compileClient;
    private final HyperscanScanService scanService;
    private final MatchHighlightService highlightService;

    public LexiconScanOrchestrator(LexiconCompileClient compileClient,
                                    HyperscanScanService scanService,
                                    MatchHighlightService highlightService) {
        this.compileClient = compileClient;
        this.scanService = scanService;
        this.highlightService = highlightService;
    }

    /**
     * Runs the full scan pipeline for the given term descriptions and message text.
     *
     * @param termDescriptions raw lexicon term expressions (e.g. {@code insider AND trading})
     * @param messageText      the communication message to scan
     * @param ruleName         optional rule name for the compile request
     * @return fully populated {@link ScanResponse}
     */
    public ScanResponse scan(List<String> termDescriptions, String messageText, String ruleName) {
        String scanId = UUID.randomUUID().toString();
        long startMs = System.currentTimeMillis();

        log.info("Starting scan session: scanId={}, terms={}, messageLen={}",
                scanId, termDescriptions.size(), messageText.length());

        List<String> warnings = new ArrayList<>();

        try {
            // ── Step 1: Compile terms ─────────────────────────────────────────
            CompileServiceResponse compileResp =
                    compileClient.compile(termDescriptions, ruleName);

            if (compileResp.hasFailures()) {
                long failedCount = compileResp.results().stream()
                        .filter(r -> !r.isPass()).count();
                warnings.add(failedCount + " term(s) failed pattern compilation and were skipped.");
                log.warn("scanId={}: {} term(s) failed compilation", scanId, failedCount);
            }

            // ── Step 2: Build CompiledTerm list (PASS terms only) ─────────────
            AtomicInteger exprIndex = new AtomicInteger(0);
            List<CompiledTerm> compiledTerms = compileResp.results().stream()
                    .filter(CompileServiceResponse.TermResult::isPass)
                    .map(r -> new CompiledTerm(
                            r.termId(), r.termDescription(),
                            r.translatedPattern(), r.hsFlags(),
                            r.requiresAndPostFilter(),
                            exprIndex.getAndIncrement()))
                    .toList();

            log.info("scanId={}: {} term(s) ready for Hyperscan", scanId, compiledTerms.size());

            // ── Step 3: Hyperscan scan ────────────────────────────────────────
            List<RawMatch> rawMatches = compiledTerms.isEmpty()
                    ? Collections.emptyList()
                    : scanService.compileAndScan(compiledTerms, messageText);

            // ── Step 4: Group matches by expression index ─────────────────────
            Map<Integer, List<MatchHighlight>> matchesByIndex =
                    highlightService.groupMatchesByTerm(rawMatches, compiledTerms, messageText);

            // ── Step 5: Build per-term results ────────────────────────────────
            List<TermScanResult> termResults = buildTermResults(
                    compileResp.results(), compiledTerms, matchesByIndex);

            // ── Step 6: Build full highlighted HTML ───────────────────────────
            List<MatchHighlight> allHighlights = matchesByIndex.values().stream()
                    .flatMap(List::stream)
                    .toList();

            String htmlHighlighted = highlightService.buildHighlightedHtml(messageText, allHighlights);

            // ── Step 7: Assemble response ─────────────────────────────────────
            int matchedTerms = (int) termResults.stream().filter(TermScanResult::hasMatches).count();
            int failedTerms  = (int) termResults.stream()
                    .filter(r -> "FAILED".equalsIgnoreCase(r.compilationStatus())).count();
            long elapsedMs = System.currentTimeMillis() - startMs;

            log.info("Scan complete: scanId={}, matched={}/{}, failed={}, elapsed={}ms",
                    scanId, matchedTerms, termDescriptions.size(), failedTerms, elapsedMs);

            return ScanResponse.success(
                    scanId, elapsedMs, termDescriptions.size(),
                    matchedTerms, failedTerms,
                    messageText, htmlHighlighted, termResults, warnings);

        } catch (Exception e) {
            log.error("Scan pipeline failed: scanId={}, error={}", scanId, e.getMessage(), e);
            return ScanResponse.error(scanId,
                    "Scan failed: " + e.getMessage());
        }
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /**
     * Builds the final list of {@link TermScanResult} records — one per term
     * submitted, regardless of whether it compiled or matched.
     *
     * @param allResults     all term results from the compile service
     * @param compiledTerms  only the PASS terms, with their expression indices
     * @param matchesByIndex highlights keyed by expression index
     */
    private List<TermScanResult> buildTermResults(
            List<CompileServiceResponse.TermResult> allResults,
            List<CompiledTerm> compiledTerms,
            Map<Integer, List<MatchHighlight>> matchesByIndex) {

        // Build index: termId → CompiledTerm (for looking up expression index)
        Map<String, CompiledTerm> compiledByTermId = compiledTerms.stream()
                .collect(Collectors.toMap(CompiledTerm::termId, ct -> ct));

        return allResults.stream().map(result -> {

            if (!result.isPass()) {
                // Failed compilation → no pattern, no matches
                String error = buildError(result);
                return new TermScanResult(
                        result.termId(), result.termDescription(),
                        null, "FAILED", false,
                        List.of(), false, error, null);
            }

            CompiledTerm ct = compiledByTermId.get(result.termId());
            List<MatchHighlight> highlights = ct != null
                    ? matchesByIndex.getOrDefault(ct.expressionIndex(), List.of())
                    : List.of();

            String postFilterNote = result.requiresAndPostFilter() ? POST_FILTER_NOTE : null;

            return new TermScanResult(
                    result.termId(), result.termDescription(),
                    result.translatedPattern(), "PASS",
                    result.requiresAndPostFilter(),
                    highlights, !highlights.isEmpty(),
                    null, postFilterNote);
        }).toList();
    }

    private String buildError(CompileServiceResponse.TermResult result) {
        if (result.translationError() != null && !result.translationError().isBlank()) {
            return "Translation error: " + result.translationError();
        }
        if (result.errorLog() != null && !result.errorLog().isBlank()) {
            return "Hyperscan error: " + result.errorLog();
        }
        return "Unknown compilation failure";
    }
}
