package com.db.macs3.ecomms.spectre.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;

/**
 * Compilation outcome for a single lexicon term.
 *
 * <p>{@code riskDriverName} has been removed from this record. It was
 * previously echoed back from the request but is no longer part of the
 * request structure.
 *
 * <h2>Null field semantics</h2>
 * <ul>
 *   <li>{@code translatedPattern} — null only when translation failed before
 *       a pattern could even be produced (see {@code translationError})</li>
 *   <li>{@code errorLog} — non-null only for Hyperscan-stage failures</li>
 *   <li>{@code translationError} — non-null only for translation-stage failures</li>
 *   <li>{@code exclusionPattern} — non-null only when {@code requiresExclusionCheck}
 *       is true (the term used {@code AND NOT})</li>
 *   <li>{@code hyperscanExpressionId} — non-null only on a {@code /compile/bundle}
 *       response (see below); always null for {@code /compile} and {@code /compile/csv},
 *       which never build a combined Hyperscan database</li>
 * </ul>
 * At most one of {@code errorLog} / {@code translationError} is non-null.
 * Both are null when {@code compilationStatus} is {@code PASS}.
 *
 * <h2>AND NOT has two different correct implementations, for two different callers</h2>
 * <p>{@code translatedPattern} and {@code exclusionPattern} are two
 * independently Hyperscan-valid patterns (Hyperscan cannot express "absent
 * from the whole message" in a single pattern — no negative lookaround
 * support). What a caller does with them differs by which endpoint it used:
 *
 * <ul>
 *   <li><b>{@code /compile} and {@code /compile/csv}</b> — the caller (e.g.
 *       the Lexicon Scanner Service) reads the JSON, compiles BOTH patterns
 *       itself, and combines the two boolean results in application code:
 *       matched iff {@code translatedPattern} matches AND {@code exclusionPattern}
 *       does not. This is the two-pattern contract described in earlier
 *       revisions of this class's Javadoc, and it is still exactly correct
 *       for a caller that reads the JSON.</li>
 *   <li><b>{@code /compile/bundle}</b> — the returned {@code .hdb} file is
 *       often the ONLY artifact a consumer reads (e.g. the Lexicon Scan
 *       Engine's Dataproc job loads the database and scans messages against
 *       it directly, with no JSON in the loop at all). For this endpoint,
 *       {@code translatedPattern} and {@code exclusionPattern} are compiled
 *       into the combined database as a native Hyperscan LOGICAL COMBINATION
 *       ({@code HS_FLAG_COMBINATION}) — Hyperscan itself evaluates "required
 *       matched AND excluded did not" during the scan and reports a match
 *       ONLY at {@code hyperscanExpressionId}, with no separate application-level
 *       combination step needed downstream. See {@code LexiconCompileBundleService}
 *       and the project README's "AND NOT in the combined database" section.</li>
 * </ul>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record TermCompilationResult(

        @JsonProperty("termId")
        String termId,

        @JsonProperty("termDescription")
        String termDescription,

        @JsonProperty("compilationStatus")
        CompilationStatus compilationStatus,

        @JsonProperty("translatedPattern")
        String translatedPattern,

        /**
         * Hyperscan error message when the pattern was syntactically valid
         * PCRE but Hyperscan's compiler still rejected it — either the main
         * pattern or, for an AND NOT term, the exclusion pattern (the
         * message says which). Null for PASS terms and for translation-stage failures.
         */
        @JsonProperty("errorLog")
        String errorLog,

        /**
         * Error from the operator-language translator, when the term's text
         * could not be converted into a PCRE pattern at all (e.g. missing
         * operand for NEAR{n}).
         * Null for PASS terms and for Hyperscan-stage failures.
         */
        @JsonProperty("translationError")
        String translationError,

        /**
         * Hyperscan compile-flag bitmask applied to the pattern(s).
         * {@code 1}=CASELESS, {@code 32}=UTF8, {@code 64}=UCP.
         * {@code 0} indicates translation never completed.
         */
        @JsonProperty("hyperscanFlags")
        int hyperscanFlags,

        /**
         * {@code true} when the term used {@code AND NOT} — see the
         * two-implementations note in class Javadoc for what the caller
         * does with this depending on which endpoint produced this result.
         * Always {@code false} for failed terms and for terms using only
         * {@code AND} (which is fully expressed by {@code translatedPattern}
         * alone — see {@code PatternCodeGenerator} class Javadoc).
         */
        @JsonProperty("requiresExclusionCheck")
        boolean requiresExclusionCheck,

        /**
         * Independently Hyperscan-valid pattern that must NOT match the same
         * message for this term to be considered matched. Non-null iff
         * {@code requiresExclusionCheck} is true.
         */
        @JsonProperty("exclusionPattern")
        String exclusionPattern,

        /**
         * On a {@code /compile/bundle} response only: the ONE expression id
         * a downstream consumer of the combined {@code .hdb} file should
         * watch for to know this term matched — already accounts for AND NOT
         * (see class Javadoc). For a term with no exclusion this is simply
         * its index in the request; for an AND NOT term it is the id of the
         * native Hyperscan combination expression, NOT the id of the
         * required pattern by itself (which is compiled QUIET and never
         * reported on its own — see {@code LexiconCompileBundleService}).
         * Always null outside {@code /compile/bundle}, and always null for
         * FAILED terms (nothing was compiled into the database for them).
         */
        @JsonProperty("hyperscanExpressionId")
        Integer hyperscanExpressionId,

        @JsonProperty("compiledAt")
        @JsonFormat(shape = JsonFormat.Shape.STRING)
        Instant compiledAt

) {
    // ── Factory methods ───────────────────────────────────────────────────────

    /**
     * Creates a PASS result with no AND-NOT exclusion.
     *
     * @param input             the term from the compile request
     * @param translatedPattern the Hyperscan PCRE pattern
     * @param hyperscanFlags    bitmask of flags used for compilation
     */
    public static TermCompilationResult pass(CompileRequest.TermInput input,
                                              String translatedPattern,
                                              int hyperscanFlags) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.PASS,
                translatedPattern, null, null,
                hyperscanFlags, false, null, null,
                Instant.now());
    }

    /**
     * Creates a PASS result for an AND NOT term — both {@code translatedPattern}
     * and {@code exclusionPattern} have already been independently Hyperscan-validated.
     *
     * @param input             the term from the compile request
     * @param translatedPattern the REQUIRED side's Hyperscan PCRE pattern
     * @param hyperscanFlags    bitmask of flags used for compilation
     * @param exclusionPattern  the EXCLUDED side's Hyperscan PCRE pattern
     */
    public static TermCompilationResult passWithExclusion(CompileRequest.TermInput input,
                                                            String translatedPattern,
                                                            int hyperscanFlags,
                                                            String exclusionPattern) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.PASS,
                translatedPattern, null, null,
                hyperscanFlags, true, exclusionPattern, null,
                Instant.now());
    }

    /**
     * Creates a FAILED result where Hyperscan rejected a pattern (either the
     * main pattern, or — for an AND NOT term — the exclusion pattern; the
     * caller passes the appropriate error message either way).
     *
     * @param input             the term from the compile request
     * @param translatedPattern the pattern that was attempted (may be the
     *                          main pattern even when the FAILURE was in the
     *                          exclusion pattern, so the analyst can still see
     *                          what the required side would have been)
     * @param errorLog          Hyperscan's error message
     * @param hyperscanFlags    the flags that were attempted
     */
    public static TermCompilationResult failedHyperscan(CompileRequest.TermInput input,
                                                         String translatedPattern,
                                                         String errorLog,
                                                         int hyperscanFlags) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.FAILED,
                translatedPattern, errorLog, null,
                hyperscanFlags, false, null, null,
                Instant.now());
    }

    /**
     * Creates a FAILED result where the term's syntax could not be translated
     * into a PCRE pattern at all. Hyperscan was never invoked.
     *
     * @param input            the term from the compile request
     * @param translationError the translator's error message
     */
    public static TermCompilationResult failedTranslation(CompileRequest.TermInput input,
                                                           String translationError) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.FAILED,
                null, null, translationError,
                0, false, null, null,
                Instant.now());
    }

    /**
     * Returns a copy of this (PASS) result with {@link #hyperscanExpressionId}
     * set — used only by {@code LexiconCompileBundleService}, once it has
     * decided the id a downstream consumer should watch for this term in the
     * combined database (see class Javadoc).
     */
    public TermCompilationResult withHyperscanExpressionId(int id) {
        return new TermCompilationResult(
                termId, termDescription, compilationStatus,
                translatedPattern, errorLog, translationError,
                hyperscanFlags, requiresExclusionCheck, exclusionPattern,
                id, compiledAt);
    }

    public boolean isPass()   { return CompilationStatus.PASS   == compilationStatus; }
    public boolean isFailed() { return CompilationStatus.FAILED == compilationStatus; }
}
