package com.db.macs3.ecomms.spectre.util;

import com.db.macs3.ecomms.spectre.model.ScriptType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link ScriptDetector}.
 *
 * Every public method, every script family, and all relevant mixed-script
 * combinations are covered.
 */
@DisplayName("ScriptDetector")
class ScriptDetectorTest {

    // ══════════════════════════════════════════════════════════════════════
    // Single-script detection — detect(String)
    // ══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Single script detection")
    class SingleScript {

        @Test @DisplayName("English text → LATIN")
        void english() {
            assertThat(ScriptDetector.detect("insider")).isEqualTo(ScriptType.LATIN);
            assertThat(ScriptDetector.detect("front running")).isEqualTo(ScriptType.LATIN);
        }

        @Test @DisplayName("Arabic text → ARABIC")
        void arabic() {
            assertThat(ScriptDetector.detect("السعر")).isEqualTo(ScriptType.ARABIC);       // price
            assertThat(ScriptDetector.detect("التلاعب")).isEqualTo(ScriptType.ARABIC);     // manipulation
            assertThat(ScriptDetector.detect("معلومات داخلية")).isEqualTo(ScriptType.ARABIC); // insider information
        }

        @Test @DisplayName("Hebrew text → HEBREW")
        void hebrew() {
            assertThat(ScriptDetector.detect("מידע")).isEqualTo(ScriptType.HEBREW);        // information
            assertThat(ScriptDetector.detect("פנים")).isEqualTo(ScriptType.HEBREW);        // insider
            assertThat(ScriptDetector.detect("מסחר פנים")).isEqualTo(ScriptType.HEBREW);   // insider trading
        }

        @Test @DisplayName("Simplified Chinese → CJK (HAN script)")
        void simplifiedChinese() {
            assertThat(ScriptDetector.detect("内幕")).isEqualTo(ScriptType.CJK);           // insider
            assertThat(ScriptDetector.detect("交易")).isEqualTo(ScriptType.CJK);           // trading
            assertThat(ScriptDetector.detect("内幕交易")).isEqualTo(ScriptType.CJK);       // insider trading
        }

        @Test @DisplayName("Traditional Chinese → CJK")
        void traditionalChinese() {
            assertThat(ScriptDetector.detect("內幕交易")).isEqualTo(ScriptType.CJK);       // traditional form
            assertThat(ScriptDetector.detect("市場操縱")).isEqualTo(ScriptType.CJK);       // market manipulation
        }

        @Test @DisplayName("Japanese Kanji → CJK")
        void japaneseKanji() {
            assertThat(ScriptDetector.detect("取引")).isEqualTo(ScriptType.CJK);           // trading
            assertThat(ScriptDetector.detect("情報")).isEqualTo(ScriptType.CJK);           // information
        }

        @Test @DisplayName("Japanese Hiragana → KANA")
        void japaneseHiragana() {
            assertThat(ScriptDetector.detect("インサイダー")).isEqualTo(ScriptType.KANA);   // insider (katakana)
            assertThat(ScriptDetector.detect("とりひき")).isEqualTo(ScriptType.KANA);       // torihiki (trading, hiragana)
        }

        @Test @DisplayName("Korean Hangul → HANGUL")
        void korean() {
            assertThat(ScriptDetector.detect("내부자")).isEqualTo(ScriptType.HANGUL);      // insider
            assertThat(ScriptDetector.detect("거래")).isEqualTo(ScriptType.HANGUL);        // trading
            assertThat(ScriptDetector.detect("정보")).isEqualTo(ScriptType.HANGUL);        // information
        }

        @Test @DisplayName("Thai → THAI")
        void thai() {
            assertThat(ScriptDetector.detect("ราคา")).isEqualTo(ScriptType.THAI);         // price
            assertThat(ScriptDetector.detect("การซื้อขาย")).isEqualTo(ScriptType.THAI);   // trading
        }

        @Test @DisplayName("Null and blank → LATIN (safe default)")
        void nullAndBlank() {
            assertThat(ScriptDetector.detect(null)).isEqualTo(ScriptType.LATIN);
            assertThat(ScriptDetector.detect("")).isEqualTo(ScriptType.LATIN);
            assertThat(ScriptDetector.detect("   ")).isEqualTo(ScriptType.LATIN);
        }

        @Test @DisplayName("Pure ASCII digits and symbols → LATIN")
        void asciiOnly() {
            assertThat(ScriptDetector.detect("123")).isEqualTo(ScriptType.LATIN);
            assertThat(ScriptDetector.detect("price123")).isEqualTo(ScriptType.LATIN);
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // Combined script detection — detectCombined(String, String)
    // ══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Combined (two-operand) script detection")
    class Combined {

        @Test @DisplayName("Latin + Latin → LATIN")
        void latinAndLatin() {
            assertThat(ScriptDetector.detectCombined("insider", "trading"))
                    .isEqualTo(ScriptType.LATIN);
        }

        @Test @DisplayName("Arabic + Arabic → ARABIC")
        void arabicAndArabic() {
            assertThat(ScriptDetector.detectCombined("السعر", "التلاعب"))
                    .isEqualTo(ScriptType.ARABIC);
        }

        @Test @DisplayName("Hebrew + Hebrew → HEBREW")
        void hebrewAndHebrew() {
            assertThat(ScriptDetector.detectCombined("מידע", "פנים"))
                    .isEqualTo(ScriptType.HEBREW);
        }

        @Test @DisplayName("CJK + CJK → CJK")
        void cjkAndCjk() {
            assertThat(ScriptDetector.detectCombined("内幕", "交易"))
                    .isEqualTo(ScriptType.CJK);
        }

        @Test @DisplayName("Korean + Korean → HANGUL")
        void koreanAndKorean() {
            assertThat(ScriptDetector.detectCombined("내부자", "거래"))
                    .isEqualTo(ScriptType.HANGUL);
        }

        // ── Mixed combinations ─────────────────────────────────────────────

        @Test @DisplayName("Latin + Korean → MIXED_CJK (char-based gap needed)")
        void latinAndKorean() {
            assertThat(ScriptDetector.detectCombined("insider", "내부자"))
                    .isEqualTo(ScriptType.MIXED_CJK);
        }

        @Test @DisplayName("Latin + Chinese → MIXED_CJK")
        void latinAndChinese() {
            assertThat(ScriptDetector.detectCombined("insider", "内幕"))
                    .isEqualTo(ScriptType.MIXED_CJK);
        }

        @Test @DisplayName("Latin + Japanese → MIXED_CJK")
        void latinAndJapanese() {
            assertThat(ScriptDetector.detectCombined("insider", "インサイダー"))
                    .isEqualTo(ScriptType.MIXED_CJK);
        }

        @Test @DisplayName("Arabic + Latin → MIXED_RTL (word-based gap still works)")
        void arabicAndLatin() {
            assertThat(ScriptDetector.detectCombined("السعر", "price"))
                    .isEqualTo(ScriptType.MIXED_RTL);
        }

        @Test @DisplayName("Hebrew + Latin → MIXED_RTL")
        void hebrewAndLatin() {
            assertThat(ScriptDetector.detectCombined("מידע", "information"))
                    .isEqualTo(ScriptType.MIXED_RTL);
        }

        @Test @DisplayName("Chinese + Korean → MIXED_CJK (both char-based)")
        void chineseAndKorean() {
            assertThat(ScriptDetector.detectCombined("内幕", "거래"))
                    .isEqualTo(ScriptType.MIXED_CJK);
        }

        @Test @DisplayName("Korean + Arabic → MIXED_CJK (CJK takes priority)")
        void koreanAndArabic() {
            // Korean is char-based; Arabic is word-based.
            // CJK/char-based must win because the Korean side has no spaces.
            assertThat(ScriptDetector.detectCombined("내부자", "معلومات"))
                    .isEqualTo(ScriptType.MIXED_CJK);
        }

        @Test @DisplayName("Emoji-only (treated as LATIN — safe default)")
        void emojiOnly() {
            // Emoji are in supplementary planes; no specific language
            ScriptType result = ScriptDetector.detectCombined("💰", "🤫");
            // Either LATIN or MIXED is acceptable — must not throw
            assertThat(result).isNotNull();
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // RTL helper methods
    // ══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("RTL helper methods")
    class RtlHelpers {

        @Test @DisplayName("hasRtlComponent: Arabic operand → true")
        void hasRtl_arabic() {
            assertThat(ScriptDetector.hasRtlComponent("السعر", "price")).isTrue();
        }

        @Test @DisplayName("hasRtlComponent: Hebrew operand → true")
        void hasRtl_hebrew() {
            assertThat(ScriptDetector.hasRtlComponent("מידע", "information")).isTrue();
        }

        @Test @DisplayName("hasRtlComponent: Latin-only → false")
        void hasRtl_latinOnly() {
            assertThat(ScriptDetector.hasRtlComponent("insider", "trading")).isFalse();
        }

        @Test @DisplayName("hasRtlComponent: CJK-only → false")
        void hasRtl_cjkOnly() {
            assertThat(ScriptDetector.hasRtlComponent("内幕", "交易")).isFalse();
        }

        @Test @DisplayName("isPurelyRtl: both Arabic → true")
        void isPurelyRtl_bothArabic() {
            assertThat(ScriptDetector.isPurelyRtl("السعر", "التلاعب")).isTrue();
        }

        @Test @DisplayName("isPurelyRtl: both Hebrew → true")
        void isPurelyRtl_bothHebrew() {
            assertThat(ScriptDetector.isPurelyRtl("מידע", "פנים")).isTrue();
        }

        @Test @DisplayName("isPurelyRtl: Arabic + Latin → false")
        void isPurelyRtl_mixed() {
            assertThat(ScriptDetector.isPurelyRtl("السعر", "price")).isFalse();
        }
    }
}
