package com.db.macs3.ecomms.spectre.engine;

import com.db.macs3.ecomms.spectre.model.FeatureDecisionRow;
import com.db.macs3.ecomms.spectre.model.ScanOutputRow;
import com.db.macs3.ecomms.spectre.model.TermMatch;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.spark.api.java.function.MapPartitionsFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Core Spark executor logic — processes one partition of messages + features.
 *
 * <p>This function is executed on Spark executors inside a {@code mapPartitions} call.
 * It receives an {@link Iterator<Row>} where each Row contains:
 * <ul>
 *   <li>message fields (message_id, source_type, run_date, sent_date,
 *       content_raw_text, attachment_texts)</li>
 *   <li>a grouped features array (all FeatureDecisionRow data for this message)</li>
 * </ul>
 *
 * <h2>Per-partition processing</h2>
 * <ol>
 *   <li>Separate features into noise-reduction and standard groups</li>
 *   <li>Scan noise-reduction features first against message body + attachments</li>
 *   <li>Evaluate the noise-reduction decision (OR/AND logic)</li>
 *   <li>If not suppressed, scan standard features</li>
 *   <li>Build {@link ScanOutputRow}s for every feature that produced at least one match</li>
 * </ol>
 *
 * <h2>Memory management</h2>
 * <p>Hyperscan Database objects are cached in a static JVM-level map inside
 * {@link HyperscanMatcher}. Scanner objects are created per-scan and closed
 * immediately after use (native memory management via try-with-resources inside
 * HyperscanMatcher.performScan). This partition function itself has no native
 * resources to manage.
 */
public class LexiconScanPartitionFunction
        implements MapPartitionsFunction<Row, ScanOutputRow> {

    private static final long serialVersionUID = 1L;
    private static final Logger log = LoggerFactory.getLogger(LexiconScanPartitionFunction.class);

    private final Broadcast<Map<String, byte[]>> broadcastHdbBytes;
    private final String                          policyEngineId;
    private final String                          pipelineExecId;

    // These are serializable, so they can be part of the closure
    private final HyperscanMatcher         matcher;
    private final NoiseReductionEvaluator  noiseEvaluator;
    private final ObjectMapper             objectMapper;

    public LexiconScanPartitionFunction(Broadcast<Map<String, byte[]>> broadcastHdbBytes,
                                         String policyEngineId,
                                         String pipelineExecId) {
        this.broadcastHdbBytes = broadcastHdbBytes;
        this.policyEngineId    = policyEngineId;
        this.pipelineExecId    = pipelineExecId;
        this.matcher           = new HyperscanMatcher();
        this.noiseEvaluator    = new NoiseReductionEvaluator();
        this.objectMapper      = new ObjectMapper();
    }

    @Override
    public Iterator<ScanOutputRow> call(Iterator<Row> partition) {
        List<ScanOutputRow> results = new ArrayList<>();
        int messageCount = 0;

        while (partition.hasNext()) {
            Row row = partition.next();
            messageCount++;

            try {
                List<ScanOutputRow> messageResults = processMessage(row);
                results.addAll(messageResults);
            } catch (Exception e) {
                String msgId = getStringField(row, "message_id");
                log.error("Failed to process message '{}': {}", msgId, e.getMessage(), e);
                // Continue processing remaining messages in this partition
            }
        }

        log.info("Partition done: {} messages processed, {} hit records produced",
                 messageCount, results.size());
        return results.iterator();
    }

    // ── Message processing ────────────────────────────────────────────────────

    /**
     * Processes a single message: runs the noise-reduction decision tree,
     * then applies standard features if appropriate.
     *
     * @param row the Spark Row containing message fields + grouped features
     * @return list of ScanOutputRow — one per feature that produced any match
     */
    @SuppressWarnings("unchecked")
    private List<ScanOutputRow> processMessage(Row row) {
        String messageId      = getStringField(row, "message_id");
        String sourceType     = getStringField(row, "source_type");
        String runDate        = getStringField(row, "run_date");
        String sentDate       = getStringField(row, "sent_date");
        String contentRawText = getStringField(row, "content_raw_text");

        // Extract attachment texts (Array<String> column)
        List<String> attachmentTexts = extractAttachmentTexts(row);

        // Extract features for this message (collect_list of struct rows)
        List<FeatureDecisionRow> allFeatures = extractFeatures(row);
        if (allFeatures.isEmpty()) {
            log.debug("Message '{}' has no applicable features — skipping", messageId);
            return Collections.emptyList();
        }

        // Separate noise-reduction from standard features
        List<FeatureDecisionRow> noiseFeatures = allFeatures.stream()
                .filter(FeatureDecisionRow::isNoiseReduction)
                .collect(Collectors.toList());
        List<FeatureDecisionRow> stdFeatures = allFeatures.stream()
                .filter(f -> !f.isNoiseReduction())
                .collect(Collectors.toList());

        log.debug("Message '{}': {} NR features, {} standard features",
                  messageId, noiseFeatures.size(), stdFeatures.size());

        List<ScanOutputRow> results = new ArrayList<>();

        // ── Step 1: Scan noise-reduction features ─────────────────────────────
        if (!noiseFeatures.isEmpty()) {
            Map<String, List<TermMatch>> nrResults = scanFeatures(
                    noiseFeatures, contentRawText, attachmentTexts, messageId, "NR");

            // ── Step 2: Noise-reduction decision ──────────────────────────────
            boolean skipStandard = noiseEvaluator.shouldSkipStandardFeatures(noiseFeatures, nrResults);

            // Emit rows for NR features that matched (regardless of the skip decision)
            for (FeatureDecisionRow nrFeat : noiseFeatures) {
                List<TermMatch> matches = nrResults.getOrDefault(nrFeat.getFeatureName(), List.of());
                if (!matches.isEmpty()) {
                    results.add(buildOutputRow(messageId, runDate, sentDate, sourceType,
                                               nrFeat, contentRawText, attachmentTexts,
                                               nrResults));
                }
            }

            if (skipStandard) {
                log.debug("Message '{}': noise reduction matched (op={}) — skipping standard features",
                          messageId, noiseEvaluator.resolveOperator(noiseFeatures));
                return results;
            }
        }

        // ── Step 3: Scan standard features ────────────────────────────────────
        if (!stdFeatures.isEmpty()) {
            Map<String, List<TermMatch>> stdResults = scanFeatures(
                    stdFeatures, contentRawText, attachmentTexts, messageId, "STD");

            for (FeatureDecisionRow stdFeat : stdFeatures) {
                List<TermMatch> matches = stdResults.getOrDefault(stdFeat.getFeatureName(), List.of());
                if (!matches.isEmpty()) {
                    results.add(buildOutputRow(messageId, runDate, sentDate, sourceType,
                                               stdFeat, contentRawText, attachmentTexts,
                                               stdResults));
                }
            }
        }

        return results;
    }

    // ── Scanning ──────────────────────────────────────────────────────────────

    /**
     * Runs the Hyperscan scanner for each feature against the message body and
     * each attachment. Returns a map of featureName → combined list of matches
     * (body matches first, then attachment matches in order).
     *
     * @param features        features to scan
     * @param contentRawText  message body text
     * @param attachmentTexts attachment raw texts in order
     * @param messageId       for logging
     * @param label           "NR" or "STD" for log clarity
     * @return map of featureName → matches across all text segments
     */
    private Map<String, List<TermMatch>> scanFeatures(List<FeatureDecisionRow> features,
                                                        String contentRawText,
                                                        List<String> attachmentTexts,
                                                        String messageId,
                                                        String label) {
        Map<String, List<TermMatch>> featureResults = new HashMap<>();

        for (FeatureDecisionRow feature : features) {
            String featureName = feature.getFeatureName();
            List<TermMatch> allMatches = new ArrayList<>();

            // Scan message body
            if (contentRawText != null && !contentRawText.isBlank()) {
                List<TermMatch> bodyMatches = matcher.scan(featureName, contentRawText, broadcastHdbBytes);
                allMatches.addAll(bodyMatches);
                log.trace("[{}] {} '{}' body: {} matches",
                          label, messageId, featureName, bodyMatches.size());
            }

            // Scan each attachment
            for (String attText : attachmentTexts) {
                if (attText != null && !attText.isBlank()) {
                    List<TermMatch> attMatches = matcher.scan(featureName, attText, broadcastHdbBytes);
                    allMatches.addAll(attMatches);
                }
            }

            featureResults.put(featureName, allMatches);
            if (!allMatches.isEmpty()) {
                log.debug("[{}] '{}' feature '{}': {} total matches",
                          label, messageId, featureName, allMatches.size());
            }
        }

        return featureResults;
    }

    // ── Output construction ───────────────────────────────────────────────────

    /**
     * Builds one {@link ScanOutputRow} for a feature that produced at least one match.
     */
    private ScanOutputRow buildOutputRow(String messageId,
                                          String runDate,
                                          String sentDate,
                                          String sourceType,
                                          FeatureDecisionRow feature,
                                          String contentRawText,
                                          List<String> attachmentTexts,
                                          Map<String, List<TermMatch>> allResults) {
        // Re-run the per-segment scan results to split them into body vs attachments
        // for the hit_details JSON (the allResults map has them combined)
        String featureName = feature.getFeatureName();
        List<TermMatch> bodyMatches = matcher.scan(featureName, contentRawText, broadcastHdbBytes);

        List<List<TermMatch>> attMatchesByIndex = new ArrayList<>();
        for (String attText : attachmentTexts) {
            attMatchesByIndex.add(matcher.scan(featureName, attText, broadcastHdbBytes));
        }

        // Distinct expression IDs that hit (for lexiconTermsHit column)
        Set<Integer> hitExprIds = allResults.getOrDefault(featureName, List.of())
                .stream()
                .map(TermMatch::getExpressionId)
                .collect(Collectors.toCollection(TreeSet::new));

        String lexiconTermsHit = hitExprIds.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(","));

        // Total terms from the .hdb — we get this from the Database via HyperscanMatcher
        // In practice, the term count is stored alongside the .hdb (from the compile service).
        // For now, approximate with the total expressions visible from hit result IDs.
        // A production implementation would load the term count from the .hdb metadata.
        int hitCount   = hitExprIds.size();
        int totalCount = hitCount; // Will be replaced with actual count from DB metadata

        ScanOutputRow out = new ScanOutputRow();
        out.setMessageId(messageId);
        out.setRunDate(runDate);
        out.setSentDate(sentDate);
        out.setPolicyEngineId(policyEngineId);
        out.setPipelineExecId(pipelineExecId);
        out.setFeatureName(featureName);
        out.setFeatureType(feature.getFeatureType());
        out.setNoiseReduction(feature.isNoiseReduction());
        out.setFeatureOperator(feature.getFeatureOperator());
        out.setLexiconTermsHit(lexiconTermsHit);
        out.setTotalCountOfTerms(totalCount);
        out.setHitCountOfTerms(hitCount);
        out.setHitDetails(buildHitDetailsJson(bodyMatches, attMatchesByIndex));
        out.setProcessTs(Timestamp.from(Instant.now()));

        return out;
    }

    /**
     * Builds the {@code hit_details} JSON string.
     *
     * <p>Structure:
     * <pre>
     * {
     *   "msg": { "matches": [ {"term_id":0,"match_text":"bomb","start_index":14,"end_index":17,"delta":0} ] },
     *   "attachment-0": { "matches": [ ... ] },
     *   "attachment-1": { "matches": [ ... ] }
     * }
     * </pre>
     */
    private String buildHitDetailsJson(List<TermMatch> bodyMatches,
                                        List<List<TermMatch>> attMatchesByIndex) {
        try {
            ObjectNode root = objectMapper.createObjectNode();

            // Message body
            if (!bodyMatches.isEmpty()) {
                root.set("msg", buildMatchesNode(bodyMatches));
            }

            // Attachments
            for (int i = 0; i < attMatchesByIndex.size(); i++) {
                List<TermMatch> attMatches = attMatchesByIndex.get(i);
                if (!attMatches.isEmpty()) {
                    root.set("attachment-" + i, buildMatchesNode(attMatches));
                }
            }

            return objectMapper.writeValueAsString(root);
        } catch (Exception e) {
            log.error("Failed to serialize hit_details: {}", e.getMessage(), e);
            return "{}";
        }
    }

    private ObjectNode buildMatchesNode(List<TermMatch> matches) {
        ObjectNode node       = objectMapper.createObjectNode();
        ArrayNode  matchArray = objectMapper.createArrayNode();

        for (TermMatch m : matches) {
            ObjectNode matchNode = objectMapper.createObjectNode();
            matchNode.put("term_id",     m.getExpressionId());
            matchNode.put("match_text",  m.getMatchText() != null ? m.getMatchText() : "");
            matchNode.put("start_index", m.getStartIndex());
            matchNode.put("end_index",   m.getEndIndex());
            matchNode.put("delta",       m.getDelta());
            matchArray.add(matchNode);
        }
        node.set("matches", matchArray);
        return node;
    }

    // ── Row field extraction helpers ──────────────────────────────────────────

    private static String getStringField(Row row, String fieldName) {
        try {
            int idx = row.fieldIndex(fieldName);
            return row.isNullAt(idx) ? null : row.getString(idx);
        } catch (IllegalArgumentException e) {
            return null; // field not present
        }
    }

    @SuppressWarnings("unchecked")
    private static List<String> extractAttachmentTexts(Row row) {
        try {
            int idx = row.fieldIndex("attachment_texts");
            if (row.isNullAt(idx)) return Collections.emptyList();
            scala.collection.Seq<Object> seq = row.getSeq(idx);
            List<String> result = new ArrayList<>();
            if (seq != null) {
                scala.collection.Iterator<Object> it = seq.iterator();
                while (it.hasNext()) {
                    Object val = it.next();
                    if (val != null) result.add(val.toString());
                }
            }
            return result;
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    /**
     * Extracts the features collected by {@code collect_list(struct(...))} in the
     * Spark aggregation step. Each element of the array is a Spark Row representing
     * one FeatureDecisionRow.
     */
    @SuppressWarnings("unchecked")
    private static List<FeatureDecisionRow> extractFeatures(Row row) {
        try {
            int idx = row.fieldIndex("features");
            if (row.isNullAt(idx)) return Collections.emptyList();
            scala.collection.Seq<Row> seq = row.getSeq(idx);
            List<FeatureDecisionRow> result = new ArrayList<>();
            if (seq != null) {
                scala.collection.Iterator<Row> it = seq.iterator();
                while (it.hasNext()) {
                    Row featRow = it.next();
                    result.add(rowToFeature(featRow));
                }
            }
            return result;
        } catch (Exception e) {
            log.warn("Failed to extract features from row: {}", e.getMessage());
            return Collections.emptyList();
        }
    }

    private static FeatureDecisionRow rowToFeature(Row r) {
        return FeatureDecisionRow.of(
                getField(r, "process_id"),
                getField(r, "message_id"),
                getField(r, "run_date"),
                getField(r, "sent_date"),
                getField(r, "feature_type"),
                r.isNullAt(r.fieldIndex("feature_id")) ? null : r.getLong(r.fieldIndex("feature_id")),
                getField(r, "feature_name"),
                getField(r, "feature_operator"),
                !r.isNullAt(r.fieldIndex("is_noise_reduction")) && r.getBoolean(r.fieldIndex("is_noise_reduction")),
                getField(r, "fm_feature_definition")
        );
    }

    private static String getField(Row row, String name) {
        try {
            int idx = row.fieldIndex(name);
            return row.isNullAt(idx) ? null : row.getString(idx);
        } catch (Exception e) {
            return null;
        }
    }
}
