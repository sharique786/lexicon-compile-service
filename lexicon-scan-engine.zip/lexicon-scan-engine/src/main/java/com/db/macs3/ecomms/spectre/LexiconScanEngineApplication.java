package com.db.macs3.ecomms.spectre;

import com.db.macs3.ecomms.spectre.engine.LexiconScanEngine;
import com.db.macs3.ecomms.spectre.model.ScanEngineArgs;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * Entry point for the Lexicon Scan Engine Spark Dataproc job.
 *
 * <h2>Invocation</h2>
 * <p>Submitted to Dataproc via:
 * <pre>
 * gcloud dataproc jobs submit spark \
 *   --cluster=my-cluster \
 *   --region=us-central1 \
 *   --jar=gs://bucket/jars/lexicon-scan-engine-1.0.0.jar \
 *   -- \
 *   --processId abc123 \
 *   --pipelineExecId exec-456 \
 *   --policyEngineId policy-789 \
 *   --triggerType POLICY_DEPLOYMENT \
 *   --runDate 2026-06-25 \
 *   --hdbGcsBucket my-hdb-bucket \
 *   --hdbGcsPrefix hyperscan-databases \
 *   --msgGcsBucket my-msg-bucket \
 *   --msgGcsPrefix messages \
 *   --bqProject my-gcp-project \
 *   --bqDataset spectre_audit_working
 * </pre>
 *
 * <h2>Spring Boot configuration for batch jobs</h2>
 * <p>Spring Boot is used only for dependency injection and configuration binding
 * — no embedded web server is started ({@code spring.main.web-application-type=none}
 * in {@code application.yml}). The application exits after
 * {@link LexiconScanEngine#run} completes.
 *
 * <h2>Exit codes</h2>
 * <ul>
 *   <li>0 — successful completion</li>
 *   <li>1 — argument parse failure</li>
 *   <li>2 — runtime error (IO, scan failure, BQ write failure)</li>
 * </ul>
 */
@SpringBootApplication
public class LexiconScanEngineApplication {

    private static final Logger log = LoggerFactory.getLogger(LexiconScanEngineApplication.class);

    /**
     * Main method — called by the Spark driver JVM on the Dataproc master node.
     *
     * @param args command-line arguments in {@code --key value} format (see class Javadoc)
     */
    public static void main(String[] args) {
        log.info("=== Lexicon Scan Engine Starting ===");
        log.info("Raw args count: {}", args.length);

        // ── Parse typed runtime arguments first (before Spring startup) ───────
        ScanEngineArgs scanEngineArgs;
        try {
            scanEngineArgs = ScanEngineArgs.parse(args);
            log.info("Parsed runtime args: {}", scanEngineArgs);
        } catch (IllegalArgumentException e) {
            log.error("Failed to parse runtime arguments: {}", e.getMessage());
            System.exit(1);
            return;
        }

        // ── Start Spring Application Context ──────────────────────────────────
        // Spring wires up LexiconScanEngine, BigQueryViewReader, etc. via DI.
        // The SparkSession bean is created by AppConfig and injected into components.
        ConfigurableApplicationContext ctx = null;
        try {
            SpringApplication app = new SpringApplication(LexiconScanEngineApplication.class);
            // Pass runtime args so @Value-annotated fields can pick up any Spring properties
            ctx = app.run(args);

            // ── Retrieve components from Spring context ────────────────────────
            SparkSession     spark  = ctx.getBean(SparkSession.class);
            LexiconScanEngine engine = ctx.getBean(LexiconScanEngine.class);

            // ── Execute the scan pipeline ─────────────────────────────────────
            log.info("=== Pipeline execution starting ===");
            engine.run(spark, scanEngineArgs);
            log.info("=== Pipeline execution complete ===");

        } catch (Exception e) {
            log.error("Lexicon Scan Engine failed with unexpected error: {}", e.getMessage(), e);
            System.exit(2);
        } finally {
            // Ensure Spring context is closed cleanly so Spark shutdown hooks run
            if (ctx != null) {
                ctx.close();
            }
        }

        log.info("=== Lexicon Scan Engine Finished ===");
        System.exit(0);
    }
}
