package com.db.macs3.ecomms.spectre.translator;

import com.db.macs3.ecomms.spectre.translator.MultiLanguagePatternBuilder.BuildResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Translates a raw lexicon term operator expression into a Hyperscan PCRE
 * pattern and recommends the Hyperscan expression flag bitmask.
 *
 * <h2>Integration diff — what changed</h2>
 * <p>Only the NEAR and FOLLOWEDBY branches changed.  All other operators
 * (OR, AND, AND NOT, NOT, wildcard, quoted phrase, literal) are unchanged.
 *
 * <pre>{@code
 * // ── BEFORE (word-only gap, breaks CJK / no-space languages) ──────────
 * private String buildNearPattern(String a, String b, int n) {
 *     String gap = "(?:\\s+\\S+){0,%d}\\s+".formatted(n);
 *     return "(?:%s%s%s|%s%s%s)".formatted(a, gap, b, b, gap, a);
 * }
 * private String buildFollowedByPattern(String a, String b, int n) {
 *     String gap = "(?:\\s+\\S+){0,%d}\\s+".formatted(n);
 *     return "%s%s%s".formatted(a, gap, b);
 * }
 *
 * // ── AFTER (language-aware, uses MultiLanguagePatternBuilder) ──────────
 * private TranslationResult buildNearPattern(String a, String b, int n) {
 *     BuildResult r = MultiLanguagePatternBuilder.buildNear(a, b, n);
 *     return new TranslationResult(r.pattern(), r.recommendedHsFlags(), false);
 * }
 * private TranslationResult buildFollowedByPattern(String a, String b, int n) {
 *     BuildResult r = MultiLanguagePatternBuilder.buildFollowedBy(a, b, n);
 *     return new TranslationResult(r.pattern(), r.recommendedHsFlags(), false,
 *                                  r.warning());
 * }
 * }</pre>
 *
 * <p>This file is a self-contained reference implementation showing the full
 * operator translation pipeline with the new multi-language support wired in.
 * In the existing project, merge these methods into the current translator class.
 */
public class LexiconTermTranslator {

    private static final Logger log = LoggerFactory.getLogger(LexiconTermTranslator.class);

    // ── Operator regex patterns ────────────────────────────────────────────
    private static final Pattern NEAR_PATTERN      = Pattern.compile(
            "^(.+?)\\s+NEAR\\{(\\d+)}\\s+(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern FOLLOWED_PATTERN  = Pattern.compile(
            "^(.+?)\\s+FOLLOWEDBY\\{(\\d+)}\\s+(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern OR_PATTERN        = Pattern.compile(
            "\\s+OR\\s+", Pattern.CASE_INSENSITIVE);
    private static final Pattern AND_PATTERN       = Pattern.compile(
            "\\s+AND\\s+", Pattern.CASE_INSENSITIVE);
    private static final Pattern AND_NOT_PATTERN   = Pattern.compile(
            "\\s+AND\\s+NOT\\s+", Pattern.CASE_INSENSITIVE);
    private static final Pattern WILDCARD_PATTERN  = Pattern.compile("\\*");
    private static final Pattern QUOTED_PHRASE     = Pattern.compile("^\"(.+)\"$");

    // ── Default Hyperscan flags ────────────────────────────────────────────
    static final int HS_CASELESS   = 1;
    static final int HS_DOTALL     = 2;
    static final int HS_UTF8       = 32;
    static final int HS_UCP        = 64;

    /** Default: CASELESS + DOTALL */
    static final int FLAGS_LATIN   = HS_CASELESS | HS_DOTALL;
    /** For any non-ASCII content: adds UTF8 + UCP so \\S/\\s match Unicode */
    static final int FLAGS_UNICODE = HS_CASELESS | HS_DOTALL | HS_UTF8 | HS_UCP;

    // ── Translation result ─────────────────────────────────────────────────

    /**
     * Holds one term's translation result.
     *
     * @param pattern              Hyperscan PCRE pattern
     * @param hsFlags              recommended Hyperscan expression flags bitmask
     * @param requiresAndPostFilter true for AND / AND NOT terms (OR pre-scan only)
     * @param warning              non-null for mixed-direction FOLLOWEDBY
     */
    public record TranslationResult(
            String  pattern,
            int     hsFlags,
            boolean requiresAndPostFilter,
            String  warning
    ) {
        public TranslationResult(String pattern, int flags, boolean andFilter) {
            this(pattern, flags, andFilter, null);
        }
    }

    // ── Main translation entry point ────────────────────────────────────────

    /**
     * Translates a single lexicon term description into a Hyperscan PCRE
     * pattern.
     *
     * @param termDescription the raw operator expression (e.g. "내부자 NEAR{3} 거래")
     * @return {@link TranslationResult} or throws {@link TranslationException}
     *         when the expression cannot be parsed
     */
    public TranslationResult translate(String termDescription) {
        if (termDescription == null || termDescription.isBlank()) {
            throw new TranslationException("Term description must not be blank");
        }

        String desc = termDescription.strip();
        log.debug("Translating term: '{}'", desc);

        // ── NEAR{n} ───────────────────────────────────────────────────────
        Matcher near = NEAR_PATTERN.matcher(desc);
        if (near.matches()) {
            String a = escapeForPcre(near.group(1).strip());
            int    n = Integer.parseInt(near.group(2));
            String b = escapeForPcre(near.group(3).strip());
            return translateNear(a, b, n);
        }

        // ── FOLLOWEDBY{n} ─────────────────────────────────────────────────
        Matcher fb = FOLLOWED_PATTERN.matcher(desc);
        if (fb.matches()) {
            String a = escapeForPcre(fb.group(1).strip());
            int    n = Integer.parseInt(fb.group(2));
            String b = escapeForPcre(fb.group(3).strip());
            return translateFollowedBy(a, b, n);
        }

        // ── AND NOT ───────────────────────────────────────────────────────
        if (AND_NOT_PATTERN.matcher(desc).find()) {
            String[] parts = AND_NOT_PATTERN.split(desc, 2);
            String positive = escapeForPcre(parts[0].strip());
            int flags = MultiLanguagePatternBuilder.recommendedHsFlags(
                    parts[0].strip(), parts.length > 1 ? parts[1].strip() : "");
            return new TranslationResult(positive, flags, true);
        }

        // ── AND ───────────────────────────────────────────────────────────
        if (AND_PATTERN.matcher(desc).find()) {
            String[] parts = AND_PATTERN.split(desc);
            String combined = buildOrAlternation(parts);
            int flags = recommendFlagsForMultiple(parts);
            return new TranslationResult(combined, flags, true);
        }

        // ── OR ────────────────────────────────────────────────────────────
        if (OR_PATTERN.matcher(desc).find()) {
            String[] parts = OR_PATTERN.split(desc);
            String combined = buildOrAlternation(parts);
            int flags = recommendFlagsForMultiple(parts);
            return new TranslationResult(combined, flags, false);
        }

        // ── Quoted phrase ─────────────────────────────────────────────────
        Matcher quoted = QUOTED_PHRASE.matcher(desc);
        if (quoted.matches()) {
            String phrase = quoted.group(1);
            // Each word in the phrase separated by flexible whitespace
            String[] words = phrase.split("\\s+");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < words.length; i++) {
                if (i > 0) sb.append("\\s+");
                sb.append(escapeForPcre(words[i]));
            }
            int flags = MultiLanguagePatternBuilder.recommendedHsFlags(phrase, "");
            return new TranslationResult(sb.toString(), flags, false);
        }

        // ── Wildcard ──────────────────────────────────────────────────────
        if (desc.contains("*")) {
            String wildcarded = WILDCARD_PATTERN.matcher(escapeForPcre(desc))
                    .replaceAll("\\\\S*");
            int flags = MultiLanguagePatternBuilder.recommendedHsFlags(desc, "");
            return new TranslationResult(wildcarded, flags, false);
        }

        // ── Literal ───────────────────────────────────────────────────────
        String escaped = escapeForPcre(desc);
        int flags = MultiLanguagePatternBuilder.recommendedHsFlags(desc, "");
        return new TranslationResult(escaped, flags, false);
    }

    // ── NEAR translation ────────────────────────────────────────────────────

    /**
     * Delegates to {@link MultiLanguagePatternBuilder#buildNear} — this is
     * the key change from the original implementation.
     *
     * <p>The old code was:
     * <pre>{@code
     * String gap = "(?:\\s+\\S+){0,%d}\\s+".formatted(n);
     * return new TranslationResult("(?:%s%s%s|%s%s%s)".formatted(a,gap,b,b,gap,a),
     *                              FLAGS_LATIN, false);
     * }</pre>
     * That ignored the script type and always used a word-gap that failed
     * for CJK / Korean / Thai.
     */
    private TranslationResult translateNear(String a, String b, int n) {
        BuildResult r = MultiLanguagePatternBuilder.buildNear(a, b, n);
        log.debug("NEAR translated: script={}, flags={}", r.scriptType(), r.recommendedHsFlags());
        return new TranslationResult(r.pattern(), r.recommendedHsFlags(), false, r.warning());
    }

    // ── FOLLOWEDBY translation ──────────────────────────────────────────────

    /**
     * Delegates to {@link MultiLanguagePatternBuilder#buildFollowedBy}.
     * Includes a warning when operands mix RTL and LTR scripts, because
     * the logical-order match may not match the user's visual intent.
     */
    private TranslationResult translateFollowedBy(String a, String b, int n) {
        BuildResult r = MultiLanguagePatternBuilder.buildFollowedBy(a, b, n);
        if (r.hasWarning()) {
            log.warn("FOLLOWEDBY RTL warning: {}", r.warning());
        }
        log.debug("FOLLOWEDBY translated: script={}, flags={}", r.scriptType(), r.recommendedHsFlags());
        return new TranslationResult(r.pattern(), r.recommendedHsFlags(), false, r.warning());
    }

    // ── Utilities ────────────────────────────────────────────────────────────

    private String buildOrAlternation(String[] parts) {
        StringBuilder sb = new StringBuilder("(?:");
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append("|");
            sb.append(escapeForPcre(parts[i].strip()));
        }
        sb.append(")");
        return sb.toString();
    }

    private int recommendFlagsForMultiple(String[] parts) {
        for (String part : parts) {
            int flags = MultiLanguagePatternBuilder.recommendedHsFlags(part.strip(), "");
            if (flags == FLAGS_UNICODE) return FLAGS_UNICODE;
        }
        return FLAGS_LATIN;
    }

    /**
     * Escapes a raw term value so it is safe to embed in a PCRE pattern.
     * Does NOT escape {@code *} (wildcard — handled separately) or
     * Unicode characters (they pass through verbatim).
     */
    static String escapeForPcre(String raw) {
        // Escape PCRE metacharacters except * (used for wildcard operator)
        return raw.replaceAll("([.+?^${}()|\\[\\]\\\\])", "\\\\$1");
    }

    // ── Exception ─────────────────────────────────────────────────────────

    public static class TranslationException extends RuntimeException {
        public TranslationException(String msg) { super(msg); }
    }
}
