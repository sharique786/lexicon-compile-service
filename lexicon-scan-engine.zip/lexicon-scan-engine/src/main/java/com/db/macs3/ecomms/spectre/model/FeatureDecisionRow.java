package com.db.macs3.ecomms.spectre.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Represents one row from the pre-computed BigQuery view that joins
 * {@code spectre-audit.language-feature-decision} (LHS) with
 * {@code spectre-audit.feature-master} (RHS).
 *
 * <p>One row = one (message_id, feature_name) pair.
 * A single message can produce multiple rows if it is associated with
 * several lexicon features.
 *
 * <p>This class is used as a Spark {@code Dataset<FeatureDecisionRow>} row.
 * All fields must be public (or have getters/setters) with a no-arg constructor
 * for Spark's {@code Encoders.bean()} to work correctly.
 */
public class FeatureDecisionRow implements Serializable {

    private static final long serialVersionUID = 1L;

    // ── From language-feature-decision (LHS) ──────────────────────────────────
    /** process_id — the join key with feature-master.policy_engine_id. */
    private String processId;

    /** message_id — corresponds to message files in GCS. */
    private String messageId;

    /** run_date in yyyy-MM-dd format. */
    private String runDate;

    /** sent_date in yyyy-MM-dd format. */
    private String sentDate;

    /**
     * Feature type as seen in language-feature-decision (e.g. "composite", "lexicon").
     * Note: this is the LFD view's feature type, not feature-master's feature_type.
     */
    private String featureType;

    /** Numeric feature ID from language-feature-decision. */
    private Long featureId;

    /**
     * Feature name — must match the .hdb filename (without .hdb extension).
     * e.g. "lexicon_market_cond_4" → "lexicon_market_cond_4.hdb"
     */
    private String featureName;

    /**
     * Feature operator: "OR" or "AND".
     * Used for noise-reduction multi-feature evaluation.
     */
    private String featureOperator;

    /**
     * Whether this feature is a noise-reduction feature.
     * Engine processes noise-reduction features FIRST; if they match,
     * standard features are skipped.
     */
    private boolean isNoiseReduction;

    // ── From feature-master (RHS) ─────────────────────────────────────────────
    /**
     * The resolved feature definition JSON from feature-master.
     * For "lexicon" type: from feature_definition column.
     * For "Composite" type: from sub_features[*].definition where sub_feature.type = 'lexicon'.
     */
    private String fmFeatureDefinition;

    // ── No-arg constructor (required for Spark Encoder) ───────────────────────
    public FeatureDecisionRow() {}

    // ── Convenience factory ───────────────────────────────────────────────────

    public static FeatureDecisionRow of(String processId, String messageId, String runDate,
                                         String sentDate, String featureType, Long featureId,
                                         String featureName, String featureOperator,
                                         boolean isNoiseReduction, String fmFeatureDefinition) {
        FeatureDecisionRow row = new FeatureDecisionRow();
        row.processId           = processId;
        row.messageId           = messageId;
        row.runDate             = runDate;
        row.sentDate            = sentDate;
        row.featureType         = featureType;
        row.featureId           = featureId;
        row.featureName         = featureName;
        row.featureOperator     = featureOperator;
        row.isNoiseReduction    = isNoiseReduction;
        row.fmFeatureDefinition = fmFeatureDefinition;
        return row;
    }

    // ── Getters and setters ───────────────────────────────────────────────────

    public String getProcessId()            { return processId; }
    public void setProcessId(String v)      { this.processId = v; }

    public String getMessageId()            { return messageId; }
    public void setMessageId(String v)      { this.messageId = v; }

    public String getRunDate()              { return runDate; }
    public void setRunDate(String v)        { this.runDate = v; }

    public String getSentDate()             { return sentDate; }
    public void setSentDate(String v)       { this.sentDate = v; }

    public String getFeatureType()          { return featureType; }
    public void setFeatureType(String v)    { this.featureType = v; }

    public Long getFeatureId()              { return featureId; }
    public void setFeatureId(Long v)        { this.featureId = v; }

    public String getFeatureName()          { return featureName; }
    public void setFeatureName(String v)    { this.featureName = v; }

    public String getFeatureOperator()      { return featureOperator; }
    public void setFeatureOperator(String v){ this.featureOperator = v; }

    public boolean isNoiseReduction()       { return isNoiseReduction; }
    public void setNoiseReduction(boolean v){ this.isNoiseReduction = v; }

    public String getFmFeatureDefinition()          { return fmFeatureDefinition; }
    public void setFmFeatureDefinition(String v)    { this.fmFeatureDefinition = v; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FeatureDecisionRow that = (FeatureDecisionRow) o;
        return Objects.equals(messageId, that.messageId) &&
               Objects.equals(featureName, that.featureName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(messageId, featureName);
    }

    @Override
    public String toString() {
        return "FeatureDecisionRow{messageId='" + messageId +
               "', featureName='" + featureName +
               "', isNoiseReduction=" + isNoiseReduction +
               "', featureOperator='" + featureOperator + "'}";
    }
}
