# Lexicon Scanner Service

Spring Boot 4 · Java 21 · Intel Hyperscan · GKE / Compute Engine

A **testing harness** for the Lexicon Compile Service.  
Upload lexicon terms (or a CSV) plus a communication message (or file), and the service:

1. Calls the **Lexicon Compile Service** to translate each term into a Hyperscan PCRE pattern.  
2. Compiles a **Hyperscan database** from all PASS patterns.  
3. **Scans** the message with Intel Hyperscan (with Java-regex fallback for test environments).  
4. Returns the **highlighted message** (HTML `<mark>` tags) and per-term match results.

A built-in **micro-frontend web UI** is served at `/` — it can be embedded in any host web application.

---

## Project structure

```
src/
├── main/java/com/db/macs3/ecomms/spectre/
│   ├── LexiconScannerApp.java          — Spring Boot entry point
│   ├── config/
│   │   ├── AppProperties.java          — @ConfigurationProperties
│   │   ├── GzipRequestFilter.java      — GZIP decompression filter
│   │   └── RestClientConfig.java       — RestClient bean + CORS + static resources
│   ├── model/
│   │   └── Models.java                 — All domain records (request / response / internal)
│   ├── client/
│   │   └── LexiconCompileClient.java   — HTTP client for Lexicon Compile Service
│   ├── service/
│   │   ├── CsvParserService.java       — OpenCSV-based CSV term parser
│   │   ├── HyperscanScanService.java   — Hyperscan compile + scan (+ Java-regex fallback)
│   │   ├── MatchHighlightService.java  — Byte-offset → char-index, HTML <mark> builder
│   │   └── LexiconScanOrchestrator.java— Full pipeline orchestration
│   └── controller/
│       ├── ScanController.java         — REST endpoints
│       └── GlobalExceptionHandler.java — Domain exception → HTTP response
├── main/resources/
│   ├── application.yml                 — Config (default, docker, cloud-run profiles)
│   └── static/index.html               — Self-contained micro-frontend UI
└── test/java/com/db/macs3/ecomms/spectre/
    ├── service/  CsvParserServiceTest, HyperscanScanServiceTest,
    │             MatchHighlightServiceTest, LexiconScanOrchestratorTest
    ├── client/   LexiconCompileClientTest
    ├── controller/ ScanControllerTest
    └── integration/ MultiLanguageScanIntegrationTest
```

---

## REST API

| Method | Path              | Content-Type              | Description                        |
|--------|-------------------|---------------------------|------------------------------------|
| POST   | `/api/scan`       | `multipart/form-data`     | Primary endpoint (UI form)         |
| POST   | `/api/scan/json`  | `application/json`        | Programmatic / GZIP clients        |
| GET    | `/api/scan/health`| —                         | Liveness probe                     |

### Multipart form fields

| Field         | When required            | Description                                      |
|---------------|--------------------------|--------------------------------------------------|
| `inputMode`   | always                   | `TERMS` or `CSV`                                 |
| `messageMode` | always                   | `TEXT` or `FILE`                                 |
| `terms`       | when inputMode=TERMS      | Newline-separated term descriptions              |
| `csvFile`     | when inputMode=CSV        | CSV file: `term_id,term_description,risk_driver` |
| `messageText` | when messageMode=TEXT     | Raw message text                                 |
| `messageFile` | when messageMode=FILE     | Message file (.txt, .eml, .msg, .html, .log)     |
| `ruleName`    | optional                 | Session name (default: `scanner-test-rule`)      |

### JSON request body (`POST /api/scan/json`)

```json
{
  "inputMode":   "TERMS",
  "messageMode": "TEXT",
  "terms":       "insider AND trading\npump OR dump",
  "messageText": "The insider passed information to his broker.",
  "ruleName":    "my-test-session"
}
```

### Response

```json
{
  "scanId": "3f8a1c2e-...",
  "scanDurationMs": 42,
  "totalTerms": 2,
  "matchedTerms": 1,
  "failedTerms": 0,
  "hasMatches": true,
  "plainMessage": "The insider...",
  "htmlHighlightedMessage": "The <mark class=\"lex-match\">insider</mark> passed...",
  "termResults": [
    {
      "termId": "scanner-test-rule::1",
      "termDescription": "insider AND trading",
      "translatedPattern": "(?:insider|trading)",
      "compilationStatus": "PASS",
      "requiresAndPostFilter": true,
      "matches": [
        { "startCharIndex": 4, "endCharIndex": 11, "matchedText": "insider" }
      ],
      "hasMatches": true,
      "postFilterNote": "AND/NOT semantics: this result shows OR pre-scan matches..."
    }
  ],
  "warnings": [],
  "status": "SUCCESS"
}
```

---

## GZIP support

| Direction | Mechanism                                       |
|-----------|-------------------------------------------------|
| Request   | `GzipRequestFilter` — decompresses gzip bodies |
| Response  | Tomcat `server.compression.*` in application.yml|

Send a gzip-compressed JSON request:
```bash
echo '{"inputMode":"TERMS","messageMode":"TEXT","terms":"insider","messageText":"insider info"}' \
  | gzip | curl -s -X POST http://localhost:8090/api/scan/json \
    -H "Content-Type: application/json" \
    -H "Content-Encoding: gzip" \
    --data-binary @-
```

---

## Local development

```bash
# Prerequisites: Java 21, Maven 3.9+

# 1 — Build and run tests
mvn clean verify

# 2 — Start the service
mvn spring-boot:run

# 3 — Open the UI
open http://localhost:8090

# 4 — Point to a running Lexicon Compile Service
# Edit application.yml or set:
export LEXICON_COMPILE_SERVICE_BASE_URL=http://localhost:8080
mvn spring-boot:run
```

---

## Docker

```bash
# Build JAR
mvn package -DskipTests

# Build image
docker build -t lexicon-scanner-service:latest .

# Run (with Lexicon Compile Service in same Docker network)
docker run -p 8090:8090 \
  -e LEXICON_COMPILE_SERVICE_BASE_URL=http://lexicon-compile-service:8080 \
  lexicon-scanner-service:latest
```

### docker-compose example

```yaml
services:
  lexicon-compile-service:
    image: lexicon-compile-service:latest
    ports: ["8080:8080"]

  lexicon-scanner-service:
    image: lexicon-scanner-service:latest
    ports: ["8090:8090"]
    environment:
      SPRING_PROFILES_ACTIVE: docker
    depends_on: [lexicon-compile-service]
```

---

## GKE / Compute Engine deployment

1. Push the image to Artifact Registry:
   ```bash
   docker tag lexicon-scanner-service:latest \
     europe-west1-docker.pkg.dev/PROJECT/REPO/lexicon-scanner-service:latest
   docker push europe-west1-docker.pkg.dev/PROJECT/REPO/lexicon-scanner-service:latest
   ```

2. Deploy to GKE:
   ```bash
   kubectl set image deployment/lexicon-scanner-service \
     lexicon-scanner-service=europe-west1-docker.pkg.dev/PROJECT/REPO/lexicon-scanner-service:latest
   ```

3. Set `LEXICON_COMPILE_SERVICE_BASE_URL` as a Kubernetes environment variable or Secret.

4. Configure `SPRING_PROFILES_ACTIVE=cloud-run` (the Dockerfile default) which enables:
   - 10 s connect timeout / 60 s read timeout
   - `fallback-to-java-regex=false` (fail fast in production)

---

## Code coverage (JaCoCo)

```bash
mvn verify
open target/site/jacoco/index.html
```

Minimum thresholds enforced at `mvn verify`:
- **Line coverage**: 70 %  
- **Branch coverage**: 60 %

---

## Key technical decisions

| Concern | Decision |
|---------|----------|
| Hyperscan match start positions | `ExpressionFlag.SOM_LEFTMOST` added per expression |
| Test-environment Hyperscan failure | `fallback-to-java-regex=true` default; same `RawMatch` semantics |
| Multi-byte UTF-8 offset mapping | `byteOffsetToCharIndex` / `charIndexToByteOffset` utilities |
| AND/NOT post-filter | OR pre-scan pattern used; `postFilterNote` in response |
| Micro-frontend UI isolation | All CSS/JS scoped inside `.la` / `.lex-*` prefix; no external CDN deps |
| Docker base image | `eclipse-temurin:21-jre-jammy` (glibc, not Alpine) — Hyperscan `.so` requires glibc |
