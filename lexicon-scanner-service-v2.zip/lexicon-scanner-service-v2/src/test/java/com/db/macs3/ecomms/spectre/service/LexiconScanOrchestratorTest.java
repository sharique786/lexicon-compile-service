package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.client.LexiconCompileClient;
import com.db.macs3.ecomms.spectre.model.DisclaimerSource;
import com.db.macs3.ecomms.spectre.model.Models.CompileServiceResponse;
import com.db.macs3.ecomms.spectre.model.Models.MatchHighlight;
import com.db.macs3.ecomms.spectre.model.Models.MessageScanResult;
import com.db.macs3.ecomms.spectre.model.Models.PatternValidationResult;
import com.db.macs3.ecomms.spectre.model.Models.RawMatch;
import com.db.macs3.ecomms.spectre.model.Models.ScanResponse;
import com.db.macs3.ecomms.spectre.model.Models.StrippedMessage;
import com.db.macs3.ecomms.spectre.model.Models.TermScanResult;
import com.db.macs3.ecomms.spectre.model.MessageSource;
import com.db.macs3.ecomms.spectre.model.TermSource;
import com.db.macs3.ecomms.spectre.model.TermType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link LexiconScanOrchestrator}.
 *
 * <p>{@link LexiconCompileClient}, {@link HyperscanScanService}, and
 * {@link MatchHighlightService} are mocked with Mockito so tests run in
 * isolation without any network or Hyperscan native library calls.
 * {@link HtmlStrippingService}, {@link CsvParserService}, and
 * {@link DisclaimerDetectionService} are used as REAL instances — all three
 * are simple, deterministic, dependency-free utilities, so mocking them
 * would only obscure what the orchestrator actually does with their output;
 * this also means the disclaimer-exclusion tests below exercise the REAL
 * detection algorithm end-to-end, not a mocked stand-in for it.
 *
 * <p>Because {@link HyperscanScanService#compileAndScan} now receives the
 * HTML-STRIPPED text (not the raw message), and {@link StrippedMessage}
 * instances are constructed fresh inside the orchestrator on every call,
 * {@code any(StrippedMessage.class)} is used when stubbing/verifying
 * {@link MatchHighlightService#groupMatchesByTerm} rather than matching a
 * specific instance.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("LexiconScanOrchestrator")
class LexiconScanOrchestratorTest {

    @Mock private LexiconCompileClient compileClient;
    @Mock private HyperscanScanService scanService;
    @Mock private MatchHighlightService highlightService;

    private HtmlStrippingService htmlStrippingService;
    private CsvParserService csvParserService;
    private DisclaimerDetectionService disclaimerDetectionService;
    private LexiconScanOrchestrator orchestrator;

    @BeforeEach
    void setUp() {
        htmlStrippingService = new HtmlStrippingService();
        csvParserService = new CsvParserService();
        disclaimerDetectionService = new DisclaimerDetectionService(htmlStrippingService);
        orchestrator = new LexiconScanOrchestrator(
                compileClient, scanService, highlightService, htmlStrippingService,
                csvParserService, disclaimerDetectionService);
    }

    /** Convenience: single-message scan with no disclaimer exclusion, matching the original test style. */
    private ScanResponse scanSingleMessage(TermType termType, TermSource termSource, String message, String ruleName) {
        return orchestrator.scan(termType, termSource, new MessageSource.SingleText(message),
                new DisclaimerSource.None(), ruleName);
    }

    /** The one (and only, for single-message scans) MessageScanResult. */
    private MessageScanResult firstMessage(ScanResponse response) {
        return response.messageResults().get(0);
    }

    // ── NATURAL_LANGUAGE + typed text (existing behaviour, preserved) ──────────

    @Test
    @DisplayName("NATURAL_LANGUAGE + text: scan() returns SUCCESS with matched term count")
    void naturalLanguageText_happyPath_successStatus() {
        String message = "insider trading is illegal";

        when(compileClient.compile(anyList(), anyString())).thenReturn(passResponse());
        when(scanService.compileAndScan(anyList(), eq(message)))
                .thenReturn(List.of(new RawMatch(0, 7, 0)));
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class)))
                .thenReturn(Map.of(0, List.of(new MatchHighlight(0, 7, "insider", false))));
        when(highlightService.buildHighlightedHtml(eq(message), anyList()))
                .thenReturn("<mark>insider</mark> trading is illegal");

        ScanResponse response = scanSingleMessage(
                TermType.NATURAL_LANGUAGE, new TermSource.TextTerms(List.of("insider AND trading")), message, "test");

        assertThat(response.status()).isEqualTo("SUCCESS");
        assertThat(response.termType()).isEqualTo("Natural Language");
        assertThat(response.totalTerms()).isEqualTo(1);
        assertThat(response.totalMessages()).isEqualTo(1);
        assertThat(response.matchedTerms()).isEqualTo(1);
        assertThat(response.hasMatches()).isTrue();
        assertThat(firstMessage(response).htmlHighlightedMessage()).contains("<mark>");
    }

    @Test
    @DisplayName("NATURAL_LANGUAGE + text: calls compileClient.compile(), never compileCsv()")
    void naturalLanguageText_callsCompileNotCompileCsv() {
        String message = "test";
        when(compileClient.compile(anyList(), anyString())).thenReturn(passResponse());
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        scanSingleMessage(TermType.NATURAL_LANGUAGE,
                new TermSource.TextTerms(List.of("insider AND trading")), message, "my-rule");

        verify(compileClient).compile(List.of("insider AND trading"), "my-rule");
        verify(compileClient, never()).compileCsv(any(), anyString());
    }

    @Test
    @DisplayName("NATURAL_LANGUAGE + text: counts failedTerms when compile service reports failures")
    void naturalLanguageText_withFailedTerms_countsFailures() {
        String message = "some message";

        when(compileClient.compile(anyList(), anyString())).thenReturn(mixedResponse());
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        ScanResponse response = scanSingleMessage(TermType.NATURAL_LANGUAGE,
                new TermSource.TextTerms(List.of("good term", "bad term")), message, null);

        assertThat(response.failedTerms()).isEqualTo(1);
        assertThat(response.warnings()).isNotEmpty();
        assertThat(response.warnings().get(0)).contains("failed pattern compilation");
    }

    @Test
    @DisplayName("NATURAL_LANGUAGE + text: FAILED term result carries the compile-service error")
    void naturalLanguageText_failedTerm_termResultStatusIsFailed() {
        String message = "some message";

        when(compileClient.compile(anyList(), anyString())).thenReturn(failedResponse());
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        ScanResponse response = scanSingleMessage(TermType.NATURAL_LANGUAGE,
                new TermSource.TextTerms(List.of("bad term")), message, null);

        List<TermScanResult> termResults = firstMessage(response).termResults();
        assertThat(termResults).hasSize(1);
        TermScanResult tr = termResults.get(0);
        assertThat(tr.compilationStatus()).isEqualTo("FAILED");
        assertThat(tr.hasMatches()).isFalse();
        assertThat(tr.compilationError()).isNotBlank();
    }

    @Test
    @DisplayName("NATURAL_LANGUAGE + text: adds postFilterNote for requiresAndPostFilter terms")
    void naturalLanguageText_andTerm_hasPostFilterNote() {
        String message = "insider information shared";

        when(compileClient.compile(anyList(), anyString())).thenReturn(andTermResponse());
        when(scanService.compileAndScan(anyList(), eq(message)))
                .thenReturn(List.of(new RawMatch(0, 7, 0)));
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class)))
                .thenReturn(Map.of(0, List.of(new MatchHighlight(0, 7, "insider", false))));
        when(highlightService.buildHighlightedHtml(eq(message), anyList()))
                .thenReturn("<mark>insider</mark> information shared");

        ScanResponse response = scanSingleMessage(TermType.NATURAL_LANGUAGE,
                new TermSource.TextTerms(List.of("insider AND information")), message, null);

        TermScanResult tr = firstMessage(response).termResults().get(0);
        assertThat(tr.requiresAndPostFilter()).isTrue();
        assertThat(tr.postFilterNote()).isNotBlank();
        assertThat(tr.postFilterNote()).contains("AND/NOT semantics");
    }

    @Test
    @DisplayName("NATURAL_LANGUAGE + text: returns ERROR status when compile client throws")
    void naturalLanguageText_compileClientException_returnsErrorStatus() {
        when(compileClient.compile(anyList(), anyString()))
                .thenThrow(new LexiconCompileClient.LexiconCompileException("Service unavailable"));

        ScanResponse response = scanSingleMessage(TermType.NATURAL_LANGUAGE,
                new TermSource.TextTerms(List.of("insider AND trading")), "some message", null);

        assertThat(response.status()).isEqualTo("ERROR");
        assertThat(response.errorMessage()).contains("Service unavailable");
    }

    @Test
    @DisplayName("NATURAL_LANGUAGE + text: skips Hyperscan when there are no PASS terms")
    void naturalLanguageText_noPassTerms_skipsScanService() {
        String message = "test";
        when(compileClient.compile(anyList(), anyString())).thenReturn(failedResponse());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        scanSingleMessage(TermType.NATURAL_LANGUAGE, new TermSource.TextTerms(List.of("bad term")), message, null);

        verify(scanService, never()).compileAndScan(anyList(), anyString());
    }

    @Test
    @DisplayName("scan() includes scanDurationMs in the response")
    void scan_includesScanDuration() {
        String message = "test";
        when(compileClient.compile(anyList(), anyString())).thenReturn(passResponse());
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        ScanResponse response = scanSingleMessage(TermType.NATURAL_LANGUAGE,
                new TermSource.TextTerms(List.of("insider AND trading")), message, null);

        assertThat(response.scanDurationMs()).isGreaterThanOrEqualTo(0);
    }

    // ── NATURAL_LANGUAGE + CSV (forwarded to /compile/csv) ──────────────────────

    @Test
    @DisplayName("NATURAL_LANGUAGE + CSV: forwards the raw file via compileCsv(), never parses it locally")
    void naturalLanguageCsv_forwardsFileToCompileCsv() {
        String message = "test message";
        MockMultipartFile csv = new MockMultipartFile("file", "terms.csv", "text/csv",
                "term_id,term_description\nr::1,insider AND trading\n".getBytes());

        when(compileClient.compileCsv(eq(csv), anyString())).thenReturn(passResponse());
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        scanSingleMessage(TermType.NATURAL_LANGUAGE, new TermSource.CsvFile(csv), message, "my-rule");

        verify(compileClient).compileCsv(csv, "my-rule");
        verify(compileClient, never()).compile(anyList(), anyString());
    }

    // ── REGEX + typed text (bypasses Compile Service entirely) ──────────────────

    @Test
    @DisplayName("REGEX + text: never calls the Compile Service at all")
    void regexText_neverCallsCompileService() {
        String message = "insider trading";
        when(scanService.validatePattern(eq("(?:insider|trading)"), eq(HyperscanScanService.HS_FLAGS_REGEX_DEFAULT)))
                .thenReturn(new PatternValidationResult(true, null));
        when(scanService.compileAndScan(anyList(), eq(message))).thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        scanSingleMessage(TermType.REGEX, new TermSource.TextTerms(List.of("(?:insider|trading)")), message, null);

        verify(compileClient, never()).compile(anyList(), anyString());
        verify(compileClient, never()).compileCsv(any(), anyString());
    }

    @Test
    @DisplayName("REGEX + text: valid pattern validated via Hyperscan and used verbatim as the compiled pattern")
    void regexText_validPattern_compiledVerbatim() {
        String message = "insider trading";
        when(scanService.validatePattern(eq("(?:insider|trading)"), eq(HyperscanScanService.HS_FLAGS_REGEX_DEFAULT)))
                .thenReturn(new PatternValidationResult(true, null));
        when(scanService.compileAndScan(anyList(), eq(message)))
                .thenReturn(List.of(new RawMatch(0, 8, 0)));
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class)))
                .thenReturn(Map.of(0, List.of(new MatchHighlight(0, 8, "insider ", false))));
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        ScanResponse response = scanSingleMessage(TermType.REGEX,
                new TermSource.TextTerms(List.of("(?:insider|trading)")), message, null);

        assertThat(response.status()).isEqualTo("SUCCESS");
        assertThat(response.termType()).isEqualTo("Regex");
        TermScanResult tr = firstMessage(response).termResults().get(0);
        assertThat(tr.compilationStatus()).isEqualTo("PASS");
        assertThat(tr.translatedPattern()).isEqualTo("(?:insider|trading)");
        assertThat(tr.postFilterNote()).isNull();
    }

    @Test
    @DisplayName("REGEX + text: invalid pattern is rejected with Hyperscan's error message, no exception thrown")
    void regexText_invalidPattern_rejectedWithError() {
        String message = "test message";
        when(scanService.validatePattern(eq("(?:unclosed"), eq(HyperscanScanService.HS_FLAGS_REGEX_DEFAULT)))
                .thenReturn(new PatternValidationResult(false, "Hyperscan rejected this pattern: unclosed group"));
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        ScanResponse response = scanSingleMessage(TermType.REGEX,
                new TermSource.TextTerms(List.of("(?:unclosed")), message, null);

        assertThat(response.status()).isEqualTo("SUCCESS");
        TermScanResult tr = firstMessage(response).termResults().get(0);
        assertThat(tr.compilationStatus()).isEqualTo("FAILED");
        assertThat(tr.compilationError()).contains("unclosed group");
        verify(scanService, never()).compileAndScan(anyList(), anyString());
    }

    // ── HTML stripping integration ───────────────────────────────────────────────

    @Test
    @DisplayName("message with HTML is stripped before being handed to Hyperscan")
    void htmlMessage_strippedBeforeScanning() {
        String original = "<p>Enjoy</p>\n<p>Happy Birthday</p>";
        when(scanService.validatePattern(anyString(), eq(HyperscanScanService.HS_FLAGS_REGEX_DEFAULT)))
                .thenReturn(new PatternValidationResult(true, null));
        when(scanService.compileAndScan(anyList(), eq("Enjoy Happy Birthday")))
                .thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class))).thenReturn(Map.of());
        when(highlightService.buildHighlightedHtml(eq(original), anyList())).thenReturn(original);

        scanSingleMessage(TermType.REGEX,
                new TermSource.TextTerms(List.of("Enjoy(?:\\s+\\S+){0,2}\\s+Happy")), original, null);

        verify(scanService).compileAndScan(anyList(), eq("Enjoy Happy Birthday"));
        verify(highlightService).buildHighlightedHtml(eq(original), anyList());
    }

    // ── Multi-message scanning (NEW) ──────────────────────────────────────────────

    @Test
    @DisplayName("multiple messages are each scanned against the SAME compiled terms, " +
                 "and each gets its own MessageScanResult")
    void multipleMessages_eachScannedIndependently() {
        when(scanService.validatePattern(eq("insider"), eq(HyperscanScanService.HS_FLAGS_REGEX_DEFAULT)))
                .thenReturn(new PatternValidationResult(true, null));

        // Message 1 has a match, message 2 does not.
        when(scanService.compileAndScan(anyList(), eq("insider trading here")))
                .thenReturn(List.of(new RawMatch(0, 8, 0)));
        when(scanService.compileAndScan(anyList(), eq("nothing relevant here")))
                .thenReturn(List.of());
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class)))
                .thenAnswer(invocation -> {
                    List<RawMatch> raw = invocation.getArgument(0);
                    return raw.isEmpty() ? Map.of() : Map.of(0, List.of(new MatchHighlight(0, 8, "insider", false)));
                });
        when(highlightService.buildHighlightedHtml(anyString(), anyList()))
                .thenAnswer(invocation -> invocation.getArgument(0));

        MessageSource.MultipleMessages messages = new MessageSource.MultipleMessages(List.of(
                new MessageSource.NamedMessageText("email1.txt", "insider trading here"),
                new MessageSource.NamedMessageText("email2.txt", "nothing relevant here")));

        ScanResponse response = orchestrator.scan(TermType.REGEX, new TermSource.TextTerms(List.of("insider")),
                messages, new DisclaimerSource.None(), null);

        assertThat(response.totalMessages()).isEqualTo(2);
        assertThat(response.messageResults()).hasSize(2);
        assertThat(response.messageResults().get(0).messageId()).isEqualTo("email1.txt");
        assertThat(response.messageResults().get(0).hasMatches()).isTrue();
        assertThat(response.messageResults().get(1).messageId()).isEqualTo("email2.txt");
        assertThat(response.messageResults().get(1).hasMatches()).isFalse();
        // matchedTerms aggregates across ALL messages: 1 (from message 1 only).
        assertThat(response.matchedTerms()).isEqualTo(1);
        // Compile Service / Hyperscan validation only ran ONCE for the shared term set,
        // not once per message.
        verify(scanService).validatePattern(eq("insider"), eq(HyperscanScanService.HS_FLAGS_REGEX_DEFAULT));
    }

    // ── Disclaimer exclusion (NEW) — uses the REAL DisclaimerDetectionService ──────

    @Test
    @DisplayName("a match found ONLY within a detected disclaimer does not count toward hasMatches / alerting")
    void disclaimerOnlyMatch_doesNotCountTowardAlert() {
        String message = "Buy now.\n\nThis message is confidential.";
        // "confidential" is inside the disclaimer text, byte offsets recomputed against the stripped text.
        String stripped = htmlStrippingService.strip(message).strippedText(); // "Buy now. This message is confidential."
        int startInStripped = stripped.indexOf("confidential");

        when(scanService.validatePattern(eq("confidential"), eq(HyperscanScanService.HS_FLAGS_REGEX_DEFAULT)))
                .thenReturn(new PatternValidationResult(true, null));
        when(scanService.compileAndScan(anyList(), eq(stripped)))
                .thenReturn(List.of(new RawMatch(startInStripped, startInStripped + 12, 0)));
        // groupMatchesByTerm is mocked (its own correctness is covered by MatchHighlightServiceTest),
        // but its OUTPUT positions must line up with where "confidential" actually sits in the ORIGINAL
        // text, so the REAL DisclaimerDetectionService can correctly find the overlap.
        int originalStart = message.indexOf("confidential");
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class)))
                .thenReturn(Map.of(0, List.of(new MatchHighlight(originalStart, originalStart + 12, "confidential", false))));
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        ScanResponse response = orchestrator.scan(TermType.REGEX,
                new TermSource.TextTerms(List.of("confidential")),
                new MessageSource.SingleText(message),
                new DisclaimerSource.TextDisclaimers(List.of("This message is confidential.")),
                null);

        TermScanResult tr = firstMessage(response).termResults().get(0);
        assertThat(tr.matches()).hasSize(1);
        assertThat(tr.matches().get(0).inDisclaimer()).isTrue();
        assertThat(tr.hasMatches()).isFalse(); // disclaimer-only -> does NOT count as a match for alerting
        assertThat(tr.hasDisclaimerOnlyMatches()).isTrue();
        assertThat(response.hasMatches()).isFalse();
        assertThat(response.matchedTerms()).isEqualTo(0);
        assertThat(firstMessage(response).disclaimerSpans()).hasSize(1);
    }

    @Test
    @DisplayName("no disclaimer source (None) — disclaimerSpans is empty and matches are never suppressed")
    void noDisclaimerSource_matchesNeverSuppressed() {
        String message = "insider trading";
        when(scanService.validatePattern(anyString(), eq(HyperscanScanService.HS_FLAGS_REGEX_DEFAULT)))
                .thenReturn(new PatternValidationResult(true, null));
        when(scanService.compileAndScan(anyList(), eq(message)))
                .thenReturn(List.of(new RawMatch(0, 8, 0)));
        when(highlightService.groupMatchesByTerm(anyList(), anyList(), any(StrippedMessage.class)))
                .thenReturn(Map.of(0, List.of(new MatchHighlight(0, 8, "insider", false))));
        when(highlightService.buildHighlightedHtml(eq(message), anyList())).thenReturn(message);

        ScanResponse response = scanSingleMessage(TermType.REGEX,
                new TermSource.TextTerms(List.of("insider")), message, null);

        assertThat(response.totalDisclaimers()).isEqualTo(0);
        assertThat(firstMessage(response).disclaimerSpans()).isEmpty();
        assertThat(firstMessage(response).hasMatches()).isTrue();
    }

    // ── Compile response fixtures ─────────────────────────────────────────────

    private CompileServiceResponse passResponse() {
        return new CompileServiceResponse("test-rule", 1, 1, 0, false, List.of(
                new CompileServiceResponse.TermResult(
                        "test-rule::1", "insider AND trading", "Compliance Scan",
                        "PASS", "(?:insider|trading)", 3, true, null, null, null)
        ));
    }

    private CompileServiceResponse andTermResponse() {
        return new CompileServiceResponse("test-rule", 1, 1, 0, false, List.of(
                new CompileServiceResponse.TermResult(
                        "test-rule::1", "insider AND information", "Compliance Scan",
                        "PASS", "(?:insider|information)", 3, true, null, null, null)
        ));
    }

    private CompileServiceResponse failedResponse() {
        return new CompileServiceResponse("test-rule", 1, 0, 1, true, List.of(
                new CompileServiceResponse.TermResult(
                        "test-rule::1", "bad term", "Compliance Scan",
                        "FAILED", null, 0, false, "Hyperscan compile error", null, null)
        ));
    }

    private CompileServiceResponse mixedResponse() {
        return new CompileServiceResponse("test-rule", 2, 1, 1, true, List.of(
                new CompileServiceResponse.TermResult(
                        "test-rule::1", "good term", "Compliance Scan",
                        "PASS", "(?:good|term)", 1, false, null, null, null),
                new CompileServiceResponse.TermResult(
                        "test-rule::2", "bad term", "Compliance Scan",
                        "FAILED", null, 0, false, "Compile error", null, null)
        ));
    }
}
