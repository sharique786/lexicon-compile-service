package com.db.macs3.ecomms.spectre.reader;

import com.google.cloud.storage.Blob;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Loads pre-compiled Intel Hyperscan database (.hdb) files from Google Cloud Storage
 * into raw byte arrays, suitable for Spark broadcasting to executors.
 *
 * <h2>Why bytes and not Database objects?</h2>
 * <p>{@code com.gliwka.hyperscan.wrapper.Database} is a JNI object containing a
 * pointer to native C memory. It is NOT Java-serializable and CANNOT be placed in
 * a Spark broadcast variable, a Spark closure, or any serialized Spark row.
 *
 * <p>The correct pattern:
 * <ol>
 *   <li>Driver: load .hdb file bytes from GCS using this class</li>
 *   <li>Driver: broadcast {@code Map<featureName, byte[]>} to all executors</li>
 *   <li>Executor (in mapPartitions): deserialize bytes → Database using
 *       {@link com.gliwka.hyperscan.wrapper.Database#load(java.io.InputStream)}</li>
 *   <li>Executor: cache Database objects in a static ConcurrentHashMap keyed by featureName</li>
 * </ol>
 *
 * <p>This avoids re-downloading .hdb files from GCS on every Spark task. Each
 * executor JVM loads each database exactly once and caches it for the lifetime
 * of the executor.
 */
@Component
public class GcsHyperscanDatabaseLoader {

    private static final Logger log = LoggerFactory.getLogger(GcsHyperscanDatabaseLoader.class);

    private final Storage storageClient;

    /**
     * Creates a loader using Application Default Credentials.
     * On Dataproc, the service account attached to the cluster is used automatically.
     */
    public GcsHyperscanDatabaseLoader() {
        this.storageClient = StorageOptions.getDefaultInstance().getService();
    }

    /** Package-private constructor for unit tests (allows injecting a mock Storage). */
    GcsHyperscanDatabaseLoader(Storage storageClient) {
        this.storageClient = storageClient;
    }

    /**
     * Loads the raw bytes of each .hdb file whose name appears in {@code featureNames}.
     *
     * <p>A .hdb file is expected at:
     * {@code gs://<bucket>/<prefix>/<featureName>.hdb}
     *
     * <p>If a file is not found for a given feature name, that feature is logged as a warning
     * and skipped — the engine will not attempt to scan against it.
     *
     * @param featureNames set of feature names (without .hdb extension) to load
     * @param gcsBucket    GCS bucket name (without gs://)
     * @param gcsPrefix    GCS key prefix (without trailing slash)
     * @return map of featureName → raw .hdb file bytes for all files found
     * @throws IOException if a file exists but cannot be read
     */
    public Map<String, byte[]> loadAsBytes(Set<String> featureNames,
                                            String gcsBucket,
                                            String gcsPrefix) throws IOException {
        log.info("Loading {} .hdb files from gs://{}/{}/",
                 featureNames.size(), gcsBucket, gcsPrefix);

        Map<String, byte[]> result = new HashMap<>(featureNames.size() * 2);
        String prefix = gcsPrefix.endsWith("/") ? gcsPrefix : gcsPrefix + "/";

        for (String featureName : featureNames) {
            String blobName = prefix + featureName + ".hdb";
            log.debug("Loading HDB: gs://{}/{}", gcsBucket, blobName);

            Blob blob = storageClient.get(gcsBucket, blobName);
            if (blob == null || !blob.exists()) {
                log.warn("HDB file not found for feature '{}' at gs://{}/{} — " +
                         "this feature will NOT be scanned",
                         featureName, gcsBucket, blobName);
                continue;
            }

            long fileSizeBytes = blob.getSize();
            log.debug("Reading {} bytes for feature '{}'", fileSizeBytes, featureName);

            byte[] bytes = blob.getContent();
            result.put(featureName, bytes);

            log.info("Loaded HDB for '{}': {} bytes ({} KB)",
                     featureName, bytes.length, bytes.length / 1024);
        }

        log.info("HDB load complete: {}/{} files loaded successfully",
                 result.size(), featureNames.size());
        return result;
    }

    /**
     * Returns the total in-memory size of all loaded .hdb bytes, in megabytes.
     * Useful for estimating whether the combined size is safe to broadcast
     * (Spark's default broadcast size limit is 8 GB, but per-executor memory
     * should be considered; aim to keep combined HDB size under 2 GB).
     *
     * @param hdbBytes the map returned by {@link #loadAsBytes}
     * @return total size in megabytes (double precision)
     */
    public double totalSizeMb(Map<String, byte[]> hdbBytes) {
        long totalBytes = hdbBytes.values().stream()
                                  .mapToLong(b -> b.length)
                                  .sum();
        return totalBytes / (1024.0 * 1024.0);
    }
}
