package com.db.macs3.ecomms.spectre.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Represents a single match produced by the Hyperscan scanner against a text segment.
 *
 * <p>Positions are byte offsets within the scanned text string (UTF-8 encoded).
 * For match positions across multiple terms in the same text, the {@link #delta}
 * field captures the gap between the end of the previous match and the start of
 * this match, enabling downstream proximity analysis.
 *
 * <p>The {@link #expressionId} corresponds to the 0-based index of the lexicon term
 * within the Hyperscan database (set by {@link com.db.macs3.ecomms.spectre.reader.GcsHyperscanDatabaseLoader}
 * when building the Expression list — id = position of the term in the terms array).
 *
 * <p>Example: "he's going to bomb the entire business unit"
 * <pre>
 *   matchText  = "bomb"
 *   startIndex = 14
 *   endIndex   = 17     (inclusive end: 14 + 4 - 1)
 *   delta      = 0      (first match in this batch)
 * </pre>
 */
public class TermMatch implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * Hyperscan expression id = 0-based index of the term in the lexicon rule.
     * Use this to look up which {@code termId} produced the match.
     */
    private int expressionId;

    /** The substring of the input text that matched the pattern. */
    private String matchText;

    /** Byte offset (inclusive) within the scanned text where the match starts. */
    private long startIndex;

    /** Byte offset (inclusive) within the scanned text where the match ends. */
    private long endIndex;

    /**
     * Gap in bytes between the end of the immediately preceding match and the
     * start of this match, within the same text scan.
     * Zero for the first match. Negative values indicate overlapping matches.
     */
    private long delta;

    // ── No-arg constructor (Spark Encoder requirement) ────────────────────────
    public TermMatch() {}

    // ── Factory ───────────────────────────────────────────────────────────────

    public static TermMatch of(int expressionId, String matchText, long startIndex, long endIndex) {
        TermMatch m = new TermMatch();
        m.expressionId = expressionId;
        m.matchText    = matchText;
        m.startIndex   = startIndex;
        m.endIndex     = endIndex;
        m.delta        = 0;
        return m;
    }

    public static TermMatch of(int expressionId, String matchText,
                                long startIndex, long endIndex, long delta) {
        TermMatch m = of(expressionId, matchText, startIndex, endIndex);
        m.delta = delta;
        return m;
    }

    /** @return the length of the matched text in characters. */
    public int matchLength() {
        return (int) (endIndex - startIndex + 1);
    }

    // ── Getters / Setters ─────────────────────────────────────────────────────

    public int getExpressionId()            { return expressionId; }
    public void setExpressionId(int v)      { this.expressionId = v; }

    public String getMatchText()            { return matchText; }
    public void setMatchText(String v)      { this.matchText = v; }

    public long getStartIndex()             { return startIndex; }
    public void setStartIndex(long v)       { this.startIndex = v; }

    public long getEndIndex()               { return endIndex; }
    public void setEndIndex(long v)         { this.endIndex = v; }

    public long getDelta()                  { return delta; }
    public void setDelta(long v)            { this.delta = v; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TermMatch that = (TermMatch) o;
        return expressionId == that.expressionId &&
               startIndex == that.startIndex &&
               endIndex == that.endIndex;
    }

    @Override
    public int hashCode() { return Objects.hash(expressionId, startIndex, endIndex); }

    @Override
    public String toString() {
        return "TermMatch{exprId=" + expressionId + ", text='" + matchText +
               "', start=" + startIndex + ", end=" + endIndex + ", delta=" + delta + '}';
    }
}
