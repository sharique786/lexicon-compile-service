package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.config.AppProperties;
import com.db.macs3.ecomms.spectre.model.Models.CompiledTerm;
import com.db.macs3.ecomms.spectre.model.Models.PatternValidationResult;
import com.db.macs3.ecomms.spectre.model.Models.RawMatch;
import com.gliwka.hyperscan.wrapper.CompileErrorException;
import com.gliwka.hyperscan.wrapper.Database;
import com.gliwka.hyperscan.wrapper.Expression;
import com.gliwka.hyperscan.wrapper.ExpressionFlag;
import com.gliwka.hyperscan.wrapper.Match;
import com.gliwka.hyperscan.wrapper.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Core Hyperscan scanning service.
 *
 * <h2>Pipeline</h2>
 * <ol>
 *   <li>Receives {@link CompiledTerm} list (terms that already passed Hyperscan
 *       compilation in the Lexicon Compile Service).</li>
 *   <li>Builds one or more {@link Expression}s per term — see
 *       "QUIET/COMBINATION expression building" below.</li>
 *   <li>Compiles a single Hyperscan {@link Database} from all expressions.</li>
 *   <li>Scans the message text with a {@link Scanner}.</li>
 *   <li>Returns {@link RawMatch} list (byte-offset based; the caller converts
 *       to char indices) — see "Stage 2: recovering text for COMBINATION matches" below.</li>
 * </ol>
 *
 * <h2>QUIET/COMBINATION expression building</h2>
 * <p>Mirrors the Lexicon Compile Service's own {@code /compile/bundle} design
 * ({@code HyperscanCombinationHandler}) rather than the earlier approach of
 * compiling a term's exclusion pattern into a SEPARATE, parallel Hyperscan
 * database and merging both scans' results in application code (see
 * {@link LexiconScanOrchestrator} class Javadoc for why that approach, while
 * functionally correct, is no longer needed):
 * <ul>
 *   <li>A term with exactly one required pattern and no AND NOT
 *       ({@code !term.needsCombination()}) compiles as ONE plain expression
 *       at {@code term.expressionIndex()}, flagged {@code SOM_LEFTMOST} —
 *       safe here since it is never {@code QUIET}.</li>
 *   <li>Any other term (decomposed, and/or AND NOT) compiles as: every
 *       pattern in both {@code requiredPatterns} and {@code exclusionPatterns}
 *       as its own {@code QUIET} sub-expression (never {@code SOM_LEFTMOST} —
 *       confirmed incompatible with {@code QUIET} by a real Hyperscan
 *       compile-time error encountered in the Lexicon Compile Service
 *       project: "HS_FLAG_QUIET is not supported in combination with
 *       HS_FLAG_SOM_LEFTMOST"), each assigned an id from an ALLOCATED range
 *       starting strictly above every term's own {@code expressionIndex}
 *       (see {@link #computeAuxIdOffset}) so it can never collide with a
 *       real term id — plus ONE {@code COMBINATION} formula expression at
 *       {@code term.expressionIndex()} referencing them (AND across every
 *       required id; AND NOT the exclusion condition, applying De Morgan's
 *       law when the exclusion side itself has more than one entry).</li>
 * </ul>
 *
 * <h2>Stage 2: recovering text for COMBINATION matches</h2>
 * <p>A {@code COMBINATION} expression's own match event has no genuine
 * contiguous text span — it is a logical boolean event over (potentially
 * scattered) {@code QUIET} sub-expression matches, and Hyperscan has
 * nothing meaningful to report as its matched string or position (by
 * default it only tracks the end offset of whichever underlying trigger
 * happened to fire last). When a matched expression is flagged
 * {@code COMBINATION}, this class does NOT trust its
 * {@code getMatchedString()}/position at all — instead it runs a second,
 * independent pass with {@code java.util.regex.Matcher} against the owning
 * term's own {@code requiredPatterns} (which are themselves genuine,
 * independently valid PCRE patterns — Hyperscan's {@code QUIET} flag only
 * suppresses match REPORTING, not the pattern's own validity) to recover
 * each leaf's real matched text and position — see {@link #toRawMatches}.
 *
 * <p>For a decomposed term this deliberately produces MULTIPLE, separate,
 * non-contiguous highlights (one per leaf that genuinely matched) rather
 * than one span covering the whole original phrase — an honest reflection
 * of what decomposition's own semantics mean ("these independent things
 * were all found somewhere in the message"), not a claim of a proximity
 * match the Compile Service already discarded when it decomposed the term.
 *
 * <h2>Fallback strategy</h2>
 * <p>In some JVM environments (test runners, IDE debuggers) the Hyperscan
 * native scratch allocator throws {@code HS_ERR_INVALID} on {@code Scanner.scan()}.
 * When {@code lexicon.scanner.fallback-to-java-regex=true} (the default),
 * the service transparently retries with {@code java.util.regex.Pattern}
 * and synthesises equivalent {@link RawMatch} objects, applying the SAME AND
 * NOT / decomposition semantics as the native path (every required pattern
 * must match somewhere; if {@code requiresExclusionCheck}, no exclusion
 * pattern may match anywhere, or the whole term is skipped) — see
 * {@link #scanWithJavaRegex}.
 *
 * <h2>Flag bitmask</h2>
 * <pre>
 *   1  = HS_FLAG_CASELESS
 *   2  = HS_FLAG_DOTALL
 *   32 = HS_FLAG_UTF8
 *   64 = HS_FLAG_UCP
 * </pre>
 */
@Service
public class HyperscanScanService {

    private static final Logger log = LoggerFactory.getLogger(HyperscanScanService.class);

    public static final int HS_FLAG_CASELESS = 1;
    public static final int HS_FLAG_DOTALL   = 2;
    public static final int HS_FLAG_UTF8     = 32;
    public static final int HS_FLAG_UCP      = 64;

    /**
     * Default Hyperscan flag bitmask applied to {@code TermType.REGEX} terms,
     * which bypass the Lexicon Compile Service entirely and therefore never
     * get script-aware flag selection from {@code ScriptDetector}. CASELESS
     * matches the platform-wide convention that lexicon matching is always
     * case-insensitive; UTF8 + UCP are required for correct multi-byte
     * (Korean, Chinese, Arabic, emoji, etc.) matching regardless of pattern
     * content, since Hyperscan must know the input is UTF-8 to interpret
     * character boundaries correctly. DOTALL is intentionally NOT included —
     * unlike AND/NOT-translated patterns, a raw user-supplied regex has no
     * implicit need for {@code .} to span newlines, and forcing it on could
     * silently change the meaning of a pattern the user wrote deliberately.
     */
    public static final int HS_FLAGS_REGEX_DEFAULT = HS_FLAG_CASELESS | HS_FLAG_UTF8 | HS_FLAG_UCP;

    private final AppProperties props;

    public HyperscanScanService(AppProperties props) {
        this.props = props;
    }

    /**
     * Compiles all terms into one Hyperscan database and scans the message text.
     *
     * @param compiledTerms list of terms that are ready for scanning
     * @param messageText   the communication message to scan (UTF-8 String)
     * @return list of raw matches (may be empty; never null)
     */
    public List<RawMatch> compileAndScan(List<CompiledTerm> compiledTerms, String messageText) {
        if (compiledTerms == null || compiledTerms.isEmpty()) {
            log.warn("compileAndScan called with no compiled terms — returning empty result");
            return Collections.emptyList();
        }
        if (messageText == null || messageText.isBlank()) {
            log.warn("compileAndScan called with blank message text — returning empty result");
            return Collections.emptyList();
        }

        log.info("Starting Hyperscan scan: {} terms, message length={} chars",
                compiledTerms.size(), messageText.length());

        try {
            return scanWithHyperscan(compiledTerms, messageText);
        } catch (Exception e) {
            if (props.getScanner().isFallbackToJavaRegex()) {
                log.warn("Hyperscan scan failed ({}), falling back to Java regex: {}",
                        e.getClass().getSimpleName(), e.getMessage());
                return scanWithJavaRegex(compiledTerms, messageText);
            }
            throw new HyperscanScanException("Hyperscan scan failed: " + e.getMessage(), e);
        }
    }

    /**
     * Compiles {@code pattern} with the given Hyperscan flag bitmask and
     * returns {@code true} if compilation succeeds.
     * Used by unit tests to verify individual patterns without full scanning.
     *
     * @param pattern  Hyperscan PCRE pattern
     * @param hsFlags  bitmask of Hyperscan expression flags
     * @return true when Hyperscan accepts the pattern; false on compile error
     */
    public boolean validatePatternCompilation(String pattern, int hsFlags) {
        return validatePattern(pattern, hsFlags).pass();
    }

    /**
     * Compiles {@code pattern} with the given Hyperscan flag bitmask and
     * returns both the pass/fail outcome AND, on failure, Hyperscan's error
     * message — needed so {@code TermType.REGEX} terms (which bypass the
     * Lexicon Compile Service and therefore never receive a translation-stage
     * error) can still surface a meaningful compilation error on the UI,
     * exactly like Natural Language terms do when the Compile Service rejects them.
     *
     * @param pattern  Hyperscan PCRE pattern (as supplied directly by the user for REGEX-type terms)
     * @param hsFlags  bitmask of Hyperscan expression flags
     * @return a {@link com.db.macs3.ecomms.spectre.model.Models.PatternValidationResult}
     */
    public PatternValidationResult validatePattern(String pattern, int hsFlags) {
        Set<ExpressionFlag> flags = toExpressionFlags(hsFlags);
        flags.add(ExpressionFlag.SOM_LEFTMOST);
        try (Database db = Database.compile(new Expression(pattern, flags, 0))) {
            log.debug("Pattern validation PASS: {}", pattern);
            return new PatternValidationResult(true, null);
        } catch (CompileErrorException e) {
            log.debug("Pattern validation FAIL: {} — {}", pattern, e.getMessage());
            return new PatternValidationResult(
                    false, "Hyperscan rejected this pattern: " + e.getMessage());
        } catch (Exception e) {
            log.debug("Pattern validation FAIL (unexpected): {} — {}", pattern, e.getMessage());
            return new PatternValidationResult(
                    false, "Pattern could not be compiled: " + e.getMessage());
        }
    }

    // ── Hyperscan scanning ────────────────────────────────────────────────────

    private List<RawMatch> scanWithHyperscan(List<CompiledTerm> terms, String messageText)
            throws CompileErrorException {

        List<Expression> expressions = buildExpressions(terms);
        Map<Integer, CompiledTerm> termsByIndex = terms.stream()
                .collect(Collectors.toMap(CompiledTerm::expressionIndex, t -> t, (a, b) -> a));
        byte[] messageBytes = messageText.getBytes(StandardCharsets.UTF_8);

        try (Database db = Database.compile(expressions)) {
            log.debug("Hyperscan database compiled: {} expressions ({} terms)",
                    expressions.size(), terms.size());

            try (Scanner scanner = new Scanner()) {
                List<Match> matches = scanner.scan(db, messageText);

                log.info("Hyperscan scan complete: {} raw match event(s)", matches.size());

                List<RawMatch> results = new ArrayList<>();
                for (Match m : matches) {
                    results.addAll(toRawMatches(m, termsByIndex, messageText, messageBytes));
                }
                return results;
            }
        }
    }

    /**
     * Builds every {@link Expression} the whole term list needs — see class
     * Javadoc "QUIET/COMBINATION expression building".
     */
    private List<Expression> buildExpressions(List<CompiledTerm> terms) {
        List<Expression> out = new ArrayList<>();
        int[] nextAuxId = {computeAuxIdOffset(terms)};

        for (CompiledTerm term : terms) {
            if (!term.needsCombination()) {
                // Simplest, most common case — one plain pattern, reportable directly.
                // Never QUIET, never COMBINATION -> SOM_LEFTMOST is always safe here.
                Set<ExpressionFlag> flags = toExpressionFlags(term.hsFlags());
                flags.add(ExpressionFlag.SOM_LEFTMOST);
                out.add(new Expression(term.requiredPatterns().get(0), flags, term.expressionIndex()));
                continue;
            }

            List<Integer> requiredIds = addQuietSide(term.requiredPatterns(), term.hsFlags(), nextAuxId, out);
            String requiredFormula = joinWithAnd(requiredIds);

            String combinationFormula;
            if (term.requiresExclusionCheck()) {
                List<Integer> excludedIds = addQuietSide(term.exclusionPatterns(), term.hsFlags(), nextAuxId, out);
                String excludedNegated = excludedIds.size() == 1
                        ? "!" + excludedIds.get(0)
                        : "(" + excludedIds.stream().map(id -> "!" + id).collect(Collectors.joining("|")) + ")";
                combinationFormula = "(" + requiredFormula + "&" + excludedNegated + ")";
            } else {
                combinationFormula = "(" + requiredFormula + ")";
            }

            out.add(new Expression(combinationFormula, EnumSet.of(ExpressionFlag.COMBINATION), term.expressionIndex()));
        }
        return out;
    }

    /** Adds every pattern in {@code patterns} as its own QUIET expression, returning their allocated ids. */
    private List<Integer> addQuietSide(List<String> patterns, int hsFlags, int[] nextAuxId, List<Expression> out) {
        List<Integer> ids = new ArrayList<>(patterns.size());
        for (String pattern : patterns) {
            int id = nextAuxId[0]++;
            Set<ExpressionFlag> flags = toExpressionFlags(hsFlags);
            flags.add(ExpressionFlag.QUIET);
            out.add(new Expression(pattern, flags, id));
            ids.add(id);
        }
        return ids;
    }

    private static String joinWithAnd(List<Integer> ids) {
        return ids.stream().map(String::valueOf).collect(Collectors.joining("&"));
    }

    /**
     * The auxiliary (non-term) id range must never overlap a real term's
     * {@code expressionIndex}. {@code offset = (largest expressionIndex) + 1}
     * is the first id available for every QUIET sub-expression this scan
     * needs; every subsequent auxiliary id is handed out sequentially from there.
     */
    private int computeAuxIdOffset(List<CompiledTerm> terms) {
        return terms.stream().mapToInt(CompiledTerm::expressionIndex).max().orElse(-1) + 1;
    }

    /**
     * Converts one Hyperscan {@link Match} to zero or more {@link RawMatch}
     * records. A plain (non-COMBINATION) match converts 1:1. A COMBINATION
     * match triggers Stage 2 recovery — see class Javadoc — which can
     * produce zero, one, or several {@link RawMatch} records, one per
     * genuine occurrence of each of the owning term's required-side leaf patterns.
     */
    private List<RawMatch> toRawMatches(Match m, Map<Integer, CompiledTerm> termsByIndex,
                                         String messageText, byte[] messageBytes) {
        int id = (int) m.getMatchedExpression().getId();
        boolean isCombination = m.getMatchedExpression().getFlags().contains(ExpressionFlag.COMBINATION);

        if (!isCombination) {
            return List.of(new RawMatch(m.getStartPosition(), m.getEndPosition(), id, false));
        }

        CompiledTerm term = termsByIndex.get(id);
        if (term == null) {
            log.warn("COMBINATION match for unrecognised expression id={} — skipping", id);
            return List.of();
        }

        List<RawMatch> stage2 = new ArrayList<>();
        int javaFlags = buildJavaRegexFlags(term.hsFlags());
        for (String leafPattern : term.requiredPatterns()) {
            try {
                Matcher matcher = Pattern.compile(leafPattern, javaFlags).matcher(messageText);
                while (matcher.find()) {
                    long startByte = charIndexToByteOffset(messageBytes, matcher.start());
                    long endByte = charIndexToByteOffset(messageBytes, matcher.end());
                    stage2.add(new RawMatch(startByte, endByte, id, true));
                }
            } catch (Exception e) {
                log.warn("Stage 2 resolution failed for leaf pattern '{}' (term id={}): {}",
                        leafPattern, id, e.getMessage());
            }
        }
        log.debug("Stage 2 resolved {} leaf match(es) for COMBINATION expression id={}", stage2.size(), id);
        return stage2;
    }

    // ── Java-regex fallback ────────────────────────────────────────────────────

    /**
     * Java regex fallback for environments where {@code Scanner.scan()} fails.
     * Applies the same AND NOT / decomposition semantics as the native
     * Hyperscan path: every entry of {@code requiredPatterns} must match
     * somewhere in the message; if {@code requiresExclusionCheck}, the term
     * is skipped ENTIRELY (no matches reported) when any entry of
     * {@code exclusionPatterns} matches anywhere. A term that passes both
     * checks reports every individual occurrence of every required pattern —
     * the same shape Stage 2 recovery produces on the native path, so
     * downstream highlighting behaves identically regardless of which path ran.
     */
    private List<RawMatch> scanWithJavaRegex(List<CompiledTerm> terms, String messageText) {
        log.debug("Java regex fallback scan: {} terms", terms.size());
        byte[] messageBytes = messageText.getBytes(StandardCharsets.UTF_8);
        List<RawMatch> results = new ArrayList<>();

        for (CompiledTerm term : terms) {
            int javaFlags = buildJavaRegexFlags(term.hsFlags());

            if (term.requiresExclusionCheck() && anyPatternMatches(term.exclusionPatterns(), messageText, javaFlags)) {
                log.trace("Term '{}' excluded by AND NOT — skipping (Java regex fallback)", term.termDescription());
                continue;
            }
            if (!allPatternsMatch(term.requiredPatterns(), messageText, javaFlags)) {
                continue;
            }

            boolean usesCombination = term.needsCombination();
            for (String pattern : term.requiredPatterns()) {
                try {
                    Matcher matcher = Pattern.compile(pattern, javaFlags).matcher(messageText);
                    while (matcher.find()) {
                        long startByte = charIndexToByteOffset(messageBytes, matcher.start());
                        long endByte   = charIndexToByteOffset(messageBytes, matcher.end());
                        results.add(new RawMatch(startByte, endByte, term.expressionIndex(), usesCombination));
                        log.trace("Regex match for '{}': [{},{}]",
                                term.termDescription(), matcher.start(), matcher.end());
                    }
                } catch (Exception e) {
                    log.warn("Java regex failed for pattern '{}': {}", pattern, e.getMessage());
                }
            }
        }

        log.info("Java regex scan complete: {} matches found", results.size());
        return results;
    }

    private boolean allPatternsMatch(List<String> patterns, String text, int javaFlags) {
        for (String pattern : patterns) {
            try {
                if (!Pattern.compile(pattern, javaFlags).matcher(text).find()) {
                    return false;
                }
            } catch (Exception e) {
                log.warn("Java regex failed for pattern '{}': {}", pattern, e.getMessage());
                return false;
            }
        }
        return true;
    }

    private boolean anyPatternMatches(List<String> patterns, String text, int javaFlags) {
        for (String pattern : patterns) {
            try {
                if (Pattern.compile(pattern, javaFlags).matcher(text).find()) {
                    return true;
                }
            } catch (Exception e) {
                log.warn("Java regex failed for exclusion pattern '{}': {}", pattern, e.getMessage());
            }
        }
        return false;
    }

    // ── Flag conversion ───────────────────────────────────────────────────────

    /**
     * Converts the Hyperscan flag bitmask to a {@link Set} of {@link ExpressionFlag} enum values.
     * CASELESS is always added as the minimum flag.
     */
    public Set<ExpressionFlag> toExpressionFlags(int bitmask) {
        Set<ExpressionFlag> flags = EnumSet.noneOf(ExpressionFlag.class);
        if ((bitmask & HS_FLAG_CASELESS) != 0) flags.add(ExpressionFlag.CASELESS);
        if ((bitmask & HS_FLAG_DOTALL)   != 0) flags.add(ExpressionFlag.DOTALL);
        if ((bitmask & HS_FLAG_UTF8)     != 0) flags.add(ExpressionFlag.UTF8);
        if ((bitmask & HS_FLAG_UCP)      != 0) flags.add(ExpressionFlag.UCP);
        if (flags.isEmpty())                    flags.add(ExpressionFlag.CASELESS);
        return flags;
    }

    /**
     * Maps the Hyperscan flag bitmask to {@link java.util.regex.Pattern} flag bits.
     * Used by the fallback Java regex path AND by Stage 2 combination-match recovery.
     */
    private int buildJavaRegexFlags(int hsBitmask) {
        int jf = Pattern.UNICODE_CASE;
        if ((hsBitmask & HS_FLAG_CASELESS) != 0) jf |= Pattern.CASE_INSENSITIVE;
        if ((hsBitmask & HS_FLAG_DOTALL)   != 0) jf |= Pattern.DOTALL;
        if ((hsBitmask & HS_FLAG_UTF8)     != 0) jf |= Pattern.UNICODE_CHARACTER_CLASS;
        return jf;
    }

    // ── UTF-8 byte offset helpers ─────────────────────────────────────────────

    /**
     * Converts a Java {@link String} character index to a UTF-8 byte offset.
     *
     * <p>Hyperscan reports match positions as byte offsets into the UTF-8
     * representation of the input string, whereas Java uses UTF-16 char indices.
     * For ASCII-only content these are identical; for multi-byte Unicode
     * (Korean, Chinese, Arabic, emoji) they differ.
     *
     * @param utf8Bytes the UTF-8 encoding of the message
     * @param charIndex Java char index in the original String
     * @return corresponding byte offset in {@code utf8Bytes}
     */
    public static long charIndexToByteOffset(byte[] utf8Bytes, int charIndex) {
        long byteOffset = 0;
        int charsProcessed = 0;
        while (charsProcessed < charIndex && byteOffset < utf8Bytes.length) {
            byte b = utf8Bytes[(int) byteOffset];
            // Determine byte-length of this UTF-8 code unit
            int seqLen;
            if      ((b & 0x80) == 0)    seqLen = 1;  // ASCII
            else if ((b & 0xE0) == 0xC0) seqLen = 2;  // 2-byte sequence
            else if ((b & 0xF0) == 0xE0) seqLen = 3;  // 3-byte sequence (most CJK)
            else                          seqLen = 4;  // 4-byte sequence (emoji, etc.)
            byteOffset += seqLen;
            // 4-byte UTF-8 = one Unicode supplementary plane char → 2 Java chars (surrogate pair)
            charsProcessed += (seqLen == 4) ? 2 : 1;
        }
        return byteOffset;
    }

    /**
     * Converts a UTF-8 byte offset to a Java {@code String} character index.
     * Inverse of {@link #charIndexToByteOffset(byte[], int)}.
     */
    public static int byteOffsetToCharIndex(byte[] utf8Bytes, long byteOffset) {
        int charIndex = 0;
        long pos = 0;
        while (pos < byteOffset && pos < utf8Bytes.length) {
            byte b = utf8Bytes[(int) pos];
            int seqLen;
            if      ((b & 0x80) == 0)    seqLen = 1;
            else if ((b & 0xE0) == 0xC0) seqLen = 2;
            else if ((b & 0xF0) == 0xE0) seqLen = 3;
            else                          seqLen = 4;
            pos += seqLen;
            charIndex += (seqLen == 4) ? 2 : 1;
        }
        return charIndex;
    }

    // ── Exception ─────────────────────────────────────────────────────────────

    /** Thrown when Hyperscan scanning fails and fallback is disabled. */
    public static final class HyperscanScanException extends RuntimeException {
        public HyperscanScanException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
