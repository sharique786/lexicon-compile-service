package com.db.macs3.ecomms.spectre.translator;

/**
 * Estimates whether an {@link Ast} is likely to produce a pattern Hyperscan
 * rejects with "Pattern is too large", and rejects it EARLY — before
 * {@link PatternCodeGenerator} even runs — with a specific, actionable error
 * instead of letting Hyperscan fail opaquely at compile time.
 *
 * <h2>Why string length isn't the right signal</h2>
 * <p>The reported failure case compiles to a 190-character pattern — nowhere
 * near any raw length limit. Hyperscan's "Pattern is too large" is a
 * documented consequence of compiled AUTOMATON STATE COUNT, not string
 * length: Intel's own issue tracker shows a 32,000-repeat bounded quantifier
 * on a simple pattern compiling fine, while a 73-repeat bounded quantifier
 * on a pattern with additional structure (their case: UTF8 mode; this
 * project's case: nested proximity operators) fails. The common thread is
 * BOUNDED REPETITION OF A COMPOUND, ITSELF-VARIABLE-LENGTH SUB-PATTERN —
 * exactly what {@code (?:\s+\S+){0,n}} is — INTERACTING WITH SURROUNDING
 * ALTERNATION. Each NEAR/FOLLOWEDBY's bounded gap sits between two operands;
 * when an operand is itself a wide OR group, a wildcard, or (for explicitly
 * nested proximity) ANOTHER bounded-gap sub-expression, the automaton must
 * track many simultaneous partial-match states — which branch of the OR
 * group matched, combined with how many gap-words have been consumed so
 * far, combined with the SAME question one level up for nested proximity.
 * That is genuine combinatorial growth, not linear string growth.
 *
 * <h2>This is a heuristic, not a guarantee</h2>
 * <p>Without Hyperscan itself available in this development environment,
 * the exact state-count Hyperscan would produce for a given AST cannot be
 * computed precisely — only estimated from the structural factors known to
 * drive it (OR-branch count, wildcard presence, and multiplicative
 * compounding across nested proximity levels). {@link #COMPLEXITY_BUDGET}
 * is a deliberately conservative, hand-reasoned threshold: comfortably above
 * simple and moderately-nested terms, comfortably below the reported failing
 * example (which scores 294 — see {@code PatternComplexityAnalyzerTest}).
 * It is a single named constant specifically so it can be tuned against real
 * Hyperscan compilation results once available; this analyzer does not
 * replace testing against the real library, it reduces how often that
 * testing surfaces the failure as a confusing late-stage compile error
 * instead of an early, specific one.
 */
final class PatternComplexityAnalyzer {

    /**
     * Conservative complexity budget — see class Javadoc. A term whose
     * estimated score exceeds this is rejected before code generation.
     */
    static final int COMPLEXITY_BUDGET = 64;

    /** Multiplier applied to a NEAR operand's score — NEAR generates both
     *  A-then-B and B-then-A, doubling automaton complexity relative to the
     *  same operands under a single-direction FOLLOWEDBY. */
    private static final int NEAR_DIRECTIONALITY_FACTOR = 2;

    /** Extra weight for a wildcard-containing word/phrase — {@code \S*}'s own
     *  unbounded internal branching compounds with any surrounding bounded
     *  repetition or alternation it sits inside. */
    private static final int WILDCARD_WEIGHT = 2;
    private static final int PLAIN_WEIGHT = 1;

    private PatternComplexityAnalyzer() {}

    /**
     * Validates {@code ast}, throwing if its estimated complexity exceeds
     * {@link #COMPLEXITY_BUDGET}. For an {@code AND NOT} term, the required
     * and excluded sides are validated SEPARATELY (they become two
     * independent Hyperscan patterns — see {@link Ast.AndNot} class
     * Javadoc — so each is its own compile-complexity risk).
     *
     * @param ast          the parsed term
     * @param originalTerm the original term text, for the error message
     * @throws TranslationException if the estimated complexity is too high
     */
    static void validateComplexity(Ast ast, String originalTerm) {
        if (ast instanceof Ast.AndNot andNot) {
            checkBudget(estimateSafely(andNot.required(), originalTerm), "required", originalTerm);
            for (Ast excluded : andNot.excluded()) {
                checkBudget(estimateSafely(excluded, originalTerm), "excluded (AND NOT)", originalTerm);
            }
            return;
        }
        checkBudget(estimateSafely(ast, originalTerm), "term", originalTerm);
    }

    /**
     * Wraps {@link #estimate} to treat integer overflow (an extremely deep
     * or wide nested structure) as unambiguously over-budget rather than
     * letting {@link ArithmeticException} propagate as an unrelated-looking
     * "unexpected error" — a term complex enough to overflow a 32-bit score
     * is complex enough to reject regardless of the exact number.
     */
    private static int estimateSafely(Ast ast, String originalTerm) {
        try {
            return estimate(ast);
        } catch (ArithmeticException overflow) {
            return Integer.MAX_VALUE;
        }
    }

    private static void checkBudget(int score, String side, String originalTerm) {
        if (score > COMPLEXITY_BUDGET) {
            throw new TranslationException(
                    "This term's " + side + " expression is estimated too structurally complex "
                    + "for Hyperscan to compile (estimated complexity " + score + ", budget "
                    + COMPLEXITY_BUDGET + ") in term: '" + originalTerm + "'."
                    + " This typically happens with nested NEAR/FOLLOWEDBY operators whose operands"
                    + " contain many OR-alternatives and/or wildcards — each nesting level multiplies"
                    + " the complexity of the levels inside it. To fix: reduce the number of"
                    + " OR-alternatives per operand, reduce wildcard usage, or split this into"
                    + " multiple simpler lexicon terms.");
        }
    }

    // ── Estimation ────────────────────────────────────────────────────────────

    private static int estimate(Ast ast) {
        return switch (ast) {
            case Ast.Or or -> or.operands().stream().mapToInt(PatternComplexityAnalyzer::estimate).sum();

            case Ast.And and -> and.operands().stream()
                    .mapToInt(PatternComplexityAnalyzer::estimate)
                    .reduce(1, Math::multiplyExact); // permutation count itself is already capped elsewhere

            case Ast.AndNot andNot -> estimate(andNot.required()); // excluded side checked separately by the caller

            case Ast.Near near ->
                    Math.multiplyExact(Math.multiplyExact(estimate(near.left()), estimate(near.right())),
                            NEAR_DIRECTIONALITY_FACTOR);

            case Ast.FollowedBy fb -> Math.multiplyExact(estimate(fb.left()), estimate(fb.right()));

            case Ast.Word w -> containsWildcard(w.text()) ? WILDCARD_WEIGHT : PLAIN_WEIGHT;

            case Ast.Phrase p -> p.words().stream().anyMatch(PatternComplexityAnalyzer::containsWildcard)
                    ? WILDCARD_WEIGHT : PLAIN_WEIGHT;

            case Ast.QuotedPhrase q -> PLAIN_WEIGHT;
        };
    }

    private static boolean containsWildcard(String word) {
        return word.indexOf('*') >= 0;
    }
}
