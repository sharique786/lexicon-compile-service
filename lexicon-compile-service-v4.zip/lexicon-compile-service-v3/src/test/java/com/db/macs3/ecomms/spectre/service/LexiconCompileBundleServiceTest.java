package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.hyperscan.HyperscanCompiler;
import com.db.macs3.ecomms.spectre.model.CompilationStatus;
import com.db.macs3.ecomms.spectre.model.CompileResponse;
import com.db.macs3.ecomms.spectre.model.TermType;
import com.db.macs3.ecomms.spectre.model.TypedCompileRequest;
import com.db.macs3.ecomms.spectre.service.LexiconCompileService;
import com.db.macs3.ecomms.spectre.translator.TermSyntaxTranslator;
import com.gliwka.hyperscan.wrapper.Database;
import com.gliwka.hyperscan.wrapper.Match;
import com.gliwka.hyperscan.wrapper.Scanner;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link LexiconCompileBundleService} — the {@code /compile/bundle}
 * endpoint's orchestration logic (Natural Language/Regex branching + combined database).
 *
 * <p>No Spring context — uses real {@code TermSyntaxTranslator} and
 * {@code HyperscanCompiler} directly, exactly like {@link LexiconCompileServiceTest}.
 */
@DisplayName("LexiconCompileBundleService Tests")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class LexiconCompileBundleServiceTest {

    private LexiconCompileBundleService bundleService;

    @BeforeEach
    void setUp() {
        var translator     = new TermSyntaxTranslator();
        var compiler        = new HyperscanCompiler();
        compiler.selfTest();
        var compileService  = new LexiconCompileService(translator, compiler, new SimpleMeterRegistry());
        bundleService        = new LexiconCompileBundleService(compileService, compiler, new SimpleMeterRegistry());
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private TypedCompileRequest request(String ruleName, TermType termType, TermSpec... specs) {
        var req = new TypedCompileRequest();
        req.setRequestId(UUID.randomUUID().toString());
        req.setLexiconRuleName(ruleName);
        req.setTermType(termType);
        List<TypedCompileRequest.TermInput> terms = new ArrayList<>();
        for (int i = 0; i < specs.length; i++) {
            terms.add(new TypedCompileRequest.TermInput(
                    ruleName + "::" + (i + 1), specs[i].description));
        }
        req.setTerms(terms);
        return req;
    }

    // Convenience: Natural Language or Regex helpers just carry description
    private record TermSpec(String description) {}
    private static TermSpec term(String desc) { return new TermSpec(desc); }

    /** Shorthand: all-Natural-Language request */
    private TypedCompileRequest naturalLanguage(String ruleName, String... descs) {
        TermSpec[] specs = new TermSpec[descs.length];
        for (int i = 0; i < descs.length; i++) specs[i] = term(descs[i]);
        return request(ruleName, TermType.NATURAL_LANGUAGE, specs);
    }

    /** Shorthand: all-Regex request */
    private TypedCompileRequest regex(String ruleName, String... descs) {
        TermSpec[] specs = new TermSpec[descs.length];
        for (int i = 0; i < descs.length; i++) specs[i] = term(descs[i]);
        return request(ruleName, TermType.REGEX, specs);
    }

    // ── Spec example from the requirements ────────────────────────────────────

    @Test @Order(1)
    @DisplayName("Spec example: Natural Language request → PASS, combined DB built, request_id/termType echoed")
    void specExampleNaturalLanguage() {
        // termType is now request-level, so the original mixed Natural-Language+Regex example
        // is split into two single-type requests — this covers the Natural Language half.
        var req = naturalLanguage("lexicon_research_1",
                "(manipulate) NEAR{5} ((price) OR (spread) OR (stock))");
        String sentRequestId = req.getRequestId();

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isTrue();
        assertThat(bundle.hyperscanDatabaseBytes()).isNotEmpty();
        assertThat(bundle.databaseNote()).isNull();
        // request_id and termType must be echoed back unchanged
        assertThat(bundle.jsonResponse().requestId()).isEqualTo(sentRequestId);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Natural Language");
    }

    @Test @Order(2)
    @DisplayName("Spec example: Regex request → PASS, combined DB built, request_id/termType echoed")
    void specExampleRegex() {
        // Regex half of the original mixed example — termType is request-level now.
        var req = regex("lexicon_research_1", "(?:price|spread|stock)");
        String sentRequestId = req.getRequestId();

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isTrue();
        assertThat(bundle.jsonResponse().requestId()).isEqualTo(sentRequestId);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Regex");
    }

    // ── JSON shape: request_id / termType present, hyperscanVersion / processingTimeMs absent ──

    @Test @Order(10)
    @DisplayName("JSON response: request_id and termType present; hyperscanVersion absent (bundle-specific shape)")
    void jsonShapeMatchesCompile() {
        var req = naturalLanguage("shape_test", "price OR spread");
        var bundle = bundleService.buildBundle(req);

        CompileResponse json = bundle.jsonResponse();
        assertThat(json.lexiconRuleName()).isEqualTo("shape_test");
        assertThat(json.engineMode()).isEqualTo("HYPERSCAN_NATIVE");
        assertThat(json.requestId()).isEqualTo(req.getRequestId());
        assertThat(json.termType()).isEqualTo("Natural Language");
        // hyperscanVersion is intentionally null/absent for the bundle endpoint
        assertThat(json.hyperscanVersion()).isNull();
        assertThat(json.results()).hasSize(1);
        assertThat(json.results().get(0).termId()).isEqualTo("shape_test::1");
    }

    // ── Natural Language term branch ──────────────────────────────────────────────────

    @Test @Order(20)
    @DisplayName("Natural Language term: NEAR{5} translated exactly like /compile")
    void naturalLanguageTermTranslated() {
        var req = naturalLanguage("std_test", "(manipulate) NEAR{5} (price)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.translatedPattern()).contains("manipulate").contains("price");
        // Word-based gap confirms translation actually ran (a Regex-type term would never produce this)
        assertThat(result.translatedPattern()).contains("\\s+\\S+");
    }

    @Test @Order(21)
    @DisplayName("Natural Language term with invalid syntax → FAILED with translationError, no DB entry")
    void naturalLanguageTermTranslationFailure() {
        var req = naturalLanguage("std_fail_test", "NEAR{5} (price)"); // missing left operand
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.FAILED);
    }

    // ── Regex term branch ────────────────────────────────────────────────────────

    @Test @Order(30)
    @DisplayName("Regex term: raw PCRE compiled verbatim, NOT passed through the translator")
    void regexTermCompiledVerbatim() {
        var req = regex("nlt_test", "(?:price|spread|stock)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        // translatedPattern must be byte-identical to the input — no translation occurred
        assertThat(result.translatedPattern()).isEqualTo("(?:price|spread|stock)");
    }

    @Test @Order(31)
    @DisplayName("Regex term with invalid regex syntax → FAILED with Hyperscan errorLog")
    void regexTermInvalidRegex() {
        var req = regex("nlt_invalid_test", "[unclosed");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.FAILED);
        assertThat(result.errorLog()).isNotBlank();
        // requiresAndPostFilter is always false for Regex-type terms
        assertThat(result.requiresAndPostFilter()).isFalse();
    }

    @Test @Order(32)
    @DisplayName("Regex term with non-Latin script gets UTF8/UCP flags automatically")
    void regexTermNonLatinFlags() {
        var req = regex("nlt_korean_test", "(?:내부자|거래)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.hyperscanFlags() & 32).isEqualTo(32); // UTF8
        assertThat(result.hyperscanFlags() & 64).isEqualTo(64); // UCP
    }

    @Test @Order(33)
    @DisplayName("Regex term with operator-language syntax (not a real regex) is treated literally, never translated")
    void regexTermNeverTranslated() {
        // If this were Natural Language, "NEAR{5}" would translate into a proximity pattern.
        // As a Regex-type term it must be compiled literally — Hyperscan treats {5} as a repetition quantifier
        // on whatever precedes it, which is valid PCRE syntax on its own.
        var req = regex("nlt_literal_test", "price NEAR.{5} stock");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        // Must be exactly what was given — proof no NEAR{n} translation ran
        assertThat(result.translatedPattern()).isEqualTo("price NEAR.{5} stock");
    }

    // ── All-Regex and all-Natural-Language scenarios ────────────────────────────────────

    @Test @Order(40)
    @DisplayName("All-Regex request: every term compiled verbatim, DB contains all")
    void allRegexRequest() {
        var req = regex("all_nlt_test",
                "(?:price|spread)", "(?:insider|tip)", "manipulat\\w+");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(3);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Regex");
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(41)
    @DisplayName("All-Natural Language request: behaves identically to /compile for every term")
    void allNaturalLanguageRequest() {
        var req = naturalLanguage("all_std_test",
                "price OR spread",
                "don't FOLLOWEDBY{3} compliance",
                "insider AND announcement");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(3);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Natural Language");
        assertThat(bundle.hasDatabase()).isTrue();
    }

    // ── Mixed pass/fail scenarios (same termType, different outcomes) ──────────

    @Test @Order(50)
    @DisplayName("Mixed PASS/FAILED within an Regex request: combined DB built from PASS subset only, with id gaps")
    void mixedPassFailedDbBuiltFromPassOnly() throws IOException {
        // termType is request-level now, so "mixed Natural-Language+Regex" is no longer expressible
        // in one request. This test instead covers a mixed PASS/FAILED outcome within a
        // single Regex request, which still exercises the id-gap behaviour identically.
        var req = regex("mixed_test",
                "(?:price|spread)",     // index 0 — PASS
                "[unclosed",             // index 1 — FAILED
                "(?:insider|tip)");      // index 2 — PASS

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(2);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().results().get(1).compilationStatus())
                .isEqualTo(CompilationStatus.FAILED);
        assertThat(bundle.hasDatabase()).isTrue();

        // Load the DB back and confirm only ids {0, 2} are present (1 is the gap)
        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            assertThat(scanMatchesIds(db, "price")).contains(0);
            assertThat(scanMatchesIds(db, "insider")).contains(2);
        }
    }

    @Test @Order(51)
    @DisplayName("Zero PASS terms: no database built, clear explanatory note returned")
    void zeroPassTermsNoDatabase() {
        var req = regex("zero_pass_test", "[unclosed", "[also_unclosed");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isFalse();
        assertThat(bundle.hyperscanDatabaseBytes()).isNull();
        assertThat(bundle.databaseNote()).isNotBlank();
        assertThat(bundle.databaseNote()).contains("zero terms reached PASS");
    }

    // ── Combined database integrity (round-trip load + scan) ───────────────────

    @Test @Order(60)
    @DisplayName("Combined DB round-trip: save() then load() reconstructs a working multi-pattern database")
    void combinedDatabaseRoundTrip() throws IOException {
        var req = regex("roundtrip_test",
                "(?:price|spread|stock)",
                "(?:insider|tip)");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.hasDatabase()).isTrue();

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            List<Integer> priceMatches  = scanMatchesIds(db, "the price went up");
            List<Integer> insiderMatches = scanMatchesIds(db, "an insider tip was shared");

            assertThat(priceMatches).contains(0);
            assertThat(insiderMatches).contains(1);
        }
    }

    @Test @Order(61)
    @DisplayName("Expression id equals the term's 0-based index in the request, not termId hash")
    void expressionIdEqualsArrayIndex() throws IOException {
        var req = regex("id_mapping_test",
                "alpha_pattern",   // index 0
                "beta_pattern",    // index 1
                "gamma_pattern");  // index 2
        var bundle = bundleService.buildBundle(req);

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            assertThat(scanMatchesIds(db, "alpha_pattern")).containsExactly(0);
            assertThat(scanMatchesIds(db, "beta_pattern")).containsExactly(1);
            assertThat(scanMatchesIds(db, "gamma_pattern")).containsExactly(2);
        }
    }

    // ── Scan helper ──────────────────────────────────────────────────────────

    /** Scans {@code text} against {@code db} and returns the matched expression ids. */
    private List<Integer> scanMatchesIds(Database db, String text) {
        List<Integer> ids = new ArrayList<>();
        try (Scanner scanner = new Scanner()) {
            scanner.allocScratch(db);
            for (Match match : scanner.scan(db, text)) {
                ids.add(match.getMatchedExpression().getId());
            }
        }
        return ids;
    }
}
