package com.db.macs3.ecomms.spectre.engine;

import com.db.macs3.ecomms.spectre.model.ScanEngineArgs;
import com.db.macs3.ecomms.spectre.reader.AvroMessageReader;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.*;

/**
 * Unit tests for {@link ScanEngineArgs} parsing and derived path/ref utilities,
 * and for {@link AvroMessageReader}'s AVRO path construction.
 *
 * <p>LexiconScanEngine's core {@code run()} method depends on live BigQuery,
 * GCS, and Spark cluster resources that require integration test infrastructure.
 * This test class covers all units that are pure Java (no external dependencies).
 */
@DisplayName("LexiconScanEngine — args and path utilities")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class LexiconScanEngineTest {

    // ── ScanEngineArgs parsing ─────────────────────────────────────────────────

    @Test @Order(1)
    @DisplayName("parse() populates all fields correctly from --key value args")
    void argsParseAllFields() {
        ScanEngineArgs args = ScanEngineArgs.parse(new String[]{
                "--processId",      "proc-001",
                "--pipelineExecId", "exec-002",
                "--policyEngineId", "pol-003",
                "--triggerType",    "POLICY_DEPLOYMENT",
                "--runDate",        "2026-06-25",
                "--hdbGcsBucket",   "hdb-bucket",
                "--hdbGcsPrefix",   "hyperscan-dbs",
                "--msgGcsBucket",   "msg-bucket",
                "--msgGcsPrefix",   "messages/raw",
                "--bqProject",      "my-project",
                "--bqDataset",      "my_dataset"
        });

        assertThat(args.getProcessId()).isEqualTo("proc-001");
        assertThat(args.getPipelineExecId()).isEqualTo("exec-002");
        assertThat(args.getPolicyEngineId()).isEqualTo("pol-003");
        assertThat(args.getTriggerType()).isEqualTo("POLICY_DEPLOYMENT");
        assertThat(args.getRunDate()).isEqualTo("2026-06-25");
        assertThat(args.getHdbGcsBucket()).isEqualTo("hdb-bucket");
        assertThat(args.getHdbGcsPrefix()).isEqualTo("hyperscan-dbs");
        assertThat(args.getMsgGcsBucket()).isEqualTo("msg-bucket");
        assertThat(args.getMsgGcsPrefix()).isEqualTo("messages/raw");
        assertThat(args.getBqProject()).isEqualTo("my-project");
        assertThat(args.getBqDataset()).isEqualTo("my_dataset");
    }

    @Test @Order(2)
    @DisplayName("parse() ignores unknown flags and continues without error")
    void argsParseIgnoresUnknownFlags() {
        ScanEngineArgs args = ScanEngineArgs.parse(new String[]{
                "--processId",      "p1",
                "--pipelineExecId", "e1",
                "--policyEngineId", "po1",
                "--triggerType",    "POLICY_TEST",
                "--runDate",        "2026-01-01",
                "--hdbGcsBucket",   "b1",
                "--hdbGcsPrefix",   "px",
                "--msgGcsBucket",   "mb",
                "--msgGcsPrefix",   "mp",
                "--bqProject",      "proj",
                "--bqDataset",      "ds",
                "--unknownFlag",    "value",   // should be ignored
                "--anotherUnknown", "xyz"
        });

        assertThat(args.getProcessId()).isEqualTo("p1");
        assertThat(args.getBqProject()).isEqualTo("proj");
    }

    @ParameterizedTest(name = "Missing required arg: --{0}")
    @CsvSource({
            "processId",
            "pipelineExecId",
            "policyEngineId",
            "triggerType",
            "runDate",
            "hdbGcsBucket",
            "hdbGcsPrefix",
            "msgGcsBucket",
            "msgGcsPrefix",
            "bqProject",
            "bqDataset"
    })
    @Order(3)
    @DisplayName("parse() throws when a required argument is missing")
    void argsParseThrowsOnMissingRequired(String missingArg) {
        // Build args array without the specified key
        String[] fullArgs = {
                "--processId",      "p1",
                "--pipelineExecId", "e1",
                "--policyEngineId", "po1",
                "--triggerType",    "POLICY_TEST",
                "--runDate",        "2026-01-01",
                "--hdbGcsBucket",   "b1",
                "--hdbGcsPrefix",   "px",
                "--msgGcsBucket",   "mb",
                "--msgGcsPrefix",   "mp",
                "--bqProject",      "proj",
                "--bqDataset",      "ds"
        };
        // Remove the pair for missingArg
        String flag = "--" + missingArg;
        java.util.List<String> argList = new java.util.ArrayList<>(java.util.Arrays.asList(fullArgs));
        int idx = argList.indexOf(flag);
        if (idx >= 0) {
            argList.remove(idx + 1); // value
            argList.remove(idx);     // flag
        }

        assertThatThrownBy(() -> ScanEngineArgs.parse(argList.toArray(new String[0])))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining(missingArg);
    }

    // ── hdbGcsUri helper ──────────────────────────────────────────────────────

    @Test @Order(10)
    @DisplayName("hdbGcsUri returns correct gs:// path with .hdb extension")
    void hdbGcsUri_correctPath() {
        ScanEngineArgs args = buildTestArgs();
        String uri = args.hdbGcsUri("lexicon_market_cond_4");
        assertThat(uri).isEqualTo("gs://hdb-bucket/hyperscan-dbs/lexicon_market_cond_4.hdb");
    }

    @Test @Order(11)
    @DisplayName("hdbGcsUri works when prefix does not end with /")
    void hdbGcsUri_prefixWithoutTrailingSlash() {
        ScanEngineArgs args = buildTestArgs();
        assertThat(args.hdbGcsUri("my_feature"))
                .startsWith("gs://hdb-bucket/")
                .endsWith("my_feature.hdb");
    }

    // ── avroGcsPath helper ────────────────────────────────────────────────────

    @Test @Order(20)
    @DisplayName("avroGcsPath returns gs:// path combining bucket and prefix")
    void avroGcsPath_correct() {
        ScanEngineArgs args = buildTestArgs();
        assertThat(args.avroGcsPath())
                .isEqualTo("gs://msg-bucket/messages/raw");
    }

    // ── bqViewRef helper ──────────────────────────────────────────────────────

    @Test @Order(30)
    @DisplayName("bqViewRef returns project.dataset.viewName")
    void bqViewRef_correct() {
        ScanEngineArgs args = buildTestArgs();
        assertThat(args.bqViewRef())
                .isEqualTo("my-project.my_dataset." + ScanEngineArgs.BQ_VIEW_NAME);
    }

    // ── TriggerType constants ─────────────────────────────────────────────────

    @Test @Order(40)
    @DisplayName("ScanEngineArgs exposes correct trigger type constants")
    void triggerTypeConstants() {
        assertThat(ScanEngineArgs.TRIGGER_TEST).isEqualTo("POLICY_TEST");
        assertThat(ScanEngineArgs.TRIGGER_DEPLOYMENT).isEqualTo("POLICY_DEPLOYMENT");
    }

    // ── AvroMessageReader path construction ───────────────────────────────────

    @Test @Order(50)
    @DisplayName("buildAvroPath appends RUN_DATE and PIPELINE_EXEC_ID partition segments")
    void avroReaderBuildsPartitionedPath() {
        ScanEngineArgs args = buildTestArgs();
        AvroMessageReader reader = new AvroMessageReader();
        String path = reader.buildAvroPath(args);

        assertThat(path)
                .startsWith("gs://msg-bucket/messages/raw")
                .contains("RUN_DATE=2026-06-25")
                .contains("PIPELINE_EXEC_ID=exec-002")
                .endsWith(".avro");
    }

    @Test @Order(51)
    @DisplayName("buildAvroPath does NOT double-append partition segments if already present")
    void avroReaderDoesNotDuplicatePartitions() {
        // Build args where msgGcsPrefix already has partition segments
        ScanEngineArgs args = ScanEngineArgs.parse(new String[]{
                "--processId",      "p1",
                "--pipelineExecId", "exec-002",
                "--policyEngineId", "po1",
                "--triggerType",    "POLICY_TEST",
                "--runDate",        "2026-06-25",
                "--hdbGcsBucket",   "hdb-bucket",
                "--hdbGcsPrefix",   "hyperscan-dbs",
                "--msgGcsBucket",   "msg-bucket",
                "--msgGcsPrefix",   "messages/RUN_DATE=2026-06-25/PIPELINE_EXEC_ID=exec-002",
                "--bqProject",      "my-project",
                "--bqDataset",      "my_dataset"
        });
        AvroMessageReader reader = new AvroMessageReader();
        String path = reader.buildAvroPath(args);

        // Should NOT have duplicated RUN_DATE
        long runDateCount = path.chars()
                .filter(c -> c == 'R')
                .count();
        // A rough check: the path should contain exactly one RUN_DATE segment
        int count = 0;
        int idx = 0;
        while ((idx = path.indexOf("RUN_DATE=", idx)) != -1) {
            count++;
            idx += "RUN_DATE=".length();
        }
        assertThat(count).isEqualTo(1);
    }

    // ── Helper ────────────────────────────────────────────────────────────────

    private ScanEngineArgs buildTestArgs() {
        return ScanEngineArgs.parse(new String[]{
                "--processId",      "proc-001",
                "--pipelineExecId", "exec-002",
                "--policyEngineId", "pol-003",
                "--triggerType",    "POLICY_TEST",
                "--runDate",        "2026-06-25",
                "--hdbGcsBucket",   "hdb-bucket",
                "--hdbGcsPrefix",   "hyperscan-dbs",
                "--msgGcsBucket",   "msg-bucket",
                "--msgGcsPrefix",   "messages/raw",
                "--bqProject",      "my-project",
                "--bqDataset",      "my_dataset"
        });
    }
}
