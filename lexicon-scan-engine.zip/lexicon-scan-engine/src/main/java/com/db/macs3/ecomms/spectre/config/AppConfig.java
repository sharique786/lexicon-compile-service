package com.db.macs3.ecomms.spectre.config;

import org.apache.spark.SparkConf;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * Spring @Configuration that wires up the Spark infrastructure.
 *
 * <h2>SparkSession creation</h2>
 * <p>On a real Dataproc cluster ({@code @Profile("!test")}) the SparkSession is
 * acquired from the cluster's running context — a new session is NOT created because
 * Dataproc already owns the SparkContext. The {@code getOrCreate()} semantics ensure
 * the existing cluster session is returned.
 *
 * <p>In unit/integration tests ({@code @Profile("test")}) a local SparkSession is
 * created with {@code spark.master=local[*]}, suitable for running on a developer
 * laptop or CI pipeline without a real cluster.
 *
 * <h2>BigQuery connector configuration</h2>
 * <p>The BigQuery Storage connector requires the GCP project to be set either via
 * the {@code parentProject} option on each read/write call (done in the reader/writer
 * classes) or globally here. Both approaches work; per-call is more explicit.
 *
 * <h2>Spark optimisation settings applied here</h2>
 * <ul>
 *   <li>Kryo serializer for faster shuffle serialization</li>
 *   <li>Adaptive Query Execution (AQE) for dynamic partition coalescing</li>
 *   <li>Skew join handling for the message × feature join</li>
 *   <li>Native Hadoop GCS connector for fast AVRO reads</li>
 * </ul>
 */
@Configuration
public class AppConfig {

    private static final Logger log = LoggerFactory.getLogger(AppConfig.class);

    @Value("${spark.app.name:LexiconScanEngine}")
    private String appName;

    @Value("${spark.master:#{null}}")
    private String sparkMaster;

    @Value("${spark.executor.memory:8g}")
    private String executorMemory;

    @Value("${spark.driver.memory:4g}")
    private String driverMemory;

    @Value("${spark.sql.shuffle.partitions:200}")
    private String shufflePartitions;

    @Value("${spark.default.parallelism:200}")
    private String defaultParallelism;

    // ── SparkSession bean ─────────────────────────────────────────────────────

    /**
     * Production SparkSession — acquires the existing cluster context on Dataproc.
     *
     * <p>The {@code @Profile("!test")} annotation prevents this bean from loading
     * during unit/integration tests, allowing the test profile to supply a local session.
     *
     * @return the cluster SparkSession (via getOrCreate)
     */
    @Bean
    @Profile("!test")
    public SparkSession sparkSession() {
        log.info("Creating SparkSession for production (Dataproc cluster)");
        SparkSession session = SparkSession.builder()
                .appName(appName)
                // All optimisation settings — cluster values are applied here if not set
                // in the Dataproc job config (Dataproc job config takes precedence)
                .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .config("spark.sql.adaptive.enabled", "true")
                .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
                .config("spark.sql.adaptive.skewJoin.enabled", "true")
                .config("spark.sql.shuffle.partitions", shufflePartitions)
                .config("spark.default.parallelism", defaultParallelism)
                // BigQuery connector — STORAGE_WRITE_API for fast output
                .config("spark.datasource.bigquery.writeMethod", "STORAGE_WRITE_API")
                // GCS connector — ensure hadoop-gcs connector is on the classpath (Dataproc includes it)
                .config("spark.hadoop.fs.gs.impl",
                        "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem")
                .config("spark.hadoop.google.cloud.auth.service.account.enable", "true")
                .getOrCreate();

        log.info("SparkSession acquired: version={}, master={}",
                 session.version(), session.sparkContext().master());
        return session;
    }

    /**
     * Test SparkSession — local mode, suitable for unit and integration tests.
     * Injected only when the {@code test} Spring profile is active.
     *
     * @return local SparkSession
     */
    @Bean
    @Profile("test")
    public SparkSession testSparkSession() {
        log.info("Creating local SparkSession for tests");
        String master = sparkMaster != null ? sparkMaster : "local[2]";
        return SparkSession.builder()
                .appName(appName + "-test")
                .master(master)
                .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .config("spark.sql.adaptive.enabled", "true")
                .config("spark.sql.shuffle.partitions", "4")
                .config("spark.default.parallelism", "4")
                // Disable UI for tests
                .config("spark.ui.enabled", "false")
                .getOrCreate();
    }
}
