package com.db.macs3.ecomms.spectre.engine;

import com.db.macs3.ecomms.spectre.model.TermMatch;
import com.gliwka.hyperscan.wrapper.*;
import org.apache.spark.broadcast.Broadcast;
import org.junit.jupiter.api.*;
import org.mockito.Mockito;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.*;

/**
 * Unit / integration tests for {@link HyperscanMatcher}.
 *
 * <p>Uses the real Hyperscan native library (via the gliwka/hyperscan-java wrapper)
 * to compile tiny in-memory databases, broadcasts their bytes via Mockito mocks,
 * and verifies that matches are correctly returned with start/end positions and delta.
 *
 * <p>Note: These tests require the Hyperscan native library to be resolvable on the
 * test classpath (packaged in the hyperscan-java JAR for the target platform).
 * On CI, ensure the native libraries are unpacked properly via the Maven Surefire
 * configuration in pom.xml.
 */
@DisplayName("HyperscanMatcher Tests")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class HyperscanMatcherTest {

    private HyperscanMatcher matcher;

    @BeforeEach
    void setUp() {
        HyperscanMatcher.clearCache();   // start each test with a clean cache
        matcher = new HyperscanMatcher();
    }

    @AfterEach
    void tearDown() {
        HyperscanMatcher.clearCache();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Compiles a tiny in-memory Hyperscan database containing the given patterns
     * and returns its serialized bytes. Expression ids are 0-based.
     */
    private byte[] compileDatabase(String... patterns) throws Exception {
        Expression[] exprs = new Expression[patterns.length];
        for (int i = 0; i < patterns.length; i++) {
            exprs[i] = new Expression(
                    patterns[i],
                    EnumSet.of(ExpressionFlag.CASELESS),
                    i);
        }
        Database db = Database.compile(exprs);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        db.save(baos);
        return baos.toByteArray();
    }

    @SuppressWarnings("unchecked")
    private Broadcast<Map<String, byte[]>> mockBroadcast(String featureName, byte[] bytes) {
        Broadcast<Map<String, byte[]>> broadcast = Mockito.mock(Broadcast.class);
        Map<String, byte[]> map = new HashMap<>();
        map.put(featureName, bytes);
        Mockito.when(broadcast.value()).thenReturn(map);
        return broadcast;
    }

    @SuppressWarnings("unchecked")
    private Broadcast<Map<String, byte[]>> emptyBroadcast() {
        Broadcast<Map<String, byte[]>> broadcast = Mockito.mock(Broadcast.class);
        Mockito.when(broadcast.value()).thenReturn(Map.of());
        return broadcast;
    }

    // ── Basic match tests ─────────────────────────────────────────────────────

    @Test @Order(1)
    @DisplayName("Single pattern match — returns correct termId, text, start, end")
    void singlePatternMatch() throws Exception {
        byte[] hdbBytes = compileDatabase("bomb");
        Broadcast<Map<String, byte[]>> broadcast = mockBroadcast("test_feature", hdbBytes);

        List<TermMatch> matches = matcher.scan("test_feature",
                "he's going to bomb the entire business unit", broadcast);

        assertThat(matches).hasSize(1);
        TermMatch m = matches.get(0);
        assertThat(m.getMatchText()).isEqualTo("bomb");
        assertThat(m.getExpressionId()).isEqualTo(0);
        assertThat(m.getStartIndex()).isGreaterThanOrEqualTo(0);
        assertThat(m.getEndIndex()).isGreaterThan(m.getStartIndex());
    }

    @Test @Order(2)
    @DisplayName("Multiple pattern database — each pattern's expressionId matches its index")
    void multiplePatternMatch() throws Exception {
        byte[] hdbBytes = compileDatabase("bomb", "manipulate", "insider");
        Broadcast<Map<String, byte[]>> broadcast = mockBroadcast("lex_research", hdbBytes);

        List<TermMatch> matches = matcher.scan("lex_research",
                "do not manipulate the price: insider trading is illegal", broadcast);

        assertThat(matches).hasSizeGreaterThanOrEqualTo(2);
        // expressionId 1 = "manipulate", expressionId 2 = "insider"
        boolean hasManipulate = matches.stream().anyMatch(m -> m.getExpressionId() == 1);
        boolean hasInsider    = matches.stream().anyMatch(m -> m.getExpressionId() == 2);
        assertThat(hasManipulate).isTrue();
        assertThat(hasInsider).isTrue();
    }

    @Test @Order(3)
    @DisplayName("No match in text — returns empty list")
    void noMatchReturnsEmptyList() throws Exception {
        byte[] hdbBytes = compileDatabase("bomb");
        Broadcast<Map<String, byte[]>> broadcast = mockBroadcast("lex_test", hdbBytes);

        List<TermMatch> matches = matcher.scan("lex_test",
                "everything is fine and normal today", broadcast);

        assertThat(matches).isEmpty();
    }

    // ── Null / blank text guards ───────────────────────────────────────────────

    @Test @Order(10)
    @DisplayName("Null text — returns empty list without scanning")
    void nullTextReturnsEmpty() throws Exception {
        byte[] hdbBytes = compileDatabase("bomb");
        Broadcast<Map<String, byte[]>> broadcast = mockBroadcast("lex_test", hdbBytes);

        assertThat(matcher.scan("lex_test", null, broadcast)).isEmpty();
    }

    @Test @Order(11)
    @DisplayName("Blank text — returns empty list without scanning")
    void blankTextReturnsEmpty() throws Exception {
        byte[] hdbBytes = compileDatabase("bomb");
        Broadcast<Map<String, byte[]>> broadcast = mockBroadcast("lex_test", hdbBytes);

        assertThat(matcher.scan("lex_test", "   ", broadcast)).isEmpty();
        assertThat(matcher.scan("lex_test", "", broadcast)).isEmpty();
    }

    @Test @Order(12)
    @DisplayName("Feature not in broadcast — returns empty list with warning")
    void featureNotInBroadcast_returnsEmpty() {
        assertThat(matcher.scan("missing_feature", "some text", emptyBroadcast())).isEmpty();
    }

    // ── Static cache behaviour ─────────────────────────────────────────────────

    @Test @Order(20)
    @DisplayName("Second scan for same feature uses cached DB (cache size stays 1)")
    void cacheRetainsDatabaseBetweenScans() throws Exception {
        byte[] hdbBytes = compileDatabase("price");
        Broadcast<Map<String, byte[]>> broadcast = mockBroadcast("lex_cache", hdbBytes);

        // First scan — loads DB into cache
        matcher.scan("lex_cache", "the price is rising", broadcast);
        int cacheAfterFirst = HyperscanMatcher.cachedDatabaseCount();

        // Second scan — should reuse cached DB
        matcher.scan("lex_cache", "price manipulation detected", broadcast);
        int cacheAfterSecond = HyperscanMatcher.cachedDatabaseCount();

        assertThat(cacheAfterFirst).isEqualTo(1);
        assertThat(cacheAfterSecond).isEqualTo(1); // still 1, not 2
    }

    @Test @Order(21)
    @DisplayName("Two different features produce two cache entries")
    void twoDifferentFeaturesTwoCacheEntries() throws Exception {
        byte[] hdb1 = compileDatabase("price");
        byte[] hdb2 = compileDatabase("insider");

        Broadcast<Map<String, byte[]>> broadcast = Mockito.mock(Broadcast.class);
        Map<String, byte[]> map = Map.of("feat_1", hdb1, "feat_2", hdb2);
        Mockito.when(broadcast.value()).thenReturn(map);

        matcher.scan("feat_1", "the price moved", broadcast);
        matcher.scan("feat_2", "insider trading", broadcast);

        assertThat(HyperscanMatcher.cachedDatabaseCount()).isEqualTo(2);
    }

    @Test @Order(22)
    @DisplayName("clearCache resets cache to 0")
    void clearCacheResetsCount() throws Exception {
        byte[] hdb = compileDatabase("bomb");
        Broadcast<Map<String, byte[]>> broadcast = mockBroadcast("f1", hdb);
        matcher.scan("f1", "a bomb threat", broadcast);

        assertThat(HyperscanMatcher.cachedDatabaseCount()).isGreaterThan(0);
        HyperscanMatcher.clearCache();
        assertThat(HyperscanMatcher.cachedDatabaseCount()).isEqualTo(0);
    }

    // ── Delta calculation ─────────────────────────────────────────────────────

    @Test @Order(30)
    @DisplayName("First match has delta = 0")
    void firstMatchHasDeltaZero() throws Exception {
        byte[] hdb = compileDatabase("bomb");
        Broadcast<Map<String, byte[]>> broadcast = mockBroadcast("f1", hdb);

        List<TermMatch> matches = matcher.scan("f1", "the bomb exploded", broadcast);

        assertThat(matches).isNotEmpty();
        assertThat(matches.get(0).getDelta()).isEqualTo(0L);
    }

    @Test @Order(31)
    @DisplayName("Second match has positive delta when matches are not adjacent")
    void secondMatchHasPositiveDelta() throws Exception {
        // Two distinct single-word patterns both appearing in the text
        byte[] hdb = compileDatabase("bomb", "unit");
        Broadcast<Map<String, byte[]>> broadcast = mockBroadcast("f1", hdb);

        // "bomb" at ~4..7, "unit" at ~38..41 — gap is positive
        List<TermMatch> matches = matcher.scan("f1",
                "the bomb will destroy the entire business unit", broadcast);

        // Both terms should match
        assertThat(matches.stream().anyMatch(m -> m.getMatchText() != null &&
                m.getMatchText().equalsIgnoreCase("bomb"))).isTrue();
        assertThat(matches.stream().anyMatch(m -> m.getMatchText() != null &&
                m.getMatchText().equalsIgnoreCase("unit"))).isTrue();

        // The second match must have a positive delta
        if (matches.size() >= 2) {
            TermMatch second = matches.get(1);
            assertThat(second.getDelta()).isGreaterThanOrEqualTo(0L);
        }
    }
}
