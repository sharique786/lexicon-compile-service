package com.db.macs3.ecomms.spectre.client;

import com.db.macs3.ecomms.spectre.client.LexiconCompileClient.LexiconCompileException;
import com.db.macs3.ecomms.spectre.config.AppProperties;
import com.db.macs3.ecomms.spectre.model.Models.CompileServiceResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestClient;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

/**
 * Unit tests for {@link LexiconCompileClient} using Spring's {@link MockRestServiceServer}.
 *
 * <p>All HTTP interactions are mocked — no real Lexicon Compile Service instance required.
 */
@DisplayName("LexiconCompileClient")
class LexiconCompileClientTest {

    private static final String BASE_URL = "http://lexicon-compile-service:8080";
    private static final String COMPILE_URL = BASE_URL + "/api/lexicon/compile";

    private MockRestServiceServer mockServer;
    private LexiconCompileClient client;

    @BeforeEach
    void setUp() {
        AppProperties props = new AppProperties();
        props.getCompileService().setBaseUrl(BASE_URL);
        props.getCompileService().setDefaultRuleName("test-rule");

        RestClient.Builder builder = RestClient.builder().baseUrl(BASE_URL);
        // Bind MockRestServiceServer via the underlying RestTemplate exchange adapter
        mockServer = MockRestServiceServer.bindTo(builder).build();
        RestClient restClient = builder.build();

        client = new LexiconCompileClient(restClient, props);
    }

    // ── compile() ────────────────────────────────────────────────────────────

    @Test
    @DisplayName("compile() returns deserialized response on HTTP 200")
    void compile_success_returnsResponse() {
        mockServer.expect(requestTo(COMPILE_URL))
                  .andExpect(method(HttpMethod.POST))
                  .andRespond(withSuccess(successBody(), MediaType.APPLICATION_JSON));

        CompileServiceResponse response = client.compile(
                List.of("insider AND trading", "pump OR dump"), "test-session");

        assertThat(response).isNotNull();
        assertThat(response.totalTerms()).isEqualTo(2);
        assertThat(response.passCount()).isEqualTo(2);
        assertThat(response.hasFailures()).isFalse();
        assertThat(response.results()).hasSize(2);

        mockServer.verify();
    }

    @Test
    @DisplayName("compile() PASS term has translatedPattern and hsFlags")
    void compile_passTerm_hasPatternAndFlags() {
        mockServer.expect(requestTo(COMPILE_URL))
                  .andRespond(withSuccess(successBody(), MediaType.APPLICATION_JSON));

        CompileServiceResponse response =
                client.compile(List.of("insider AND trading"), null);

        CompileServiceResponse.TermResult first = response.results().get(0);
        assertThat(first.compilationStatus()).isEqualTo("PASS");
        assertThat(first.translatedPattern()).isEqualTo("(?:insider|trading)");
        assertThat(first.hsFlags()).isEqualTo(3);  // CASELESS|DOTALL
        assertThat(first.requiresAndPostFilter()).isTrue();
    }

    @Test
    @DisplayName("compile() with failed term — hasFailures=true, errorLog populated")
    void compile_failedTerm_hasFailuresTrue() {
        mockServer.expect(requestTo(COMPILE_URL))
                  .andRespond(withSuccess(failureBody(), MediaType.APPLICATION_JSON));

        CompileServiceResponse response =
                client.compile(List.of("(unclosed pattern"), null);

        assertThat(response.hasFailures()).isTrue();
        assertThat(response.failedCount()).isEqualTo(1);
        assertThat(response.results().get(0).compilationStatus()).isEqualTo("FAILED");
    }

    @Test
    @DisplayName("compile() throws LexiconCompileException on HTTP 500")
    void compile_serverError_throwsException() {
        mockServer.expect(requestTo(COMPILE_URL))
                  .andRespond(withStatus(HttpStatus.INTERNAL_SERVER_ERROR));

        assertThatThrownBy(() -> client.compile(List.of("insider AND trading"), null))
                .isInstanceOf(LexiconCompileException.class)
                .hasMessageContaining("server error");
    }

    @Test
    @DisplayName("compile() throws LexiconCompileException on HTTP 400")
    void compile_clientError_throwsException() {
        mockServer.expect(requestTo(COMPILE_URL))
                  .andRespond(withStatus(HttpStatus.BAD_REQUEST));

        assertThatThrownBy(() -> client.compile(List.of("bad request"), null))
                .isInstanceOf(LexiconCompileException.class)
                .hasMessageContaining("client error");
    }

    @Test
    @DisplayName("compile() with null term list returns empty response without HTTP call")
    void compile_nullTermList_returnsEmptyWithoutCall() {
        // No mock expectation — no HTTP call should be made
        CompileServiceResponse response = client.compile(null, "any-rule");
        assertThat(response.totalTerms()).isEqualTo(0);
        assertThat(response.results()).isEmpty();
    }

    @Test
    @DisplayName("compile() uses default rule name when ruleName is blank")
    void compile_blankRuleName_usesDefault() {
        mockServer.expect(requestTo(COMPILE_URL))
                  .andRespond(withSuccess(successBody(), MediaType.APPLICATION_JSON));

        // Should not throw — default rule name is used
        CompileServiceResponse response = client.compile(List.of("insider AND trading"), "");
        assertThat(response).isNotNull();
        mockServer.verify();
    }

    // ── Response JSON fixtures ────────────────────────────────────────────────

    private String successBody() {
        return """
            {
              "lexiconRuleName": "test-rule",
              "totalTerms": 2,
              "passCount": 2,
              "failedCount": 0,
              "hasFailures": false,
              "results": [
                {
                  "termId": "test-rule::1",
                  "termDescription": "insider AND trading",
                  "riskDriverName": "Compliance Scan",
                  "compilationStatus": "PASS",
                  "translatedPattern": "(?:insider|trading)",
                  "hsFlags": 3,
                  "requiresAndPostFilter": true
                },
                {
                  "termId": "test-rule::2",
                  "termDescription": "pump OR dump",
                  "riskDriverName": "Compliance Scan",
                  "compilationStatus": "PASS",
                  "translatedPattern": "(?:pump|dump)",
                  "hsFlags": 1,
                  "requiresAndPostFilter": false
                }
              ]
            }
            """;
    }

    private String failureBody() {
        return """
            {
              "lexiconRuleName": "test-rule",
              "totalTerms": 1,
              "passCount": 0,
              "failedCount": 1,
              "hasFailures": true,
              "results": [
                {
                  "termId": "test-rule::1",
                  "termDescription": "(unclosed pattern",
                  "riskDriverName": "Compliance Scan",
                  "compilationStatus": "FAILED",
                  "hsFlags": 0,
                  "requiresAndPostFilter": false,
                  "errorLog": "Syntax error: unclosed group"
                }
              ]
            }
            """;
    }
}
