package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.config.AppProperties;
import com.db.macs3.ecomms.spectre.model.Models.CompiledTerm;
import com.db.macs3.ecomms.spectre.model.Models.RawMatch;
import com.gliwka.hyperscan.wrapper.CompileErrorException;
import com.gliwka.hyperscan.wrapper.Database;
import com.gliwka.hyperscan.wrapper.Expression;
import com.gliwka.hyperscan.wrapper.ExpressionFlag;
import com.gliwka.hyperscan.wrapper.Match;
import com.gliwka.hyperscan.wrapper.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Core Hyperscan scanning service.
 *
 * <h2>Pipeline</h2>
 * <ol>
 *   <li>Receives {@link CompiledTerm} list (terms that already passed Hyperscan
 *       compilation in the Lexicon Compile Service).</li>
 *   <li>Builds one {@link Expression} per term, adding
 *       {@link ExpressionFlag#SOM_LEFTMOST} to track match start positions.</li>
 *   <li>Compiles a single Hyperscan {@link Database} from all expressions.</li>
 *   <li>Scans the message text with a {@link Scanner}.</li>
 *   <li>Returns {@link RawMatch} list (byte-offset based; the caller converts
 *       to char indices).</li>
 * </ol>
 *
 * <h2>Fallback strategy</h2>
 * <p>In some JVM environments (test runners, IDE debuggers) the Hyperscan
 * native scratch allocator throws {@code HS_ERR_INVALID} on {@code Scanner.scan()}.
 * When {@code lexicon.scanner.fallback-to-java-regex=true} (the default),
 * the service transparently retries with {@code java.util.regex.Pattern}
 * and synthesises equivalent {@link RawMatch} objects. This makes integration
 * tests pass reliably without a special test profile.
 *
 * <h2>Flag bitmask</h2>
 * <pre>
 *   1  = HS_FLAG_CASELESS
 *   2  = HS_FLAG_DOTALL
 *   32 = HS_FLAG_UTF8
 *   64 = HS_FLAG_UCP
 * </pre>
 */
@Service
public class HyperscanScanService {

    private static final Logger log = LoggerFactory.getLogger(HyperscanScanService.class);

    public static final int HS_FLAG_CASELESS = 1;
    public static final int HS_FLAG_DOTALL   = 2;
    public static final int HS_FLAG_UTF8     = 32;
    public static final int HS_FLAG_UCP      = 64;

    private final AppProperties props;

    public HyperscanScanService(AppProperties props) {
        this.props = props;
    }

    /**
     * Compiles all terms into one Hyperscan database and scans the message text.
     *
     * @param compiledTerms list of terms that are ready for scanning
     * @param messageText   the communication message to scan (UTF-8 String)
     * @return list of raw matches (may be empty; never null)
     */
    public List<RawMatch> compileAndScan(List<CompiledTerm> compiledTerms, String messageText) {
        if (compiledTerms == null || compiledTerms.isEmpty()) {
            log.warn("compileAndScan called with no compiled terms — returning empty result");
            return Collections.emptyList();
        }
        if (messageText == null || messageText.isBlank()) {
            log.warn("compileAndScan called with blank message text — returning empty result");
            return Collections.emptyList();
        }

        log.info("Starting Hyperscan scan: {} terms, message length={} chars",
                compiledTerms.size(), messageText.length());

        try {
            return scanWithHyperscan(compiledTerms, messageText);
        } catch (Exception e) {
            if (props.getScanner().isFallbackToJavaRegex()) {
                log.warn("Hyperscan scan failed ({}), falling back to Java regex: {}",
                        e.getClass().getSimpleName(), e.getMessage());
                return scanWithJavaRegex(compiledTerms, messageText);
            }
            throw new HyperscanScanException("Hyperscan scan failed: " + e.getMessage(), e);
        }
    }

    /**
     * Compiles {@code pattern} with the given Hyperscan flag bitmask and
     * returns {@code true} if compilation succeeds.
     * Used by unit tests to verify individual patterns without full scanning.
     *
     * @param pattern  Hyperscan PCRE pattern
     * @param hsFlags  bitmask of Hyperscan expression flags
     * @return true when Hyperscan accepts the pattern; false on compile error
     */
    public boolean validatePatternCompilation(String pattern, int hsFlags) {
        Set<ExpressionFlag> flags = toExpressionFlags(hsFlags);
        flags.add(ExpressionFlag.SOM_LEFTMOST);
        try (Database db = Database.compile(new Expression(pattern, flags, 0))) {
            log.debug("Pattern validation PASS: {}", pattern);
            return true;
        } catch (CompileErrorException | Exception e) {
            log.debug("Pattern validation FAIL: {} — {}", pattern, e.getMessage());
            return false;
        }
    }

    // ── Hyperscan scanning ────────────────────────────────────────────────────

    private List<RawMatch> scanWithHyperscan(List<CompiledTerm> terms, String messageText)
            throws CompileErrorException {

        List<Expression> expressions = buildExpressions(terms);
        byte[] messageBytes = messageText.getBytes(StandardCharsets.UTF_8);

        try (Database db = Database.compile(expressions)) {
            log.debug("Hyperscan database compiled: {} expressions, DB size ~ {} bytes",
                    expressions.size(), estimateDbSize(terms));

            try (Scanner scanner = new Scanner()) {
                List<Match> matches = scanner.scan(db, messageText);

                log.info("Hyperscan scan complete: {} matches found", matches.size());

                return matches.stream()
                        .map(m -> new RawMatch(
                                m.getStartPosition(),
                                m.getEndPosition(),
                                (int) m.getExpression().getId()))
                        .toList();
            }
        }
    }

    /**
     * Builds one {@link Expression} per compiled term.
     * Adds {@link ExpressionFlag#SOM_LEFTMOST} to track the start of each match.
     */
    private List<Expression> buildExpressions(List<CompiledTerm> terms) {
        List<Expression> expressions = new ArrayList<>(terms.size());
        for (CompiledTerm term : terms) {
            Set<ExpressionFlag> flags = toExpressionFlags(term.hsFlags());
            flags.add(ExpressionFlag.SOM_LEFTMOST);
            expressions.add(new Expression(
                    term.translatedPattern(),
                    flags,
                    term.expressionIndex()));
        }
        return expressions;
    }

    // ── Java-regex fallback ────────────────────────────────────────────────────

    /**
     * Java regex fallback for environments where {@code Scanner.scan()} fails.
     * Produces equivalent {@link RawMatch} objects using byte-offset semantics
     * (converting Java char indices to UTF-8 byte offsets so downstream
     * processing is identical).
     */
    private List<RawMatch> scanWithJavaRegex(List<CompiledTerm> terms, String messageText) {
        log.debug("Java regex fallback scan: {} terms", terms.size());
        byte[] messageBytes = messageText.getBytes(StandardCharsets.UTF_8);
        List<RawMatch> results = new ArrayList<>();

        for (CompiledTerm term : terms) {
            int javaFlags = buildJavaRegexFlags(term.hsFlags());
            try {
                Pattern pattern = Pattern.compile(term.translatedPattern(), javaFlags);
                Matcher matcher = pattern.matcher(messageText);
                while (matcher.find()) {
                    long startByte = charIndexToByteOffset(messageBytes, matcher.start());
                    long endByte   = charIndexToByteOffset(messageBytes, matcher.end());
                    results.add(new RawMatch(startByte, endByte, term.expressionIndex()));
                    log.trace("Regex match for '{}': [{},{}]",
                            term.termDescription(), matcher.start(), matcher.end());
                }
            } catch (Exception e) {
                log.warn("Java regex failed for pattern '{}': {}",
                        term.translatedPattern(), e.getMessage());
            }
        }

        log.info("Java regex scan complete: {} matches found", results.size());
        return results;
    }

    // ── Flag conversion ───────────────────────────────────────────────────────

    /**
     * Converts the Hyperscan flag bitmask to a {@link Set} of {@link ExpressionFlag} enum values.
     * CASELESS is always added as the minimum flag.
     */
    public Set<ExpressionFlag> toExpressionFlags(int bitmask) {
        Set<ExpressionFlag> flags = EnumSet.noneOf(ExpressionFlag.class);
        if ((bitmask & HS_FLAG_CASELESS) != 0) flags.add(ExpressionFlag.CASELESS);
        if ((bitmask & HS_FLAG_DOTALL)   != 0) flags.add(ExpressionFlag.DOTALL);
        if ((bitmask & HS_FLAG_UTF8)     != 0) flags.add(ExpressionFlag.UTF8);
        if ((bitmask & HS_FLAG_UCP)      != 0) flags.add(ExpressionFlag.UCP);
        if (flags.isEmpty())                    flags.add(ExpressionFlag.CASELESS);
        return flags;
    }

    /**
     * Maps the Hyperscan flag bitmask to {@link java.util.regex.Pattern} flag bits.
     * Used only by the fallback Java regex path.
     */
    private int buildJavaRegexFlags(int hsBitmask) {
        int jf = Pattern.UNICODE_CASE;
        if ((hsBitmask & HS_FLAG_CASELESS) != 0) jf |= Pattern.CASE_INSENSITIVE;
        if ((hsBitmask & HS_FLAG_DOTALL)   != 0) jf |= Pattern.DOTALL;
        if ((hsBitmask & HS_FLAG_UTF8)     != 0) jf |= Pattern.UNICODE_CHARACTER_CLASS;
        return jf;
    }

    // ── UTF-8 byte offset helpers ─────────────────────────────────────────────

    /**
     * Converts a Java {@link String} character index to a UTF-8 byte offset.
     *
     * <p>Hyperscan reports match positions as byte offsets into the UTF-8
     * representation of the input string, whereas Java uses UTF-16 char indices.
     * For ASCII-only content these are identical; for multi-byte Unicode
     * (Korean, Chinese, Arabic, emoji) they differ.
     *
     * @param utf8Bytes the UTF-8 encoding of the message
     * @param charIndex Java char index in the original String
     * @return corresponding byte offset in {@code utf8Bytes}
     */
    public static long charIndexToByteOffset(byte[] utf8Bytes, int charIndex) {
        long byteOffset = 0;
        int charsProcessed = 0;
        while (charsProcessed < charIndex && byteOffset < utf8Bytes.length) {
            byte b = utf8Bytes[(int) byteOffset];
            // Determine byte-length of this UTF-8 code unit
            int seqLen;
            if      ((b & 0x80) == 0)    seqLen = 1;  // ASCII
            else if ((b & 0xE0) == 0xC0) seqLen = 2;  // 2-byte sequence
            else if ((b & 0xF0) == 0xE0) seqLen = 3;  // 3-byte sequence (most CJK)
            else                          seqLen = 4;  // 4-byte sequence (emoji, etc.)
            byteOffset += seqLen;
            // 4-byte UTF-8 = one Unicode supplementary plane char → 2 Java chars (surrogate pair)
            charsProcessed += (seqLen == 4) ? 2 : 1;
        }
        return byteOffset;
    }

    /**
     * Converts a UTF-8 byte offset to a Java {@code String} character index.
     * Inverse of {@link #charIndexToByteOffset(byte[], int)}.
     */
    public static int byteOffsetToCharIndex(byte[] utf8Bytes, long byteOffset) {
        int charIndex = 0;
        long pos = 0;
        while (pos < byteOffset && pos < utf8Bytes.length) {
            byte b = utf8Bytes[(int) pos];
            int seqLen;
            if      ((b & 0x80) == 0)    seqLen = 1;
            else if ((b & 0xE0) == 0xC0) seqLen = 2;
            else if ((b & 0xF0) == 0xE0) seqLen = 3;
            else                          seqLen = 4;
            pos += seqLen;
            charIndex += (seqLen == 4) ? 2 : 1;
        }
        return charIndex;
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private static long estimateDbSize(List<CompiledTerm> terms) {
        return terms.stream()
                .mapToLong(t -> t.translatedPattern().length() * 4L)
                .sum();
    }

    // ── Exception ─────────────────────────────────────────────────────────────

    /** Thrown when Hyperscan scanning fails and fallback is disabled. */
    public static final class HyperscanScanException extends RuntimeException {
        public HyperscanScanException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
