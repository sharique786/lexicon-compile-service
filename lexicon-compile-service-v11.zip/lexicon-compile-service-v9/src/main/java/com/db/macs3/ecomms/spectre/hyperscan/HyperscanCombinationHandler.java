package com.db.macs3.ecomms.spectre.hyperscan;

import com.db.macs3.ecomms.spectre.model.TermCompilationResult;
import com.gliwka.hyperscan.wrapper.Expression;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Builds the Hyperscan {@link Expression}(s) one term needs in a
 * {@code /compile/bundle} combined database — the dedicated home for every
 * QUIET/COMBINATION decision this platform makes, kept separate from
 * {@link HyperscanCompiler} (general Hyperscan validation/serialisation,
 * with no opinion about ids or which terms need a combination) and
 * {@code LexiconCompileBundleService} (request orchestration, with no
 * opinion about expression construction).
 *
 * <h2>The id scheme: a term's reportable expression is ALWAYS its own term number</h2>
 * <p>Every PASS term's reportable Hyperscan expression id — whether it
 * compiles as one plain pattern or needs a logical combination — is ALWAYS
 * its own term number (parsed from its {@code termId}'s {@code ::<n>}
 * suffix). This is what makes the {@code .hdb} file self-sufficient: a
 * downstream consumer that already knows a term's number (from the lexicon
 * rule definition itself, independent of any compile response) can predict
 * which expression id to watch for that term without reading the JSON
 * response at all. Every QUIET sub-expression a combination needs
 * (decomposition leaves, the exclusion pattern(s)) is assigned an id from a
 * separate range — see {@link #computeIdOffset} / {@link HyperscanIdAllocator} —
 * that starts strictly above every real term number in the request and is
 * handed out sequentially, so it can never collide with a term number or
 * with any other auxiliary id.
 *
 * <p>This deliberately differs from an earlier version of this class, which
 * let the required side's own id BE the term number even when a combination
 * was needed (freeing the combination formula itself to need an allocated
 * id instead) — meaning the reportable id sometimes was the term number and
 * sometimes was not, and a consumer needed the JSON's own
 * {@code hyperscanExpressionId} field to find out which. The current
 * design has no such ambiguity: it is ALWAYS the term number.
 *
 * <h2>The flat-formula design, and why it avoids nested combinations</h2>
 * <p>Hyperscan's documented logical-combination syntax and Intel's own
 * official example ({@code "(101 & 102 & 103) | (104 & !105)"}, from
 * "Logical Combinations of Regular Expressions in Hyperscan") show a
 * combination expression's formula referencing plain pattern ids directly,
 * with arbitrary boolean structure and parenthesisation — but never one
 * combination expression referencing another combination expression's id.
 * Rather than rely on nested combinations working (unverified — worth
 * flagging explicitly, not assuming), this class builds AT MOST ONE
 * combination expression per term, whose formula references only plain
 * (non-combination) ids — every decomposition leaf, the required pattern if
 * not decomposed, and the exclusion pattern if not decomposed. Correctness
 * for a decomposed excluded side requires applying De Morgan's law
 * explicitly: decomposition combines leaves with AND ("all parts found" —
 * see {@code PatternDecomposer}), so the negation needed for AND NOT's
 * excluded side is
 * {@code NOT(E1 AND E2 AND ... AND Em) = (NOT E1) OR (NOT E2) OR ... OR (NOT Em)},
 * not a naive AND of negations (which would incorrectly exclude the term
 * even when only ONE decomposed exclusion leaf was absent, rather than ALL of them).
 *
 * <table>
 * <caption>Combination formula by case (R = required id(s), E = excluded id(s))</caption>
 * <tr><td>Plain, single pattern, no AND NOT</td><td>no combination — {@code id = termNumber} directly</td></tr>
 * <tr><td>Decomposed, no AND NOT</td><td>{@code (R1&R2&...&Rn)}, id = termNumber</td></tr>
 * <tr><td>AND NOT, neither side decomposed</td><td>{@code (R&!E)}, id = termNumber</td></tr>
 * <tr><td>AND NOT, required decomposed</td><td>{@code (R1&R2&...&Rn&!E)}, id = termNumber</td></tr>
 * <tr><td>AND NOT, excluded decomposed</td><td>{@code (R&(!E1|!E2|...|!Em))}, id = termNumber</td></tr>
 * <tr><td>AND NOT, both decomposed</td><td>{@code (R1&...&Rn&(!E1|...|!Em))}, id = termNumber</td></tr>
 * </table>
 *
 * <h2>Flag constraint: COMBINATION only pairs with QUIET/SINGLEMATCH</h2>
 * <p>A Hyperscan expression flagged {@code COMBINATION} may only additionally
 * carry {@code QUIET} and/or {@code SINGLEMATCH} — never {@code CASELESS},
 * {@code UTF8}, {@code UCP}, {@code DOTALL}, or {@code SOM_LEFTMOST}, which
 * apply only to the plain sub-expressions being combined, not to the
 * boolean formula referencing their ids. {@link HyperscanCompiler#toCombinationExpressionFlags}
 * already returns exactly {@code {COMBINATION}} and nothing else, so this
 * constraint holds automatically everywhere this class builds a combination
 * expression.
 */
@Component
public class HyperscanCombinationHandler {

    private final HyperscanCompiler compiler;

    public HyperscanCombinationHandler(HyperscanCompiler compiler) {
        this.compiler = compiler;
    }

    /**
     * The auxiliary (non-term-number) id range must never overlap a real
     * term number, however sparse or large those term numbers are.
     * {@code offset = (largest term number) + 1} is the first id available
     * for every QUIET sub-expression this request needs; every subsequent
     * auxiliary id is handed out sequentially from there by
     * {@link HyperscanIdAllocator}.
     */
    public int computeIdOffset(Collection<Integer> termNumbers) {
        return termNumbers.stream().mapToInt(Integer::intValue).max().orElse(0) + 1;
    }

    /**
     * Hands out sequentially increasing ids for QUIET sub-expressions within
     * one bundle request (decomposition leaves, exclusion pattern(s)).
     * Starting from {@link #computeIdOffset}, every id this allocator
     * returns is guaranteed distinct from every real term number and from
     * every other id it has already handed out.
     */
    public static final class HyperscanIdAllocator {
        private int nextId;
        public HyperscanIdAllocator(int startId) { this.nextId = startId; }
        public int allocate() { return nextId++; }
    }

    /**
     * Adds this PASS term's Hyperscan {@link Expression}(s) to
     * {@code expressionsOut}, ALWAYS using {@code id = termNumber} for the
     * term's one reportable expression — see class Javadoc.
     *
     * @param termResult   a PASS result — {@code translatedPattern} (and,
     *                      when {@code requiresExclusionCheck}, {@code exclusionPattern})
     *                      one or more independently Hyperscan-validated patterns each
     * @param termNumber    this term's own term number, parsed from its {@code termId}
     * @param idAllocator   shared across the whole bundle request — see {@link #computeIdOffset}
     * @param expressionsOut every expression this term needs is appended here
     * @param includeSom     whether to include SOM_LEFTMOST on every QUIET sub-expression —
     *                        see {@code TypedCompileRequest#trackMatchPosition}. A plain,
     *                        non-combination term's single expression always includes it
     *                        regardless (matching pre-existing behaviour) unless this is false.
     */
    public void addExpressions(TermCompilationResult termResult, int termNumber,
                                HyperscanIdAllocator idAllocator, List<Expression> expressionsOut,
                                boolean includeSom) {
        List<String> requiredPatterns = termResult.translatedPattern();
        boolean needsCombination = termResult.requiresExclusionCheck() || requiredPatterns.size() > 1;

        if (!needsCombination) {
            // Simplest, most common case — one plain pattern, reportable directly.
            expressionsOut.add(new Expression(
                    requiredPatterns.get(0),
                    compiler.toExpressionFlags(termResult.hyperscanFlags(), includeSom),
                    termNumber));
            return;
        }

        List<Integer> requiredIds = addQuietSide(
                requiredPatterns, idAllocator, expressionsOut, termResult.hyperscanFlags(), includeSom);
        String requiredFormula = joinWithAnd(requiredIds);

        String combinationFormula;
        if (termResult.requiresExclusionCheck()) {
            List<Integer> excludedIds = addQuietSide(
                    termResult.exclusionPattern(), idAllocator, expressionsOut,
                    termResult.hyperscanFlags(), includeSom);
            String excludedNegated = excludedIds.size() == 1
                    ? "!" + excludedIds.get(0)
                    : "(" + excludedIds.stream().map(id -> "!" + id).collect(Collectors.joining("|")) + ")";
            combinationFormula = "(" + requiredFormula + "&" + excludedNegated + ")";
        } else {
            combinationFormula = "(" + requiredFormula + ")";
        }

        expressionsOut.add(new Expression(combinationFormula, compiler.toCombinationExpressionFlags(), termNumber));
    }

    /** Adds every pattern in {@code patterns} as its own QUIET expression, returning their allocated ids. */
    private List<Integer> addQuietSide(List<String> patterns, HyperscanIdAllocator idAllocator,
                                        List<Expression> expressionsOut, int hyperscanFlags, boolean includeSom) {
        List<Integer> ids = new ArrayList<>(patterns.size());
        for (String pattern : patterns) {
            int id = idAllocator.allocate();
            expressionsOut.add(new Expression(
                    pattern, compiler.toSubExpressionFlags(hyperscanFlags, includeSom), id));
            ids.add(id);
        }
        return ids;
    }

    private static String joinWithAnd(List<Integer> ids) {
        return ids.stream().map(String::valueOf).collect(Collectors.joining("&"));
    }
}
