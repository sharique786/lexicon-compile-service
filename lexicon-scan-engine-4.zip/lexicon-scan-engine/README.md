# Lexicon Scan Engine

A Dataproc/Spark batch job that scans messages and attachments against
Hyperscan-compiled lexicon feature databases, applies the noise-reduction /
disclaimer / lexicon decision tree, and writes hit and audit results to
BigQuery.

Base package: `com.db.macs3.ecomms.spectre.scanengine`

---

## What's new in this revision

### 1. Java 11 compatibility (was targeting Java 17+ records)

Every domain model in this project was originally written as a Java 17+
`record`. Records aren't available at all in Java 11 (not even as a
preview feature — preview support started in Java 14), so all **35 record
classes across 24 files** were converted to plain Java 11 classes:
private final fields, an explicit canonical constructor, and one accessor
method per field.

**The accessor method names were deliberately kept identical to what a
record would have generated** (`.messageId()`, `.featureId()`, `.matches()`,
etc.) specifically so no calling code anywhere in the project needed to
change — only the class *declaration* changed, not its public shape.
`equals`/`hashCode`/`toString` were hand-written per class using the same
value-equality semantics a record provides by default.

Two other Java 12+ features were found and fixed the same way:

- An arrow-syntax `switch` expression (Java 14+) in `OutputRowBuilder` →
  converted to a traditional `switch` statement.
- A non-constant `static` field inside a JUnit `@Nested` inner class (only
  legal from Java 16 onward) → converted to an instance field, since
  `@Nested` classes are inherently non-static inner classes.

JSON (de)serialization for the classes that used to rely on Jackson reading
record components (`FeatureDefinition`, `MatchedTextJson`, `RuntimeArgs`,
`BqTableConfig`) now uses the standard, portable `@JsonCreator` constructor
+ `@JsonProperty`-per-parameter pattern — the conventional way to get
Jackson to deserialize into an immutable class without records or JavaBean
setters.

`pom.xml` already targeted Java 11
(`<java.version>11</java.version>`, `maven.compiler.source/target=11`) and
Spring Boot 2.7.18 (the last Spring Boot line with full Java 11 support,
since Spring Boot 3.x requires Java 17+) — this revision makes the actual
source code match that target, verified with `javac --release 11` rather
than a plain compile (which would silently tolerate newer syntax).

### 2. Spring Boot integration (was zero `@Component`/`@Service` usage)

The job previously had a plain `static void main(String[])` entry point
with no Spring wiring at all, despite `spring-boot-starter` already being a
project dependency.

**A Spark job's driver and its executors are separate JVMs.** Executors run
whatever closures Spark serializes and ships to them; they have no Spring
`ApplicationContext` of their own — Spring's dependency-injection container
fundamentally cannot span a Spark cluster. This shaped where Spring was
(and wasn't) introduced:

| Class | Runs on | Spring-managed? |
|---|---|---|
| `ScanEngineApplication` | Driver | `@SpringBootApplication` — real entry point now |
| `ScanEngineJobRunner` | Driver | `@Service`, constructor-injected with `GcsClient` + `ScanEngineProperties` |
| `GcsClient` | Driver **and** executors | `@Component` for driver injection; also plain `new GcsClient()`-constructible for executor-side use inside `PartitionProcessor`'s closure — both work identically since it holds no Spring-specific state |
| `PartitionProcessor`, `HyperscanDatabaseLoader`, `FeatureScanOrchestrator`, `DecisionTreeEvaluator`, `FeatureGroupingService`, `OutputRowBuilder`, and every static utility class | Executors (inside `mapPartitions`) | Deliberately plain, Spring-independent Java — must be constructible and Java-serializable with no `ApplicationContext` available, since that's exactly the environment they run in once Spark ships them to an executor |

`ScanEngineProperties` is now bound via a **real** Spring
`@ConfigurationProperties` context (`application.yml` /
`application-test.yml`), not the manual `spark.conf().get(...)`
reconstruction the old code used as a workaround. One subtlety worth
knowing: `SPECTRE_MAX_ATTACHMENT_SIZE_BYTES` doesn't follow the
`scan-engine.*` prefix's relaxed-binding naming convention (that would
expect `SCAN_ENGINE_MAX_ATTACHMENT_SIZE_BYTES`), so that one property is
bound via `@Value("${SPECTRE_MAX_ATTACHMENT_SIZE_BYTES:#{null}}")`
specifically rather than the class's own `@ConfigurationProperties`
binding.

### 3. `lexicon-hit-summary` schema change

- `evaluated_lexicons.term_dtls.min_hit_count` — **removed**. No longer
  populated; `minimumHits` remains informational-only for this engine (a
  later downstream process applies it) and is no longer echoed per-term.
- `evaluated_lexicons.term_dtls.regex_match_hit_count` (`INT64`) — **added**.
  For each `term_id`, this is the count of every individual occurrence that
  term's compiled Hyperscan pattern matched in the message text — every
  occurrence across every scanned area (subject, message body, each
  attachment), not just a yes/no or a distinct-area count. A pattern like
  `(?:market|manipulate)` matching 5 separate times in the message body
  records `5` here. Column order matches the confirmed schema:
  `term_id` → `term_regex_pattern` → `regex_match_hit_count`.

This is computed from the same `TermMatchResult` each term's matches are
already collected into (`OutputRowBuilder.buildSummaryRow`) — it's the size
of that term's match list, taken from the **raw, pre-disclaimer-suppression**
scan results (matching this table's existing "broad summary of everything
checked" semantics, as opposed to `lexicon-hit-restricted`/`-unrestricted`,
which use the suppressed set).

---

## Architecture

```
BQ view (vw_src_msg_lexicon_decision_mapping)     AVRO messages (GCS)
        │  filtered, grouped by message_id                │  filtered to relevant message_ids
        └──────────────────────┬───────────────────────────┘
                                │  join on message_id
                                ▼
                    mapPartitions(PartitionProcessor)
                    (one HyperscanDatabaseLoader + FeatureScanOrchestrator
                     per partition — see "Driver-load discipline" below)
                                │
                for each message: FeatureGroupingService.groupAndOrder()
                              → DecisionTreeEvaluator.evaluate()
                              → OutputRowBuilder.build*()
                                │
                                ▼
                    MessageProcessingResult (success or per-message error)
                                │
                ┌───────────────┼───────────────┬─────────────────┐
                ▼               ▼               ▼                 ▼
      lexicon-hit-summary   lexicon-hit-      feature-hit-   pipeline_record_audit
                             restricted/       summary        (failures only)
                             unrestricted
                             (+ CSV mirror)
```

### Decision-tree logic (`FeatureGroupingService` + `DecisionTreeEvaluator`)

1. View rows for one message are grouped by `feature_id` into
   `FeatureGroup`s, then ordered: **NoiseReduction → Disclaimer → Lexicon**.
2. Each **NoiseReduction** group is evaluated in order; the moment one is a
   hit (its `OR`/`AND` operator resolved across its members), evaluation
   **stops entirely** — every later group (further NoiseReduction, the
   Disclaimer group, all Lexicon groups) is never evaluated, not
   evaluated-and-discarded.
3. If no NoiseReduction group short-circuits, the **Disclaimer** group (if
   present) is scanned exactly like a standard lexicon feature — it is not
   the Scanner Service's separate exact-substring detector. Its matches are
   recorded for the next step.
4. Every **Lexicon**-category group is scanned; any match **fully contained**
   within a disclaimer match's span (same area, and same `attachmentId` for
   attachments — never across different coordinate spaces) is suppressed.
   Partial overlap does **not** suppress a match.

### `HtmlStrippingService`

HTML tags and whitespace runs are collapsed to a single space before
scanning, with an offset map translating stripped-text match positions back
to the original text. Verified against the requirement's own worked
example: `startCharIndex=3`, `matchedText="Enjoy Happy"` match exactly;
`endCharIndex` computes to `21` (the requirement's prose states `22`,
which — checked multiple independent ways — does not appear to be
internally consistent with its own `startCharIndex`/`matchedText`; treated
as a documentation slip, flagged in code).

### Memory-safety design (`HyperscanDatabaseLoader`, `LruCache`)

An earlier approach read every `.hdb` file's full bytes on the **driver**
into a `Map<String, byte[]>` and broadcast that whole map to every executor
— risking driver OOM for many/large files, and wasting executor memory on
files a given partition never needs.

This engine instead:
- Resolves the Hyperscan compile folder's wildcard timestamp segment with
  **exactly one GCS listing call per job run** (`HyperscanPathResolver`),
  then builds every feature's `.hdb` path by simple string concatenation.
- Broadcasts only the small, string-only `feature → path` map.
- Loads actual `.hdb` bytes **lazily, per partition, streamed** (not fully
  buffered) — one `HyperscanDatabaseLoader` per Spark partition (via
  `mapPartitions`, not `map`, specifically so this loader and its cache are
  constructed once and reused across every message in that partition).
- Bounds each partition's cumulative loaded-database memory with a
  configurable `LruCache` (`scan-engine.max-cached-databases-per-partition`,
  default 20), evicting the least-recently-used database rather than
  growing without bound.

---

## Output tables

| Table | Grain | Notes |
|---|---|---|
| `lexicon-hit-summary` | One row per message | One `evaluated_lexicons` entry per **evaluated feature group** (not per sub-feature member) — includes NoiseReduction/Disclaimer/Lexicon groups alike, using raw (pre-suppression) match counts |
| `lexicon-hit-restricted` | One row per message (restricted source only) | Lexicon-category groups only, **post** disclaimer-suppression; `matched_text` is a serialized `hit_details_hs` JSON structure per term |
| `lexicon-hit-unrestricted` | One row per message (unrestricted source only) | Identical shape to `-restricted`, split purely by source GCS subfolder |
| `feature-hit-summary` | One row per message | Every evaluated group's resolved hit status, plus each multi-member group's own sub-feature breakdown |
| `pipeline_stage_audit` | One row per job start + one per completion | `IN_PROGRESS` → `SUCCESS`/`FAILED` |
| `pipeline_record_audit` | One row per **failed** message | Per-message processing failures — the whole job does not fail on one message's error |

`lexicon-hit-restricted`'s rows are also mirrored to a single CSV file at
`gs://<environment_bkt>/<policy_engine_id>/<process_id>/restricted/<pipeline_exec_id>.csv`
(nested columns flattened to JSON strings, since CSV has no native nested
representation).

---

## Configuration

| Source | Carries |
|---|---|
| `RuntimeArgs` (JSON, Airflow-supplied) | `dataset_details[]`, `feature_partition_value`, `pipeline_exec_id`, `policy_engine_id`, `process_id`, `trigger_type` |
| `BqTableConfig` (JSON on GCS, path passed as a Dataproc submit argument) | Fully-qualified view/table identifiers |
| `application.yml` / `application-test.yml` (Spring) | GCS buckets, cache sizing, audit identity strings |
| `SPECTRE_MAX_ATTACHMENT_SIZE_BYTES` (env var) | Skip attachments larger than this; unset = unlimited |

Confirmed values: `trigger_type` is `policy-alert-live` (always exactly one
`dataset_details` entry) or `policy-alert-test` (can have several — read
and unioned per entry).

---

## Build & test

```bash
mvn clean test        # unit + JUnit 5 tests, JaCoCo coverage report
mvn clean package      # shaded jar for Dataproc submission
```

Tests run against the `test` Spring profile (`application-test.yml`).

---

## Deployment

```bash
gcloud dataproc jobs submit spark \
  --cluster=<cluster-name> \
  --region=<region> \
  --jar=gs://<bucket>/lexicon-scan-engine-1.0.0.jar \
  --class=com.db.macs3.ecomms.spectre.scanengine.spark.ScanEngineApplication \
  --properties="<see Spark configuration below>" \
  -- \
  gs://<bucket>/runtime-args/<process_id>.json \
  gs://<bucket>/config/bq-table-config.json
```

---

## Spark configuration

Starting points below — this job has not run against a live cluster yet
(no Spark/GCP connectivity in this project's development environment), so
these are reasoned defaults grounded in the job's own architecture and
current Dataproc/Spark tuning guidance, not numbers pulled from an actual
run. **Treat them as a starting point to monitor and adjust from**,
particularly executor sizing and partition counts, once real message
volumes and `.hdb` file sizes are known.

### Executor sizing — favor moderate cores per executor, not maximal

```
spark.executor.cores=4
spark.executor.memory=14g
spark.executor.memoryOverhead=6g
spark.executor.instances=<see dynamic allocation below>
```

The general Spark best practice of ~5 cores per executor (the widely-cited
balance between within-executor parallelism and GC/overhead pressure — very
high core counts cause more GC contention, very low counts under-utilize
each executor) applies here, but this job has an **additional, specific**
reason to stay on the low side of that range: each concurrent task on an
executor can trigger its own `.hdb` load-and-cache cycle
(`HyperscanDatabaseLoader`, up to `max-cached-databases-per-partition`
entries each). More cores means more concurrent partitions means more
simultaneous native-memory pressure and more simultaneous GCS read
connections from the same executor. 4 cores keeps this bounded while still
getting reasonable parallelism.

**`memoryOverhead` needs to be explicitly generous, not left at Dataproc's
auto-calculated default.** Hyperscan is accessed via JNI — every loaded
`.hdb` database and every active `Scanner` consumes **off-heap** native
memory that the JVM heap sizing (and therefore Dataproc's own default
overhead calculation) knows nothing about. Undersizing this is a likely
source of YARN killing containers for exceeding physical memory even when
the JVM heap itself looks healthy in the Spark UI. Start with the ~6GB
above (well beyond the ~1-4GB typical non-native-library default) and
watch for container-killed errors; raise further if `.hdb` files turn out
to be large or `max-cached-databases-per-partition` is increased.

### Partitioning

```
spark.sql.adaptive.enabled=true
spark.sql.adaptive.coalescePartitions.enabled=true
spark.sql.shuffle.partitions=<start at 2-3x total executor cores, let AQE adjust>
```

Adaptive Query Execution should stay on — it rebalances post-shuffle
partition sizes automatically after the message↔view join and the view's
`groupBy(message_id)` aggregation, both of which have data-dependent skew
potential (some messages legitimately have far more applicable features
than others).

Aim for partitions large enough that a partition's `HyperscanDatabaseLoader`
cache gets reused across a meaningful number of messages before the task
ends (a partition of a few dozen messages barely benefits from the
per-partition cache at all), but not so large that one partition's peak
memory (its own message batch plus up to `max-cached-databases-per-partition`
loaded `.hdb` files) risks exceeding executor memory. A few thousand
messages per partition is a reasonable target to tune around, adjusted by
`spark.sql.files.maxPartitionBytes` on the AVRO read side or an explicit
`.repartition()` after the join if the natural file-based partitioning
doesn't land near that.

### Serialization

```
spark.serializer=org.apache.spark.serializer.KryoSerializer
```

`PartitionProcessor`'s `mapPartitions` result type (`MessageProcessingResult`)
is already read via `Encoders.kryo(...)` in code; setting Kryo as the
**default** serializer (not just for that one Encoder) speeds up shuffle
and broadcast serialization generally too. Explicit class registration
(`spark.kryo.registrationRequired=true` plus a registrator) is optional —
Kryo works correctly without it, just marginally slower on first use of an
unregistered class — worth adding later if serialization shows up in
profiling, not a correctness requirement now.

### BigQuery connector writes

```
spark.datasource.bigquery.writeMethod=indirect
spark.datasource.bigquery.intermediateFormat=avro
spark.datasource.bigquery.temporaryGcsBucket=<staging-bucket>
```

For datasets above roughly 10GB, the indirect write path (stage as Avro on
GCS, then a single BigQuery load job) generally outperforms the direct
Storage Write API path, which is the better fit for the small, per-message-
scale tables here (`lexicon-hit-summary`, `-restricted`, `-unrestricted`,
`feature-hit-summary`, given "millions of messages"). The two audit tables
(`pipeline_stage_audit`: two rows per run; `pipeline_record_audit`: only
failed messages, expected to be a small fraction) are small enough that
`writeMethod=direct` is a reasonable alternative for just those two writes
if per-table tuning is preferred over one global setting — `OutputTableWriter`
doesn't currently set `writeMethod` explicitly (it uses the connector's own
default), so this is worth revisiting as an explicit `.option(...)` per
table if write performance profiling shows it matters.

### Dynamic allocation

```
spark.dynamicAllocation.enabled=true
spark.dynamicAllocation.minExecutors=<baseline for the audit-write tail>
spark.dynamicAllocation.maxExecutors=<peak for expected daily message volume>
spark.dynamicAllocation.shuffleTracking.enabled=true
```

Daily message volume is not fixed, so scaling executor count to the actual
workload (rather than a fixed `--num-executors`) avoids both
over-provisioning on light days and under-provisioning on heavy ones.
Align the min/max bounds with the underlying Dataproc cluster's own
autoscaling policy so the two don't fight each other.

### Speculative execution

```
spark.speculation=false
```

Leave off, at least initially. Each task does real external work (a
possible GCS `.hdb` fetch on cache miss, and ultimately a BigQuery write)
— a speculative retry duplicates that work, and this job's correctness
depends on the BigQuery connector's own handling of a duplicated write
attempt, which has not been verified against a live cluster here. Revisit
only after confirming the connector's duplicate-write behavior is safe for
this job's write pattern.

### GCS connector (per-partition `.hdb` streaming reads)

```
spark.hadoop.fs.gs.io.buffersize=<tune from default if profiling shows read latency>
spark.hadoop.fs.gs.http.max.retry=10
```

Every cache miss in `HyperscanDatabaseLoader` opens a fresh GCS read
stream; with many executors and moderate core counts, this can mean a
meaningful number of concurrent GCS connections at job start (before each
partition's cache warms up). The retry setting above is a safety margin
for transient GCS throttling under that initial burst; the buffer size is
worth profiling against actual `.hdb` file sizes rather than guessed.

---

## Known limitations / deferred work

- **~~AND NOT / decomposed term expression-ID resolution~~ — resolved.**
  The Compile Service's `/compile/bundle` endpoint now guarantees every PASS
  term's reportable Hyperscan expression id is *always* its own term number
  (`HyperscanCombinationHandler`'s id scheme), whether the term compiled as
  a single plain pattern or needed a QUIET/COMBINATION structure for AND
  NOT or decomposition. This engine's `term_id = feature::expressionId`
  convention (`TermIdBuilder`, `FeatureScanOrchestrator`) now works
  correctly and uniformly for every term type with no special-casing —
  QUIET auxiliary sub-expressions are never reported as matches at all
  (Hyperscan's own callback mechanism filters them out), so this engine
  never even sees an expression id for one.
- **~~`term_regex_pattern` is not populated~~ — resolved.** Rather than
  needing to separately read the Compile Service's JSON output, the pattern
  text is read directly from the match itself:
  `com.gliwka.hyperscan-java`'s `Match.getMatchedExpression().getExpression()`
  returns the original pattern text embedded in the `.hdb` file's own
  expression metadata. `HyperscanScanService.scan()` reads it directly, and
  `ExpressionIdResolver` was simplified accordingly — it now only resolves
  a `termId` string, not a bundled `(termId, pattern)` pair.
- **Spark/BigQuery/GCS-dependent code is not executable-verified** in this
  project's development environment (no live cluster or GCP credentials
  available here). Written carefully against documented APIs and covered
  by unit tests wherever the logic could be isolated from those
  dependencies, but should be exercised against a real cluster (or the
  integration test setup once built) before first production use.
- **Integration test harness, Dockerfile** — not yet built.
