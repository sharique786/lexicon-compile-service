package com.db.macs3.ecomms.spectre.reader;

import com.db.macs3.ecomms.spectre.model.ScanEngineArgs;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryException;
import com.google.cloud.bigquery.TableInfo;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link BigQueryViewReader}.
 *
 * <p>Verifies the SQL view SQL is structurally correct and that
 * view creation / update logic handles the 404 (create) vs existing (update) paths.
 * The Spark Dataset read methods are tested via Spark integration tests (not included here
 * to avoid requiring a BQ connection in unit tests).
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("BigQueryViewReader Tests")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class BigQueryViewReaderTest {

    @Mock
    private BigQuery mockBigQuery;

    private BigQueryViewReader reader;
    private ScanEngineArgs     args;

    @BeforeEach
    void setUp() {
        reader = new BigQueryViewReader(mockBigQuery);
        args   = ScanEngineArgs.parse(new String[]{
            "--processId",      "proc-123",
            "--pipelineExecId", "exec-456",
            "--policyEngineId", "pol-789",
            "--triggerType",    "POLICY_TEST",
            "--runDate",        "2026-06-25",
            "--hdbGcsBucket",   "hdb-bucket",
            "--hdbGcsPrefix",   "databases",
            "--msgGcsBucket",   "msg-bucket",
            "--msgGcsPrefix",   "messages",
            "--bqProject",      "my-project",
            "--bqDataset",      "working_dataset"
        });
    }

    // ── SQL structure tests ────────────────────────────────────────────────────

    @Test @Order(1)
    @DisplayName("buildViewSql contains CREATE OR REPLACE VIEW with correct view reference")
    void viewSqlContainsCorrectViewRef() {
        String sql = reader.buildViewSql(args);
        assertThat(sql).contains("CREATE OR REPLACE VIEW");
        assertThat(sql).contains("my-project.working_dataset." + ScanEngineArgs.BQ_VIEW_NAME);
    }

    @Test @Order(2)
    @DisplayName("buildViewSql references both source BQ tables")
    void viewSqlReferencesBothSourceTables() {
        String sql = reader.buildViewSql(args);
        assertThat(sql).contains(ScanEngineArgs.BQ_LANGUAGE_FEATURE_DEC);
        assertThat(sql).contains(ScanEngineArgs.BQ_FEATURE_MASTER);
    }

    @Test @Order(3)
    @DisplayName("buildViewSql contains UNNEST for features array (language-feature-decision)")
    void viewSqlUnnestsLfdFeatures() {
        String sql = reader.buildViewSql(args);
        // Must unnest the features ARRAY from language-feature-decision
        assertThat(sql).containsIgnoringCase("UNNEST(lfd.features)");
    }

    @Test @Order(4)
    @DisplayName("buildViewSql filters feature-master to lexicon type features")
    void viewSqlFiltersLexiconType() {
        String sql = reader.buildViewSql(args);
        assertThat(sql).contains("feature_type = 'lexicon'");
    }

    @Test @Order(5)
    @DisplayName("buildViewSql contains UNNEST for sub_features array (Composite handling)")
    void viewSqlUnnestsSubFeatures() {
        String sql = reader.buildViewSql(args);
        assertThat(sql).containsIgnoringCase("UNNEST(fm.sub_features)");
        assertThat(sql).contains("feature_type = 'Composite'");
        assertThat(sql).contains("sf.type = 'lexicon'");
    }

    @Test @Order(6)
    @DisplayName("buildViewSql selects resolved_feature_definition (fm_feature_definition alias)")
    void viewSqlSelectsResolvedDefinition() {
        String sql = reader.buildViewSql(args);
        assertThat(sql).contains("resolved_feature_definition");
        assertThat(sql).contains("fm_feature_definition");
    }

    @Test @Order(7)
    @DisplayName("buildViewSql joins on process_id = policy_engine_id and feature_name")
    void viewSqlJoinConditions() {
        String sql = reader.buildViewSql(args);
        assertThat(sql).contains("process_id");
        assertThat(sql).contains("policy_engine_id");
        assertThat(sql).contains("feature_name");
    }

    @Test @Order(8)
    @DisplayName("buildViewSql contains UNION ALL between lexicon and composite CTE")
    void viewSqlContainsUnionAll() {
        String sql = reader.buildViewSql(args);
        assertThat(sql).containsIgnoringCase("UNION ALL");
    }

    @Test @Order(9)
    @DisplayName("buildViewSql includes is_noise_reduction with COALESCE for null safety")
    void viewSqlHandlesNullNoiseReduction() {
        String sql = reader.buildViewSql(args);
        assertThat(sql).containsIgnoringCase("COALESCE");
        assertThat(sql).contains("is_noise_reduction");
    }

    // ── View creation: update path (table exists) ─────────────────────────────

    @Test @Order(20)
    @DisplayName("createOrReplaceView updates existing view (BQ update called)")
    void createOrReplace_updatesExistingView() {
        // BQ.update() returns a non-null Table → view already exists, no create needed
        when(mockBigQuery.update(any(TableInfo.class))).thenReturn(null);

        assertThatCode(() -> reader.createOrReplaceView(args)).doesNotThrowAnyException();
        verify(mockBigQuery, times(1)).update(any(TableInfo.class));
        verify(mockBigQuery, never()).create(any(TableInfo.class));
    }

    // ── View creation: create path (404 on update) ────────────────────────────

    @Test @Order(21)
    @DisplayName("createOrReplaceView creates view when BQ returns 404 on update")
    void createOrReplace_createsWhenNotFound() {
        // Simulate BQ returning 404 (view doesn't exist yet)
        when(mockBigQuery.update(any(TableInfo.class)))
                .thenThrow(new BigQueryException(404, "Not found"));
        when(mockBigQuery.create(any(TableInfo.class))).thenReturn(null);

        assertThatCode(() -> reader.createOrReplaceView(args)).doesNotThrowAnyException();
        verify(mockBigQuery, times(1)).update(any(TableInfo.class));
        verify(mockBigQuery, times(1)).create(any(TableInfo.class));
    }

    // ── View creation: unexpected error ────────────────────────────────────────

    @Test @Order(22)
    @DisplayName("createOrReplaceView propagates non-404 BQ exceptions")
    void createOrReplace_propagatesNon404Exception() {
        when(mockBigQuery.update(any(TableInfo.class)))
                .thenThrow(new BigQueryException(500, "Internal Server Error"));

        assertThatThrownBy(() -> reader.createOrReplaceView(args))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Failed to create/update BQ view");
    }
}
