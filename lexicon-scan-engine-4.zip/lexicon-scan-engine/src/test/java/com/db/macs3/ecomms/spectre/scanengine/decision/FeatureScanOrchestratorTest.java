package com.db.macs3.ecomms.spectre.scanengine.decision;

import com.db.macs3.ecomms.spectre.scanengine.hyperscan.HyperscanDatabaseLoader;
import com.db.macs3.ecomms.spectre.scanengine.model.match.MatchArea;
import com.db.macs3.ecomms.spectre.scanengine.model.match.TermMatchResult;
import com.db.macs3.ecomms.spectre.scanengine.model.message.*;
import com.db.macs3.ecomms.spectre.scanengine.model.view.FeatureDecisionRow;
import com.gliwka.hyperscan.wrapper.Database;
import com.gliwka.hyperscan.wrapper.Expression;
import com.gliwka.hyperscan.wrapper.ExpressionFlag;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

@DisplayName("FeatureScanOrchestrator")
class FeatureScanOrchestratorTest {

    private static FeatureDecisionRow row(String featureId, String featuresToApply, String defJson) {
        return new FeatureDecisionRow("proc-1", "msg-101", "part-1", "Lexicon-Tagging",
                "lexicon", featureId, featureId + "-name", null, featuresToApply,
                "N", null, defJson, "2026-08-16", "101");
    }

    private static String defJson(String feature, String... scopes) {
        StringBuilder scopeArr = new StringBuilder("[");
        for (int i = 0; i < scopes.length; i++) {
            if (i > 0) scopeArr.append(",");
            scopeArr.append("\"").append(scopes[i]).append("\"");
        }
        scopeArr.append("]");
        return "{\"featureName\":\"x\",\"featureType\":\"Lexicon\",\"isNoiseReduction\":false,"
                + "\"body\":{\"feature\":\"" + feature + "\",\"totalTermsCount\":5,\"minimumHits\":1,"
                + "\"scope\":" + scopeArr + "}}";
    }

    private static HyperscanDatabaseLoader.GcsByteStreamer seedingStreamer() {
        return path -> {
            Database.testCurrentLoadPath = path;
            return new ByteArrayInputStream(new byte[]{1});
        };
    }

    @Test
    @DisplayName("only scans the areas the feature's scope covers")
    void respectsScopeAreaSelection() {
        Map<String, String> pathMap = Map.of("lex_bomb-1", "gs://bucket/lex_bomb-1.hdb");
        Database.testPathToExpressions = Map.of("gs://bucket/lex_bomb-1.hdb", List.of(
                new Expression("bomb", EnumSet.of(ExpressionFlag.SOM_LEFTMOST, ExpressionFlag.CASELESS), 1)));

        HyperscanDatabaseLoader loader = new HyperscanDatabaseLoader(pathMap, seedingStreamer(), 10);
        FeatureScanOrchestrator orchestrator = new FeatureScanOrchestrator(loader, null);

        ScanMessage message = new ScanMessage("msg-101",
                new MessageSource("chat", "src", "sys", "conv-1"),
                new MessageContent(null, "there is a bomb in the body", "bomb in subject too", null),
                List.of(new MessageAttachment("att-1", null, "file.txt", "bomb in attachment too")),
                new MessageProcessing("2026-08-16", "10"), "ds1", true);

        FeatureDecisionRow bodyOnlyRow = row("1", "lex_bomb-1", defJson("lex_bomb-1", "Message Body"));
        List<TermMatchResult> results = orchestrator.scannerFor(message).scan(bodyOnlyRow);

        assertThat(results).hasSize(1);
        assertThat(results.get(0).matches()).hasSize(1);
        assertThat(results.get(0).matches().get(0).area()).isEqualTo(MatchArea.MESSAGE_BODY);
    }

    @Test
    @DisplayName("merges matches for the same term across multiple areas into ONE TermMatchResult")
    void mergesMatchesAcrossAreas() {
        Map<String, String> pathMap = Map.of("lex_bomb-2", "gs://bucket/lex_bomb-2.hdb");
        Database.testPathToExpressions = Map.of("gs://bucket/lex_bomb-2.hdb", List.of(
                new Expression("bomb", EnumSet.of(ExpressionFlag.SOM_LEFTMOST, ExpressionFlag.CASELESS), 7)));

        HyperscanDatabaseLoader loader = new HyperscanDatabaseLoader(pathMap, seedingStreamer(), 10);
        FeatureScanOrchestrator orchestrator = new FeatureScanOrchestrator(loader, null);

        ScanMessage message = new ScanMessage("msg-101",
                new MessageSource("chat", "src", "sys", "conv-1"),
                new MessageContent(null, "there is a bomb in the body", "bomb in subject too", null),
                List.of(new MessageAttachment("att-1", null, "file.txt", "bomb in attachment too")),
                new MessageProcessing("2026-08-16", "10"), "ds1", true);

        FeatureDecisionRow allScopeRow = row("2", "lex_bomb-2", defJson("lex_bomb-2", "subject", "Message Body", "Attachment"));
        List<TermMatchResult> results = orchestrator.scannerFor(message).scan(allScopeRow);

        assertThat(results).hasSize(1);
        assertThat(results.get(0).matches()).hasSize(3);
        assertThat(results.get(0).termId()).isEqualTo("lex_bomb-2::7");

        Set<MatchArea> areas = new HashSet<>();
        for (var m : results.get(0).matches()) areas.add(m.area());
        assertThat(areas).hasSize(3);
    }

    @Test
    @DisplayName("skips an attachment exceeding the configured size limit entirely")
    void skipsOversizedAttachment() {
        Map<String, String> pathMap = Map.of("lex_bomb-3", "gs://bucket/lex_bomb-3.hdb");
        Database.testPathToExpressions = Map.of("gs://bucket/lex_bomb-3.hdb", List.of(
                new Expression("bomb", EnumSet.of(ExpressionFlag.SOM_LEFTMOST, ExpressionFlag.CASELESS), 1)));

        HyperscanDatabaseLoader loader = new HyperscanDatabaseLoader(pathMap, seedingStreamer(), 10);
        FeatureScanOrchestrator limited = new FeatureScanOrchestrator(loader, 5L); // 5-byte limit

        ScanMessage message = new ScanMessage("msg-101",
                new MessageSource("chat", "src", "sys", "conv-1"),
                new MessageContent(null, null, null, null),
                List.of(new MessageAttachment("att-1", null, "file.txt", "bomb in a long attachment")),
                new MessageProcessing("2026-08-16", "10"), "ds1", true);

        FeatureDecisionRow attachOnlyRow = row("3", "lex_bomb-3", defJson("lex_bomb-3", "Attachment"));
        assertThat(limited.scannerFor(message).scan(attachOnlyRow)).isEmpty();

        FeatureScanOrchestrator unlimited = new FeatureScanOrchestrator(loader, null);
        assertThat(unlimited.scannerFor(message).scan(attachOnlyRow)).hasSize(1);
    }

    @Test
    @DisplayName("termRegexPattern is populated directly from the matched Expression's own pattern " +
                 "text — no longer null, and needs no separate JSON file alongside the .hdb")
    void termRegexPatternPopulatedFromMatch() {
        Map<String, String> pathMap = Map.of("lex_bomb-4", "gs://bucket/lex_bomb-4.hdb");
        Database.testPathToExpressions = Map.of("gs://bucket/lex_bomb-4.hdb", List.of(
                new Expression("bomb", EnumSet.of(ExpressionFlag.SOM_LEFTMOST, ExpressionFlag.CASELESS), 1)));

        HyperscanDatabaseLoader loader = new HyperscanDatabaseLoader(pathMap, seedingStreamer(), 10);
        FeatureScanOrchestrator orchestrator = new FeatureScanOrchestrator(loader, null);

        ScanMessage message = new ScanMessage("msg-101",
                new MessageSource("chat", "src", "sys", "conv-1"),
                new MessageContent(null, "there is a bomb in the body", null, null),
                List.of(), new MessageProcessing("2026-08-16", "10"), "ds1", true);

        FeatureDecisionRow bodyOnlyRow = row("4", "lex_bomb-4", defJson("lex_bomb-4", "Message Body"));
        List<TermMatchResult> results = orchestrator.scannerFor(message).scan(bodyOnlyRow);

        assertThat(results).hasSize(1);
        assertThat(results.get(0).termRegexPattern()).isEqualTo("bomb");
        assertThat(results.get(0).termId()).isEqualTo("lex_bomb-4::1");
    }

    @Test
    @DisplayName("The expression id → termId mapping works uniformly for high, non-index-like expression " +
                 "ids too — the Compile Service's id scheme guarantees a PASS term's reportable id is " +
                 "always its own term number, whatever that number is, not necessarily a small sequential index")
    void expressionIdMappingWorksForHighTermNumbers() {
        Map<String, String> pathMap = Map.of("lex_bomb-5", "gs://bucket/lex_bomb-5.hdb");
        Database.testPathToExpressions = Map.of("gs://bucket/lex_bomb-5.hdb", List.of(
                new Expression("insider AND NOT compliance",
                        EnumSet.of(ExpressionFlag.SOM_LEFTMOST, ExpressionFlag.CASELESS), 47)));

        HyperscanDatabaseLoader loader = new HyperscanDatabaseLoader(pathMap, seedingStreamer(), 10);
        FeatureScanOrchestrator orchestrator = new FeatureScanOrchestrator(loader, null);

        ScanMessage message = new ScanMessage("msg-101",
                new MessageSource("chat", "src", "sys", "conv-1"),
                new MessageContent(null, "insider AND NOT compliance", null, null),
                List.of(), new MessageProcessing("2026-08-16", "10"), "ds1", true);

        FeatureDecisionRow row = row("5", "lex_bomb-5", defJson("lex_bomb-5", "Message Body"));
        List<TermMatchResult> results = orchestrator.scannerFor(message).scan(row);

        assertThat(results).hasSize(1);
        // The Compile Service's id scheme means this is ALWAYS the term's own number — 47 here —
        // simple string concatenation via TermIdBuilder, no special-casing needed for a term
        // that (per its pattern text) was clearly an AND NOT term at compile time.
        assertThat(results.get(0).termId()).isEqualTo("lex_bomb-5::47");
    }
}
