package com.db.macs3.ecomms.spectre.translator;

import java.util.ArrayList;
import java.util.List;

/**
 * Recursive-descent parser: {@code List<Token>} → {@link Ast}.
 *
 * <h2>Grammar (highest precedence last, i.e. tightest-binding first)</h2>
 * <pre>
 * orExpr        := andNotExpr ( OR andNotExpr )*
 * andNotExpr    := andExpr ( AND_NOT andExpr )*
 * andExpr       := proximityExpr ( AND proximityExpr )*
 * proximityExpr := notExpr ( (NEAR | FOLLOWEDBY) notExpr )*      [left-associative]
 * notExpr       := NOT? atom
 * atom          := '(' orExpr ')' | QUOTED_PHRASE | wordOrPhrase
 * wordOrPhrase  := WORD+                                          [greedy]
 * </pre>
 *
 * <p>Because every level of this grammar recurses into {@code atom}, and
 * {@code atom}'s parenthesised form recurses straight back into
 * {@code orExpr}, parentheses are resolved at whatever depth they actually
 * appear at — there is no separate "strip the outer parens first" pass to
 * get subtly wrong for multiply-nested or redundant wrapping. A term like
 * {@code (((me) OR (cking)))} is handled by ordinary recursion: the outer
 * two parens are pure grouping around a single atom, so each is consumed by
 * exactly one non-branching pass through {@code atom} → {@code orExpr} →
 * ... → {@code atom} before the actual {@code (me) OR (cking)} content is reached.
 *
 * <h2>Unwrapped multi-word phrases are accepted, not rejected</h2>
 * <p>{@code wordOrPhrase} greedily consumes every consecutive {@code WORD}
 * token with no operator between them into one {@link Ast.Phrase} (or a
 * single {@link Ast.Word} if there is only one). This means a lexicon term
 * author who writes {@code bomb this place OR blow this place up} without
 * wrapping the phrases in parentheses still gets a working term — "bomb
 * this place" is treated as one literal phrase automatically, exactly as if
 * it had been written {@code (bomb this place)}. Because the greedy
 * collection stops the moment it sees a token that is NOT a bare word (an
 * operator, a parenthesis, end of input), operators like {@code OR} still
 * correctly separate one phrase from the next.
 */
final class ExpressionParser {

    private final List<Token> tokens;
    private final String originalTerm;
    private int currentTokenIndex = 0;

    private ExpressionParser(List<Token> tokens, String originalTerm) {
        this.tokens = tokens;
        this.originalTerm = originalTerm;
    }

    /**
     * Parses a fully-tokenized lexicon term into an {@link Ast}.
     *
     * @param tokens       token stream from {@link Tokenizer#tokenize}
     * @param originalTerm the original (preprocessed) term text, for error messages
     * @return the root AST node
     * @throws TranslationException on any grammatical/structural validation failure
     */
    static Ast parse(List<Token> tokens, String originalTerm) {
        if (tokens.isEmpty()) {
            throw new TranslationException("Lexicon term is empty: '" + originalTerm + "'.");
        }
        ExpressionParser parser = new ExpressionParser(tokens, originalTerm);
        Ast result = parser.parseOr();
        if (parser.currentTokenIndex != tokens.size()) {
            throw parser.unexpectedTokenError("after '" + parser.describe(result) + "'");
        }
        return result;
    }

    // ── Grammar levels ───────────────────────────────────────────────────────

    private Ast parseOr() {
        List<Ast> alternatives = new ArrayList<>();
        alternatives.add(parseAndNot());
        while (peekIs(Token.Or.class)) {
            advance();
            alternatives.add(parseAndNot());
        }
        return alternatives.size() == 1 ? alternatives.get(0) : new Ast.Or(alternatives);
    }

    private Ast parseAndNot() {
        Ast requiredOperand = parseAnd();
        List<Ast> excludedOperands = new ArrayList<>();
        while (peekIs(Token.AndNot.class)) {
            advance();
            excludedOperands.add(parseAnd());
        }
        return excludedOperands.isEmpty() ? requiredOperand : new Ast.AndNot(requiredOperand, excludedOperands);
    }

    /**
     * {@code andExpr := proximityExpr ( AND proximityExpr )*}
     *
     * <p>Caps the operand count at {@link ParseContext#MAX_AND_OPERANDS} —
     * {@link PatternCodeGenerator#generateAnd} expresses "all present, any
     * order, unbounded distance" by enumerating every ordering of the
     * operands (N! permutations), so operand count directly controls
     * pattern size; beyond the ceiling the resulting pattern reliably fails
     * Hyperscan compilation with "Pattern Too Long", the same class of
     * failure {@link #checkForChainedProximityOperator} prevents for
     * chained NEAR/FOLLOWEDBY.
     */
    private Ast parseAnd() {
        List<Ast> operands = new ArrayList<>();
        operands.add(parseProximity());
        while (peekIs(Token.And.class)) {
            advance();
            operands.add(parseProximity());
        }
        if (operands.size() > ParseContext.MAX_AND_OPERANDS) {
            throw new TranslationException(
                    "Too many AND operands at the same level (" + operands.size() + ") in term: '"
                    + originalTerm + "'. A maximum of " + ParseContext.MAX_AND_OPERANDS + " is supported"
                    + " — each additional operand multiplies the size of the resulting Hyperscan pattern."
                    + " Split this term into multiple simpler lexicon terms instead.");
        }
        return operands.size() == 1 ? operands.get(0) : new Ast.And(operands);
    }

    /**
     * {@code proximityExpr := notLevel ( (NEAR | FOLLOWEDBY) notLevel )?}
     *
     * <p>Deliberately {@code ?} (at most ONE proximity operator), not
     * {@code *}. Chaining {@code A FOLLOWEDBY{5} B FOLLOWEDBY{6} C} at the
     * SAME grammar level is rejected outright — every additional chained
     * NEAR/FOLLOWEDBY multiplies the size of the bidirectional pattern each
     * one already produces, and in practice this is exactly what caused
     * Hyperscan to reject otherwise-valid-looking terms with
     * "Pattern Too Long" (see {@link #checkForChainedProximityOperator}).
     * The fix is at the grammar level, not a size check after the fact:
     * a term that genuinely needs two proximity relationships must say so
     * explicitly with parentheses — {@code (A FOLLOWEDBY{5} B) FOLLOWEDBY{6} C}
     * — which this grammar allows perfectly well, since the inner
     * parenthesised group is parsed at its OWN, separate level.
     */
    private Ast parseProximity() {
        Ast leftOperand = parseAtom();
        if (!peekIsNearOrFollowedBy()) {
            return leftOperand;
        }
        Token proximityToken = advance();
        Ast rightOperand = parseAtom();
        Ast result = (proximityToken instanceof Token.Near near)
                ? new Ast.Near(leftOperand, rightOperand, near.distance())
                : new Ast.FollowedBy(leftOperand, rightOperand, ((Token.FollowedBy) proximityToken).distance());
        checkForChainedProximityOperator();
        return result;
    }

    /**
     * After parsing exactly one NEAR/FOLLOWEDBY at this level, a SECOND one
     * immediately following (with no wrapping parentheses) is rejected with
     * a specific, actionable error — rather than letting it fall through to
     * a generic "could not parse" error further up the call stack, or worse,
     * being silently accepted and handed to Hyperscan to fail on with an
     * opaque "Pattern Too Long".
     */
    private void checkForChainedProximityOperator() {
        if (peekIsNearOrFollowedBy()) {
            Token next = tokens.get(currentTokenIndex);
            String keyword = (next instanceof Token.Near) ? LexiconOperatorKeyword.NEAR : LexiconOperatorKeyword.FOLLOWEDBY;
            throw new TranslationException(
                    "Cannot have multiple " + LexiconOperatorKeyword.NEAR + " or " + LexiconOperatorKeyword.FOLLOWEDBY
                    + " operators at the same level in term: '" + originalTerm + "'"
                    + " (found a second " + keyword + " chained directly after the first)."
                    + " Wrap one side in parentheses to nest them explicitly instead, e.g."
                    + " '(A " + keyword + "{n} B) " + keyword + "{m} C' — this also keeps the resulting"
                    + " Hyperscan pattern from growing so large that it fails to compile.");
        }
    }

    /**
     * There is no independent {@code NOT} operator — {@code NOT} is only
     * ever valid immediately after {@code AND}, forming a single
     * {@link Token.AndNot} token at the LEXICAL level (see {@link Tokenizer}).
     * A bare {@link Token.Not} reaching here means the term used {@code NOT}
     * (or, previously, {@code !}) on its own — that is rejected with a
     * specific error rather than silently interpreted as a prefix negation,
     * since Hyperscan cannot express negation as a standalone operator
     * anyway (see {@link Ast.AndNot} class Javadoc for what {@code AND NOT}
     * actually compiles to and why it is different from a hypothetical
     * standalone {@code NOT}).
     */
    private void rejectStandaloneNot() {
        if (peekIs(Token.Not.class)) {
            throw new TranslationException(
                    "Standalone NOT is not supported in term: '" + originalTerm + "'."
                    + " NOT must always be paired with AND, written as 'X AND NOT Y'."
                    + " To match the literal word \"NOT\" instead, wrap it in quotes.");
        }
    }

    private Ast parseAtom() {
        if (currentTokenIndex >= tokens.size()) {
            throw unexpectedTokenError("expected a term");
        }
        Token currentToken = tokens.get(currentTokenIndex);
        if (currentToken instanceof Token.LParen) {
            return parseParenGroup();
        }
        if (currentToken instanceof Token.QuotedPhrase quotedPhrase) {
            advance();
            return new Ast.QuotedPhrase(quotedPhrase.text());
        }
        if (currentToken instanceof Token.Word) {
            return parseWordOrPhrase();
        }
        rejectStandaloneNot(); // gives a specific error for Token.Not rather than the generic one below
        throw unexpectedTokenError("expected a term, parenthesis, or quoted phrase");
    }

    /**
     * Greedily collects one or more consecutive bare {@link Token.Word}
     * tokens (no operator between them) into a single atom — a
     * {@link Ast.Word} if there is just one, or an {@link Ast.Phrase} if
     * there are several. This is what lets a lexicon term author write
     * {@code bomb this place} without wrapping parentheses — see class Javadoc.
     */
    private Ast parseWordOrPhrase() {
        List<String> collectedWords = new ArrayList<>();
        while (currentTokenIndex < tokens.size() && tokens.get(currentTokenIndex) instanceof Token.Word word) {
            collectedWords.add(word.text());
            currentTokenIndex++;
        }
        return collectedWords.size() == 1 ? new Ast.Word(collectedWords.get(0)) : new Ast.Phrase(collectedWords);
    }

    /**
     * Handles {@code '(' ... ')'} as a plain grammar rule — {@code atom := '(' orExpr ')'}.
     * No look-ahead or special-casing is needed here: whatever is inside the
     * parentheses, whether it is an operator expression or a bare multi-word
     * phrase, is resolved by the normal recursive descent through
     * {@link #parseOr} down to {@link #parseWordOrPhrase}.
     */
    private Ast parseParenGroup() {
        advance(); // consume '('
        if (peekIs(Token.RParen.class)) {
            throw new TranslationException("Empty parentheses '()' are not allowed in term: '" + originalTerm + "'.");
        }
        Ast innerExpression = parseOr();
        expectClosingParen();
        return innerExpression;
    }

    // ── Look-ahead helpers ────────────────────────────────────────────────────

    private boolean peekIsNearOrFollowedBy() {
        if (currentTokenIndex >= tokens.size()) return false;
        Token token = tokens.get(currentTokenIndex);
        return token instanceof Token.Near || token instanceof Token.FollowedBy;
    }

    private boolean peekIs(Class<? extends Token> tokenType) {
        return currentTokenIndex < tokens.size() && tokenType.isInstance(tokens.get(currentTokenIndex));
    }

    private Token advance() {
        return tokens.get(currentTokenIndex++);
    }

    private void expectClosingParen() {
        if (currentTokenIndex >= tokens.size() || !(tokens.get(currentTokenIndex) instanceof Token.RParen)) {
            throw new TranslationException(
                    "Expected closing ')' in term: '" + originalTerm + "'.");
        }
        currentTokenIndex++;
    }

    private TranslationException unexpectedTokenError(String context) {
        return new TranslationException(
                "Could not parse term: '" + originalTerm + "' (" + context + ")."
                + " Check for unbalanced parentheses or a malformed operator.");
    }

    /** Best-effort human-readable rendering of an AST node for error messages. */
    private String describe(Ast astNode) {
        return switch (astNode) {
            case Ast.Word word -> word.text();
            case Ast.Phrase phrase -> String.join(" ", phrase.words());
            case Ast.QuotedPhrase quotedPhrase -> "\"" + quotedPhrase.text() + "\"";
            default -> "(...)";
        };
    }
}
