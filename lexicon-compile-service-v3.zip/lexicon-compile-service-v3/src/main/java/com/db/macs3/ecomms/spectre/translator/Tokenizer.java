package com.db.macs3.ecomms.spectre.translator;

import java.util.ArrayList;
import java.util.List;

/**
 * Converts a raw lexicon term string into a {@link Token} stream.
 *
 * <p>This is the single place that scans the raw character sequence — every
 * downstream component ({@link ExpressionParser}) works only with the
 * resulting token list, never with raw string indices. The previous
 * implementation re-scanned raw indices independently in four different
 * methods ({@code splitTopLevel}, {@code splitOnAndNot},
 * {@code findTopLevelProximity}, {@code isWrappedInParens}), each with its
 * own paren-depth and quote-tracking logic; consolidating that into one
 * tokenizer eliminates the class of bugs that arose from those four
 * implementations disagreeing at the edges (see class Javadoc on
 * {@link Token} for the specific case this fixes).
 *
 * <h2>Validation performed here (lexical level)</h2>
 * <ul>
 *   <li>Reserved keywords ({@code OR}, {@code AND}, {@code NOT}, {@code NEAR},
 *       {@code FOLLOWEDBY}) are recognised ONLY in exact case; any other
 *       case is ordinary literal text.</li>
 *   <li>{@code NEAR}/{@code FOLLOWEDBY} must be immediately followed by
 *       {@code {n}} with no whitespace, where {@code n} is a single digit 1-9
 *       (no zero, no negative, no letters, no multi-digit, no comma-separated values).</li>
 *   <li>Parentheses must be balanced.</li>
 *   <li>Quoted phrases must be closed.</li>
 *   <li>The term must contain at least one real letter-or-digit character
 *       somewhere (rejects pure-symbol input like {@code "#@$#%$"}).</li>
 * </ul>
 *
 * <p>Validation that depends on GRAMMATICAL structure — e.g. "a multi-word
 * phrase must be wrapped in parentheses" — cannot be done at the lexical
 * level (the tokenizer has no concept of "operand position") and is
 * performed by {@link ExpressionParser} instead.
 */
final class Tokenizer {

    private final String input;
    private int pos = 0;

    private Tokenizer(String input) {
        this.input = input;
    }

    /**
     * Tokenizes {@code rawExpression}, fully validating lexical structure.
     *
     * @param rawExpression the preprocessed (trimmed, NFC-normalised) term text
     * @return the token stream, ready for {@link ExpressionParser}
     * @throws TranslationException on any lexical validation failure
     */
    static List<Token> tokenize(String rawExpression) {
        requireMeaningfulContent(rawExpression);
        return new Tokenizer(rawExpression).run();
    }

    // ── Meaningful-content check ────────────────────────────────────────────

    /**
     * Rejects input containing no letter-or-digit character anywhere — e.g.
     * {@code "#@$#%$"}. Unicode-aware ({@link Character#isLetterOrDigit(int)})
     * so German, Korean, Arabic, Chinese, etc. content is correctly accepted.
     */
    private static void requireMeaningfulContent(String text) {
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            if (Character.isLetterOrDigit(cp)) {
                return; // found at least one — valid
            }
            i += Character.charCount(cp);
        }
        throw new TranslationException(
                "Lexicon term contains no meaningful content (only symbols/whitespace): '" + text + "'."
                + " A lexicon term must contain at least one letter or digit.");
    }

    // ── Main scan loop ───────────────────────────────────────────────────────

    private List<Token> run() {
        List<Token> tokens = new ArrayList<>();
        int parenDepth = 0;

        while (pos < input.length()) {
            char c = input.charAt(pos);

            if (Character.isWhitespace(c)) {
                pos++;
                continue;
            }
            if (c == '(') {
                tokens.add(new Token.LParen());
                parenDepth++;
                pos++;
                continue;
            }
            if (c == ')') {
                parenDepth--;
                if (parenDepth < 0) {
                    throw new TranslationException(
                            "Unmatched closing parenthesis ')' at position " + pos + " in term: '" + input + "'."
                            + " Every ')' must have a matching '(' before it.");
                }
                tokens.add(new Token.RParen());
                pos++;
                continue;
            }
            if (c == '"') {
                tokens.add(scanQuotedPhrase());
                continue;
            }
            if (c == '!') {
                tokens.add(new Token.Not());
                pos++;
                continue;
            }

            tokens.add(scanWordLike(tokens));
        }

        if (parenDepth != 0) {
            throw new TranslationException(
                    "Unmatched opening parenthesis '(' in term: '" + input + "'."
                    + " Every '(' must have a matching ')'. Found " + parenDepth
                    + " unclosed parenthes" + (parenDepth == 1 ? "is" : "es") + ".");
        }

        return tokens;
    }

    // ── Quoted phrase ────────────────────────────────────────────────────────

    private Token.QuotedPhrase scanQuotedPhrase() {
        int start = pos;
        pos++; // consume opening quote
        StringBuilder sb = new StringBuilder();
        while (pos < input.length() && input.charAt(pos) != '"') {
            sb.append(input.charAt(pos));
            pos++;
        }
        if (pos >= input.length()) {
            throw new TranslationException(
                    "Unclosed quoted phrase starting at position " + start + " in term: '" + input + "'."
                    + " Every opening '\"' must have a matching closing '\"'.");
        }
        pos++; // consume closing quote
        return new Token.QuotedPhrase(sb.toString());
    }

    // ── Word-like run (operator keyword or literal word) ────────────────────

    /**
     * Scans one maximal run of non-whitespace, non-paren, non-quote
     * characters and classifies it as a reserved-keyword token or an
     * ordinary {@link Token.Word}.
     *
     * @param tokensSoFar the tokens accumulated so far (reserved for future
     *                    context-sensitive checks; not currently used)
     */
    private Token scanWordLike(List<Token> tokensSoFar) {
        int start = pos;
        while (pos < input.length() && !isBoundary(input.charAt(pos))) {
            pos++;
        }
        String run = input.substring(start, pos);

        // ── Exact-case reserved keywords ────────────────────────────────────
        if (run.equals("OR")) {
            return new Token.Or();
        }
        if (run.equals("NOT")) {
            return new Token.Not();
        }
        if (run.equals("AND")) {
            return scanAndOrAndNot();
        }
        if (run.startsWith("NEAR")) {
            return scanProximityKeyword(run, "NEAR");
        }
        if (run.startsWith("FOLLOWEDBY")) {
            return scanProximityKeyword(run, "FOLLOWEDBY");
        }

        return new Token.Word(run);
    }

    /** True for characters that end a word-like run: whitespace, parens, or the quote character. */
    private static boolean isBoundary(char c) {
        return Character.isWhitespace(c) || c == '(' || c == ')' || c == '"';
    }

    /**
     * Having just consumed the exact word {@code "AND"}, looks ahead
     * (skipping whitespace only — no intervening punctuation) for a
     * following exact word {@code "NOT"}. If found, consumes it too and
     * returns a single {@link Token.AndNot}; otherwise returns {@link Token.And}
     * without consuming anything further.
     *
     * <p>This is the direct fix for the original implementation's fragility:
     * it required the exact 9-character literal {@code " AND NOT "} (both
     * surrounding spaces significant), so {@code "AND NOT("} — a completely
     * ordinary way to write it, with no space before the parenthesis — was
     * never recognised as AND-NOT at all. Here, {@code AND} and {@code NOT}
     * are independent tokens; whatever comes after {@code NOT} (a space, a
     * parenthesis, anything) is irrelevant to recognising the operator.
     */
    private Token scanAndOrAndNot() {
        int save = pos;
        skipWhitespace();
        int wordStart = pos;
        while (pos < input.length() && !isBoundary(input.charAt(pos))) {
            pos++;
        }
        String next = input.substring(wordStart, pos);
        if (next.equals("NOT")) {
            return new Token.AndNot();
        }
        // Not a NOT — rewind to just after "AND" and let the next scan loop
        // iteration tokenize whatever followed on its own.
        pos = save;
        return new Token.And();
    }

    private void skipWhitespace() {
        while (pos < input.length() && Character.isWhitespace(input.charAt(pos))) {
            pos++;
        }
    }

    /**
     * Validates and tokenizes a {@code NEAR{n}} / {@code FOLLOWEDBY{n}}
     * candidate. {@code run} is the word-like text already scanned (which
     * may be just {@code "NEAR"} with no brace at all, or the keyword plus a
     * malformed brace expression) — every failure mode gets a specific,
     * actionable error message rather than silently falling back to literal
     * text, since a near-miss on this syntax is essentially always a typo,
     * not intentional literal content.
     *
     * @param run     the word-like run already scanned (starts with {@code keyword})
     * @param keyword {@code "NEAR"} or {@code "FOLLOWEDBY"}
     */
    private Token scanProximityKeyword(String run, String keyword) {
        if (run.equals(keyword)) {
            // Bare "NEAR" / "FOLLOWEDBY" with no attached brace at all.
            // Check whether a brace expression follows separated by whitespace —
            // that's the specific "whitespace before brace" validation failure.
            int save = pos;
            skipWhitespace();
            if (pos < input.length() && input.charAt(pos) == '{') {
                throw new TranslationException(
                        keyword + " must be immediately followed by '{n}' with no whitespace"
                        + " (found a space before '{' at position " + pos + " in term: '" + input + "')."
                        + " Write it as " + keyword + "{n}, e.g. " + keyword + "{3}.");
            }
            pos = save;
            throw new TranslationException(
                    keyword + " is missing its '{n}' distance value in term: '" + input + "'."
                    + " Expected format: " + keyword + "{n}, e.g. " + keyword + "{3}."
                    + " To use \"" + keyword + "\" as literal text instead, wrap it in quotes.");
        }

        // run is longer than the bare keyword — must be keyword immediately
        // followed by a brace expression within the SAME whitespace-free run.
        String rest = run.substring(keyword.length());
        if (rest.charAt(0) != '{') {
            // e.g. "NEARby" — not our keyword at all, just an ordinary word
            // that happens to start with the same letters.
            return new Token.Word(run);
        }

        if (!rest.endsWith("}")) {
            throw new TranslationException(
                    keyword + "{...} is missing its closing '}' in term: '" + input + "'.");
        }

        String inner = rest.substring(1, rest.length() - 1);
        validateProximityDistance(keyword, inner);
        int n = Integer.parseInt(inner);
        return keyword.equals("NEAR") ? new Token.Near(n) : new Token.FollowedBy(n);
    }

    /**
     * Validates the {@code n} inside {@code NEAR{n}}/{@code FOLLOWEDBY{n}}:
     * must be exactly one digit, 1-9 (no zero, no negative sign, no letters,
     * no multi-digit values, no comma-separated values).
     */
    private void validateProximityDistance(String keyword, String inner) {
        if (inner.isEmpty()) {
            throw new TranslationException(
                    keyword + "{} has no distance value in term: '" + input + "'. Expected " + keyword + "{n}, e.g. " + keyword + "{3}.");
        }
        if (inner.contains(",")) {
            throw new TranslationException(
                    keyword + "{" + inner + "} is invalid in term: '" + input + "'."
                    + " Only a single value is allowed (no comma-separated range). Expected " + keyword + "{n}, e.g. " + keyword + "{3}.");
        }
        if (inner.length() != 1 || inner.charAt(0) < '1' || inner.charAt(0) > '9') {
            String reason;
            if (inner.chars().allMatch(Character::isDigit)) {
                reason = inner.equals("0") ? "zero is not allowed"
                       : inner.length() > 1 ? "only a single digit (1-9) is allowed, not a multi-digit value"
                       : "value out of range";
            } else if (inner.startsWith("-")) {
                reason = "negative values are not allowed";
            } else {
                reason = "the distance must be numeric, not '" + inner + "'";
            }
            throw new TranslationException(
                    keyword + "{" + inner + "} is invalid in term: '" + input + "' — " + reason + "."
                    + " Expected " + keyword + "{n} where n is a single digit from 1 to 9.");
        }
    }
}
