package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.hyperscan.HyperscanCompiler;
import com.db.macs3.ecomms.spectre.model.CompilationStatus;
import com.db.macs3.ecomms.spectre.model.CompileResponse;
import com.db.macs3.ecomms.spectre.model.TermCompilationResult;
import com.db.macs3.ecomms.spectre.model.TermType;
import com.db.macs3.ecomms.spectre.model.TypedCompileRequest;
import com.db.macs3.ecomms.spectre.service.LexiconCompileService;
import com.db.macs3.ecomms.spectre.translator.TermSyntaxTranslator;
import com.gliwka.hyperscan.wrapper.Database;
import com.gliwka.hyperscan.wrapper.Match;
import com.gliwka.hyperscan.wrapper.Scanner;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link LexiconCompileBundleService} — the {@code /compile/bundle}
 * endpoint's orchestration logic (Natural Language/Regex branching + combined database).
 *
 * <p>No Spring context — uses real {@code TermSyntaxTranslator} and
 * {@code HyperscanCompiler} directly, exactly like {@link LexiconCompileServiceTest}.
 */
@DisplayName("LexiconCompileBundleService Tests")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class LexiconCompileBundleServiceTest {

    private LexiconCompileBundleService bundleService;

    @BeforeEach
    void setUp() {
        var translator     = new TermSyntaxTranslator();
        var compiler        = new HyperscanCompiler();
        compiler.selfTest();
        var compileService  = new LexiconCompileService(translator, compiler, new SimpleMeterRegistry());
        bundleService        = new LexiconCompileBundleService(compileService, compiler, new SimpleMeterRegistry());
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private TypedCompileRequest request(String ruleName, TermType termType, TermSpec... specs) {
        var req = new TypedCompileRequest();
        req.setRequestId(UUID.randomUUID().toString());
        req.setLexiconRuleName(ruleName);
        req.setTermType(termType);
        List<TypedCompileRequest.TermInput> terms = new ArrayList<>();
        for (int i = 0; i < specs.length; i++) {
            terms.add(new TypedCompileRequest.TermInput(
                    ruleName + "::" + (i + 1), specs[i].description));
        }
        req.setTerms(terms);
        return req;
    }

    // Convenience: Natural Language or Regex helpers just carry description
    private record TermSpec(String description) {}
    private static TermSpec term(String desc) { return new TermSpec(desc); }

    /** Shorthand: all-Natural-Language request */
    private TypedCompileRequest naturalLanguage(String ruleName, String... descs) {
        TermSpec[] specs = new TermSpec[descs.length];
        for (int i = 0; i < descs.length; i++) specs[i] = term(descs[i]);
        return request(ruleName, TermType.NATURAL_LANGUAGE, specs);
    }

    /** Shorthand: all-Regex request */
    private TypedCompileRequest regex(String ruleName, String... descs) {
        TermSpec[] specs = new TermSpec[descs.length];
        for (int i = 0; i < descs.length; i++) specs[i] = term(descs[i]);
        return request(ruleName, TermType.REGEX, specs);
    }

    // ── Spec example from the requirements ────────────────────────────────────

    @Test @Order(1)
    @DisplayName("Spec example: Natural Language request → PASS, combined DB built, request_id/termType echoed")
    void specExampleNaturalLanguage() {
        // termType is now request-level, so the original mixed Natural-Language+Regex example
        // is split into two single-type requests — this covers the Natural Language half.
        var req = naturalLanguage("lexicon_research_1",
                "(manipulate) NEAR{5} ((price) OR (spread) OR (stock))");
        String sentRequestId = req.getRequestId();

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isTrue();
        assertThat(bundle.hyperscanDatabaseBytes()).isNotEmpty();
        assertThat(bundle.databaseNote()).isNull();
        // request_id and termType must be echoed back unchanged
        assertThat(bundle.jsonResponse().requestId()).isEqualTo(sentRequestId);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Natural Language");
    }

    @Test @Order(2)
    @DisplayName("Spec example: Regex request → PASS, combined DB built, request_id/termType echoed")
    void specExampleRegex() {
        // Regex half of the original mixed example — termType is request-level now.
        var req = regex("lexicon_research_1", "(?:price|spread|stock)");
        String sentRequestId = req.getRequestId();

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isTrue();
        assertThat(bundle.jsonResponse().requestId()).isEqualTo(sentRequestId);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Regex");
    }

    // ── JSON shape: request_id / termType present, hyperscanVersion / processingTimeMs absent ──

    @Test @Order(10)
    @DisplayName("JSON response: request_id and termType present; hyperscanVersion absent (bundle-specific shape)")
    void jsonShapeMatchesCompile() {
        var req = naturalLanguage("shape_test", "price OR spread");
        var bundle = bundleService.buildBundle(req);

        CompileResponse json = bundle.jsonResponse();
        assertThat(json.lexiconRuleName()).isEqualTo("shape_test");
        assertThat(json.engineMode()).isEqualTo("HYPERSCAN_NATIVE");
        assertThat(json.requestId()).isEqualTo(req.getRequestId());
        assertThat(json.termType()).isEqualTo("Natural Language");
        // hyperscanVersion is intentionally null/absent for the bundle endpoint
        assertThat(json.hyperscanVersion()).isNull();
        assertThat(json.results()).hasSize(1);
        assertThat(json.results().get(0).termId()).isEqualTo("shape_test::1");
    }

    // ── Natural Language term branch ──────────────────────────────────────────────────

    @Test @Order(20)
    @DisplayName("Natural Language term: NEAR{5} translated exactly like /compile")
    void naturalLanguageTermTranslated() {
        var req = naturalLanguage("std_test", "(manipulate) NEAR{5} (price)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.translatedPattern()).contains("manipulate").contains("price");
        // Word-based gap confirms translation actually ran (a Regex-type term would never produce this)
        assertThat(result.translatedPattern()).contains("\\s+\\S+");
    }

    @Test @Order(21)
    @DisplayName("Natural Language term with invalid syntax → FAILED with translationError, no DB entry")
    void naturalLanguageTermTranslationFailure() {
        var req = naturalLanguage("std_fail_test", "NEAR{5} (price)"); // missing left operand
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.FAILED);
    }

    // ── Regex term branch ────────────────────────────────────────────────────────

    @Test @Order(30)
    @DisplayName("Regex term: raw PCRE compiled verbatim, NOT passed through the translator")
    void regexTermCompiledVerbatim() {
        var req = regex("nlt_test", "(?:price|spread|stock)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        // translatedPattern must be byte-identical to the input — no translation occurred
        assertThat(result.translatedPattern()).isEqualTo("(?:price|spread|stock)");
    }

    @Test @Order(31)
    @DisplayName("Regex term with invalid regex syntax → FAILED with Hyperscan errorLog")
    void regexTermInvalidRegex() {
        var req = regex("nlt_invalid_test", "[unclosed");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.FAILED);
        assertThat(result.errorLog()).isNotBlank();
        // requiresExclusionCheck is always false for Regex-type terms
        assertThat(result.requiresExclusionCheck()).isFalse();
    }

    @Test @Order(32)
    @DisplayName("Regex term with non-Latin script gets UTF8/UCP flags automatically")
    void regexTermNonLatinFlags() {
        var req = regex("nlt_korean_test", "(?:내부자|거래)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.hyperscanFlags() & 32).isEqualTo(32); // UTF8
        assertThat(result.hyperscanFlags() & 64).isEqualTo(64); // UCP
    }

    @Test @Order(33)
    @DisplayName("Regex term with operator-language syntax (not a real regex) is treated literally, never translated")
    void regexTermNeverTranslated() {
        // If this were Natural Language, "NEAR{5}" would translate into a proximity pattern.
        // As a Regex-type term it must be compiled literally — Hyperscan treats {5} as a repetition quantifier
        // on whatever precedes it, which is valid PCRE syntax on its own.
        var req = regex("nlt_literal_test", "price NEAR.{5} stock");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        // Must be exactly what was given — proof no NEAR{n} translation ran
        assertThat(result.translatedPattern()).isEqualTo("price NEAR.{5} stock");
    }

    // ── All-Regex and all-Natural-Language scenarios ────────────────────────────────────

    @Test @Order(40)
    @DisplayName("All-Regex request: every term compiled verbatim, DB contains all")
    void allRegexRequest() {
        var req = regex("all_nlt_test",
                "(?:price|spread)", "(?:insider|tip)", "manipulat\\w+");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(3);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Regex");
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(41)
    @DisplayName("All-Natural Language request: behaves identically to /compile for every term")
    void allNaturalLanguageRequest() {
        var req = naturalLanguage("all_std_test",
                "price OR spread",
                "don't FOLLOWEDBY{3} compliance",
                "insider AND announcement");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(3);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Natural Language");
        assertThat(bundle.hasDatabase()).isTrue();
    }

    // ── Mixed pass/fail scenarios (same termType, different outcomes) ──────────

    @Test @Order(50)
    @DisplayName("Mixed PASS/FAILED within an Regex request: combined DB built from PASS subset only, with id gaps")
    void mixedPassFailedDbBuiltFromPassOnly() throws IOException {
        // termType is request-level now, so "mixed Natural-Language+Regex" is no longer expressible
        // in one request. This test instead covers a mixed PASS/FAILED outcome within a
        // single Regex request, which still exercises the id-gap behaviour identically.
        var req = regex("mixed_test",
                "(?:price|spread)",     // index 0 — PASS
                "[unclosed",             // index 1 — FAILED
                "(?:insider|tip)");      // index 2 — PASS

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(2);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().results().get(1).compilationStatus())
                .isEqualTo(CompilationStatus.FAILED);
        assertThat(bundle.hasDatabase()).isTrue();

        // Load the DB back and confirm only ids {1, 3} are present (2 is the gap —
        // termIds "rule::1"/"rule::2"/"rule::3" -> term numbers 1/2/3; term number 2 FAILED).
        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            assertThat(scanMatchesIds(db, "price")).contains(1);
            assertThat(scanMatchesIds(db, "insider")).contains(3);
        }
    }

    @Test @Order(51)
    @DisplayName("Zero PASS terms: no database built, clear explanatory note returned")
    void zeroPassTermsNoDatabase() {
        var req = regex("zero_pass_test", "[unclosed", "[also_unclosed");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isFalse();
        assertThat(bundle.hyperscanDatabaseBytes()).isNull();
        assertThat(bundle.databaseNote()).isNotBlank();
        assertThat(bundle.databaseNote()).contains("zero terms reached PASS");
    }

    // ── Combined database integrity (round-trip load + scan) ───────────────────

    @Test @Order(60)
    @DisplayName("Combined DB round-trip: save() then load() reconstructs a working multi-pattern database")
    void combinedDatabaseRoundTrip() throws IOException {
        var req = regex("roundtrip_test",
                "(?:price|spread|stock)",
                "(?:insider|tip)");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.hasDatabase()).isTrue();

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            List<Integer> priceMatches  = scanMatchesIds(db, "the price went up");
            List<Integer> insiderMatches = scanMatchesIds(db, "an insider tip was shared");

            // termIds "roundtrip_test::1", "roundtrip_test::2" -> term numbers 1, 2 (not array indices 0, 1).
            assertThat(priceMatches).contains(1);
            assertThat(insiderMatches).contains(2);
        }
    }

    @Test @Order(61)
    @DisplayName("Expression id equals the term's PARSED TERM NUMBER (from termId's '::n' suffix), " +
                 "not its array position in the request")
    void expressionIdEqualsTermNumber() throws IOException {
        var req = regex("id_mapping_test",
                "alpha_pattern",   // termId "id_mapping_test::1" -> term number 1
                "beta_pattern",    // termId "id_mapping_test::2" -> term number 2
                "gamma_pattern");  // termId "id_mapping_test::3" -> term number 3
        var bundle = bundleService.buildBundle(req);

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            assertThat(scanMatchesIds(db, "alpha_pattern")).containsExactly(1);
            assertThat(scanMatchesIds(db, "beta_pattern")).containsExactly(2);
            assertThat(scanMatchesIds(db, "gamma_pattern")).containsExactly(3);
        }
    }

    // ── Scan helper ──────────────────────────────────────────────────────────

    /** Scans {@code text} against {@code db} and returns the matched expression ids. */
    private List<Integer> scanMatchesIds(Database db, String text) {
        List<Integer> ids = new ArrayList<>();
        try (Scanner scanner = new Scanner()) {
            scanner.allocScratch(db);
            for (Match match : scanner.scan(db, text)) {
                ids.add(match.getMatchedExpression().getId());
            }
        }
        return ids;
    }

    // ── AND NOT: native Hyperscan logical combination (this fix) ─────────────────

    @Test @Order(70)
    @DisplayName("THE REPORTED SCENARIO: \"((don't forward) AND NOT (compliance OR legal))\" gets a " +
                 "combination hyperscanExpressionId, not the required pattern's own id")
    void andNotTerm_getsCombinationExpressionId() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE,
                term("((don't forward) AND NOT (compliance OR legal))"));

        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.requiresExclusionCheck()).isTrue();
        assertThat(result.translatedPattern()).isEqualTo("don't forward");
        assertThat(result.exclusionPattern()).contains("compliance").contains("legal");

        // termId "test-rule::1" -> term number 1; offset = maxTermNumber(1)+1 = 2.
        // required=1, exclusion=offset(2)+1=3, combination=2*offset(2)+1=5.
        assertThat(result.hyperscanExpressionId()).isEqualTo(5);

        // The combined database must still compile successfully with the combination
        // expression included — a real assertion only meaningful when the test
        // environment has genuine Hyperscan (see class Javadoc note on combinations).
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(71)
    @DisplayName("A plain term (no AND NOT) gets hyperscanExpressionId equal to its own term number, "
                 + "not its array position")
    void plainTerm_getsOwnTermNumberAsExpressionId() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE, term("insider OR trading"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.requiresExclusionCheck()).isFalse();
        // termId "test-rule::1" -> term number 1 (NOT array index 0).
        assertThat(result.hyperscanExpressionId()).isEqualTo(1);
    }

    @Test @Order(72)
    @DisplayName("Plain AND (no NOT) also gets its own term number as expression id — self-contained, no combination needed")
    void plainAndTerm_selfContained_ownTermNumberAsExpressionId() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE, term("price AND rigging"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.requiresExclusionCheck()).isFalse();
        assertThat(result.hyperscanExpressionId()).isEqualTo(1);
    }

    @Test @Order(73)
    @DisplayName("Mixed request: plain terms and an AND NOT term each get correctly distinct expression ids")
    void mixedRequest_correctIdsForEachTerm() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE,
                term("insider OR trading"),          // index 0, plain
                term("price AND rigging"),            // index 1, plain (self-contained AND)
                term("confidential AND NOT public")); // index 2, AND NOT

        var bundle = bundleService.buildBundle(req);
        var results = bundle.jsonResponse().results();

        assertThat(results).allMatch(TermCompilationResult::isPass);
        // termIds "test-rule::1", "test-rule::2", "test-rule::3" -> term numbers 1, 2, 3.
        // maxTermNumber=3, offset=4. Term #3 (AND NOT): required=3, exclusion=4+3=7, combination=2*4+3=11.
        assertThat(results.get(0).hyperscanExpressionId()).isEqualTo(1);
        assertThat(results.get(1).hyperscanExpressionId()).isEqualTo(2);
        assertThat(results.get(2).hyperscanExpressionId()).isEqualTo(11);
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(74)
    @DisplayName("FAILED terms have no hyperscanExpressionId — nothing was compiled into the database for them")
    void failedTerm_hasNoExpressionId() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE, term("(unclosed"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.isFailed()).isTrue();
        assertThat(result.hyperscanExpressionId()).isNull();
    }

    @Test @Order(75)
    @DisplayName("Chained AND NOT (A AND NOT B AND NOT C) still produces exactly one combination expression id")
    void chainedAndNot_stillOneCombinationId() {
        var req = request("test-rule", TermType.NATURAL_LANGUAGE,
                term("(a) AND NOT (b) AND NOT (c)"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.requiresExclusionCheck()).isTrue();
        // termId "test-rule::1" -> term number 1; offset=2; combination = 2*2+1 = 5.
        assertThat(result.hyperscanExpressionId()).isEqualTo(5);
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(76)
    @DisplayName("REGEX-type terms never require exclusion checks — no combination expression involved")
    void regexTerm_neverRequiresExclusionCheck() {
        var req = request("test-rule", TermType.REGEX, term("(?:insider|trading)"));
        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.requiresExclusionCheck()).isFalse();
        assertThat(result.hyperscanExpressionId()).isEqualTo(1); // termId "test-rule::1" -> term number 1
    }

    // ── trackMatchPosition: SOM_LEFTMOST opt-out for "Pattern too large" mitigation ──

    @Test @Order(80)
    @DisplayName("trackMatchPosition omitted (default): combined database still compiles and matches correctly")
    void trackMatchPositionOmitted_stillWorks() throws IOException {
        var req = regex("som_default_test", "(?:price|spread|stock)");
        // trackMatchPosition left unset — must default to the previous, always-on behaviour.
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.hasDatabase()).isTrue();
        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            // termId "som_default_test::1" -> term number 1 (NOT array index 0).
            assertThat(scanMatchesIds(db, "the price went up")).containsExactly(1);
        }
    }

    @Test @Order(81)
    @DisplayName("trackMatchPosition=false: combined database still compiles and matches correctly, " +
                 "without SOM_LEFTMOST — reduces compile complexity for the Dataproc Scan Engine's " +
                 "boolean-match-only use case")
    void trackMatchPositionFalse_stillCompilesAndMatches() throws IOException {
        var req = new TypedCompileRequest();
        req.setRequestId("som-opt-out-test");
        req.setLexiconRuleName("som_opt_out_test");
        req.setTermType(TermType.REGEX);
        req.setTrackMatchPosition(false);
        req.setTerms(List.of(new TypedCompileRequest.TermInput("t::1", "(?:price|spread|stock)")));

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.hasDatabase()).isTrue();
        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            // Match DETECTION and expression id reporting are unaffected by omitting SOM —
            // only the reported start-of-match offset accuracy changes, which this
            // boolean-alerting use case doesn't need.
            // termId "t::1" -> term number 1 (NOT array index 0).
            assertThat(scanMatchesIds(db, "the price went up")).containsExactly(1);
        }
    }

    @Test @Order(82)
    @DisplayName("trackMatchPosition=false with an AND NOT term: still correctly excludes/matches, " +
                 "using the same real Hyperscan combined database round-trip as trackMatchPosition=true")
    void trackMatchPositionFalse_andNotStillCorrect() throws IOException {
        var req = new TypedCompileRequest();
        req.setRequestId("som-opt-out-andnot-test");
        req.setLexiconRuleName("som_opt_out_andnot_test");
        req.setTermType(TermType.NATURAL_LANGUAGE);
        req.setTrackMatchPosition(false);
        req.setTerms(List.of(new TypedCompileRequest.TermInput(
                "t::1", "((don't forward) AND NOT (compliance OR legal))")));

        var bundle = bundleService.buildBundle(req);
        var result = bundle.jsonResponse().results().get(0);

        assertThat(result.isPass()).isTrue();
        assertThat(bundle.hasDatabase()).isTrue();
        // termId "t::1" -> term number 1; offset=2; combination = 2*2+1 = 5.
        assertThat(result.hyperscanExpressionId()).isEqualTo(5);

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            // Required pattern present, exclusion ALSO present -> combination (id 2) must NOT fire.
            assertThat(scanMatchesIds(db, "Please don't forward this message to compliance or legal"))
                    .doesNotContain(5);
        }
    }
}
