package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.config.AppProperties;
import com.db.macs3.ecomms.spectre.model.Models.CompiledTerm;
import com.db.macs3.ecomms.spectre.model.Models.PatternValidationResult;
import com.db.macs3.ecomms.spectre.model.Models.RawMatch;
import com.gliwka.hyperscan.wrapper.CompileErrorException;
import com.gliwka.hyperscan.wrapper.Database;
import com.gliwka.hyperscan.wrapper.Expression;
import com.gliwka.hyperscan.wrapper.ExpressionFlag;
import com.gliwka.hyperscan.wrapper.Match;
import com.gliwka.hyperscan.wrapper.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Core Hyperscan scanning service.
 *
 * <h2>Pipeline</h2>
 * <ol>
 *   <li>Receives {@link CompiledTerm} list (terms that already passed Hyperscan
 *       compilation in the Lexicon Compile Service, with expression ids already
 *       assigned by {@link LexiconScanOrchestrator} — see that class for why
 *       id assignment happens once, at term-resolution time, not per scan).</li>
 *   <li>Builds one or more {@link Expression}s per term — see
 *       "Expression building" below.</li>
 *   <li>Compiles a single Hyperscan {@link Database} from all expressions.</li>
 *   <li>Scans the message text with a {@link Scanner}.</li>
 *   <li>Returns {@link RawMatch} list (byte-offset based; the caller converts
 *       to char indices) — see "Stage 2: recovering text for COMBINATION matches" below.</li>
 * </ol>
 *
 * <h2>AND NOT no longer uses native Hyperscan COMBINATION — confirmed broken</h2>
 * <p>An earlier version of this class compiled every AND NOT term as a single
 * native {@code HS_FLAG_COMBINATION} formula, e.g. {@code (R&!E)}, mirroring
 * the Lexicon Compile Service's own earlier design. This is confirmed BROKEN
 * by Hyperscan's own documented evaluation model — see
 * {@link CompiledTerm} class Javadoc for the full explanation (eager,
 * progressive combination evaluation; the "purely negative combinations
 * deferred to end-of-data" special case that a mixed positive/negative
 * formula like {@code R&!E} does not qualify for). The concrete, observed
 * failure mode: an AND NOT term could incorrectly count as matched when its
 * required pattern appeared BEFORE its excluded pattern in the same message
 * — the combination fired the instant the required pattern matched, before
 * the excluded pattern had been reached by the scan at all.
 *
 * <h2>Expression building</h2>
 * <p>Branches strictly on {@link CompiledTerm#requiresExclusionCheck()}, not
 * on decomposition — see {@link CompiledTerm#usesNativeCombination()}:
 * <ul>
 *   <li><b>AND NOT (any term where {@code requiresExclusionCheck()} is true,
 *       regardless of decomposition on either side)</b> — NO combination at
 *       all. Every pattern in both {@code requiredPatterns} and
 *       {@code exclusionPatterns} compiles as its own PLAIN,
 *       individually-reportable expression, using the id already assigned to
 *       it in {@link CompiledTerm#requiredExpressionIds()} /
 *       {@link CompiledTerm#excludedExpressionIds()}. Each safely carries
 *       {@code SOM_LEFTMOST} (never {@code QUIET}). The caller
 *       ({@code LexiconScanOrchestrator}) evaluates the boolean condition
 *       itself, AFTER the whole scan completes, using the complete set of
 *       matched expression ids — see that class for why this is also a
 *       simplification, not just a fix.</li>
 *   <li><b>Pure decomposition, no AND NOT</b> ({@link CompiledTerm#usesNativeCombination()})
 *       — UNCHANGED, still safe: no negation is involved, so Hyperscan's
 *       eager evaluation cannot produce a false positive here (a positive
 *       sub-expression's truth value is only ever true after it genuinely
 *       matches). Every leaf pattern compiles as its own {@code QUIET}
 *       sub-expression (an ALLOCATED auxiliary id — see
 *       {@link #computeAuxIdOffset} — never {@code SOM_LEFTMOST}, confirmed
 *       incompatible with {@code QUIET}), plus ONE {@code COMBINATION}
 *       formula expression at {@code requiredExpressionIds().get(0)} ANDing
 *       every leaf id together.</li>
 *   <li><b>Simple, single-pattern term</b> — one plain expression at
 *       {@code requiredExpressionIds().get(0)}, flagged {@code SOM_LEFTMOST}.</li>
 * </ul>
 *
 * <h2>Stage 2: recovering text for COMBINATION matches</h2>
 * <p>A {@code COMBINATION} expression's own match event has no genuine
 * contiguous text span — it is a logical boolean event over (potentially
 * scattered) {@code QUIET} sub-expression matches, and Hyperscan has
 * nothing meaningful to report as its matched string or position. Since AND
 * NOT no longer uses {@code COMBINATION} at all, this can now only happen
 * for a purely-decomposed, non-AND-NOT term. When a matched expression is
 * flagged {@code COMBINATION}, this class does NOT trust its
 * {@code getMatchedString()}/position at all — instead it runs a second,
 * independent pass with {@code java.util.regex.Matcher} against the owning
 * term's own {@code requiredPatterns} to recover each leaf's real matched
 * text and position — see {@link #toRawMatches}. Every AND NOT match
 * (required or excluded side) is a plain expression with genuinely reliable
 * position/text data straight from Hyperscan — no Stage 2 needed.
 *
 * <p>For a decomposed term this deliberately produces MULTIPLE, separate,
 * non-contiguous highlights (one per leaf that genuinely matched) rather
 * than one span covering the whole original phrase — an honest reflection
 * of what decomposition's own semantics mean ("these independent things
 * were all found somewhere in the message"), not a claim of a proximity
 * match the Compile Service already discarded when it decomposed the term.
 *
 * <h2>Fallback strategy</h2>
 * <p>In some JVM environments (test runners, IDE debuggers) the Hyperscan
 * native scratch allocator throws {@code HS_ERR_INVALID} on {@code Scanner.scan()}.
 * When {@code lexicon.scanner.fallback-to-java-regex=true} (the default),
 * the service transparently retries with {@code java.util.regex.Pattern}
 * and synthesises equivalent {@link RawMatch} objects, reporting each
 * pattern's occurrences under the SAME expression id shape the native path
 * would have used — see {@link #scanWithJavaRegex}. This means the fallback
 * path performs NO gating/boolean evaluation of its own any more (an
 * earlier version did — checking exclusion and requiring all patterns to
 * match before reporting anything): it reports raw matches uniformly, and
 * {@code LexiconScanOrchestrator} evaluates the boolean condition identically
 * regardless of which path produced the matches.
 *
 * <h2>Flag bitmask</h2>
 * <pre>
 *   1  = HS_FLAG_CASELESS
 *   2  = HS_FLAG_DOTALL
 *   32 = HS_FLAG_UTF8
 *   64 = HS_FLAG_UCP
 * </pre>
 */
@Service
public class HyperscanScanService {

    private static final Logger log = LoggerFactory.getLogger(HyperscanScanService.class);

    public static final int HS_FLAG_CASELESS = 1;
    public static final int HS_FLAG_DOTALL   = 2;
    public static final int HS_FLAG_UTF8     = 32;
    public static final int HS_FLAG_UCP      = 64;

    /**
     * Default Hyperscan flag bitmask applied to {@code TermType.REGEX} terms,
     * which bypass the Lexicon Compile Service entirely and therefore never
     * get script-aware flag selection from {@code ScriptDetector}. CASELESS
     * matches the platform-wide convention that lexicon matching is always
     * case-insensitive; UTF8 + UCP are required for correct multi-byte
     * (Korean, Chinese, Arabic, emoji, etc.) matching regardless of pattern
     * content, since Hyperscan must know the input is UTF-8 to interpret
     * character boundaries correctly. DOTALL is intentionally NOT included —
     * unlike AND/NOT-translated patterns, a raw user-supplied regex has no
     * implicit need for {@code .} to span newlines, and forcing it on could
     * silently change the meaning of a pattern the user wrote deliberately.
     */
    public static final int HS_FLAGS_REGEX_DEFAULT = HS_FLAG_CASELESS | HS_FLAG_UTF8 | HS_FLAG_UCP;

    private final AppProperties props;

    public HyperscanScanService(AppProperties props) {
        this.props = props;
    }

    /**
     * Compiles all terms into one Hyperscan database and scans the message text.
     *
     * @param compiledTerms list of terms that are ready for scanning, with
     *                      expression ids already assigned (see
     *                      {@code LexiconScanOrchestrator})
     * @param messageText   the communication message to scan (UTF-8 String)
     * @return list of raw matches (may be empty; never null)
     */
    public List<RawMatch> compileAndScan(List<CompiledTerm> compiledTerms, String messageText) {
        if (compiledTerms == null || compiledTerms.isEmpty()) {
            log.warn("compileAndScan called with no compiled terms — returning empty result");
            return Collections.emptyList();
        }
        if (messageText == null || messageText.isBlank()) {
            log.warn("compileAndScan called with blank message text — returning empty result");
            return Collections.emptyList();
        }

        log.info("Starting Hyperscan scan: {} terms, message length={} chars",
                compiledTerms.size(), messageText.length());

        try {
            return scanWithHyperscan(compiledTerms, messageText);
        } catch (Exception e) {
            if (props.getScanner().isFallbackToJavaRegex()) {
                log.warn("Hyperscan scan failed ({}), falling back to Java regex: {}",
                        e.getClass().getSimpleName(), e.getMessage());
                return scanWithJavaRegex(compiledTerms, messageText);
            }
            throw new HyperscanScanException("Hyperscan scan failed: " + e.getMessage(), e);
        }
    }

    /**
     * Compiles {@code pattern} with the given Hyperscan flag bitmask and
     * returns {@code true} if compilation succeeds.
     * Used by unit tests to verify individual patterns without full scanning.
     *
     * @param pattern  Hyperscan PCRE pattern
     * @param hsFlags  bitmask of Hyperscan expression flags
     * @return true when Hyperscan accepts the pattern; false on compile error
     */
    public boolean validatePatternCompilation(String pattern, int hsFlags) {
        return validatePattern(pattern, hsFlags).pass();
    }

    /**
     * Compiles {@code pattern} with the given Hyperscan flag bitmask and
     * returns both the pass/fail outcome AND, on failure, Hyperscan's error
     * message — needed so {@code TermType.REGEX} terms (which bypass the
     * Lexicon Compile Service and therefore never receive a translation-stage
     * error) can still surface a meaningful compilation error on the UI,
     * exactly like Natural Language terms do when the Compile Service rejects them.
     *
     * @param pattern  Hyperscan PCRE pattern (as supplied directly by the user for REGEX-type terms)
     * @param hsFlags  bitmask of Hyperscan expression flags
     * @return a {@link com.db.macs3.ecomms.spectre.model.Models.PatternValidationResult}
     */
    public PatternValidationResult validatePattern(String pattern, int hsFlags) {
        Set<ExpressionFlag> flags = toExpressionFlags(hsFlags);
        flags.add(ExpressionFlag.SOM_LEFTMOST);
        try (Database db = Database.compile(new Expression(pattern, flags, 0))) {
            log.debug("Pattern validation PASS: {}", pattern);
            return new PatternValidationResult(true, null);
        } catch (CompileErrorException e) {
            log.debug("Pattern validation FAIL: {} — {}", pattern, e.getMessage());
            return new PatternValidationResult(
                    false, "Hyperscan rejected this pattern: " + e.getMessage());
        } catch (Exception e) {
            log.debug("Pattern validation FAIL (unexpected): {} — {}", pattern, e.getMessage());
            return new PatternValidationResult(
                    false, "Pattern could not be compiled: " + e.getMessage());
        }
    }

    // ── Hyperscan scanning ────────────────────────────────────────────────────

    private List<RawMatch> scanWithHyperscan(List<CompiledTerm> terms, String messageText)
            throws CompileErrorException {

        List<Expression> expressions = buildExpressions(terms);

        // Only needed for Stage 2 lookup (COMBINATION match -> owning term). Since AND NOT
        // terms never produce a COMBINATION expression any more, only terms that genuinely
        // use native combination (pure decomposition, no AND NOT) need an entry here.
        Map<Integer, CompiledTerm> combinationTermsById = terms.stream()
                .filter(CompiledTerm::usesNativeCombination)
                .collect(Collectors.toMap(t -> t.requiredExpressionIds().get(0), t -> t, (a, b) -> a));

        byte[] messageBytes = messageText.getBytes(StandardCharsets.UTF_8);

        try (Database db = Database.compile(expressions)) {
            log.debug("Hyperscan database compiled: {} expressions ({} terms)",
                    expressions.size(), terms.size());

            try (Scanner scanner = new Scanner()) {
                List<Match> matches = scanner.scan(db, messageText);

                log.info("Hyperscan scan complete: {} raw match event(s)", matches.size());

                List<RawMatch> results = new ArrayList<>();
                for (Match m : matches) {
                    results.addAll(toRawMatches(m, combinationTermsById, messageText, messageBytes));
                }
                return results;
            }
        }
    }

    /**
     * Builds every {@link Expression} the whole term list needs — see class
     * Javadoc "Expression building".
     */
    private List<Expression> buildExpressions(List<CompiledTerm> terms) {
        List<Expression> out = new ArrayList<>();
        int[] nextAuxId = {computeAuxIdOffset(terms)};

        for (CompiledTerm term : terms) {

            if (term.requiresExclusionCheck()) {
                // AND NOT — no combination, regardless of decomposition on either side (see
                // class Javadoc). Every pattern (both sides) is its own plain, individually-
                // reportable expression, using the id already assigned to it.
                addPlainExpressions(term.requiredPatterns(), term.requiredExpressionIds(), term.hsFlags(), out);
                addPlainExpressions(term.exclusionPatterns(), term.excludedExpressionIds(), term.hsFlags(), out);
                continue;
            }

            if (!term.usesNativeCombination()) {
                // Simplest, most common case — one plain pattern, reportable directly.
                // Never QUIET, never COMBINATION -> SOM_LEFTMOST is always safe here.
                Set<ExpressionFlag> flags = toExpressionFlags(term.hsFlags());
                flags.add(ExpressionFlag.SOM_LEFTMOST);
                out.add(new Expression(term.requiredPatterns().get(0), flags, term.requiredExpressionIds().get(0)));
                continue;
            }

            // Pure decomposition, no AND NOT — native COMBINATION remains safe here (no
            // negation involved) — see class Javadoc.
            List<Integer> leafIds = addQuietSide(term.requiredPatterns(), term.hsFlags(), nextAuxId, out);
            String combinationFormula = "(" + joinWithAnd(leafIds) + ")";
            out.add(new Expression(combinationFormula, EnumSet.of(ExpressionFlag.COMBINATION),
                    term.requiredExpressionIds().get(0)));
        }
        return out;
    }

    /**
     * Adds every (pattern, id) pair as its own plain, individually-reportable
     * expression — used for AND NOT terms now, where every required/excluded
     * pattern must report on its own so the caller can evaluate the boolean
     * condition after the whole scan completes. Includes SOM_LEFTMOST,
     * safely, since none of these are QUIET.
     *
     * @param patterns must be the same length as {@code ids}, paired positionally
     */
    private void addPlainExpressions(List<String> patterns, List<Integer> ids, int hsFlags, List<Expression> out) {
        for (int i = 0; i < patterns.size(); i++) {
            Set<ExpressionFlag> flags = toExpressionFlags(hsFlags);
            flags.add(ExpressionFlag.SOM_LEFTMOST);
            out.add(new Expression(patterns.get(i), flags, ids.get(i)));
        }
    }

    /** Adds every pattern in {@code patterns} as its own QUIET expression, returning their allocated ids. */
    private List<Integer> addQuietSide(List<String> patterns, int hsFlags, int[] nextAuxId, List<Expression> out) {
        List<Integer> ids = new ArrayList<>(patterns.size());
        for (String pattern : patterns) {
            int id = nextAuxId[0]++;
            Set<ExpressionFlag> flags = toExpressionFlags(hsFlags);
            flags.add(ExpressionFlag.QUIET);
            out.add(new Expression(pattern, flags, id));
            ids.add(id);
        }
        return ids;
    }

    private static String joinWithAnd(List<Integer> ids) {
        return ids.stream().map(String::valueOf).collect(Collectors.joining("&"));
    }

    /**
     * The auxiliary (non-term) id range must never overlap ANY id already
     * assigned to a term (whether {@code requiredExpressionIds} or
     * {@code excludedExpressionIds}) — unlike the earlier design, a term's own
     * ids are no longer a single, small, sequential value, since an AND NOT
     * term now consumes one id per required/excluded pattern. {@code offset =
     * (largest id assigned to any term, across the whole request) + 1} is the
     * first id available for every QUIET sub-expression this scan needs;
     * every subsequent auxiliary id is handed out sequentially from there.
     */
    private int computeAuxIdOffset(List<CompiledTerm> terms) {
        int max = -1;
        for (CompiledTerm term : terms) {
            for (int id : term.requiredExpressionIds()) max = Math.max(max, id);
            if (term.excludedExpressionIds() != null) {
                for (int id : term.excludedExpressionIds()) max = Math.max(max, id);
            }
        }
        return max + 1;
    }

    /**
     * Converts one Hyperscan {@link Match} to zero or more {@link RawMatch}
     * records. A plain (non-COMBINATION) match converts 1:1 — this now
     * includes every AND NOT required/excluded match, which is always plain.
     * A COMBINATION match (only possible for a purely-decomposed, non-AND-NOT
     * term now) triggers Stage 2 recovery — see class Javadoc — which can
     * produce zero, one, or several {@link RawMatch} records, one per
     * genuine occurrence of each of the owning term's required-side leaf patterns.
     */
    private List<RawMatch> toRawMatches(Match m, Map<Integer, CompiledTerm> combinationTermsById,
                                         String messageText, byte[] messageBytes) {
        int id = (int) m.getMatchedExpression().getId();
        boolean isCombination = m.getMatchedExpression().getFlags().contains(ExpressionFlag.COMBINATION);

        if (!isCombination) {
            return List.of(new RawMatch(m.getStartPosition(), m.getEndPosition(), id, false));
        }

        CompiledTerm term = combinationTermsById.get(id);
        if (term == null) {
            log.warn("COMBINATION match for unrecognised expression id={} — skipping", id);
            return List.of();
        }

        List<RawMatch> stage2 = new ArrayList<>();
        int javaFlags = buildJavaRegexFlags(term.hsFlags());
        for (String leafPattern : term.requiredPatterns()) {
            try {
                Matcher matcher = Pattern.compile(leafPattern, javaFlags).matcher(messageText);
                while (matcher.find()) {
                    long startByte = charIndexToByteOffset(messageBytes, matcher.start());
                    long endByte = charIndexToByteOffset(messageBytes, matcher.end());
                    stage2.add(new RawMatch(startByte, endByte, id, true));
                }
            } catch (Exception e) {
                log.warn("Stage 2 resolution failed for leaf pattern '{}' (term id={}): {}",
                        leafPattern, id, e.getMessage());
            }
        }
        log.debug("Stage 2 resolved {} leaf match(es) for COMBINATION expression id={}", stage2.size(), id);
        return stage2;
    }

    // ── Java-regex fallback ────────────────────────────────────────────────────

    /**
     * Java regex fallback for environments where {@code Scanner.scan()} fails.
     * Reports every pattern's occurrences under the SAME expression id shape
     * the native path would have used — see class Javadoc "Fallback strategy".
     * Performs NO gating/boolean evaluation itself; {@code LexiconScanOrchestrator}
     * evaluates the boolean condition identically regardless of which path
     * produced the matches, from the raw match-id set alone.
     */
    private List<RawMatch> scanWithJavaRegex(List<CompiledTerm> terms, String messageText) {
        log.debug("Java regex fallback scan: {} terms", terms.size());
        byte[] messageBytes = messageText.getBytes(StandardCharsets.UTF_8);
        List<RawMatch> results = new ArrayList<>();

        for (CompiledTerm term : terms) {
            int javaFlags = buildJavaRegexFlags(term.hsFlags());

            if (term.requiresExclusionCheck()) {
                // AND NOT: each required/excluded pattern reports under its OWN,
                // individually-assigned id — mirroring the native path's plain expressions.
                emitEachPatternUnderOwnId(term.requiredPatterns(), term.requiredExpressionIds(),
                        javaFlags, messageText, messageBytes, false, results);
                emitEachPatternUnderOwnId(term.exclusionPatterns(), term.excludedExpressionIds(),
                        javaFlags, messageText, messageBytes, false, results);
                continue;
            }

            if (!term.usesNativeCombination()) {
                // Simple, single-pattern term — one id, one pattern.
                emitEachPatternUnderOwnId(term.requiredPatterns(), term.requiredExpressionIds(),
                        javaFlags, messageText, messageBytes, false, results);
                continue;
            }

            // Pure decomposition, no AND NOT: the native path requires ALL leaves to match
            // somewhere before the combination fires at all — replicate that AND-gate here,
            // then (mirroring Stage 2) report every leaf's own occurrences under the ONE
            // shared, combination-equivalent id.
            if (!allPatternsMatch(term.requiredPatterns(), messageText, javaFlags)) {
                continue;
            }
            int combinationId = term.requiredExpressionIds().get(0);
            for (String pattern : term.requiredPatterns()) {
                try {
                    Matcher matcher = Pattern.compile(pattern, javaFlags).matcher(messageText);
                    while (matcher.find()) {
                        long startByte = charIndexToByteOffset(messageBytes, matcher.start());
                        long endByte = charIndexToByteOffset(messageBytes, matcher.end());
                        results.add(new RawMatch(startByte, endByte, combinationId, true));
                    }
                } catch (Exception e) {
                    log.warn("Java regex failed for pattern '{}': {}", pattern, e.getMessage());
                }
            }
        }

        log.info("Java regex scan complete: {} matches found", results.size());
        return results;
    }

    /**
     * Finds every occurrence of every (pattern, id) pair and emits a
     * {@link RawMatch} for each, using that pair's own id.
     *
     * @param patterns must be the same length as {@code ids}, paired positionally
     */
    private void emitEachPatternUnderOwnId(List<String> patterns, List<Integer> ids, int javaFlags,
                                            String messageText, byte[] messageBytes,
                                            boolean fromCombination, List<RawMatch> out) {
        for (int i = 0; i < patterns.size(); i++) {
            String pattern = patterns.get(i);
            int id = ids.get(i);
            try {
                Matcher matcher = Pattern.compile(pattern, javaFlags).matcher(messageText);
                while (matcher.find()) {
                    long startByte = charIndexToByteOffset(messageBytes, matcher.start());
                    long endByte = charIndexToByteOffset(messageBytes, matcher.end());
                    out.add(new RawMatch(startByte, endByte, id, fromCombination));
                    log.trace("Regex match for pattern '{}' (id={}): [{},{}]",
                            pattern, id, matcher.start(), matcher.end());
                }
            } catch (Exception e) {
                log.warn("Java regex failed for pattern '{}': {}", pattern, e.getMessage());
            }
        }
    }

    private boolean allPatternsMatch(List<String> patterns, String text, int javaFlags) {
        for (String pattern : patterns) {
            try {
                if (!Pattern.compile(pattern, javaFlags).matcher(text).find()) {
                    return false;
                }
            } catch (Exception e) {
                log.warn("Java regex failed for pattern '{}': {}", pattern, e.getMessage());
                return false;
            }
        }
        return true;
    }

    // ── Flag conversion ───────────────────────────────────────────────────────

    /**
     * Converts the Hyperscan flag bitmask to a {@link Set} of {@link ExpressionFlag} enum values.
     * CASELESS is always added as the minimum flag.
     */
    public Set<ExpressionFlag> toExpressionFlags(int bitmask) {
        Set<ExpressionFlag> flags = EnumSet.noneOf(ExpressionFlag.class);
        if ((bitmask & HS_FLAG_CASELESS) != 0) flags.add(ExpressionFlag.CASELESS);
        if ((bitmask & HS_FLAG_DOTALL)   != 0) flags.add(ExpressionFlag.DOTALL);
        if ((bitmask & HS_FLAG_UTF8)     != 0) flags.add(ExpressionFlag.UTF8);
        if ((bitmask & HS_FLAG_UCP)      != 0) flags.add(ExpressionFlag.UCP);
        if (flags.isEmpty())                    flags.add(ExpressionFlag.CASELESS);
        return flags;
    }

    /**
     * Maps the Hyperscan flag bitmask to {@link java.util.regex.Pattern} flag bits.
     * Used by the fallback Java regex path AND by Stage 2 combination-match recovery.
     */
    private int buildJavaRegexFlags(int hsBitmask) {
        int jf = Pattern.UNICODE_CASE;
        if ((hsBitmask & HS_FLAG_CASELESS) != 0) jf |= Pattern.CASE_INSENSITIVE;
        if ((hsBitmask & HS_FLAG_DOTALL)   != 0) jf |= Pattern.DOTALL;
        if ((hsBitmask & HS_FLAG_UTF8)     != 0) jf |= Pattern.UNICODE_CHARACTER_CLASS;
        return jf;
    }

    // ── UTF-8 byte offset helpers ─────────────────────────────────────────────

    /**
     * Converts a Java {@link String} character index to a UTF-8 byte offset.
     *
     * <p>Hyperscan reports match positions as byte offsets into the UTF-8
     * representation of the input string, whereas Java uses UTF-16 char indices.
     * For ASCII-only content these are identical; for multi-byte Unicode
     * (Korean, Chinese, Arabic, emoji) they differ.
     *
     * @param utf8Bytes the UTF-8 encoding of the message
     * @param charIndex Java char index in the original String
     * @return corresponding byte offset in {@code utf8Bytes}
     */
    public static long charIndexToByteOffset(byte[] utf8Bytes, int charIndex) {
        long byteOffset = 0;
        int charsProcessed = 0;
        while (charsProcessed < charIndex && byteOffset < utf8Bytes.length) {
            byte b = utf8Bytes[(int) byteOffset];
            // Determine byte-length of this UTF-8 code unit
            int seqLen;
            if      ((b & 0x80) == 0)    seqLen = 1;  // ASCII
            else if ((b & 0xE0) == 0xC0) seqLen = 2;  // 2-byte sequence
            else if ((b & 0xF0) == 0xE0) seqLen = 3;  // 3-byte sequence (most CJK)
            else                          seqLen = 4;  // 4-byte sequence (emoji, etc.)
            byteOffset += seqLen;
            // 4-byte UTF-8 = one Unicode supplementary plane char → 2 Java chars (surrogate pair)
            charsProcessed += (seqLen == 4) ? 2 : 1;
        }
        return byteOffset;
    }

    /**
     * Converts a UTF-8 byte offset to a Java {@code String} character index.
     * Inverse of {@link #charIndexToByteOffset(byte[], int)}.
     */
    public static int byteOffsetToCharIndex(byte[] utf8Bytes, long byteOffset) {
        int charIndex = 0;
        long pos = 0;
        while (pos < byteOffset && pos < utf8Bytes.length) {
            byte b = utf8Bytes[(int) pos];
            int seqLen;
            if      ((b & 0x80) == 0)    seqLen = 1;
            else if ((b & 0xE0) == 0xC0) seqLen = 2;
            else if ((b & 0xF0) == 0xE0) seqLen = 3;
            else                          seqLen = 4;
            pos += seqLen;
            charIndex += (seqLen == 4) ? 2 : 1;
        }
        return charIndex;
    }

    // ── Exception ─────────────────────────────────────────────────────────────

    /** Thrown when Hyperscan scanning fails and fallback is disabled. */
    public static final class HyperscanScanException extends RuntimeException {
        public HyperscanScanException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
