package com.db.macs3.ecomms.spectre.reader;

import com.db.macs3.ecomms.spectre.model.MessageRecord;
import com.db.macs3.ecomms.spectre.model.ScanEngineArgs;
import org.apache.spark.api.java.function.FilterFunction;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.*;
import org.apache.spark.sql.types.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.apache.spark.sql.functions.*;

/**
 * Reads AVRO message files from GCS and produces a {@code Dataset<MessageRecord>}
 * filtered to only the message IDs that appear in the feature decisions view.
 *
 * <h2>AVRO structure handled</h2>
 * <pre>
 * {
 *   "message_id": string,
 *   "source_type": "chat" | "email",
 *   "run_date": string,
 *   "metadata": {...},
 *   "content": { "raw_text": string, "subject": string, "clean_text": string },
 *   "attachment": [
 *     { "raw_text": string, "content_type": string, "content_encoding": string }
 *   ]
 * }
 * </pre>
 *
 * <h2>Optimisations</h2>
 * <ul>
 *   <li>Path partitioning: reads only the RUN_DATE/PIPELINE_EXEC_ID partition,
 *       exploiting Dataproc's GCS path partitioning to skip unrelated files.</li>
 *   <li>Projection pushdown: only {@code message_id}, {@code source_type},
 *       {@code run_date}, {@code content.raw_text}, and {@code attachment[].raw_text}
 *       are selected — other fields are never read from disk.</li>
 *   <li>Message ID filter: applied after reading, using a broadcast set for
 *       efficient executor-local filtering (no shuffle required).</li>
 *   <li>Attachment explosion: the attachment array is collected into a
 *       {@code List<String>} within the same {@link MessageRecord}, avoiding
 *       a costly cross-join explode that would duplicate message body text.</li>
 * </ul>
 */
@Component
public class AvroMessageReader {

    private static final Logger log = LoggerFactory.getLogger(AvroMessageReader.class);

    /**
     * Reads AVRO messages from the partitioned GCS path, projects only the required
     * fields, and filters to message IDs present in the feature decisions view.
     *
     * @param spark              active Spark session
     * @param args               job runtime arguments (GCS paths, run date, etc.)
     * @param broadcastMessageIds broadcast set of message IDs to include (from BQ view)
     * @return dataset of {@link MessageRecord}s, one per message
     */
    public Dataset<MessageRecord> readAndFilter(SparkSession spark,
                                                 ScanEngineArgs args,
                                                 Broadcast<Set<String>> broadcastMessageIds) {
        String avroPath = buildAvroPath(args);
        log.info("Reading AVRO messages from: {}", avroPath);

        // Read AVRO — schema inference is expensive on large datasets;
        // provide the schema explicitly if available to skip an extra scan pass.
        Dataset<Row> rawDf = spark.read()
                .format("avro")
                .load(avroPath);

        log.debug("AVRO raw schema: {}", rawDf.schema().treeString());

        // Project only required columns to minimise shuffle and memory pressure.
        // content.raw_text   → the main message body
        // attachment         → array of attachment structs; we collect raw_text from each
        Dataset<Row> projected = rawDf.select(
                col("message_id"),
                col("source_type"),
                col("run_date"),
                col("content.raw_text").alias("content_raw_text"),
                col("attachment")          // keep as array<struct>; extracted below
        );

        // Collect attachment raw_text values into a plain array column,
        // then drop the original struct array — avoids unnecessary field retention.
        Dataset<Row> withAttachments = projected.withColumn(
                "attachment_texts",
                // transform() is a Spark built-in higher-order function (Spark 2.4+)
                expr("transform(attachment, a -> a.raw_text)")
        ).drop("attachment");

        log.info("Projecting and filtering {} message partitions", avroPath);

        // Filter to only relevant message IDs using the broadcast set.
        // This avoids a shuffle: the filter runs locally on each executor using
        // the broadcast variable rather than requiring a join.
        Dataset<Row> filtered = withAttachments.filter(
                (FilterFunction<Row>) row -> {
                    String msgId = row.isNullAt(row.fieldIndex("message_id"))
                                   ? null
                                   : row.getString(row.fieldIndex("message_id"));
                    return msgId != null && broadcastMessageIds.value().contains(msgId);
                }
        );

        // Map each Row to a typed MessageRecord
        return filtered.map(
                (MapFunction<Row, MessageRecord>) AvroMessageReader::rowToMessageRecord,
                Encoders.bean(MessageRecord.class)
        );
    }

    // ── Path construction ─────────────────────────────────────────────────────

    /**
     * Constructs the GCS path for AVRO message files, using partition pruning
     * where the path structure encodes RUN_DATE and PIPELINE_EXEC_ID.
     *
     * <p>Expected path pattern:
     * {@code gs://<bucket>/<prefix>/RUN_DATE=<date>/PIPELINE_EXEC_ID=<id>/**}
     *
     * <p>If the msgGcsPrefix already contains partition segments, the raw path
     * is used as-is, allowing the caller to control partitioning granularity.
     *
     * @param args job runtime arguments
     * @return fully qualified GCS path with wildcard for recursive read
     */
    public String buildAvroPath(ScanEngineArgs args) {
        String base = args.avroGcsPath();
        // Append partition segments only if not already present
        if (!base.contains("RUN_DATE=")) {
            base = base + "/RUN_DATE=" + args.getRunDate()
                       + "/PIPELINE_EXEC_ID=" + args.getPipelineExecId();
        }
        return base.endsWith("/") ? base + "*.avro" : base + "/*.avro";
    }

    // ── Row mapping ───────────────────────────────────────────────────────────

    /**
     * Maps a Spark {@link Row} (with projected columns) to a {@link MessageRecord}.
     *
     * @param row the projected and filtered AVRO row
     * @return populated MessageRecord
     */
    @SuppressWarnings("unchecked")
    private static MessageRecord rowToMessageRecord(Row row) {
        String messageId       = getStrOrNull(row, "message_id");
        String sourceType      = getStrOrNull(row, "source_type");
        String runDate         = getStrOrNull(row, "run_date");
        String contentRawText  = getStrOrNull(row, "content_raw_text");

        // attachment_texts column is Array<String> (may contain nulls for attachments
        // with no raw_text — those are filtered out below)
        List<String> attachmentTexts = new ArrayList<>();
        int attIdx = row.fieldIndex("attachment_texts");
        if (!row.isNullAt(attIdx)) {
            scala.collection.Seq<Object> attSeq = row.getSeq(attIdx);
            if (attSeq != null) {
                scala.collection.Iterator<Object> it = attSeq.iterator();
                while (it.hasNext()) {
                    Object item = it.next();
                    if (item != null) {
                        String txt = item.toString();
                        if (!txt.isBlank()) {
                            attachmentTexts.add(txt);
                        }
                    }
                }
            }
        }

        return MessageRecord.of(messageId, sourceType, runDate, contentRawText, attachmentTexts);
    }

    private static String getStrOrNull(Row row, String fieldName) {
        int idx = row.fieldIndex(fieldName);
        return row.isNullAt(idx) ? null : row.getString(idx);
    }
}
