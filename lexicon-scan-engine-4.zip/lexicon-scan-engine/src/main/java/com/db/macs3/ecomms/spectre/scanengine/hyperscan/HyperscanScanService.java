package com.db.macs3.ecomms.spectre.scanengine.hyperscan;

import com.db.macs3.ecomms.spectre.scanengine.html.HtmlStrippingService;
import com.db.macs3.ecomms.spectre.scanengine.model.match.AreaMatch;
import com.db.macs3.ecomms.spectre.scanengine.model.match.MatchArea;
import com.db.macs3.ecomms.spectre.scanengine.model.match.MatchSpan;
import com.db.macs3.ecomms.spectre.scanengine.model.match.TermMatchResult;
import com.gliwka.hyperscan.wrapper.Database;
import com.gliwka.hyperscan.wrapper.Match;
import com.gliwka.hyperscan.wrapper.Scanner;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.IntFunction;

/**
 * Scans one piece of message text (subject, message body, or one
 * attachment's content) against a loaded Hyperscan {@link Database},
 * combining {@link HtmlStrippingService}'s original-text offset mapping
 * with Hyperscan's own match reporting to produce {@link TermMatchResult}s
 * at ORIGINAL-text coordinates.
 *
 * <h2>Match position semantics (verified against the wrapper's own docs)</h2>
 * <p>{@code com.gliwka.hyperscan-java}'s {@link Match#getStartPosition()} and
 * {@link Match#getEndPosition()} are documented as returning JAVA CHARACTER
 * indices (the wrapper converts Hyperscan's native UTF-8 BYTE offsets to
 * Java {@code char} indices internally) — NOT raw byte offsets requiring a
 * separate conversion step. {@code getEndPosition()} is INCLUSIVE (the index
 * of the last matched character, not one-past-the-end), so it is converted
 * to an exclusive bound ({@code +1}) before being combined with
 * {@link HtmlStrippingService.OffsetMap}, which expects exclusive
 * boundaries. {@link Match#getMatchedString()} (available whenever
 * {@code SOM_LEFTMOST} is set, which this platform always sets — start-of-match
 * tracking is required for exactly this kind of position reporting) is used
 * directly as the stripped-text matched substring, rather than re-deriving
 * it via {@code String.substring} on the start/end positions, to avoid any
 * risk of an independently-introduced off-by-one disagreeing with what
 * Hyperscan itself reports as matched.
 *
 * <h2>Expression id → term identity resolution</h2>
 * <p><b>Both previously-open questions here are now resolved</b> by the
 * Lexicon Compile Service's current {@code /compile/bundle} id scheme: every
 * PASS term's reportable Hyperscan expression id — whether it compiled as a
 * single plain pattern or needed a QUIET/COMBINATION structure for AND NOT
 * or decomposition — is ALWAYS that term's own term number (see the Compile
 * Service's {@code HyperscanCombinationHandler} class Javadoc). This means:
 * <ul>
 *   <li>{@link ExpressionIdResolver} only ever needs to map an expression id
 *       to a {@code termId} string ({@code <feature>::<expressionId>}, via
 *       {@code TermIdBuilder}) — the previously-open question of what a
 *       native-combination id for an AND NOT/decomposed term even meant no
 *       longer applies, since that id IS simply the term's own number now.</li>
 *   <li>QUIET auxiliary sub-expressions (decomposition leaves, an AND NOT
 *       term's exclusion pattern(s)) are never reported as {@link Match}es
 *       at all — Hyperscan's own callback mechanism filters them out, since
 *       QUIET means exactly that. This class never even sees an expression
 *       id for one.</li>
 *   <li>{@code term_regex_pattern} no longer needs a separate JSON file read
 *       alongside the {@code .hdb} — see "Pattern text" below.</li>
 * </ul>
 *
 * <h2>Pattern text comes directly from the match, not a separate file</h2>
 * <p>{@code com.gliwka.hyperscan-java}'s {@link Match#getMatchedExpression()}
 * returns the actual {@link com.gliwka.hyperscan.wrapper.Expression} object
 * that matched — which itself carries the original pattern text via
 * {@code getExpression()}. This is populated from the {@code .hdb} file's
 * own embedded expression metadata (written when the Compile Service built
 * the combined database), not from any accompanying JSON — the {@code .hdb}
 * file is genuinely self-sufficient for this. {@link #scan} reads it
 * directly rather than asking the caller-supplied resolver for it, which is
 * why {@link ExpressionIdResolver} only resolves a {@code termId} now.
 */
public final class HyperscanScanService {

    /**
     * Resolves a Hyperscan expression id (as reported on a {@link Match})
     * to the {@code termId} it belongs to — see class Javadoc "Expression
     * id → term identity resolution". The pattern text itself is read
     * directly from the match, not from this resolver — see "Pattern text
     * comes directly from the match" above.
     */
    @FunctionalInterface
    public interface ExpressionIdResolver {
        /** @return the termId for {@code expressionId}, or null if this id is not recognised (see {@link #scan}) */
        String resolve(int expressionId);
    }

    private HyperscanScanService() {}

    /**
     * Scans {@code originalText} against {@code database}, returning one
     * {@link TermMatchResult} per DISTINCT term that matched (each carrying
     * every occurrence found, tagged with {@code area}/{@code attachmentId}).
     *
     * @param originalText     the text to scan, in its original (possibly HTML-bearing) form —
     *                          HTML is stripped internally before scanning; see {@link HtmlStrippingService}
     * @param database          a loaded Hyperscan database — see {@code HyperscanDatabaseLoader}
     * @param resolver           maps a matched expression id back to term identity — see
     *                          {@link ExpressionIdResolver}
     * @param area                which part of the message {@code originalText} is
     * @param attachmentId       required (non-null) iff {@code area == ATTACHMENT}; null otherwise
     * @return term matches found, empty if {@code originalText} is blank or nothing matched
     * @throws HyperscanScanException if the native scan call itself fails (scratch allocation,
     *                                  a corrupted database, etc. — see requirement 3.b)
     */
    public static List<TermMatchResult> scan(String originalText, Database database,
                                              ExpressionIdResolver resolver,
                                              MatchArea area, String attachmentId) {
        if (originalText == null || originalText.isBlank()) {
            return List.of();
        }

        HtmlStrippingService.StripResult stripResult = HtmlStrippingService.strip(originalText);
        String strippedText = stripResult.strippedText();

        List<Match> rawMatches;
        try (Scanner scanner = new Scanner()) {
            scanner.allocScratch(database);
            rawMatches = scanner.scan(database, strippedText);
        } catch (Exception e) {
            throw new HyperscanScanException("Hyperscan scan failed: " + e.getMessage(), e);
        }

        if (rawMatches == null || rawMatches.isEmpty()) {
            return List.of();
        }

        // Group raw matches by expression id, preserving first-seen order for determinism.
        Map<Integer, List<Match>> byExpressionId = new LinkedHashMap<>();
        for (Match m : rawMatches) {
            int id = m.getMatchedExpression().getId();
            byExpressionId.computeIfAbsent(id, k -> new ArrayList<>()).add(m);
        }

        List<TermMatchResult> results = new ArrayList<>(byExpressionId.size());
        for (Map.Entry<Integer, List<Match>> entry : byExpressionId.entrySet()) {
            int expressionId = entry.getKey();
            String termId = resolver.resolve(expressionId);
            if (termId == null) {
                // An expression id this resolver doesn't recognise — skip rather than fail the
                // whole scan. In practice this should not happen for a well-formed .hdb file:
                // QUIET sub-expressions are never reported as matches at all (Hyperscan's own
                // callback mechanism filters them out), so every expression id reaching this
                // point should be a term's own reportable id.
                continue;
            }

            // The pattern text comes directly from the match's own Expression object — see
            // class Javadoc "Pattern text comes directly from the match, not a separate file".
            // Every match sharing this expressionId carries the identical Expression instance,
            // so reading it from the first one is sufficient.
            String termRegexPattern = entry.getValue().get(0).getMatchedExpression().getExpression();

            List<AreaMatch> areaMatches = new ArrayList<>(entry.getValue().size());
            for (Match m : entry.getValue()) {
                int strippedStart = (int) m.getStartPosition();
                int strippedEndExclusive = (int) m.getEndPosition() + 1; // inclusive -> exclusive

                int originalStart = stripResult.offsetMap().toOriginal(strippedStart);
                int originalEnd = stripResult.offsetMap().toOriginal(strippedEndExclusive);
                String matchedText = m.getMatchedString();

                MatchSpan span = new MatchSpan(originalStart, originalEnd, matchedText);
                areaMatches.add(new AreaMatch(area, attachmentId, span));
            }
            results.add(new TermMatchResult(termId, termRegexPattern, areaMatches));
        }
        return results;
    }

    /** Thrown when the native Hyperscan scan call itself fails — see requirement 3.b. */
    public static final class HyperscanScanException extends RuntimeException {
        public HyperscanScanException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
