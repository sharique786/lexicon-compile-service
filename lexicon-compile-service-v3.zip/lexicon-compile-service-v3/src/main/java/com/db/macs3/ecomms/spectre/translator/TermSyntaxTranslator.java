package com.db.macs3.ecomms.spectre.translator;

import com.ibm.icu.text.Normalizer2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Translates lexicon term descriptions (operator language) into
 * Hyperscan-compatible PCRE patterns.
 *
 * <h2>Pipeline</h2>
 * <pre>
 * raw text → preprocess → Tokenizer → List&lt;Token&gt; → ExpressionParser → Ast
 *          → PatternCodeGenerator → (pattern, flags, required/excluded operands)
 * </pre>
 *
 * <p>Each stage is a separate, independently-testable class. This replaced
 * an earlier single-class implementation that mixed lexical scanning,
 * grammar resolution, and pattern generation together via repeated raw
 * string-index arithmetic — see {@link Tokenizer} and {@link ExpressionParser}
 * class Javadoc for the specific bugs that architecture produced and how
 * separating these concerns fixes them structurally rather than case-by-case.
 *
 * <h2>Operator precedence (grammar — see {@link ExpressionParser})</h2>
 * <table>
 * <tr><td>Atom</td><td>word, "quoted phrase", emoji, non-english, wildcard, parens (highest)</td></tr>
 * <tr><td>NOT</td><td>prefix negation</td></tr>
 * <tr><td>NEAR{n} / FOLLOWEDBY{n}</td><td>proximity, left-associative chaining</td></tr>
 * <tr><td>AND</td><td>conjunction — text must contain all operands</td></tr>
 * <tr><td>AND NOT</td><td>exclusion — text must contain the left side but not the right</td></tr>
 * <tr><td>OR</td><td>alternation (lowest)</td></tr>
 * </table>
 *
 * <h2>Pattern examples</h2>
 * <pre>
 * (crap OR bad) NEAR{3} (bonus OR comp)
 *   → (?:(?:crap|bad)(?:\s+\S+){0,3}\s+(?:bonus|comp)|(?:bonus|comp)(?:\s+\S+){0,3}\s+(?:crap|bad))
 *
 * (F) FOLLOWEDBY{1} (((me) OR (cking)))
 *   → F(?:\s+\S+){0,1}\s+(?:me|cking)
 *
 * ((fix) OR (rig)) FOLLOWEDBY{2} (the rate) AND NOT (fed rate move)
 *   → hsPattern:        (?:fix|rig)(?:\s+\S+){0,2}\s+the rate
 *     requiredOperands: ["(?:fix|rig)(?:\s+\S+){0,2}\s+the rate"]
 *     excludedOperands: ["fed rate move"]
 *   (Hyperscan has no negative lookbehind, so the exclusion cannot be baked
 *   into hsPattern itself — see class Javadoc on {@link PatternCodeGenerator})
 *
 * ((he?d kill) OR (she?d kill))
 *   → (?:he\?d kill|she\?d kill)     — '?' is always literal
 *
 * (check her out) OR (chimp*)
 *   → (?:check her out|chimp\S*)
 *
 * 내부자 NEAR{3} 거래    (Korean insider NEAR trading)
 *   → (?:내부자[\s\S]{0,18}거래|거래[\s\S]{0,18}내부자)
 *
 * 💰 OR 🤫
 *   → (?:\x{1F4B0}|\x{1F92B})  (with UTF8+UCP flags)
 * </pre>
 */
@Component
public final class TermSyntaxTranslator {

    private static final Logger log = LoggerFactory.getLogger(TermSyntaxTranslator.class);

    /**
     * Translates one lexicon term description into a Hyperscan PCRE pattern.
     *
     * @param rawExpression the "Term Description" from the CSV/JSON input
     * @return {@link TranslationResult.Success} with pattern, flags, and
     *         required/excluded operand metadata, or
     *         {@link TranslationResult.Error} with a specific, actionable error message
     */
    public TranslationResult translate(String rawExpression) {
        if (rawExpression == null || rawExpression.isBlank()) {
            return TranslationResult.error("Term description is null or blank");
        }
        try {
            String preprocessed = preprocess(rawExpression);
            log.debug("Translating: '{}'", preprocessed);

            List<Token> tokens = Tokenizer.tokenize(preprocessed);
            Ast ast = ExpressionParser.parse(tokens, preprocessed);

            ParseContext ctx = new ParseContext();
            String pattern = PatternCodeGenerator.generate(ast, ctx);
            int flags = ctx.computeFlags();

            log.debug("Translated: '{}' -> pattern='{}' flags={} required={} excluded={}",
                    rawExpression, pattern, flags, ctx.getRequiredOperands(), ctx.getExcludedOperands());

            return TranslationResult.success(pattern, flags, ctx.requiresAndPostFilter(),
                    ctx.getRequiredOperands(), ctx.getExcludedOperands());

        } catch (TranslationException te) {
            log.warn("Translation failed for '{}': {}", rawExpression, te.getMessage());
            return TranslationResult.error(te.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error translating '{}': {}", rawExpression, e.getMessage(), e);
            return TranslationResult.error("Unexpected error: " + e.getMessage());
        }
    }

    // ── Pre-processing ────────────────────────────────────────────────────────

    /**
     * Normalises the raw expression before tokenizing:
     * <ol>
     *   <li>Trim whitespace</li>
     *   <li>Unescape CSV double-quote encoding: {@code ""} → {@code "}</li>
     *   <li>Unicode NFC normalisation (ICU4J) for consistent multi-language handling</li>
     * </ol>
     *
     * <p>Outer {@code "..."} wrapping is intentionally NOT stripped here —
     * {@link Tokenizer} recognises a quoted phrase as its own token type,
     * and {@link ExpressionParser}/{@link PatternCodeGenerator} handle its
     * content as always-literal. Stripping quotes at this stage would expose
     * their content to normal tokenization, silently losing the "always
     * literal" guarantee quotes are supposed to provide.
     */
    private String preprocess(String raw) {
        String s = raw.trim();
        s = s.replace("\"\"", "\u0000DQ\u0000");
        s = s.replace("\u0000DQ\u0000", "\"");
        try {
            s = Normalizer2.getNFCInstance().normalize(s);
        } catch (Exception e) {
            log.debug("ICU4J normalisation skipped: {}", e.getMessage());
        }
        return s;
    }
}
