package com.db.macs3.ecomms.spectre.translator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Comprehensive tests for the Tokenizer → ExpressionParser → PatternCodeGenerator
 * pipeline, organised around the specific bug reports and requirements that
 * drove this rewrite. Every example given in the requirements document is
 * reproduced here verbatim as a test case, plus the five real terms from the
 * bug-report screenshot (reconstructed from the German lexicon rule set).
 */
@DisplayName("TermSyntaxTranslator")
class TermSyntaxTranslatorTest {

    private TermSyntaxTranslator translator;

    @BeforeEach
    void setUp() {
        translator = new TermSyntaxTranslator();
    }

    private TranslationResult.Success translateOk(String term) {
        TranslationResult r = translator.translate(term);
        assertThat(r).as("expected SUCCESS for '%s' but got: %s", term,
                r.isSuccess() ? "" : ((TranslationResult.Error) r).message())
                .isInstanceOf(TranslationResult.Success.class);
        return (TranslationResult.Success) r;
    }

    private String translateError(String term) {
        TranslationResult r = translator.translate(term);
        assertThat(r).as("expected ERROR for '%s' but got SUCCESS", term)
                .isInstanceOf(TranslationResult.Error.class);
        return ((TranslationResult.Error) r).message();
    }

    // ══════════════════════════════════════════════════════════════════════
    // Requirement 1: brackets resolve first, at any nesting depth
    // ══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Requirement 1 — bracket resolution order")
    class BracketResolution {

        @Test
        @DisplayName("Example 1: (crap OR bad) NEAR{3} (bonus OR comp)")
        void example1_orInsideNear() {
            var s = translateOk("(crap OR bad) NEAR{3} (bonus OR comp)");
            assertThat(s.hsPattern()).isEqualTo(
                    "(?:(?:crap|bad)(?:\\s+\\S+){0,3}\\s+(?:bonus|comp)"
                    + "|(?:bonus|comp)(?:\\s+\\S+){0,3}\\s+(?:crap|bad))");
        }

        @Test
        @DisplayName("Example 2: (F) FOLLOWEDBY{1} (((me) OR (cking))) — triple redundant wrapping")
        void example2_deeplyRedundantWrapping() {
            var s = translateOk("(F) FOLLOWEDBY{1} (((me) OR (cking)))");
            assertThat(s.hsPattern()).isEqualTo("F(?:\\s+\\S+){0,1}\\s+(?:me|cking)");
        }

        @ParameterizedTest(name = "[{index}] {0}")
        @ValueSource(strings = {
                "(((me) OR (cking)))",
                "((((me) OR (cking))))",
                "(((((F)))))",
        })
        @DisplayName("Arbitrary depths of pure redundant wrapping resolve without error")
        void arbitraryRedundantWrappingDepths(String term) {
            assertThat(translator.translate(term).isSuccess()).as(term).isTrue();
        }

        @Test
        @DisplayName("Triple-nested NEAR inside OR does not crash and resolves inner group first")
        void tripleNestedNearInsideOr() {
            var s = translateOk("(((crap) NEAR{3} (bad))) OR (bonus OR comp)");
            assertThat(s.hsPattern()).contains("crap").contains("bad").contains("bonus").contains("comp");
        }

        @Test
        @DisplayName("Mixed nesting: OR-of-parens combined with a NEAR sibling")
        void mixedNestingOrAndNear() {
            var s = translateOk("((crap) OR (bad)) OR (bonus NEAR{3} comp)");
            assertThat(s.hsPattern()).contains("crap").contains("bad");
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // Requirement 2: multi-word phrases must be wrapped in parentheses
    // ══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Requirement 2 — multi-word phrases must be wrapped")
    class MultiWordWrapping {

        @Test
        @DisplayName("Properly wrapped multi-word OR alternatives succeed (unchanged)")
        void wrappedPhrasesSucceed() {
            var s = translateOk("(bomb this place) OR (blow this place up)");
            assertThat(s.hsPattern()).contains("bomb this place").contains("blow this place up");
        }

        @Test
        @DisplayName("Unwrapped multi-word phrase at top level is now ACCEPTED as an implicit phrase")
        void unwrappedTopLevelPhraseAccepted() {
            var s = translateOk("bomb this place OR blow this place up");
            assertThat(s.hsPattern()).isEqualTo("(?:bomb this place|blow this place up)");
        }

        @Test
        @DisplayName("Unwrapped multi-word OR-alternative nested inside an otherwise-wrapped group is also accepted")
        void unwrappedNestedAlternativeAccepted() {
            var s = translateOk("(für dich OR für Sie)");
            assertThat(s.hsPattern()).isEqualTo("(?:f\u00fcr dich|f\u00fcr Sie)");
        }

        @Test
        @DisplayName("A single (one-word) atom never needs wrapping")
        void singleWordNeverNeedsWrapping() {
            assertThat(translator.translate("fix OR rig").isSuccess()).isTrue();
        }

        @Test
        @DisplayName("Unwrapped phrase inside NEAR/FOLLOWEDBY operands is also accepted")
        void unwrappedPhraseInProximityOperand() {
            var s = translateOk("insider trading NEAR{3} market manipulation");
            assertThat(s.hsPattern()).contains("insider trading").contains("market manipulation");
        }

        @Test
        @DisplayName("Deeply-nested wrapping still resolves correctly even with implicit phrase collection active")
        void deepNestingStillCorrectWithImplicitPhrases() {
            var s = translateOk("(((crap) NEAR{3} (bad))) OR (bonus OR comp)");
            assertThat(s.hsPattern()).contains("crap").contains("bad").contains("bonus").contains("comp");
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // Requirement 3: '?' is always literal
    // ══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Requirement 3 — '?' is always literal")
    class LiteralQuestionMark {

        @Test
        @DisplayName("he?d / she?d — '?' escaped as a literal character, never a live quantifier")
        void questionMarkIsLiteral() {
            var s = translateOk("((he?d kill) OR (she?d kill))");
            assertThat(s.hsPattern()).isEqualTo("(?:he\\?d kill|she\\?d kill)");
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // Requirement 4: wildcard '*' — prefix, suffix, and non-ASCII words
    // ══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Requirement 4 — wildcard handling")
    class Wildcards {

        @Test
        @DisplayName("Suffix wildcard: chimp* -> chimp\\S*")
        void suffixWildcard() {
            var s = translateOk("(check her out) OR (chimp*)");
            assertThat(s.hsPattern()).isEqualTo("(?:check her out|chimp\\S*)");
        }

        @Test
        @DisplayName("Prefix wildcard: *handler -> \\S*handler")
        void prefixWildcard() {
            var s = translateOk("(*handler)");
            assertThat(s.hsPattern()).isEqualTo("\\S*handler");
        }

        @Test
        @DisplayName("THE REPORTED BUG: suffix wildcard on a non-ASCII word must still convert to \\S*")
        void wildcardOnNonAsciiWord_theReportedBug() {
            var s = translateOk("(verschwör*)");
            assertThat(s.hsPattern()).isEqualTo("verschw\u00f6r\\S*");
            assertThat(s.hsPattern()).doesNotContain("r*"); // bare, un-expanded '*' must not survive
        }

        @Test
        @DisplayName("Prefix wildcard on a non-ASCII word")
        void prefixWildcardOnNonAsciiWord() {
            var s = translateOk("(*händler)");
            assertThat(s.hsPattern()).isEqualTo("\\S*h\u00e4ndler");
        }

        @Test
        @DisplayName("Wildcard inside a quoted phrase is a LITERAL asterisk, not expanded")
        void wildcardInQuotesIsLiteral() {
            var s = translateOk("\"chimp*\"");
            assertThat(s.hsPattern()).isEqualTo("chimp\\*");
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // Requirement 5: AND / AND NOT
    // ══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Requirement 5 — AND / AND NOT")
    class AndAndNot {

        @Test
        @DisplayName("Plain AND: both operands required, recorded for post-filter")
        void plainAnd() {
            var s = translateOk("((want to) AND (fix))");
            assertThat(s.requiresAndPostFilter()).isTrue();
            assertThat(s.requiredOperands()).hasSize(2);
            assertThat(s.requiredOperands()).anyMatch(o -> o.contains("want to"));
            assertThat(s.requiredOperands()).anyMatch(o -> o.contains("fix"));
        }

        @Test
        @DisplayName("AND NOT: positive pattern is the Hyperscan scan expression; " +
                     "exclusion is captured separately, NOT as an invalid Hyperscan lookbehind")
        void andNot_positivePatternAndSeparateExclusion() {
            var s = translateOk("((fix) OR (rig)) FOLLOWEDBY{2} (the rate) AND NOT (fed rate move)");
            assertThat(s.hsPattern()).contains("fix|rig").contains("the rate");
            // Hyperscan has no negative lookbehind — the exclusion must never appear
            // baked into the scan pattern itself.
            assertThat(s.hsPattern()).doesNotContain("fed rate move");
            assertThat(s.hsPattern()).doesNotContain("?<!");
            assertThat(s.excludedOperands()).hasSize(1);
            assertThat(s.excludedOperands().get(0)).contains("fed rate move");
        }

        @Test
        @DisplayName("THE REPORTED BUG: 'AND NOT(' with no space before the parenthesis is recognised correctly")
        void andNotWithoutSpaceBeforeParen() {
            // The original implementation required the literal 9-character
            // string " AND NOT " and silently mis-parsed this common,
            // perfectly ordinary way of writing it.
            var s = translateOk("(hello) AND NOT(world)");
            assertThat(s.requiresAndPostFilter()).isTrue();
            assertThat(s.excludedOperands()).containsExactly("world");
        }

        @Test
        @DisplayName("THE REPORTED BUG: chained FOLLOWEDBY inside an AND-NOT exclusion, written without a space, " +
                     "no longer collapses into unrecognised literal text")
        void chainedFollowedByInsideAndNotWithoutSpace() {
            var s = translateOk("(hello) AND NOT((a OR b) FOLLOWEDBY{1} (c OR d) FOLLOWEDBY{1} (e OR f))");
            assertThat(s.excludedOperands()).hasSize(1);
            String excluded = s.excludedOperands().get(0);
            assertThat(excluded).contains("(?:a|b)").contains("(?:c|d)").contains("(?:e|f)");
        }

        @Test
        @DisplayName("Nested NEAR inside an AND-NOT exclusion (one alternative of an OR-of-phrases) resolves correctly")
        void nestedNearInsideAndNotExclusion() {
            var s = translateOk("(hello) AND NOT((plain phrase) OR ((EURIBOR FIXING) NEAR{2} TENOR))");
            assertThat(s.excludedOperands()).hasSize(1);
            assertThat(s.excludedOperands().get(0)).contains("EURIBOR FIXING").contains("TENOR");
        }

        @Test
        @DisplayName("Chained AND NOT: A AND NOT B AND NOT C excludes both B and C")
        void chainedAndNot() {
            var s = translateOk("(a) AND NOT (b) AND NOT (c)");
            assertThat(s.excludedOperands()).hasSize(2);
        }

        @Test
        @DisplayName("Standalone NOT / ! still returns the operand pattern with post-filter flag set")
        void standaloneNot() {
            var s = translateOk("NOT (spam)");
            assertThat(s.requiresAndPostFilter()).isTrue();
            assertThat(s.hsPattern()).isEqualTo("spam");
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // Validation rules
    // ══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Validation — reserved keywords are case-sensitive")
    class CaseSensitiveKeywords {

        @Test
        @DisplayName("lowercase 'or' is literal text, not the OR operator")
        void lowercaseOrIsLiteral() {
            var s = translateOk("(price or spread)");
            assertThat(s.hsPattern()).isEqualTo("price or spread");
        }

        @Test
        @DisplayName("lowercase 'and' is literal text")
        void lowercaseAndIsLiteral() {
            var s = translateOk("(rock and roll)");
            assertThat(s.hsPattern()).isEqualTo("rock and roll");
        }

        @Test
        @DisplayName("lowercase 'near' is literal text, not the NEAR operator")
        void lowercaseNearIsLiteral() {
            var s = translateOk("(the office near you)");
            assertThat(s.hsPattern()).contains("near");
        }

        @Test
        @DisplayName("Mixed-case 'Or'/'And'/'Not' are literal, not operators")
        void mixedCaseIsLiteral() {
            assertThat(translator.translate("(Or And Not)").isSuccess()).isTrue();
        }
    }

    @Nested
    @DisplayName("Validation — NEAR/FOLLOWEDBY distance must be a single digit 1-9")
    class ProximityDistanceValidation {

        @ParameterizedTest(name = "[{index}] {0}{1} is rejected")
        @CsvSource({
                "NEAR, '{0}'",
                "NEAR, '{-1}'",
                "NEAR, '{abcd}'",
                "NEAR, '{10}'",
                "NEAR, '{0,6}'",
                "FOLLOWEDBY, '{0}'",
                "FOLLOWEDBY, '{-1}'",
                "FOLLOWEDBY, '{abcd}'",
                "FOLLOWEDBY, '{10}'",
                "FOLLOWEDBY, '{0,6}'",
        })
        void invalidDistanceRejected(String keyword, String brace) {
            String term = "(a) " + keyword + brace.replace("'", "") + " (b)";
            assertThat(translator.translate(term).isSuccess()).as(term).isFalse();
        }

        @ParameterizedTest(name = "[{index}] distance {0} is accepted")
        @ValueSource(ints = {1, 2, 3, 4, 5, 6, 7, 8, 9})
        void validSingleDigitDistancesAccepted(int n) {
            assertThat(translator.translate("(a) NEAR{" + n + "} (b)").isSuccess()).isTrue();
            assertThat(translator.translate("(a) FOLLOWEDBY{" + n + "} (b)").isSuccess()).isTrue();
        }

        @Test
        @DisplayName("Whitespace between NEAR and '{' is rejected")
        void whitespaceBeforeBraceRejected_near() {
            assertThat(translateError("(a) NEAR {3} (b)")).contains("whitespace");
        }

        @Test
        @DisplayName("Whitespace between FOLLOWEDBY and '{' is rejected")
        void whitespaceBeforeBraceRejected_followedBy() {
            assertThat(translateError("(a) FOLLOWEDBY {3} (b)")).contains("whitespace");
        }
    }

    @Nested
    @DisplayName("Validation — structural correctness")
    class StructuralValidation {

        @Test
        @DisplayName("Unmatched closing bracket without matching open is rejected")
        void missingClosingParen() {
            assertThat(translator.translate("(fix NEAR{3} (rate)").isSuccess()).isFalse();
        }

        @Test
        @DisplayName("Unmatched opening bracket without matching close is rejected")
        void missingOpeningParen() {
            assertThat(translator.translate("fix NEAR{3} rate)").isSuccess()).isFalse();
        }

        @Test
        @DisplayName("Empty parentheses are rejected")
        void emptyParensRejected() {
            assertThat(translator.translate("()").isSuccess()).isFalse();
        }

        @Test
        @DisplayName("Unclosed quoted phrase is rejected")
        void unclosedQuoteRejected() {
            assertThat(translator.translate("\"unclosed phrase").isSuccess()).isFalse();
        }
    }

    @Nested
    @DisplayName("Validation — meaningful content required")
    class MeaningfulContentValidation {

        @ParameterizedTest(name = "[{index}] ''{0}'' is rejected as meaningless")
        @ValueSource(strings = {"#@$#%$", "!!!", "()", "***", "   "})
        void symbolOnlyContentRejected(String term) {
            assertThat(translator.translate(term).isSuccess()).as(term).isFalse();
        }

        @Test
        @DisplayName("A single letter is meaningful content, even alone")
        void singleLetterIsMeaningful() {
            assertThat(translator.translate("F").isSuccess()).isTrue();
        }

        @Test
        @DisplayName("Non-Latin content (Korean) is meaningful")
        void nonLatinContentIsMeaningful() {
            assertThat(translator.translate("내부자").isSuccess()).isTrue();
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // The five real terms from the bug-report screenshot
    // ══════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Screenshot terms — no crash on any of the five real reported terms")
    class ScreenshotTerms {

        @Test
        @DisplayName("Term 2: never throws (previously crashed with StringIndexOutOfBoundsException)")
        void term2_neverCrashes() {
            String term = "(Scheiße OR Scheisse OR Scheiß OR Scheiss OR Kacke OR Scheißdreck OR Scheissdreck "
                    + "OR dreckige OR scheisse OR verdammte OR verfluchte OR Müll OR Muell OR Dreck OR schlecht "
                    + "OR schlimm OR böse OR boese OR übel OR uebel OR unzureichend) "
                    + "NEAR{5} (Bonus OR Bonuszahlung OR Gehaltszulage OR Comp OR Komp OR Kompensation OR Vergütung)";
            assertThat(translator.translate(term)).isNotNull(); // must not throw
        }

        @Test
        @DisplayName("Term 3: prefix-wildcard German words compile with wildcard correctly expanded")
        void term3_prefixWildcardOnGermanWords() {
            var s = translateOk("(gemobbt OR eingeschüchtert) NEAR{2} (broker OR *händler OR *haendler)");
            assertThat(s.hsPattern()).contains("\\S*h\u00e4ndler").contains("\\S*haendler");
        }

        @Test
        @DisplayName("Term 1: original screenshot term (unwrapped multi-word OR-alternatives) now compiles directly")
        void term1_originalUnwrappedFormNowCompiles() {
            // "zusammen tun", "bereit stellen", etc. are unwrapped 2-word OR-alternatives —
            // previously rejected by the (now-removed) bracket-wrapping requirement.
            String term =
                "((konspirier* OR verschwör* OR zusammentun OR zusammen tun OR zusammengetan OR zusammen getan) "
                + "NEAR{4} (allokier* OR verteil* OR bereitstellen OR bereit stellen OR zuteilen OR zu teilen)) "
                + "NEAR{4} (Löhne OR Lohn OR Gehalt OR benefit* OR Vergütung OR bonus*)";
            assertThat(translator.translate(term)).isNotNull(); // must not throw, must not be rejected for wrapping
            assertThat(translator.translate(term).isSuccess()).isTrue();
        }

        @Test
        @DisplayName("Term 4: original screenshot term (unwrapped OR-alternatives on both sides) now compiles directly")
        void term4_originalUnwrappedFormNowCompiles() {
            var s = translateOk(
                "((nur für dich OR nur fuer dich OR nur für Sie OR nur fuer Sie)) "
                + "AND NOT((für dich OR für Sie OR fuer dich OR fuer Sie) "
                + "FOLLOWEDBY{1} (als OR zum OR zur) FOLLOWEDBY{1} (Hintergrund OR Info OR Update OR Illustration))");
            assertThat(s.excludedOperands()).hasSize(1);
        }

        @Test
        @DisplayName("Term 5: original screenshot term (unwrapped 'EURIBOR FIXING' left operand) now compiles directly")
        void term5_originalUnwrappedFormNowCompiles() {
            var s = translateOk(
                "(fixing NEAR{2} (tenor OR drive OR rig OR want the OR whack)) "
                + "AND NOT((FIXING JISDOR G. TENOR) OR (Tenor Value Date Fixing) "
                + "OR (EURIBOR FIXING NEAR{2} TENOR))");
            assertThat(s.excludedOperands()).hasSize(1);
        }

        @Test
        @DisplayName("Term 4 (previously-required manual correction still also works)")
        void term4_corrected() {
            var s = translateOk(
                "((nur für dich) OR (nur fuer dich)) "
                + "AND NOT(((für dich) OR (fuer dich)) FOLLOWEDBY{1} (als OR zum) FOLLOWEDBY{1} (Hintergrund OR Info))");
            assertThat(s.excludedOperands()).hasSize(1);
        }

        @Test
        @DisplayName("Term 5 (previously-required manual correction still also works)")
        void term5_corrected() {
            var s = translateOk(
                "(fixing NEAR{2} (tenor OR drive OR rig)) "
                + "AND NOT((plain phrase here) OR ((EURIBOR FIXING) NEAR{2} TENOR))");
            assertThat(s.excludedOperands()).hasSize(1);
        }
    }
}
