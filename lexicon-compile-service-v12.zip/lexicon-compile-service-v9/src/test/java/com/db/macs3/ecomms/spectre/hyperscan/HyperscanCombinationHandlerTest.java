package com.db.macs3.ecomms.spectre.hyperscan;

import com.db.macs3.ecomms.spectre.model.CompilationStatus;
import com.db.macs3.ecomms.spectre.model.TermCompilationResult;
import com.gliwka.hyperscan.wrapper.Expression;
import com.gliwka.hyperscan.wrapper.ExpressionFlag;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link HyperscanCombinationHandler} in isolation — testing
 * the expression-building logic directly against hand-built
 * {@link TermCompilationResult} inputs, rather than only indirectly through
 * {@code LexiconCompileBundleServiceTest}'s end-to-end scenarios. This lets
 * every branch (plain, decomposed-only, AND-NOT-only, both, id-allocator
 * behaviour in isolation) be checked precisely without needing a real term
 * description to translate first.
 */
@DisplayName("HyperscanCombinationHandler")
class HyperscanCombinationHandlerTest {

    private HyperscanCombinationHandler handler;

    @BeforeEach
    void setUp() {
        HyperscanCompiler compiler = new HyperscanCompiler();
        compiler.selfTest();
        handler = new HyperscanCombinationHandler(compiler);
    }

    private TermCompilationResult passResult(List<String> translatedPattern, boolean requiresExclusionCheck,
                                              List<String> exclusionPattern) {
        return new TermCompilationResult(
                "t::1", "desc", CompilationStatus.PASS,
                translatedPattern, null, null,
                1, requiresExclusionCheck, exclusionPattern, List.of(),
                null, Instant.now());
    }

    @Nested
    @DisplayName("computeIdOffset")
    class ComputeIdOffset {

        @Test
        @DisplayName("Returns max term number + 1")
        void returnsMaxPlusOne() {
            assertThat(handler.computeIdOffset(List.of(1, 2, 3))).isEqualTo(4);
        }

        @Test
        @DisplayName("Works correctly with sparse, non-contiguous term numbers")
        void worksWithSparseNumbers() {
            assertThat(handler.computeIdOffset(List.of(5, 100, 7))).isEqualTo(101);
        }

        @Test
        @DisplayName("Single term number: offset is that number + 1")
        void singleTermNumber() {
            assertThat(handler.computeIdOffset(List.of(42))).isEqualTo(43);
        }

        @Test
        @DisplayName("Empty collection: offset defaults to 1 (never collides, since no term numbers exist)")
        void emptyCollectionDefaultsToOne() {
            assertThat(handler.computeIdOffset(List.of())).isEqualTo(1);
        }
    }

    @Nested
    @DisplayName("HyperscanIdAllocator")
    class IdAllocatorBehaviour {

        @Test
        @DisplayName("Hands out strictly sequential ids starting from the given offset")
        void sequentialFromOffset() {
            var allocator = new HyperscanCombinationHandler.HyperscanIdAllocator(10);
            assertThat(allocator.allocate()).isEqualTo(10);
            assertThat(allocator.allocate()).isEqualTo(11);
            assertThat(allocator.allocate()).isEqualTo(12);
        }

        @Test
        @DisplayName("Two independently-constructed allocators do not share state")
        void independentAllocators() {
            var a = new HyperscanCombinationHandler.HyperscanIdAllocator(5);
            var b = new HyperscanCombinationHandler.HyperscanIdAllocator(5);
            assertThat(a.allocate()).isEqualTo(5);
            assertThat(a.allocate()).isEqualTo(6);
            assertThat(b.allocate()).isEqualTo(5); // unaffected by a's allocations
        }
    }

    @Nested
    @DisplayName("addExpressions — plain term (no combination needed)")
    class PlainTerm {

        @Test
        @DisplayName("A single, non-decomposed, non-AND-NOT pattern produces exactly one expression at id=termNumber")
        void producesOneExpressionAtTermNumber() {
            var result = passResult(List.of("insider"), false, null);
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 7, new HyperscanCombinationHandler.HyperscanIdAllocator(8), out);

            assertThat(out).hasSize(1);
            assertThat(out.get(0).getId()).isEqualTo(7);
            assertThat(out.get(0).getExpression()).isEqualTo("insider");
        }

        @Test
        @DisplayName("A plain term's expression is NOT flagged QUIET — it must report directly")
        void plainTermNotQuiet() {
            var result = passResult(List.of("insider"), false, null);
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 1, new HyperscanCombinationHandler.HyperscanIdAllocator(2), out);

            assertThat(out.get(0).getFlags().contains(ExpressionFlag.QUIET)).isFalse();
        }

        @Test
        @DisplayName("A plain term's expression never carries the COMBINATION flag")
        void plainTermNeverCombination() {
            var result = passResult(List.of("insider"), false, null);
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 1, new HyperscanCombinationHandler.HyperscanIdAllocator(2), out);

            assertThat(out.get(0).getFlags().contains(ExpressionFlag.COMBINATION)).isFalse();
        }
    }

    @Nested
    @DisplayName("addExpressions — decomposed term, no AND NOT")
    class DecomposedNoAndNot {

        @Test
        @DisplayName("N leaves + 1 combination = N+1 expressions total; combination at id=termNumber")
        void producesLeavesPlusOneCombination() {
            var result = passResult(List.of("leafA", "leafB", "leafC"), false, null);
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 9, new HyperscanCombinationHandler.HyperscanIdAllocator(10), out);

            assertThat(out).hasSize(4); // 3 leaves + 1 combination
            long combinationCount = out.stream().filter(e -> e.getId() == 9).count();
            assertThat(combinationCount).isEqualTo(1);
        }

        @Test
        @DisplayName("Every leaf is QUIET and uses an allocated id, never the term number")
        void leavesAreQuietAndAllocated() {
            var result = passResult(List.of("leafA", "leafB"), false, null);
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 3, new HyperscanCombinationHandler.HyperscanIdAllocator(4), out);

            List<Expression> leaves = out.stream().filter(e -> e.getId() != 3).toList();
            assertThat(leaves).hasSize(2);
            assertThat(leaves).allMatch(e -> e.getFlags().contains(ExpressionFlag.QUIET));
            assertThat(leaves).allMatch(e -> e.getId() != 3);
        }

        @Test
        @DisplayName("Combination formula ANDs every leaf id together")
        void combinationFormulaAndsLeafIds() {
            var result = passResult(List.of("leafA", "leafB", "leafC"), false, null);
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 1, new HyperscanCombinationHandler.HyperscanIdAllocator(2), out);

            Expression combo = out.stream().filter(e -> e.getId() == 1).findFirst().orElseThrow();
            // ids 2, 3, 4 allocated in order for the 3 leaves
            assertThat(combo.getExpression()).isEqualTo("(2&3&4)");
        }
    }

    @Nested
    @DisplayName("addExpressions — AND NOT, neither side decomposed")
    class SimpleAndNot {

        @Test
        @DisplayName("Exactly 3 expressions: required QUIET + excluded QUIET + combination")
        void producesThreeExpressions() {
            var result = passResult(List.of("required"), true, List.of("excluded"));
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 5, new HyperscanCombinationHandler.HyperscanIdAllocator(6), out);

            assertThat(out).hasSize(3);
        }

        @Test
        @DisplayName("Combination formula is (requiredId&!excludedId)")
        void combinationFormulaShape() {
            var result = passResult(List.of("required"), true, List.of("excluded"));
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 1, new HyperscanCombinationHandler.HyperscanIdAllocator(2), out);

            Expression combo = out.stream().filter(e -> e.getId() == 1).findFirst().orElseThrow();
            assertThat(combo.getExpression()).isEqualTo("(2&!3)");
        }
    }

    @Nested
    @DisplayName("addExpressions — AND NOT with decomposed excluded side (De Morgan's law)")
    class DecomposedExcludedSide {

        @Test
        @DisplayName("Combination formula uses OR of negated excluded leaf ids, not AND of negations")
        void usesOrOfNegations() {
            var result = passResult(List.of("required"), true, List.of("exclA", "exclB", "exclC"));
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 1, new HyperscanCombinationHandler.HyperscanIdAllocator(2), out);

            Expression combo = out.stream().filter(e -> e.getId() == 1).findFirst().orElseThrow();
            // required=2; exclA=3, exclB=4, exclC=5
            assertThat(combo.getExpression()).isEqualTo("(2&(!3|!4|!5))");
        }

        @Test
        @DisplayName("Total expression count: 1 required + 3 excluded leaves + 1 combination = 5")
        void correctTotalCount() {
            var result = passResult(List.of("required"), true, List.of("exclA", "exclB", "exclC"));
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 1, new HyperscanCombinationHandler.HyperscanIdAllocator(2), out);

            assertThat(out).hasSize(5);
        }
    }

    @Nested
    @DisplayName("Flag constraint: a combination expression's flags are exactly {COMBINATION}")
    class CombinationFlagConstraint {

        @Test
        @DisplayName("Never mixes CASELESS/UTF8/UCP/DOTALL/SOM_LEFTMOST into a combination expression's own flags")
        void combinationFlagsNeverMixed() {
            var result = passResult(List.of("required"), true, List.of("excluded"));
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 1, new HyperscanCombinationHandler.HyperscanIdAllocator(2), out);

            Expression combo = out.stream().filter(e -> e.getId() == 1).findFirst().orElseThrow();
            assertThat(combo.getFlags()).hasSize(1);
            assertThat(combo.getFlags().contains(ExpressionFlag.COMBINATION)).isTrue();
        }

        @Test
        @DisplayName("QUIET sub-expressions NEVER carry SOM_LEFTMOST — the exact bug a real Hyperscan " +
                     "compile error confirmed (\"HS_FLAG_QUIET is not supported in combination with " +
                     "HS_FLAG_SOM_LEFTMOST\"), now structurally impossible rather than caller-controlled")
        void quietSubExpressionsNeverCarrySomLeftmost() {
            var result = passResult(List.of("required"), true, List.of("excluded"));
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 1, new HyperscanCombinationHandler.HyperscanIdAllocator(2), out);

            assertThat(out).hasSize(3);
            List<Expression> quietExpressions = out.stream()
                    .filter(e -> e.getFlags().contains(ExpressionFlag.QUIET)).toList();
            assertThat(quietExpressions).hasSize(2); // required + excluded, both QUIET
            assertThat(quietExpressions.stream()
                    .noneMatch(e -> e.getFlags().contains(ExpressionFlag.SOM_LEFTMOST)))
                    .isTrue();
        }

        @Test
        @DisplayName("A plain (non-combination) term's single expression DOES carry SOM_LEFTMOST — " +
                     "safe there since it is never QUIET")
        void plainTermCarriesSomLeftmost() {
            var result = passResult(List.of("insider"), false, null);
            List<Expression> out = new ArrayList<>();
            handler.addExpressions(result, 1, new HyperscanCombinationHandler.HyperscanIdAllocator(2), out);

            assertThat(out).hasSize(1);
            assertThat(out.get(0).getFlags().contains(ExpressionFlag.SOM_LEFTMOST)).isTrue();
        }
    }
}
