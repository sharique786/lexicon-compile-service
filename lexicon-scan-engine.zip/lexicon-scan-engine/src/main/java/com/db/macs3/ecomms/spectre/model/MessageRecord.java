package com.db.macs3.ecomms.spectre.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Represents a single communication message loaded from AVRO files on GCS.
 *
 * <p>AVRO schema fields mapped:
 * <ul>
 *   <li>{@code message_id}         → {@link #messageId}</li>
 *   <li>{@code source_type}        → {@link #sourceType} ("chat" | "email")</li>
 *   <li>{@code run_date}           → {@link #runDate}</li>
 *   <li>{@code content.raw_text}   → {@link #contentRawText}</li>
 *   <li>{@code attachment[*].raw_text} → {@link #attachmentTexts}
 *       (one entry per attachment, preserving order)</li>
 * </ul>
 *
 * <p>Subject, clean_text, and attachment metadata (content_type, encoding) are
 * not scanned and are not included here, to minimise executor memory usage.
 *
 * <p>The Scan Engine scans:
 * <ol>
 *   <li>The message body: {@link #contentRawText}</li>
 *   <li>Each attachment independently: {@code attachmentTexts.get(i)} → "attachment-{i}"</li>
 * </ol>
 */
public class MessageRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /** Unique message identifier — matches BQ language-feature-decision.message_id. */
    private String messageId;

    /** "chat" or "email" — influences downstream scoring, carried through for output. */
    private String sourceType;

    /** run_date in yyyy-MM-dd format — used for BQ output partitioning. */
    private String runDate;

    /**
     * Raw body text of the message (from {@code content.raw_text}).
     * May be null or blank for system-generated messages; the engine skips
     * scanning of blank text but still records the message in the audit table.
     */
    private String contentRawText;

    /**
     * Raw text of each attachment in the order they appear in the AVRO record.
     * Index {@code i} maps to "attachment-{i}" in the hit_details JSON output.
     * Empty list when the message has no attachments.
     */
    private List<String> attachmentTexts;

    // ── No-arg constructor (required for Spark Dataset Encoder) ───────────────
    public MessageRecord() {
        this.attachmentTexts = new ArrayList<>();
    }

    // ── Factory ───────────────────────────────────────────────────────────────

    public static MessageRecord of(String messageId, String sourceType, String runDate,
                                    String contentRawText, List<String> attachmentTexts) {
        MessageRecord rec = new MessageRecord();
        rec.messageId        = messageId;
        rec.sourceType       = sourceType;
        rec.runDate          = runDate;
        rec.contentRawText   = contentRawText;
        rec.attachmentTexts  = attachmentTexts != null ? new ArrayList<>(attachmentTexts)
                                                       : new ArrayList<>();
        return rec;
    }

    // ── Convenience ───────────────────────────────────────────────────────────

    /** @return true when the message body text is non-null and non-blank. */
    public boolean hasContent() {
        return contentRawText != null && !contentRawText.isBlank();
    }

    /** @return number of attachments (may be zero). */
    public int attachmentCount() {
        return attachmentTexts == null ? 0 : attachmentTexts.size();
    }

    /** @return an unmodifiable view of the attachment texts list. */
    public List<String> getAttachmentTextsView() {
        return Collections.unmodifiableList(
                attachmentTexts != null ? attachmentTexts : Collections.emptyList());
    }

    // ── Getters and setters ───────────────────────────────────────────────────

    public String getMessageId()                { return messageId; }
    public void setMessageId(String v)          { this.messageId = v; }

    public String getSourceType()               { return sourceType; }
    public void setSourceType(String v)         { this.sourceType = v; }

    public String getRunDate()                  { return runDate; }
    public void setRunDate(String v)            { this.runDate = v; }

    public String getContentRawText()           { return contentRawText; }
    public void setContentRawText(String v)     { this.contentRawText = v; }

    public List<String> getAttachmentTexts()    { return attachmentTexts; }
    public void setAttachmentTexts(List<String> v) {
        this.attachmentTexts = v != null ? v : new ArrayList<>();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        return Objects.equals(messageId, ((MessageRecord) o).messageId);
    }

    @Override
    public int hashCode() { return Objects.hash(messageId); }

    @Override
    public String toString() {
        return "MessageRecord{messageId='" + messageId + "', sourceType='" + sourceType +
               "', attachments=" + attachmentCount() + '}';
    }
}
