package com.db.macs3.ecomms.spectre.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.Instant;
import java.util.List;

/**
 * Shared domain models for the Lexicon Scanner Service.
 *
 * <h2>Request models</h2>
 * <ul>
 *   <li>{@link ScanApiRequest} — JSON body for the REST API</li>
 * </ul>
 *
 * <h2>Lexicon Compile Service wire models</h2>
 * <ul>
 *   <li>{@link CompileServiceRequest} / {@link CompileServiceRequest.TermInput}</li>
 *   <li>{@link CompileServiceResponse} / {@link CompileServiceResponse.TermResult}</li>
 * </ul>
 *
 * <h2>Internal pipeline models</h2>
 * <ul>
 *   <li>{@link CompiledTerm}   — a term that compiled successfully, ready for Hyperscan</li>
 *   <li>{@link RawMatch}       — raw Hyperscan match (byte-offset based)</li>
 *   <li>{@link MatchHighlight} — a single match region mapped to char indices</li>
 *   <li>{@link TermScanResult} — aggregated result for one lexicon term</li>
 *   <li>{@link ScanResponse}   — the full response returned to the UI / caller</li>
 * </ul>
 */
public final class Models {

    private Models() {}

    // ══════════════════════════════════════════════════════════════════════════
    // API Request
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * JSON body accepted by {@code POST /api/scan/json}.
     * Multipart form data uses {@code POST /api/scan} with individual fields.
     *
     * @param inputMode   how lexicon terms are supplied ({@code TERMS} or {@code CSV})
     * @param termType    how the term(s) should be interpreted ({@code NATURAL_LANGUAGE} or
     *                    {@code REGEX}); defaults to {@code NATURAL_LANGUAGE} when blank —
     *                    see {@link TermType#fromString(String)}
     * @param messageMode how the message is supplied ({@code TEXT} or {@code FILE})
     * @param terms       newline-separated term descriptions (when inputMode=TERMS)
     * @param csvContent  raw CSV text content (when inputMode=CSV, for JSON requests)
     * @param messageText raw message text (when messageMode=TEXT)
     * @param ruleName    optional rule / session name for the compile request
     * @param disclaimerInputMode how disclaimer text is supplied ({@code NONE}, {@code TEXT}, or {@code CSV});
     *                            defaults to {@code NONE} — see {@link com.db.macs3.ecomms.spectre.model.DisclaimerSource}
     * @param disclaimers          newline-separated disclaimer texts (when disclaimerInputMode=TEXT)
     * @param disclaimerCsvContent raw CSV text content for disclaimers (when disclaimerInputMode=CSV, JSON callers only)
     */
    public record ScanApiRequest(
            String inputMode,
            String termType,
            String messageMode,
            String terms,
            String csvContent,
            String messageText,
            String ruleName,
            String disclaimerInputMode,
            String disclaimers,
            String disclaimerCsvContent
    ) {}

    // ══════════════════════════════════════════════════════════════════════════
    // Lexicon Compile Service wire models
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Request body sent to the Lexicon Compile Service.
     *
     * <p>Matches the Compile Service's current single request type,
     * {@code TypedCompileRequest} — {@code request_id} and {@code termType}
     * are both required fields now (previously this client sent neither);
     * {@code riskDriverName} per term has been removed entirely, since
     * {@code TypedCompileRequest.TermInput} no longer carries it.
     *
     * @param requestId       caller-generated UUID, echoed back for end-to-end tracing —
     *                        REQUIRED by the Compile Service (rejects a blank/missing value)
     * @param lexiconRuleName logical name for this compilation session
     * @param termType        always {@code "Natural Language"} for this client — the only
     *                        caller of this record ({@link com.db.macs3.ecomms.spectre.service.LexiconScanOrchestrator})
     *                        exclusively uses it for Natural Language terms; {@code TermType.REGEX}
     *                        terms bypass the Compile Service entirely and are compiled directly
     * @param terms           list of term inputs to compile
     */
    public record CompileServiceRequest(
            String requestId,
            String lexiconRuleName,
            String termType,
            List<TermInput> terms
    ) {

        /** The only {@code termType} value this client ever sends. */
        public static final String TERM_TYPE_NATURAL_LANGUAGE = "Natural Language";

        /**
         * One term to compile.
         *
         * @param termId          unique identifier, e.g. {@code scanner::1}
         * @param termDescription the raw operator expression, e.g. {@code insider AND trading}
         */
        public record TermInput(
                String termId,
                String termDescription
        ) {}
    }

    /**
     * Full response from the Lexicon Compile Service.
     *
     * <p>Annotated {@code ignoreUnknown = true} because the Compile Service's
     * response has grown new fields over time (e.g. {@code hyperscanVersion},
     * {@code hyperscanExpressionId} per term) — this client only needs the
     * fields declared below and must not break when the upstream service adds more.
     *
     * @param requestId       echoed from the request — see {@link CompileServiceRequest}
     * @param lexiconRuleName rule name echoed from the request
     * @param totalTerms      total number of terms submitted
     * @param passCount       number that compiled successfully
     * @param failedCount     number that failed compilation or translation
     * @param hasFailures     convenience flag — true when failedCount &gt; 0
     * @param results         per-term compilation outcomes
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CompileServiceResponse(
            String requestId,
            String lexiconRuleName,
            int totalTerms,
            int passCount,
            int failedCount,
            boolean hasFailures,
            List<TermResult> results
    ) {

        /**
         * Compilation outcome for one term.
         *
         * <p><b>{@code translatedPattern} and {@code exclusionPattern} are
         * lists, not single strings</b> — matching the Compile Service's
         * current {@code TermCompilationResult} shape exactly. One entry for
         * a term simple enough to compile as a single pattern; several when
         * the Compile Service had to decompose it (see
         * {@link com.db.macs3.ecomms.spectre.service.HyperscanScanService}
         * class Javadoc for how this client compiles a term with more than
         * one required-side entry, or any exclusion pattern at all, as a
         * native Hyperscan QUIET/COMBINATION structure rather than a single
         * plain expression).
         *
         * <p>This is the second time this client's field types have drifted
         * out of sync with an upstream rename/reshape without a compile
         * error catching it — the first time
         * ({@code hsFlags}/{@code requiresAndPostFilter} → {@code hyperscanFlags}/
         * {@code requiresExclusionCheck}) silently deserialized to
         * {@code 0}/{@code false} because {@code @JsonIgnoreProperties(ignoreUnknown = true)}
         * only protects against the compile service ADDING fields, never
         * against a field this client expects being renamed or reshaped.
         * A {@code String} → {@code List<String>} type change is a harder
         * failure mode than a silent default, at least: Jackson genuinely
         * cannot coerce a JSON array into a {@code String} field, so this
         * mismatch would have failed loudly (a deserialization exception on
         * every single compile call) rather than silently, unlike the
         * rename before it.
         *
         * @param termId                 echoed from the request
         * @param termDescription        echoed from the request
         * @param compilationStatus      {@code "PASS"} or {@code "FAILED"}
         * @param translatedPattern      the REQUIRED side's Hyperscan-valid pattern(s);
         *                               null when FAILED, otherwise always non-empty
         * @param hyperscanFlags         bitmask: 1=CASELESS, 32=UTF8, 64=UCP
         * @param requiresExclusionCheck true for AND NOT terms — {@code exclusionPattern}
         *                               must also be checked; see class Javadoc
         * @param exclusionPattern       independently Hyperscan-valid pattern(s) that must NOT
         *                               match the same message; non-null iff requiresExclusionCheck
         * @param errorLog               Hyperscan compile error (null when PASS)
         * @param translationError       translator error (null when PASS)
         * @param compiledAt             timestamp of compilation
         */
        @JsonIgnoreProperties(ignoreUnknown = true)
        public record TermResult(
                String termId,
                String termDescription,
                String compilationStatus,
                List<String> translatedPattern,
                int hyperscanFlags,
                boolean requiresExclusionCheck,
                List<String> exclusionPattern,
                String errorLog,
                String translationError,
                Instant compiledAt
        ) {
            /** Returns true when this term compiled successfully and has a usable pattern. */
            public boolean isPass() {
                return "PASS".equalsIgnoreCase(compilationStatus);
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Internal pipeline models
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * The result of {@link com.db.macs3.ecomms.spectre.service.HtmlStrippingService#strip}:
     * the original text, the HTML-stripped/whitespace-collapsed text that
     * Hyperscan actually scans, and the index mapping between them.
     *
     * <p>{@code strippedToOriginalIndex[j]} gives the character index in
     * {@link #originalText} that produced the character at index {@code j}
     * in {@link #strippedText}. See {@link #mapSpanToOriginal} for converting
     * a matched span from stripped-text coordinates to original-text coordinates.
     *
     * @param originalText            the message exactly as supplied by the user
     * @param strippedText            HTML-stripped, whitespace-collapsed text (what Hyperscan scans)
     * @param strippedToOriginalIndex per-character offset map, length == strippedText.length()
     */
    public record StrippedMessage(
            String originalText,
            String strippedText,
            int[] strippedToOriginalIndex
    ) {

        /**
         * Maps a {@code [strippedStart, strippedEnd)} span (as reported by
         * Hyperscan against {@link #strippedText}) to the corresponding
         * {@code [originalStart, originalEnd)} span in {@link #originalText}.
         *
         * <p>Convention: {@code originalEnd} is exclusive — one past the
         * original index of the span's last stripped character — matching
         * ordinary Java substring semantics.
         *
         * @param strippedStart start index into {@link #strippedText}, inclusive
         * @param strippedEnd   end index into {@link #strippedText}, exclusive
         * @return a two-element array {@code [originalStart, originalEnd]}
         */
        public int[] mapSpanToOriginal(int strippedStart, int strippedEnd) {
            if (strippedToOriginalIndex.length == 0 || strippedStart >= strippedEnd) {
                return new int[]{0, 0};
            }
            int safeStart = Math.max(0, Math.min(strippedStart, strippedToOriginalIndex.length - 1));
            int safeEnd   = Math.max(safeStart + 1, Math.min(strippedEnd, strippedToOriginalIndex.length));
            int originalStart = strippedToOriginalIndex[safeStart];
            int originalEnd   = strippedToOriginalIndex[safeEnd - 1] + 1;
            return new int[]{originalStart, originalEnd};
        }

        /**
         * Records auto-generate {@code equals()}/{@code hashCode()} using
         * {@link Object#equals} per component — for an {@code int[]} field that
         * means REFERENCE equality, which is almost never what's wanted (two
         * separately-computed but content-identical mappings would compare
         * unequal). Overridden here to use {@link java.util.Arrays} content
         * comparison instead, so {@code StrippedMessage} behaves the way every
         * caller (and every test) reasonably expects it to.
         */
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof StrippedMessage that)) return false;
            return java.util.Objects.equals(originalText, that.originalText)
                    && java.util.Objects.equals(strippedText, that.strippedText)
                    && java.util.Arrays.equals(strippedToOriginalIndex, that.strippedToOriginalIndex);
        }

        @Override
        public int hashCode() {
            int result = java.util.Objects.hash(originalText, strippedText);
            result = 31 * result + java.util.Arrays.hashCode(strippedToOriginalIndex);
            return result;
        }

        @Override
        public String toString() {
            return "StrippedMessage{originalLen=" + (originalText != null ? originalText.length() : 0)
                    + ", strippedLen=" + strippedText.length() + "}";
        }
    }

    /**
     * Result of validating one raw regex pattern directly against Hyperscan
     * (used for {@code TermType.REGEX} terms, which skip the Compile Service
     * entirely — see {@link com.db.macs3.ecomms.spectre.service.HyperscanScanService#validatePattern}).
     *
     * @param pass         true when Hyperscan accepted the pattern
     * @param errorMessage Hyperscan's compile error text; null when {@code pass} is true
     */
    public record PatternValidationResult(
            boolean pass,
            String errorMessage
    ) {}

    /**
     * A lexicon term that passed Hyperscan compilation and is ready to scan.
     *
     * <h2>Compiled as one plain expression, or as a QUIET/COMBINATION structure</h2>
     * <p>Mirrors the Lexicon Compile Service's own {@code /compile/bundle}
     * design ({@code HyperscanCombinationHandler}): a term whose
     * {@link #requiredPatterns} has exactly one entry and
     * {@link #requiresExclusionCheck} is false compiles as a single plain
     * Hyperscan expression at {@link #expressionIndex}. Any other term
     * (decomposed, and/or AND NOT) needs a native Hyperscan LOGICAL
     * COMBINATION — every pattern in both lists compiles as a QUIET
     * sub-expression, and {@link #expressionIndex} becomes the id of a
     * {@code COMBINATION} formula expression referencing them. Either way,
     * {@link #expressionIndex} is always this term's own single reportable
     * id — see {@link #needsCombination()} and
     * {@link com.db.macs3.ecomms.spectre.service.HyperscanScanService}
     * class Javadoc for how expressions are actually built from this.
     *
     * <p>This replaces an earlier design where AND NOT was enforced by
     * compiling the exclusion pattern into a SEPARATE, parallel Hyperscan
     * database and merging both scans' results in application code — see
     * {@link com.db.macs3.ecomms.spectre.service.LexiconScanOrchestrator}
     * class Javadoc for why that approach, while functionally correct, is
     * no longer needed once Hyperscan resolves the boolean condition
     * natively during a single scan pass.
     *
     * @param termId                 unique identifier
     * @param termDescription        original lexicon expression
     * @param requiredPatterns       the required side's Hyperscan-valid pattern(s) — one
     *                               entry normally, several when the Compile Service decomposed it
     * @param exclusionPatterns      the excluded side's Hyperscan-valid pattern(s) for an AND NOT
     *                               term; null when {@link #requiresExclusionCheck} is false
     * @param hsFlags                bitmask of Hyperscan expression flags
     * @param requiresExclusionCheck true when the term uses AND NOT semantics
     * @param expressionIndex        this term's own reportable Hyperscan expression id —
     *                               always exactly one id per term, whatever it compiled as
     */
    public record CompiledTerm(
            String termId,
            String termDescription,
            List<String> requiredPatterns,
            List<String> exclusionPatterns,
            int hsFlags,
            boolean requiresExclusionCheck,
            int expressionIndex
    ) {
        /**
         * @return true when this term needs a native Hyperscan QUIET/COMBINATION
         *         structure rather than a single plain expression — i.e. it was
         *         decomposed, uses AND NOT, or both.
         */
        public boolean needsCombination() {
            return requiresExclusionCheck || requiredPatterns.size() > 1;
        }
    }

    /**
     * A raw match returned by Hyperscan, using byte offsets into the UTF-8 input.
     *
     * <h2>{@code fromCombination}: when position/text cannot be trusted</h2>
     * <p>A COMBINATION expression's own match event has no genuine
     * contiguous text span — it is a logical boolean event over
     * (potentially scattered) QUIET sub-expression matches, and Hyperscan
     * has nothing meaningful to report as its "matched string" or position.
     * {@code fromCombination=true} flags exactly this case, telling
     * {@code MatchHighlightService} to run Stage 2 Java-regex resolution
     * against the owning {@link CompiledTerm}'s own leaf patterns instead of
     * trusting {@code startByteOffset}/{@code endByteOffset} — see that
     * class's Javadoc.
     *
     * @param startByteOffset start of the matched region (bytes into UTF-8 message);
     *                        not meaningful when {@code fromCombination} is true
     * @param endByteOffset   end of the matched region (exclusive, bytes);
     *                        not meaningful when {@code fromCombination} is true
     * @param expressionIndex index of the matching expression in the compiled database —
     *                        always a {@code CompiledTerm.expressionIndex()}, never an
     *                        auxiliary QUIET sub-expression id (those are never reported
     *                        as matches at all — Hyperscan's own callback mechanism
     *                        filters them out)
     * @param fromCombination true when this match came from a COMBINATION expression —
     *                        see class Javadoc above
     */
    public record RawMatch(
            long startByteOffset,
            long endByteOffset,
            int expressionIndex,
            boolean fromCombination
    ) {}

    /**
     * A single match region mapped to Java {@code String} character indices.
     *
     * @param startCharIndex  start of the match in the message (Java char index)
     * @param endCharIndex    end of the match in the message (exclusive, Java char index)
     * @param matchedText     the extracted substring from the message
     * @param inDisclaimer    true when this match falls entirely within a detected
     *                        disclaimer region — see {@link DisclaimerSpan} and
     *                        {@link com.db.macs3.ecomms.spectre.service.DisclaimerDetectionService}.
     *                        A disclaimer match is still reported (and shown on the UI
     *                        with a "not an alert — found in disclaimer" note) but does
     *                        NOT count toward {@link TermScanResult#hasMatches()} /
     *                        alerting, matching the requirement that boilerplate
     *                        disclaimer text (e.g. the word "confidential" appearing
     *                        in a standard footer) must not trigger a false alert.
     */
    public record MatchHighlight(
            int startCharIndex,
            int endCharIndex,
            String matchedText,
            boolean inDisclaimer
    ) {
        /** @return true when this match should count toward alerting (i.e. NOT disclaimer-only). */
        public boolean countsTowardAlert() {
            return !inDisclaimer;
        }
    }

    /**
     * One occurrence of a user-supplied disclaimer text found within a message,
     * in ORIGINAL-text character coordinates (same convention as {@link MatchHighlight}).
     *
     * @param startCharIndex start of the disclaimer occurrence (inclusive)
     * @param endCharIndex   end of the disclaimer occurrence (exclusive)
     * @param disclaimerText the disclaimer text that was matched (as supplied by the user)
     */
    public record DisclaimerSpan(
            int startCharIndex,
            int endCharIndex,
            String disclaimerText
    ) {}

    /**
     * All scan results aggregated for one lexicon term, against ONE message.
     *
     * @param termId                 unique term identifier
     * @param termDescription        original lexicon expression
     * @param translatedPattern      the REQUIRED side's Hyperscan-valid pattern(s) used for
     *                               scanning — one entry normally, several when decomposed;
     *                               matches the Compile Service's own list shape (see
     *                               {@link CompileServiceResponse.TermResult})
     * @param compilationStatus      {@code "PASS"}, {@code "FAILED"}, or {@code "SKIPPED"}
     * @param requiresExclusionCheck true for AND NOT terms — an exclusion pattern
     *                               was independently scanned for; see {@code excludedByAndNot}
     * @param matches                match regions found for the REQUIRED pattern in this
     *                               message (each individually flagged {@link MatchHighlight#inDisclaimer()})
     * @param hasMatches             true when at least one ALERT-worthy match exists —
     *                               false when there are no required-pattern matches, when every
     *                               match is disclaimer-only, OR when {@code excludedByAndNot} is true
     *                               (the exclusion pattern negates the whole term regardless of matches)
     * @param hasDisclaimerOnlyMatches true when every match found for this term/message fell
     *                               within a disclaimer — informational: nothing to alert on,
     *                               but not silently invisible either
     * @param excludedByAndNot       true when this term's exclusion pattern (see
     *                               {@code requiresExclusionCheck}) was found ANYWHERE in this
     *                               message — required-pattern matches are still listed in
     *                               {@code matches} for visibility, but never count toward alerting
     * @param compilationError       error message when compilationStatus is FAILED
     * @param exclusionNote          informational note explaining an AND NOT exclusion when
     *                               {@code excludedByAndNot} is true
     */
    public record TermScanResult(
            String termId,
            String termDescription,
            List<String> translatedPattern,
            String compilationStatus,
            boolean requiresExclusionCheck,
            List<MatchHighlight> matches,
            boolean hasMatches,
            boolean hasDisclaimerOnlyMatches,
            boolean excludedByAndNot,
            String compilationError,
            String exclusionNote
    ) {}

    /**
     * Scan results for exactly one message — one message may be scanned
     * against many terms; this bundles all of them together with the
     * message's own text/highlighting.
     *
     * @param messageId              identifies which message this is — the uploaded
     *                               file's name, or {@code "Pasted Message"} /
     *                               {@code "Message N"} for text-area input
     * @param plainMessage           original message text (for the UI text panel)
     * @param htmlHighlightedMessage HTML with {@code <mark>} tags for matched regions —
     *                               disclaimer-only matches get a visually distinct
     *                               {@code lex-match-disclaimer} CSS class instead of
     *                               {@code lex-match}, so the UI can render them muted
     *                               with a "not an alert" note rather than as a live alert
     * @param disclaimerSpans        disclaimer occurrences detected in this message
     * @param termResults            per-term scan results for this message
     * @param matchedTerms           number of terms with at least one ALERT-worthy match
     *                               (i.e. {@link TermScanResult#hasMatches()} true) in this message
     * @param hasMatches             true when any term has an alert-worthy match in this message
     */
    public record MessageScanResult(
            String messageId,
            String plainMessage,
            String htmlHighlightedMessage,
            List<DisclaimerSpan> disclaimerSpans,
            List<TermScanResult> termResults,
            int matchedTerms,
            boolean hasMatches
    ) {}

    /**
     * Complete scan response returned to the UI and REST callers — covers
     * one or more messages scanned against the same term set.
     *
     * @param scanId               UUID of this scan session
     * @param scanDurationMs       wall-clock time for the full pipeline
     * @param termType             {@code "Natural Language"} or {@code "Regex"} — the request
     *                             type applied to every term in this scan (see {@link TermType})
     * @param totalMessages        number of messages scanned
     * @param totalTerms           number of terms submitted
     * @param totalDisclaimers     number of disclaimer texts supplied (0 if none)
     * @param matchedTerms         number of (message, term) pairs with at least one alert-worthy match,
     *                             summed across all messages
     * @param failedTerms          number of terms that failed compilation (term-level, not per-message)
     * @param hasMatches           true when any message has an alert-worthy match
     * @param messageResults       one entry per scanned message
     * @param warnings             non-fatal informational messages
     * @param status               {@code "SUCCESS"} or {@code "ERROR"}
     * @param errorMessage         populated only when status is {@code "ERROR"}
     */
    public record ScanResponse(
            String scanId,
            long scanDurationMs,
            String termType,
            int totalMessages,
            int totalTerms,
            int totalDisclaimers,
            int matchedTerms,
            int failedTerms,
            boolean hasMatches,
            List<MessageScanResult> messageResults,
            List<String> warnings,
            String status,
            String errorMessage
    ) {

        /** Convenience factory for a successful scan response. */
        public static ScanResponse success(
                String scanId, long durationMs, String termType,
                int totalTerms, int totalDisclaimers, int failedTerms,
                List<MessageScanResult> messageResults, List<String> warnings) {
            int matchedTerms = messageResults.stream().mapToInt(MessageScanResult::matchedTerms).sum();
            boolean hasMatches = messageResults.stream().anyMatch(MessageScanResult::hasMatches);
            return new ScanResponse(
                    scanId, durationMs, termType,
                    messageResults.size(), totalTerms, totalDisclaimers,
                    matchedTerms, failedTerms, hasMatches,
                    messageResults, warnings, "SUCCESS", null
            );
        }

        /** Convenience factory for an error response. */
        public static ScanResponse error(String scanId, String message) {
            return new ScanResponse(
                    scanId, 0, null, 0, 0, 0, 0, 0, false,
                    List.of(), List.of(), "ERROR", message
            );
        }
    }
}
