package com.db.macs3.ecomms.spectre.scanengine.decision;

import com.db.macs3.ecomms.spectre.scanengine.constants.BqColumns;
import com.db.macs3.ecomms.spectre.scanengine.hyperscan.HyperscanDatabaseLoader;
import com.db.macs3.ecomms.spectre.scanengine.hyperscan.HyperscanScanService;
import com.db.macs3.ecomms.spectre.scanengine.hyperscan.TermIdBuilder;
import com.db.macs3.ecomms.spectre.scanengine.model.feature.FeatureDefinition;
import com.db.macs3.ecomms.spectre.scanengine.model.match.MatchArea;
import com.db.macs3.ecomms.spectre.scanengine.model.match.TermMatchResult;
import com.db.macs3.ecomms.spectre.scanengine.model.message.MessageAttachment;
import com.db.macs3.ecomms.spectre.scanengine.model.message.ScanMessage;
import com.db.macs3.ecomms.spectre.scanengine.model.view.FeatureDecisionRow;
import com.gliwka.hyperscan.wrapper.Database;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Scans one {@link FeatureDecisionRow} (one lexicon feature applied to one
 * message) against whatever areas its {@code feature_definition.body.scope}
 * covers, using a per-partition {@link HyperscanDatabaseLoader} for the
 * actual {@code .hdb} database — this is the
 * {@link DecisionTreeEvaluator.FeatureRowScanner} implementation
 * {@code DecisionTreeEvaluator} needs, wired to the real Hyperscan/GCS
 * layer rather than a test double.
 *
 * <h2>Designed for reuse inside one {@code mapPartitions} call</h2>
 * <p>One instance is constructed per Spark partition (sharing that
 * partition's single {@link HyperscanDatabaseLoader}, and therefore its
 * cache — see that class's own Javadoc for why this matters for memory), and
 * its {@link #processMessage} is called once per message within that
 * partition. Nothing here performs a Spark action (no {@code collect}, no
 * driver-side aggregation) — every call operates on exactly one message and
 * returns plain, serialisable result objects, safe to run entirely on an
 * executor.
 *
 * <h2>Known gap: term_regex_pattern is not populated</h2>
 * <p>{@code lexicon-hit-summary.term_dtls.term_regex_pattern} is left null.
 * A loaded {@code .hdb} binary carries compiled Hyperscan automata, not the
 * original PCRE pattern text — recovering it requires the accompanying JSON
 * the Compile Service's {@code /compile/bundle} endpoint produces alongside
 * the database, which this engine does not currently read. This is the same
 * underlying gap as expression-id resolution for AND NOT/decomposed terms
 * (acknowledged as deferred, to be addressed together at the Compile
 * Service side) — both need the same kind of expression-id → term-metadata
 * mapping that only that accompanying JSON currently carries.
 */
public final class FeatureScanOrchestrator {

    private final HyperscanDatabaseLoader databaseLoader;
    private final Long maxAttachmentSizeBytes;

    /**
     * @param databaseLoader            this partition's shared, cached loader
     * @param maxAttachmentSizeBytes    null means unlimited (requirement 4.e default) — an
     *                                   attachment whose {@code cleanText} UTF-8 byte length
     *                                   exceeds this is skipped entirely (not scanned, not an error)
     */
    public FeatureScanOrchestrator(HyperscanDatabaseLoader databaseLoader, Long maxAttachmentSizeBytes) {
        this.databaseLoader = databaseLoader;
        this.maxAttachmentSizeBytes = maxAttachmentSizeBytes;
    }

    /** A {@link DecisionTreeEvaluator.FeatureRowScanner} bound to one message — see {@code processMessage}. */
    public DecisionTreeEvaluator.FeatureRowScanner scannerFor(ScanMessage message) {
        return row -> scanRow(row, message);
    }

    /**
     * Scans one row's lexicon feature against every area its scope covers,
     * merging matches for the SAME term found in more than one area (e.g. a
     * term matching in both the subject and the body) into one
     * {@link TermMatchResult} rather than reporting it twice.
     */
    private List<TermMatchResult> scanRow(FeatureDecisionRow row, ScanMessage message) {
        FeatureDefinition definition = FeatureDefinition.parse(row.featureDefinitionJson());
        String feature = definition.body().feature();
        Database database = databaseLoader.load(feature);

        HyperscanScanService.ExpressionIdResolver resolver = expressionId ->
                TermIdBuilder.build(feature, expressionId);

        Map<String, List<TermMatchResult>> byTermId = new LinkedHashMap<>();

        if (definition.body().hasScope(BqColumns.FeatureDefinitionJson.SCOPE_SUBJECT)) {
            addResults(byTermId, HyperscanScanService.scan(
                    message.content() == null ? null : message.content().subject(),
                    database, resolver, MatchArea.SUBJECT, null));
        }

        if (definition.body().hasScope(BqColumns.FeatureDefinitionJson.SCOPE_MESSAGE_BODY)) {
            addResults(byTermId, HyperscanScanService.scan(
                    message.content() == null ? null : message.content().rawText(),
                    database, resolver, MatchArea.MESSAGE_BODY, null));
        }

        if (definition.body().hasScope(BqColumns.FeatureDefinitionJson.SCOPE_ATTACHMENT)) {
            for (MessageAttachment attachment : message.attachmentsOrEmpty()) {
                if (!withinSizeLimit(attachment)) {
                    continue;
                }
                addResults(byTermId, HyperscanScanService.scan(
                        attachment.cleanText(), database, resolver, MatchArea.ATTACHMENT, attachment.attachmentId()));
            }
        }

        return mergeByTermId(byTermId);
    }

    private boolean withinSizeLimit(MessageAttachment attachment) {
        if (maxAttachmentSizeBytes == null) {
            return true;
        }
        if (attachment.cleanText() == null) {
            return true;
        }
        long byteLength = attachment.cleanText().getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
        return byteLength <= maxAttachmentSizeBytes;
    }

    private void addResults(Map<String, List<TermMatchResult>> byTermId, List<TermMatchResult> results) {
        for (TermMatchResult tmr : results) {
            byTermId.computeIfAbsent(tmr.termId(), k -> new ArrayList<>()).add(tmr);
        }
    }

    /** Merges every area's {@link TermMatchResult} for the same term_id into one, concatenating their matches. */
    private List<TermMatchResult> mergeByTermId(Map<String, List<TermMatchResult>> byTermId) {
        List<TermMatchResult> merged = new ArrayList<>(byTermId.size());
        for (Map.Entry<String, List<TermMatchResult>> entry : byTermId.entrySet()) {
            List<TermMatchResult> parts = entry.getValue();
            if (parts.size() == 1) {
                merged.add(parts.get(0));
                continue;
            }
            List<com.db.macs3.ecomms.spectre.scanengine.model.match.AreaMatch> allMatches = new ArrayList<>();
            for (TermMatchResult part : parts) {
                allMatches.addAll(part.matches());
            }
            merged.add(new TermMatchResult(entry.getKey(), parts.get(0).termRegexPattern(), allMatches));
        }
        return merged;
    }
}
