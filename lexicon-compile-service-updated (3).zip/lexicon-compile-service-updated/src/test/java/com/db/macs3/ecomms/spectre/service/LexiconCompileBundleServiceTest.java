package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.hyperscan.HyperscanCompiler;
import com.db.macs3.ecomms.spectre.model.CompilationStatus;
import com.db.macs3.ecomms.spectre.model.CompileResponse;
import com.db.macs3.ecomms.spectre.model.TypedCompileRequest;
import com.db.macs3.ecomms.spectre.service.LexiconCompileService;
import com.db.macs3.ecomms.spectre.translator.TermSyntaxTranslator;
import com.gliwka.hyperscan.wrapper.Database;
import com.gliwka.hyperscan.wrapper.Match;
import com.gliwka.hyperscan.wrapper.Scanner;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link LexiconCompileBundleService} — the {@code /compile/bundle}
 * endpoint's orchestration logic (Standard/NLT branching + combined database).
 *
 * <p>No Spring context — uses real {@code TermSyntaxTranslator} and
 * {@code HyperscanCompiler} directly, exactly like {@link LexiconCompileServiceTest}.
 */
@DisplayName("LexiconCompileBundleService Tests")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class LexiconCompileBundleServiceTest {

    private LexiconCompileBundleService bundleService;

    @BeforeEach
    void setUp() {
        var translator     = new TermSyntaxTranslator();
        var compiler        = new HyperscanCompiler();
        compiler.selfTest();
        var compileService  = new LexiconCompileService(translator, compiler, new SimpleMeterRegistry());
        bundleService        = new LexiconCompileBundleService(compileService, compiler, new SimpleMeterRegistry());
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private TypedCompileRequest request(String ruleName, String termType, TermSpec... specs) {
        var req = new TypedCompileRequest();
        req.setRequestId(UUID.randomUUID().toString());
        req.setLexiconRuleName(ruleName);
        req.setTermType(termType);
        List<TypedCompileRequest.TermInput> terms = new ArrayList<>();
        for (int i = 0; i < specs.length; i++) {
            terms.add(new TypedCompileRequest.TermInput(
                    ruleName + "::" + (i + 1), specs[i].description));
        }
        req.setTerms(terms);
        return req;
    }

    // Convenience: Standard or NLT helpers just carry description
    private record TermSpec(String description) {}
    private static TermSpec term(String desc) { return new TermSpec(desc); }

    /** Shorthand: all-Standard request */
    private TypedCompileRequest std(String ruleName, String... descs) {
        TermSpec[] specs = new TermSpec[descs.length];
        for (int i = 0; i < descs.length; i++) specs[i] = term(descs[i]);
        return request(ruleName, "Standard", specs);
    }

    /** Shorthand: all-NLT request */
    private TypedCompileRequest nlt(String ruleName, String... descs) {
        TermSpec[] specs = new TermSpec[descs.length];
        for (int i = 0; i < descs.length; i++) specs[i] = term(descs[i]);
        return request(ruleName, "NLT", specs);
    }

    // ── Spec example from the requirements ────────────────────────────────────

    @Test @Order(1)
    @DisplayName("Spec example: Standard request → PASS, combined DB built, request_id/termType echoed")
    void specExampleStandard() {
        // termType is now request-level, so the original mixed Standard+NLT example
        // is split into two single-type requests — this covers the Standard half.
        var req = std("lexicon_research_1",
                "(manipulate) NEAR{5} ((price) OR (spread) OR (stock))");
        String sentRequestId = req.getRequestId();

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isTrue();
        assertThat(bundle.hyperscanDatabaseBytes()).isNotEmpty();
        assertThat(bundle.databaseNote()).isNull();
        // request_id and termType must be echoed back unchanged
        assertThat(bundle.jsonResponse().requestId()).isEqualTo(sentRequestId);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Standard");
    }

    @Test @Order(2)
    @DisplayName("Spec example: NLT request → PASS, combined DB built, request_id/termType echoed")
    void specExampleNlt() {
        // NLT half of the original mixed example — termType is request-level now.
        var req = nlt("lexicon_research_1", "(?:price|spread|stock)");
        String sentRequestId = req.getRequestId();

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isTrue();
        assertThat(bundle.jsonResponse().requestId()).isEqualTo(sentRequestId);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("NLT");
    }

    // ── JSON shape: request_id / termType present, hyperscanVersion / processingTimeMs absent ──

    @Test @Order(10)
    @DisplayName("JSON response: request_id and termType present; hyperscanVersion absent (bundle-specific shape)")
    void jsonShapeMatchesCompile() {
        var req = std("shape_test", "price OR spread");
        var bundle = bundleService.buildBundle(req);

        CompileResponse json = bundle.jsonResponse();
        assertThat(json.lexiconRuleName()).isEqualTo("shape_test");
        assertThat(json.engineMode()).isEqualTo("HYPERSCAN_NATIVE");
        assertThat(json.requestId()).isEqualTo(req.getRequestId());
        assertThat(json.termType()).isEqualTo("Standard");
        // hyperscanVersion is intentionally null/absent for the bundle endpoint
        assertThat(json.hyperscanVersion()).isNull();
        assertThat(json.results()).hasSize(1);
        assertThat(json.results().get(0).termId()).isEqualTo("shape_test::1");
    }

    // ── Standard term branch ──────────────────────────────────────────────────

    @Test @Order(20)
    @DisplayName("Standard term: NEAR{5} translated exactly like /compile")
    void standardTermTranslated() {
        var req = std("std_test", "(manipulate) NEAR{5} (price)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.translatedPattern()).contains("manipulate").contains("price");
        // Word-based gap confirms translation actually ran (NLT would never produce this)
        assertThat(result.translatedPattern()).contains("\\s+\\S+");
    }

    @Test @Order(21)
    @DisplayName("Standard term with invalid syntax → FAILED with translationError, no DB entry")
    void standardTermTranslationFailure() {
        var req = std("std_fail_test", "NEAR{5} (price)"); // missing left operand
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.FAILED);
    }

    // ── NLT term branch ────────────────────────────────────────────────────────

    @Test @Order(30)
    @DisplayName("NLT term: raw PCRE compiled verbatim, NOT passed through the translator")
    void nltTermCompiledVerbatim() {
        var req = nlt("nlt_test", "(?:price|spread|stock)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        // translatedPattern must be byte-identical to the input — no translation occurred
        assertThat(result.translatedPattern()).isEqualTo("(?:price|spread|stock)");
    }

    @Test @Order(31)
    @DisplayName("NLT term with invalid regex syntax → FAILED with Hyperscan errorLog")
    void nltTermInvalidRegex() {
        var req = nlt("nlt_invalid_test", "[unclosed");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.FAILED);
        assertThat(result.errorLog()).isNotBlank();
        // requiresAndPostFilter is always false for NLT
        assertThat(result.requiresAndPostFilter()).isFalse();
    }

    @Test @Order(32)
    @DisplayName("NLT term with non-Latin script gets UTF8/UCP flags automatically")
    void nltTermNonLatinFlags() {
        var req = nlt("nlt_korean_test", "(?:내부자|거래)");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        assertThat(result.compilationStatus()).isEqualTo(CompilationStatus.PASS);
        assertThat(result.hyperscanFlags() & 32).isEqualTo(32); // UTF8
        assertThat(result.hyperscanFlags() & 64).isEqualTo(64); // UCP
    }

    @Test @Order(33)
    @DisplayName("NLT term with operator-language syntax (not a real regex) is treated literally, never translated")
    void nltTermNeverTranslated() {
        // If this were Standard, "NEAR{5}" would translate into a proximity pattern.
        // As NLT it must be compiled literally — Hyperscan treats {5} as a repetition quantifier
        // on whatever precedes it, which is valid PCRE syntax on its own.
        var req = nlt("nlt_literal_test", "price NEAR.{5} stock");
        var bundle = bundleService.buildBundle(req);

        var result = bundle.jsonResponse().results().get(0);
        // Must be exactly what was given — proof no NEAR{n} translation ran
        assertThat(result.translatedPattern()).isEqualTo("price NEAR.{5} stock");
    }

    // ── All-NLT and all-Standard scenarios ────────────────────────────────────

    @Test @Order(40)
    @DisplayName("All-NLT request: every term compiled verbatim, DB contains all")
    void allNltRequest() {
        var req = nlt("all_nlt_test",
                "(?:price|spread)", "(?:insider|tip)", "manipulat\\w+");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(3);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("NLT");
        assertThat(bundle.hasDatabase()).isTrue();
    }

    @Test @Order(41)
    @DisplayName("All-Standard request: behaves identically to /compile for every term")
    void allStandardRequest() {
        var req = std("all_std_test",
                "price OR spread",
                "don't FOLLOWEDBY{3} compliance",
                "insider AND announcement");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(3);
        assertThat(bundle.jsonResponse().termType()).isEqualTo("Standard");
        assertThat(bundle.hasDatabase()).isTrue();
    }

    // ── Mixed pass/fail scenarios (same termType, different outcomes) ──────────

    @Test @Order(50)
    @DisplayName("Mixed PASS/FAILED within an NLT request: combined DB built from PASS subset only, with id gaps")
    void mixedPassFailedDbBuiltFromPassOnly() throws IOException {
        // termType is request-level now, so "mixed Standard+NLT" is no longer expressible
        // in one request. This test instead covers a mixed PASS/FAILED outcome within a
        // single NLT request, which still exercises the id-gap behaviour identically.
        var req = nlt("mixed_test",
                "(?:price|spread)",     // index 0 — PASS
                "[unclosed",             // index 1 — FAILED
                "(?:insider|tip)");      // index 2 — PASS

        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(2);
        assertThat(bundle.jsonResponse().failedCount()).isEqualTo(1);
        assertThat(bundle.jsonResponse().results().get(1).compilationStatus())
                .isEqualTo(CompilationStatus.FAILED);
        assertThat(bundle.hasDatabase()).isTrue();

        // Load the DB back and confirm only ids {0, 2} are present (1 is the gap)
        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            assertThat(scanMatchesIds(db, "price")).contains(0);
            assertThat(scanMatchesIds(db, "insider")).contains(2);
        }
    }

    @Test @Order(51)
    @DisplayName("Zero PASS terms: no database built, clear explanatory note returned")
    void zeroPassTermsNoDatabase() {
        var req = nlt("zero_pass_test", "[unclosed", "[also_unclosed");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.jsonResponse().passCount()).isEqualTo(0);
        assertThat(bundle.hasDatabase()).isFalse();
        assertThat(bundle.hyperscanDatabaseBytes()).isNull();
        assertThat(bundle.databaseNote()).isNotBlank();
        assertThat(bundle.databaseNote()).contains("zero terms reached PASS");
    }

    // ── Combined database integrity (round-trip load + scan) ───────────────────

    @Test @Order(60)
    @DisplayName("Combined DB round-trip: save() then load() reconstructs a working multi-pattern database")
    void combinedDatabaseRoundTrip() throws IOException {
        var req = nlt("roundtrip_test",
                "(?:price|spread|stock)",
                "(?:insider|tip)");
        var bundle = bundleService.buildBundle(req);

        assertThat(bundle.hasDatabase()).isTrue();

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            List<Integer> priceMatches  = scanMatchesIds(db, "the price went up");
            List<Integer> insiderMatches = scanMatchesIds(db, "an insider tip was shared");

            assertThat(priceMatches).contains(0);
            assertThat(insiderMatches).contains(1);
        }
    }

    @Test @Order(61)
    @DisplayName("Expression id equals the term's 0-based index in the request, not termId hash")
    void expressionIdEqualsArrayIndex() throws IOException {
        var req = nlt("id_mapping_test",
                "alpha_pattern",   // index 0
                "beta_pattern",    // index 1
                "gamma_pattern");  // index 2
        var bundle = bundleService.buildBundle(req);

        try (Database db = Database.load(new ByteArrayInputStream(bundle.hyperscanDatabaseBytes()))) {
            assertThat(scanMatchesIds(db, "alpha_pattern")).containsExactly(0);
            assertThat(scanMatchesIds(db, "beta_pattern")).containsExactly(1);
            assertThat(scanMatchesIds(db, "gamma_pattern")).containsExactly(2);
        }
    }

    // ── Scan helper ──────────────────────────────────────────────────────────

    /** Scans {@code text} against {@code db} and returns the matched expression ids. */
    private List<Integer> scanMatchesIds(Database db, String text) {
        List<Integer> ids = new ArrayList<>();
        try (Scanner scanner = new Scanner()) {
            scanner.allocScratch(db);
            for (Match match : scanner.scan(db, text)) {
                ids.add(match.getMatchedExpression().getId());
            }
        }
        return ids;
    }
}
