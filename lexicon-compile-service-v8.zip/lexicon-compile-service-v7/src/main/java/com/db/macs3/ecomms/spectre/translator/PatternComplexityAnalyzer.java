package com.db.macs3.ecomms.spectre.translator;

/**
 * Estimates whether an {@link Ast} is likely to produce a pattern Hyperscan
 * rejects with "Pattern is too large", and rejects it EARLY — before
 * {@link PatternCodeGenerator} even runs — with a specific, actionable error
 * instead of letting Hyperscan fail opaquely at compile time.
 *
 * <h2>Why string length isn't the right signal</h2>
 * <p>The reported failure case compiles to a 190-character pattern — nowhere
 * near any raw length limit. Hyperscan's "Pattern is too large" is a
 * documented consequence of compiled AUTOMATON STATE COUNT, not string
 * length: Intel's own issue tracker shows a 32,000-repeat bounded quantifier
 * on a simple pattern compiling fine, while a 73-repeat bounded quantifier
 * on a pattern with additional structure fails.
 *
 * <h2>Revision history: nesting depth, not branch width, is the primary driver</h2>
 * <p>The first version of this analyzer scored pure OR-branch width and
 * wildcard presence, multiplying operand scores together at each NEAR/FOLLOWEDBY.
 * Real Hyperscan testing falsified that model directly: a term with a single
 * NEAR over an 18-alternative and an 8-alternative OR group (no nesting)
 * scored 480 under that model and compiled successfully; a term with two
 * NESTED FOLLOWEDBY operators over much narrower 4-alternative OR groups
 * scored only 294 and was REJECTED by real Hyperscan with "Pattern is too
 * large" — the model had the ordering backwards.
 *
 * <p>The reason, reasoned from how bounded repetition compiles: a bounded
 * gap like {@code (?:\s+\S+){0,4}} requires the automaton to track "how many
 * gap-words have been consumed so far" as part of its state (a handful of
 * states — 0 through 4 — is cheap on its own, which is why the wide,
 * single-level NEAR case above compiled fine). But when one proximity
 * operator's operand is ITSELF a proximity operator, the automaton must
 * track TWO independent gap-counters SIMULTANEOUSLY for ambiguous partial
 * matches — the outer gap's count AND the inner gap's count — and that is a
 * PRODUCT of state spaces, not a sum. Nesting depth compounds multiplicatively;
 * OR-branch width at a single level does not compound the same way.
 *
 * <p>{@link #estimate} now applies an explicit nesting penalty: a NEAR/FOLLOWEDBY
 * whose operand is itself a NEAR/FOLLOWEDBY multiplies the whole expression's
 * score by {@code (nestedDistance + 1)} — the nested gap's own bound plus
 * one, standing in for the number of additional simultaneous counter-states
 * that nesting introduces. A single-level proximity operator (either operand
 * a plain OR/word/phrase, never another proximity node) gets no such penalty,
 * matching the empirical result that width alone did not cause failure.
 *
 * <h2>This is still a heuristic, not a guarantee</h2>
 * <p>It is now calibrated against two known real Hyperscan outcomes (one
 * PASS at raw complexity 480, one real FAILURE at raw complexity 294 that
 * becomes 1470 once the nesting penalty is applied — see
 * {@code PatternComplexityAnalyzerTest}), not just reasoned from first
 * principles. Two data points bound the budget but do not prove the formula
 * generalizes to arbitrary structures; {@link #COMPLEXITY_BUDGET} remains a
 * single named constant specifically so it can be re-tuned as more real
 * Hyperscan compilation results become available, and the risk of getting it
 * wrong is deliberately asymmetric: a false REJECTION costs the caller a
 * clear, actionable error and a term split; a false ACCEPTANCE costs an
 * opaque Hyperscan failure downstream. The budget is set with headroom above
 * the known-good case and well below the known-bad case, erring toward
 * rejecting when uncertain.
 */
final class PatternComplexityAnalyzer {

    /**
     * Complexity budget — see class Javadoc. Comfortably above the known
     * real PASS case (480, single-level wide NEAR) and comfortably below the
     * known real FAILURE case (1470 with the nesting penalty applied,
     * two-level nested FOLLOWEDBY). A term whose estimated score exceeds
     * this is rejected before code generation.
     */
    static final int COMPLEXITY_BUDGET = 700;

    /** Multiplier applied to a NEAR operand's score — NEAR generates both
     *  A-then-B and B-then-A, doubling automaton complexity relative to the
     *  same operands under a single-direction FOLLOWEDBY. */
    private static final int NEAR_DIRECTIONALITY_FACTOR = 2;

    /** Extra weight for a wildcard-containing word/phrase — {@code \S*}'s own
     *  unbounded internal branching compounds with any surrounding bounded
     *  repetition or alternation it sits inside. */
    private static final int WILDCARD_WEIGHT = 2;
    private static final int PLAIN_WEIGHT = 1;

    private PatternComplexityAnalyzer() {}

    /**
     * Validates {@code ast}, throwing if its estimated complexity exceeds
     * {@link #COMPLEXITY_BUDGET}. For an {@code AND NOT} term, the required
     * and excluded sides are validated SEPARATELY (they become two
     * independent Hyperscan patterns — see {@link Ast.AndNot} class
     * Javadoc — so each is its own compile-complexity risk).
     *
     * @param ast          the parsed term
     * @param originalTerm the original term text, for the error message
     * @throws TranslationException if the estimated complexity is too high
     */
    static void validateComplexity(Ast ast, String originalTerm) {
        if (ast instanceof Ast.AndNot andNot) {
            checkBudget(estimateSafely(andNot.required(), originalTerm), "required", originalTerm);
            for (Ast excluded : andNot.excluded()) {
                checkBudget(estimateSafely(excluded, originalTerm), "excluded (AND NOT)", originalTerm);
            }
            return;
        }
        checkBudget(estimateSafely(ast, originalTerm), "term", originalTerm);
    }

    /**
     * Wraps {@link #estimate} to treat integer overflow (an extremely deep
     * or wide nested structure) as unambiguously over-budget rather than
     * letting {@link ArithmeticException} propagate as an unrelated-looking
     * "unexpected error" — a term complex enough to overflow a 32-bit score
     * is complex enough to reject regardless of the exact number.
     */
    private static int estimateSafely(Ast ast, String originalTerm) {
        try {
            return estimate(ast);
        } catch (ArithmeticException overflow) {
            return Integer.MAX_VALUE;
        }
    }

    private static void checkBudget(int score, String side, String originalTerm) {
        if (score > COMPLEXITY_BUDGET) {
            throw new TranslationException(
                    "This term's " + side + " expression is estimated too structurally complex "
                    + "for Hyperscan to compile (estimated complexity " + score + ", budget "
                    + COMPLEXITY_BUDGET + ") in term: '" + originalTerm + "'."
                    + " This typically happens with NESTED NEAR/FOLLOWEDBY operators — one proximity"
                    + " operator's operand is itself another proximity operator — especially when the"
                    + " nested one has a large distance bound. To fix: reduce nesting (prefer a single"
                    + " proximity level where possible), reduce the nested operator's distance{n}, or"
                    + " split this into multiple simpler lexicon terms.");
        }
    }

    // ── Estimation ────────────────────────────────────────────────────────────

    private static int estimate(Ast ast) {
        return switch (ast) {
            case Ast.Or or -> or.operands().stream().mapToInt(PatternComplexityAnalyzer::estimate).sum();

            case Ast.And and -> and.operands().stream()
                    .mapToInt(PatternComplexityAnalyzer::estimate)
                    .reduce(1, Math::multiplyExact); // permutation count itself is already capped elsewhere

            case Ast.AndNot andNot -> estimate(andNot.required()); // excluded side checked separately by the caller

            case Ast.Near near -> {
                int base = Math.multiplyExact(estimate(near.left()), estimate(near.right()));
                int directional = Math.multiplyExact(base, NEAR_DIRECTIONALITY_FACTOR);
                yield Math.multiplyExact(directional, nestingPenalty(near.left(), near.right()));
            }

            case Ast.FollowedBy fb -> {
                int base = Math.multiplyExact(estimate(fb.left()), estimate(fb.right()));
                yield Math.multiplyExact(base, nestingPenalty(fb.left(), fb.right()));
            }

            case Ast.Word w -> containsWildcard(w.text()) ? WILDCARD_WEIGHT : PLAIN_WEIGHT;

            case Ast.Phrase p -> p.words().stream().anyMatch(PatternComplexityAnalyzer::containsWildcard)
                    ? WILDCARD_WEIGHT : PLAIN_WEIGHT;

            case Ast.QuotedPhrase q -> PLAIN_WEIGHT;
        };
    }

    /**
     * The extra multiplicative penalty for a proximity operator whose
     * operand(s) are THEMSELVES proximity operators — see class Javadoc.
     * {@code (nestingFactor(left) × nestingFactor(right))}: neutral (1) for
     * a non-proximity operand, {@code distance+1} for a nested one — so a
     * proximity node with NEITHER operand nested gets no penalty at all,
     * matching the empirical single-level-NEAR PASS case exactly.
     */
    private static int nestingPenalty(Ast left, Ast right) {
        return Math.multiplyExact(nestingFactor(left), nestingFactor(right));
    }

    private static int nestingFactor(Ast operand) {
        return switch (operand) {
            case Ast.Near near -> near.distance() + 1;
            case Ast.FollowedBy fb -> fb.distance() + 1;
            default -> 1;
        };
    }

    private static boolean containsWildcard(String word) {
        return word.indexOf('*') >= 0;
    }
}
