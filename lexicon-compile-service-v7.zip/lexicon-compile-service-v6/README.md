# Lexicon Compile Service
### Spring Boot 4.0.6 · JDK 21 · Intel Hyperscan (com.gliwka.hyperscan 5.4.0-2.0.0) · GCP Cloud Run

**Base package:** `com.db.macs3.ecomms.spectre`

---

## What This Service Does

Accepts lexicon rule definitions (as JSON, CSV, or a typed bundle request), translates each term description into a Hyperscan-compatible PCRE pattern, validates it via `Database.compile()`, and returns per-term compilation results. Used by compliance surveillance systems before scanning millions of communication messages at runtime.

---

## Supported Term Description Features

| Feature | Syntax | PCRE output |
|---|---|---|
| **OR** | `price OR spread OR stock` | `(?:price\|spread\|stock)` |
| **AND** | `A AND B AND C` | Every ordering of A/B/C joined by an unbounded gap — see [AND](#and-co-occurrence-any-order-no-distance-limit) below |
| **AND NOT** | `insider AND NOT disclaimer` | TWO separate patterns — see [AND NOT](#and-not-a-two-pattern-contract-not-a-single-regex) below |
| **NEAR{n}** | `manipulate NEAR{5} price` | Bidirectional, bounded gap: `(?:A{gap}B\|B{gap}A)` |
| **FOLLOWEDBY{n}** | `don't FOLLOWEDBY{3} compliance` | Directional, bounded gap: `A{gap}B` only |
| **Wildcard trailing** | `manipulate*` | `manipulate\S*` |
| **Wildcard leading** | `*running` | `\S*running` |
| **Literal `?`** | `he?d kill` | `he\?d kill` — always literal, never the PCRE "optional" quantifier |
| **Quoted phrase** | `"please don't forward"` | PCRE-escaped literal (`*`/`?` inside quotes are also literal) |
| **CSV double-quote** | `""please don't forward""` | Unescaped → `"please don't forward"` |
| **Unwrapped multi-word phrase** | `bomb this place OR blow this place up` | Each run of bare words with no operator between them is treated as one literal phrase automatically — wrapping in parentheses is optional, not required |
| **Emoji** | `💰 OR 🤫` | `(?:\x{1F4B0}\|\x{1F92B})` + UTF8+UCP |
| **Korean / Japanese / Chinese / Arabic / Hebrew / German / Turkish** | e.g. `비밀 OR 내부자 거래` | Literal + UTF8+UCP flags |
| **Leet-speak** | `1ns1d3r* OR fr0nt*` | Literal (intentional — matches obfuscated text) |
| **Mixed language** | `insider OR 내부자 OR 💰` | OR group + UTF8+UCP |

> **There is no independent `NOT` operator.** `NOT` (and the legacy `!` shorthand) previously worked as a standalone prefix negation; it no longer does. `NOT` is only ever valid immediately after `AND`, as `AND NOT`. A bare `NOT some text` is rejected at compile time with an explicit error telling you to write `AND NOT` instead. `!` has no special meaning any more — it is now ordinary literal text.

---

## AND: co-occurrence, any order, no distance limit

`price AND rigging` means: both words must appear **somewhere** in the message, in **any order**, with **no limit** on how far apart they are — the same relationship `FOLLOWEDBY{n}` expresses, just without `FOLLOWEDBY`'s distance cap. This is genuinely compiled into a single Hyperscan pattern using the same bidirectional-alternation technique `NEAR`/`FOLLOWEDBY` already use for a *bounded* gap, just with the gap made unbounded:

```
price AND rigging
  → (?:price[\s\S]*rigging|rigging[\s\S]*price)
```

`[\s\S]*` matches any character, any number of times — ordinary PCRE alternation and repetition, nothing Hyperscan can't compile. For three or more operands, every ordering (permutation) is enumerated the same way: `A AND B AND C` produces all six A/B/C orderings joined by `|`. **A term can have at most 5 AND operands at one level** — each additional operand multiplies the pattern's permutation count (5! = 120), and beyond that the resulting pattern reliably becomes too large for Hyperscan to compile; split a larger requirement into multiple simpler lexicon terms instead.

Worked example, matching the exact scenario this fix addresses:

| Message | `price AND rigging` |
|---|---|
| *"There's price change and market rigging is going on"* | **Matches** — both words present, in that order, with other words between them |
| *"There's price change"* | **Does not match** — "rigging" never appears |

### An earlier version of this document was wrong about this

A previous revision documented AND as `(?=.*A)(?=.*B)(?=.*C).*` — a chain of positive lookaheads. **Hyperscan does not support lookahead of any kind** (it is a linear-time, DFA/NFA-based multi-pattern matcher, not a backtracking engine), so that pattern was never something Hyperscan could actually compile and use as documented. In practice, terms using AND degraded silently to matching on *any single* operand — `price AND rigging` behaved like `price OR rigging`. The fix above removes lookahead from the picture entirely.

---

## AND NOT: two different implementations, for two different callers

`price AND NOT change` means: `price` must appear, and `change` must **not** appear anywhere in the same message. Unlike AND, this cannot be compiled into one *ordinary* Hyperscan pattern — "absent from the whole text" is exactly what negative lookaround exists to express, and Hyperscan's regular pattern matching has none.

An earlier version of this document documented `insider AND NOT disclaimer` as `(?=.*insider)(?!.*disclaimer).*` — a positive lookahead plus a negative lookahead. That was never something Hyperscan could compile at all. A later revision fixed the pattern generation but assumed every caller would read `translatedPattern` and `exclusionPattern` as separate JSON fields and combine them itself — which breaks for a caller that never sees the JSON, only a compiled `.hdb` file (see below). **Both endpoints now do the right thing for what they actually return.**

### `/compile` and `/compile/csv`: the two-pattern JSON contract

These endpoints return two independent, separately Hyperscan-validated patterns, and it is the caller's responsibility to combine them — appropriate for a caller like the Lexicon Scanner Service, which reads this JSON directly:

```json
{
  "translatedPattern":       "price",
  "requiresExclusionCheck":  true,
  "exclusionPattern":        "(?:change)"
}
```

A term is correctly matched only when:

```
translatedPattern  DOES match the message      AND
exclusionPattern   does NOT match the message
```

```java
boolean requiredMatch  = hyperscanFoundAMatchFor(translatedPattern, message);
boolean excludedMatch  = requiresExclusionCheck
                          && hyperscanFoundAMatchFor(exclusionPattern, message);
boolean termMatches    = requiredMatch && !excludedMatch;
```

Both patterns are validated by `Database.compile()` independently at compile time — if either one is rejected by Hyperscan, the whole term is reported `FAILED`. Chained exclusions (`A AND NOT B AND NOT C`) combine B and C into one `exclusionPattern` via OR — the term is excluded if *either* is present.

### `/compile/bundle`: a native Hyperscan logical combination — no JSON needed at scan time

The typed bundle endpoint's `.hdb` file is frequently the **only** artifact a downstream consumer reads — the Lexicon Scan Engine's Dataproc job loads the compiled database and scans messages directly against it, with no JSON in the loop at all. The two-pattern JSON contract above is meaningless to a consumer that never sees the JSON, so for this endpoint, AND NOT is compiled directly INTO the database using Hyperscan 5.0+'s native **logical combination** feature (`HS_FLAG_COMBINATION`): a compiled expression whose pattern text is a boolean formula over *other expressions' ids* (`&`/`|`/`!`), which Hyperscan evaluates natively during the scan.

**Expression ids are term numbers, not array positions.** Every `termId` on this platform follows `<lexicon_rule_name>::<term_number>` (e.g. `lexicon_research_1::1`). A term's Hyperscan expression id is derived from that term number, not from its position in the request's `terms` array — see [Hyperscan expression ids are term numbers](#hyperscan-expression-ids-are-term-numbers-not-array-positions) below for why and how.

For an AND NOT term with term number `n`, THREE expressions go into the combined database instead of one:

| id | pattern | flags | reported on its own? |
|---|---|---|---|
| `n` | the required pattern | normal + `QUIET` | No |
| `offset + n` | the exclusion pattern | normal + `QUIET` | No |
| `2*offset + n` | `"(n&!(offset+n))"` | `COMBINATION` only | **Yes** |

where `offset` = the largest term number in the request, plus 1 — computed once per request so the exclusion/combination id ranges can never collide with a real term number, however sparse those numbers are.

`QUIET` suppresses a sub-expression's own match reporting — without it, the required pattern would raise its own match every time it's present, regardless of the exclusion, silently reproducing the exact bug this fix addresses. Only the combination expression is ever reported, and it is reported *only* when the required pattern matched and the exclusion pattern did not — Hyperscan itself evaluates that boolean condition; no application-level combination step is needed downstream.

**`hyperscanExpressionId`** in the JSON response tells a consumer exactly which id to watch — the term number for a plain term, the combination id above for an AND NOT term. A consumer that simply treats "any reported match on this database = an alert" is automatically correct with zero per-term special-casing, since AND NOT terms' sub-expressions never report on their own.

Worked example — `((don't forward) AND NOT (compliance OR legal))` as the only term in a bundle request, with `termId = "lexicon_research_1::1"` (term number 1, so `offset = 2`):

```json
{
  "termId":                 "lexicon_research_1::1",
  "translatedPattern":      "don't forward",
  "requiresExclusionCheck": true,
  "exclusionPattern":       "(?:(?:compliance|legal))",
  "hyperscanExpressionId":  5
}
```

Compiled into the database: id `1` = `"don't forward"` (QUIET), id `3` (= offset 2 + term number 1) = `"(?:(?:compliance|legal))"` (QUIET), id `5` (= 2×offset 2 + term number 1) = `"(1&!3)"` (COMBINATION). Scanning *"Please don't forward this message to compliance or legal"*: id `1`'s pattern is present and id `3`'s pattern is also present, so the combination's condition (`1 AND NOT 3`) is false — Hyperscan reports **no match** for this message, on any id. That is the correct outcome: the message must not be flagged.

> **Dependency note:** `ExpressionFlag.COMBINATION` and `ExpressionFlag.QUIET` were added to `com.gliwka.hyperscan-java` in its v1.0.0 release; this project pins the wrapper's v2.0.0 line (`5.4.0-2.0.0`), which post-dates that release. If a future dependency change ever removed these constants, every affected call site would fail to compile with an unambiguous "cannot find symbol" naming the exact missing flag — not a silent behaviour change.

---

## Hyperscan expression ids are term numbers, not array positions

Every `termId` in a `/compile/bundle` request must end with `::<n>` where `n` is a non-negative integer — the platform-wide term-number convention already used in lexicon rule definitions (e.g. `lexicon_research_1::1`, `lexicon_research_1::42`). The Hyperscan expression id a term is compiled at is `n`, not the term's 0-based position in the request's `terms` array.

This matters because the compiled `.hdb` file is frequently read on its own, independent of any particular compile request's ordering — a downstream consumer that already knows a term by its number (from the lexicon rule definition itself) can find it directly in the database at that same id, with no array-position bookkeeping required.

**Both conditions are validated for the whole request before any term is compiled:**
- Every `termId` must match `::<n>` — a malformed one (missing the suffix, or a non-numeric/negative value) fails the whole request with HTTP 400, naming every offending `termId`.
- Every parsed term number must be unique within the request — two terms sharing a number would collide at the same Hyperscan expression id and silently corrupt the combined database, so this is rejected up front instead.

```json
{
  "error": "termId must end with '::<n>' where n is a non-negative integer (the platform's term-number convention, e.g. 'lexicon_rule_name::1') — required for /compile/bundle's Hyperscan expression id scheme. Malformed termId(s): [lexicon_research_1::abc]",
  "status": 400
}
```

Term numbers do **not** need to be contiguous or start at 0 — `lexicon_research_1::3` and `lexicon_research_1::100` in the same request work fine; AND NOT's exclusion/combination ids (see above) are always computed from the *largest* term number present, so they never collide with any real term number regardless of how sparse the numbering is.

---

## Validation: no chained NEAR/FOLLOWEDBY at the same level

A term like:

```
((termA OR termB OR termC) FOLLOWEDBY{5} (termD OR termE) FOLLOWEDBY{6} (termF OR termG))
```

chains two `FOLLOWEDBY` operators at the same grammar level. Each proximity operator's bidirectional pattern construction multiplies pattern size on its own; chaining two of them compounds that, and terms shaped like this reliably fail Hyperscan compilation with `Pattern Too Long` even though the term description itself parses without error. This is now rejected explicitly at translation time, before Hyperscan is ever invoked:

```
Cannot have multiple NEAR or FOLLOWEDBY operators at the same level in term: '...'
(found a second FOLLOWEDBY chained directly after the first). Wrap one side in
parentheses to nest them explicitly instead, e.g. '(A FOLLOWEDBY{n} B) FOLLOWEDBY{m} C'
```

If a term genuinely needs two proximity relationships, say so explicitly with parentheses — each side is then parsed at its own, separate grammar level, which both resolves the ambiguity and keeps the resulting pattern's size bounded:

```
(termA FOLLOWEDBY{5} termD) FOLLOWEDBY{6} termF     ✓ valid — explicit nesting
termA FOLLOWEDBY{5} termD FOLLOWEDBY{6} termF        ✗ rejected — chained, same level
```

The same rule applies to `NEAR`, and to any mix of `NEAR`/`FOLLOWEDBY` chained together.

---

## "Pattern is too large": explicitly-nested proximity with wide OR/wildcard operands

Explicit nesting (the workaround above) avoids the chained-same-level rejection, but a *sufficiently* nested-and-wide term can still hit Hyperscan's own compile-time limit:

```
(((wordA word B OR wordC* wordD OR wordE* wordF OR wordG) FOLLOWEDBY{4}
  (wordH* OR wordI wordJ* wordK OR wordL* wordM OR wordN)) FOLLOWEDBY{4}
  (wordO* OR wordP* wordQ OR wordR* wordS OR wordT))
```

This compiles to a 190-character pattern — nowhere near a string-length limit. "Pattern is too large" here is a documented consequence of Hyperscan's *compiled automaton state count*, not string length: Intel's own issue tracker shows a 32,000-repeat bounded quantifier on a simple pattern compiling fine, while a 73-repeat bounded quantifier on a pattern with additional structure fails. The common driver is **bounded repetition of a compound, itself-variable-length sub-pattern, interacting with surrounding alternation** — exactly what `(?:\s+\S+){0,4}` sitting between two wide OR groups is, and nesting one proximity operator's result into another compounds it further.

### Two mitigations, applied together

**1. `PatternComplexityAnalyzer` rejects likely failures early.** Before code generation, the term's AST is scored heuristically (OR-branch count, wildcard presence, multiplicative compounding across nested proximity levels) against a conservative budget. The term above scores 294 against a budget of 64, and is rejected with a specific error instead of reaching Hyperscan and failing opaquely:

```
This term's term expression is estimated too structurally complex for Hyperscan to
compile (estimated complexity 294, budget 64) in term: '...'. This typically happens
with nested NEAR/FOLLOWEDBY operators whose operands contain many OR-alternatives
and/or wildcards — each nesting level multiplies the complexity of the levels inside
it. To fix: reduce the number of OR-alternatives per operand, reduce wildcard usage,
or split this into multiple simpler lexicon terms.
```

This is a heuristic, not a guarantee — the exact state count Hyperscan would produce can't be computed without Hyperscan itself. The budget (`PatternComplexityAnalyzer.COMPLEXITY_BUDGET`) is a single named constant specifically so it can be tuned against real compilation results.

**2. `trackMatchPosition: false` reduces compiled complexity for `/compile/bundle`.** Hyperscan's `SOM_LEFTMOST` (start-of-match tracking) is required for the Scanner Service's highlighting, but is documented to increase compiled state count — and the Lexicon Scan Engine's Dataproc job needs boolean match confirmation for alerting, not match positions for highlighting. Setting this on a bundle request omits `SOM_LEFTMOST` from every compiled expression, trading position-reporting away for reduced compile complexity:

```json
{
  "request_id": "...", "lexiconRuleName": "...", "termType": "Natural Language",
  "trackMatchPosition": false,
  "terms": [ ... ]
}
```

Defaults to `true` (unchanged behaviour) when omitted — `/compile` and `/compile/csv` are unaffected by this setting entirely; they always include `SOM_LEFTMOST`, since Scanner Service highlighting needs it.

### What was considered and not adopted

Reducing the bounded-repetition count itself (e.g. `{0,4}` → unbounded) was considered and rejected — it would silently change `FOLLOWEDBY{n}`'s meaning from "within n words" to "anywhere afterward", the same class of correctness bug fixed earlier for `AND`. Splitting nested proximity into multiple independently-scanned sub-patterns with application-level position correlation (structurally similar to the `AND NOT` combination fix) remains a further option if the two mitigations above prove insufficient in practice — a larger change, not pursued in this round.

---

## Hyperscan Flag Bitmask

| Flag | Value | Applied when |
|---|---|---|
| `HS_FLAG_CASELESS` | 1 | Always |
| `HS_FLAG_UTF8` | 32 | Any non-ASCII character present |
| `HS_FLAG_UCP` | 64 | Alongside UTF8, for Unicode property support |

Example: a Korean term → flags = 1 + 32 + 64 = 97.

> `HS_FLAG_DOTALL` is intentionally never set. DOTALL only changes what the bare `.` metacharacter matches — every gap this service generates (NEAR/FOLLOWEDBY's bounded gap, AND's unbounded gap) is built from the `\s`/`\S`/`[\s\S]` character classes, never from `.`, so DOTALL has no effect on anything this service produces.

---

## REST API

### `POST /api/lexicon/compile`

**Content-Type:** `application/json`
**Content-Encoding:** `gzip` *(recommended)*
**Accept-Encoding:** `gzip` *(recommended)*

#### Request
```json
{
  "lexiconRuleName": "lexicon_research_1",
  "terms": [
    {
      "termId": "lexicon_research_1::1",
      "termDescription": "(manipulate) NEAR{5} ((price) OR (spread) OR (stock))",
      "riskDriverName": "Research Based Front Running"
    },
    {
      "termId": "lexicon_research_1::2",
      "termDescription": "price AND NOT change",
      "riskDriverName": "Selective Disclosure"
    }
  ]
}
```

#### Response
```json
{
  "lexiconRuleName": "lexicon_research_1",
  "totalTerms": 2,
  "passCount": 2,
  "failedCount": 0,
  "hasFailures": false,
  "engineMode": "HYPERSCAN_NATIVE",
  "hyperscanVersion": "5.4.0-2.0.0",
  "compiledAt": "2026-01-15T10:23:45.123Z",
  "processingTimeMs": 12,
  "results": [
    {
      "termId": "lexicon_research_1::1",
      "termDescription": "(manipulate) NEAR{5} ((price) OR (spread) OR (stock))",
      "riskDriverName": "Research Based Front Running",
      "compilationStatus": "PASS",
      "translatedPattern": "(?:manipulate(?:\\s+\\S+){0,5}\\s+(?:price|spread|stock)|(?:price|spread|stock)(?:\\s+\\S+){0,5}\\s+manipulate)",
      "hyperscanFlags": 1,
      "requiresExclusionCheck": false,
      "compiledAt": "2026-01-15T10:23:45.124Z"
    },
    {
      "termId": "lexicon_research_1::2",
      "termDescription": "price AND NOT change",
      "riskDriverName": "Selective Disclosure",
      "compilationStatus": "PASS",
      "translatedPattern": "price",
      "hyperscanFlags": 1,
      "requiresExclusionCheck": true,
      "exclusionPattern": "(?:change)",
      "compiledAt": "2026-01-15T10:23:45.125Z"
    }
  ]
}
```

### `POST /api/lexicon/compile/csv`

**Content-Type:** `multipart/form-data`
Fields: `file` (CSV, columns `term_id, term_description[, risk_driver]`), `ruleName` (optional)

Same response shape as `/compile`.

### `POST /api/lexicon/compile/bundle`

**Content-Type:** `application/json`
Root-level `termType`: `"Natural Language"` (operator-language terms, translated as above) or `"Regex"` (caller-supplied PCRE, compiled verbatim — no translation, but still Hyperscan-validated and still script-aware for flags). One request, one term type, applied to every term in it.

**Response:** a zip containing the same JSON shape as `/compile` (plus `request_id` and `termType`) alongside a combined Hyperscan `.hdb` database file compiled from every `PASS` term — see [the AND NOT bundle note above](#compilebundle-the-exclusion-pattern-is-in-the-combined-database-too) for how exclusion patterns are represented in it.

### `GET /api/lexicon/health`

Returns engine mode, version, supported operators and languages.

### `GET /actuator/health`

Spring Boot Actuator health — includes the Hyperscan self-test component.

---

## Project Structure

```
lexicon-compile-service/
├── pom.xml                              Spring Boot 4, JDK 21, Hyperscan, Checkstyle, JaCoCo
├── Dockerfile                           2-stage JDK 21 build; no native compile step
│
├── src/main/java/com/db/macs3/ecomms/spectre/
│   ├── LexiconCompileServiceApp.java    @SpringBootApplication
│   │
│   ├── translator/
│   │   ├── Tokenizer.java               Raw text → token stream; ALL lexical validation lives here
│   │   ├── Token.java                   Sealed token types
│   │   ├── ExpressionParser.java        Token stream → AST; grammar-level validation (chained
│   │   │                                proximity, AND operand ceiling, no standalone NOT)
│   │   ├── Ast.java                     Sealed AST node types
│   │   ├── PatternCodeGenerator.java    AST → PCRE pattern(s); the AND/AND-NOT construction lives here
│   │   ├── MultiLanguagePatternBuilder.java  NEAR/FOLLOWEDBY bounded-gap construction, script-aware
│   │   ├── ParseContext.java            Mutable flag + exclusion-pattern accumulator during codegen
│   │   ├── TermSyntaxTranslator.java    Orchestrates the pipeline above; @Component entry point
│   │   ├── TranslationResult.java       Sealed interface: Success | Error (JDK 21)
│   │   └── TranslationException.java    Thrown for any lexical/grammatical validation failure
│   │
│   ├── hyperscan/
│   │   └── HyperscanCompiler.java       com.gliwka.hyperscan wrapper; @PostConstruct self-test
│   │
│   ├── model/
│   │   ├── CompileRequest.java          /compile request (with riskDriverName)
│   │   ├── CompileResponse.java         /compile and /compile/bundle response
│   │   ├── TypedCompileRequest.java     /compile/bundle request (root-level termType, no riskDriverName)
│   │   ├── TermType.java                NATURAL_LANGUAGE | REGEX
│   │   ├── TermCompilationResult.java   Per-term result; carries exclusionPattern for AND NOT terms
│   │   ├── CompilationStatus.java       PASS | FAILED
│   │   └── ScriptType.java              Unicode script classification for flag selection
│   │
│   ├── service/
│   │   ├── LexiconCompileService.java       Translate → validate (incl. exclusion pattern) → build response
│   │   ├── CsvCompileService.java           CSV parsing + BOM stripping; delegates to above
│   │   └── LexiconCompileBundleService.java Typed bundle endpoint; builds the combined .hdb
│   │
│   ├── controller/
│   │   ├── LexiconCompileController.java  POST /compile, /compile/csv, /compile/bundle, GET /health
│   │   └── GlobalExceptionHandler.java    @RestControllerAdvice — 400/413/500 responses
│   │
│   ├── util/
│   │   ├── ScriptDetector.java          Per-codepoint Unicode script detection → recommended flags
│   │   └── TikaLanguageSupport.java     Optional language-detection complement
│   │
│   └── config/
│       ├── GzipRequestFilter.java       jakarta.servlet.Filter — decompresses GZIP requests
│       ├── LexiconProperties.java       @ConfigurationProperties prefix: lexicon
│       └── LexiconCompileConfig.java    CORS, Hyperscan health indicator
│
├── src/main/resources/
│   ├── application.yml                  local / test / cloud-run profiles (no dup spring: keys)
│   └── checkstyle/
│       ├── checkstyle.xml               Google Java Style, 120-char limit, SLF4J enforcement
│       └── suppressions.xml
│
└── src/test/java/com/db/macs3/ecomms/spectre/
    ├── translator/TermSyntaxTranslatorTest.java       All operators, all languages, edge cases,
    │                                                   the exact AND/AND-NOT worked examples above
    ├── hyperscan/HyperscanCompilerTest.java            Live Hyperscan compile validation + thread safety
    ├── service/LexiconCompileServiceTest.java          End-to-end translate→compile pipeline
    ├── service/LexiconCompileBundleServiceTest.java    Typed bundle endpoint, Natural Language + Regex
    ├── service/CsvCompileServiceTest.java               CSV parsing: header, BOM, quotes, multi-lang
    ├── controller/LexiconCompileControllerTest.java    MockMvc: JSON, GZIP, CSV, validation, health
    └── integration/MultiLanguageIntegrationTest.java   Real messages in 8 languages + emoji
```

---

## curl Examples

### Plain JSON request
```bash
curl -X POST http://localhost:8080/api/lexicon/compile \
  -H "Content-Type: application/json" \
  -H "Accept-Encoding: gzip" \
  -d @src/test/resources/sample-request.json \
  --compressed | python3 -m json.tool
```

### GZIP request + response
```bash
gzip -c src/test/resources/sample-request.json | \
curl -X POST http://localhost:8080/api/lexicon/compile \
  -H "Content-Type: application/json" \
  -H "Content-Encoding: gzip" \
  -H "Accept-Encoding: gzip" \
  --data-binary @- \
  --compressed | python3 -m json.tool
```

### CSV upload
```bash
curl -X POST http://localhost:8080/api/lexicon/compile/csv \
  -F "file=@src/test/resources/sample-lexicon.csv" \
  -F "ruleName=lexicon_research_1" \
  -H "Accept-Encoding: gzip" \
  --compressed | python3 -m json.tool
```

### Typed bundle request (Natural Language)
```bash
curl -X POST http://localhost:8080/api/lexicon/compile/bundle \
  -H "Content-Type: application/json" \
  -d '{
        "request_id": "550e8400-e29b-41d4-a716-446655440000",
        "lexiconRuleName": "lexicon_research_1",
        "termType": "Natural Language",
        "terms": [
          {"termId": "lexicon_research_1::1", "termDescription": "price AND NOT change"}
        ]
      }' \
  -o bundle.zip
```

---

## Running Tests

```bash
# All tests (Hyperscan native lib auto-extracted from JAR)
mvn test

# Specific test class
mvn test -Dtest=TermSyntaxTranslatorTest
mvn test -Dtest=MultiLanguageIntegrationTest
mvn test -Dtest=LexiconCompileControllerTest

# Coverage report (target/site/jacoco/index.html)
mvn verify
```

---

## Cloud Run Deployment

```bash
export PROJECT_ID=my-gcp-project
export REGION=us-central1
export IMAGE=gcr.io/${PROJECT_ID}/lexicon-compile-service

gcloud builds submit --tag ${IMAGE} .

gcloud run deploy lexicon-compile-service \
  --image=${IMAGE} \
  --region=${REGION} \
  --memory=2Gi \
  --cpu=2 \
  --min-instances=1 \
  --max-instances=10 \
  --concurrency=80 \
  --set-env-vars="SPRING_PROFILES_ACTIVE=cloud-run" \
  --allow-unauthenticated
```
