package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.hyperscan.HyperscanCompiler;
import com.db.macs3.ecomms.spectre.model.CompileRequest;
import com.db.macs3.ecomms.spectre.model.CompileResponse;
import com.db.macs3.ecomms.spectre.model.InvalidTermIdException;
import com.db.macs3.ecomms.spectre.model.TermCompilationResult;
import com.db.macs3.ecomms.spectre.model.TermType;
import com.db.macs3.ecomms.spectre.model.TypedCompileRequest;
import com.db.macs3.ecomms.spectre.util.ScriptDetector;
import com.gliwka.hyperscan.wrapper.Expression;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Orchestrates {@code POST /api/lexicon/compile/bundle}.
 *
 * <p>Each request carries one root-level {@link TermType}:
 * <ul>
 *   <li>{@link TermType#NATURAL_LANGUAGE} — translated via the existing
 *       {@code TermSyntaxTranslator} pipeline, by delegating straight to
 *       {@link LexiconCompileService#compileTerm}. Identical behaviour to
 *       {@code /compile} for every Natural Language term.</li>
 *   <li>{@link TermType#REGEX} — the caller's {@code termDescription} is already
 *       a PCRE pattern. No translation step runs; the pattern is compiled
 *       as-is. Flags are still derived from the pattern's script content
 *       via {@link ScriptDetector} so non-Latin Regex-type patterns (e.g. a raw
 *       Korean or Arabic regex) get the correct UTF8/UCP flags.</li>
 * </ul>
 *
 * <p>After every term is resolved to PASS or FAILED, all PASS terms are
 * compiled into <b>one combined multi-pattern Hyperscan database</b> via
 * {@link HyperscanCompiler#compileCombinedDatabase}. The JSON summary
 * returned by {@link #buildBundle} is the same {@link CompileResponse}
 * / {@link TermCompilationResult} shape that {@code /compile} returns, with
 * one addition specific to this endpoint: {@code hyperscanExpressionId} —
 * see below and {@link TermCompilationResult} class Javadoc.
 *
 * <h2>Hyperscan expression id scheme: term number, not array position</h2>
 * <p>Every {@code termId} in this platform follows the convention
 * {@code <lexicon_rule_name>::<term_number>} (e.g. {@code lexicon_research_1::1}).
 * The expression id a term gets in the combined database is derived from
 * that term number — NOT the term's 0-based position in the request's
 * {@code terms} array. This matters because the {@code .hdb} file is often
 * consumed on its own (see the AND NOT section below): a downstream reader
 * that already knows a term by its number (from the lexicon rule definition
 * itself, independent of whatever order a particular compile request happened
 * to list terms in) can find it in the database without needing the JSON
 * response to map "index 3" back to "term number 7". Every {@code termId} in
 * a bundle request MUST end with {@code ::<n>} for a non-negative integer
 * {@code n}, and every {@code n} in one request must be unique — both are
 * validated for the WHOLE request before any term is compiled; see
 * {@link #validateTermIds} and {@link InvalidTermIdException}.
 *
 * <p>A term with no AND NOT exclusion and no decomposition (see below) gets
 * one {@link Expression} at {@code id = n}, its term number. FAILED terms
 * are simply absent from the combined database.
 *
 * <p><b>AND NOT terms, and terms too structurally complex for one pattern
 * ("Pattern is too large" — see {@code PatternComplexityAnalyzer} /
 * {@code PatternDecomposer}), compile into MULTIPLE expressions with one
 * reportable id.</b> Hyperscan cannot express "the exclusion pattern is
 * absent from the whole message" in a single pattern — there is no negative
 * lookaround. What CAN be expressed natively is a Hyperscan 5.0+ <i>logical
 * combination</i> ({@code HS_FLAG_COMBINATION}): a compiled expression whose
 * text is a boolean formula over OTHER expressions' ids (operators
 * {@code &}/{@code |}/{@code !}), which Hyperscan itself evaluates during
 * the scan and reports as a match only when the formula is true.
 *
 * <p>Every auxiliary expression a term needs beyond its own term number
 * (decomposition leaves, an exclusion pattern, a combination formula) is
 * assigned the NEXT available id from a simple sequential allocator starting
 * at {@code offset = (largest term number in this request) + 1} — see
 * {@link #computeIdOffset} — rather than a fixed arithmetic formula, since a
 * decomposed term can need an arbitrary number of leaf expressions, not a
 * fixed count. See {@link #addExpressions} for the complete combination-formula
 * construction, including why it deliberately never has one combination
 * expression reference another (a capability Hyperscan's own documented
 * examples never demonstrate, so this design does not rely on it).
 *
 * <p>The FINAL combination expression's id (when a term needs one) is this
 * term's {@code hyperscanExpressionId} — the ONE id a downstream consumer
 * needs to watch. Because every other expression a multi-expression term
 * produces is QUIET, a consumer that merely counts "any match on this
 * database = an alert" is automatically correct with no per-term
 * special-casing. This is what makes the {@code .hdb} file alone — with no
 * JSON in the loop — correct for a consumer like the Lexicon Scan Engine's
 * Dataproc job, which loads the database and scans directly against it.
 *
 * <p>See {@link HyperscanCompiler} class Javadoc for the underlying Hyperscan
 * combination mechanism and the wrapper-version dependency note, and the
 * project README's "AND NOT in the combined database" and "Hyperscan expression
 * ids are term numbers" sections for worked examples.
 */
@Service
public class LexiconCompileBundleService {

    private static final Logger log = LoggerFactory.getLogger(LexiconCompileBundleService.class);

    private final LexiconCompileService compileService;
    private final HyperscanCompiler     compiler;
    private final Counter               naturalLanguageTermCounter;
    private final Counter               regexTermCounter;
    private final Counter               databaseBuiltCounter;
    private final Counter               databaseFailedCounter;

    public LexiconCompileBundleService(LexiconCompileService compileService,
                                        HyperscanCompiler compiler,
                                        MeterRegistry meterRegistry) {
        this.compileService             = compileService;
        this.compiler                    = compiler;
        this.naturalLanguageTermCounter = meterRegistry.counter("lexicon.compile.bundle.natural_language");
        this.regexTermCounter            = meterRegistry.counter("lexicon.compile.bundle.regex");
        this.databaseBuiltCounter       = meterRegistry.counter("lexicon.compile.bundle.database.built");
        this.databaseFailedCounter      = meterRegistry.counter("lexicon.compile.bundle.database.failed");
    }

    /**
     * Compiles every term in the request and builds the combined Hyperscan
     * database from the PASS subset.
     *
     * <p>{@link TypedCompileRequest#getTermType()} is at the request root
     * level — all terms in a single request share the same term type. The
     * {@link TypedCompileRequest#isRegexType()} check is therefore performed
     * once on the request, not per-term.
     *
     * @param request validated typed-compile request
     * @return {@link CompileBundleResult} — JSON summary + optional database bytes
     */
    public CompileBundleResult buildBundle(TypedCompileRequest request) {
        long startTimeMs = System.currentTimeMillis();
        log.info("Compiling bundle: {} {} term(s) for rule '{}' (request_id={})",
                request.getTerms().size(), request.getTermType(),
                request.getLexiconRuleName(), request.getRequestId());

        // Every termId's term number is needed for its expression id — parsed
        // and validated for the WHOLE request before any term is compiled, so
        // a malformed or duplicate termId is rejected clearly up front rather
        // than corrupting the combined database with a Hyperscan id collision.
        Map<String, Integer> termNumberByTermId = validateTermIds(request);
        int idOffset = computeIdOffset(termNumberByTermId.values());
        HyperscanIdAllocator idAllocator = new HyperscanIdAllocator(idOffset);

        // termType is at the request root — the same branch applies to all terms.
        boolean isRegexType = request.isRegexType();
        boolean includeSom = request.isTrackMatchPosition();
        if (!includeSom) {
            log.info("request_id={}: trackMatchPosition=false — SOM_LEFTMOST omitted from every " +
                    "compiled expression in this bundle to reduce compile complexity", request.getRequestId());
        }

        List<TermCompilationResult> termResults      = new ArrayList<>(request.getTerms().size());
        List<Expression> passingExpressions          = new ArrayList<>(request.getTerms().size());

        for (TypedCompileRequest.TermInput termInput : request.getTerms()) {

            // Adapter: TermCompilationResult factories still require CompileRequest.TermInput.
            // riskDriverName is null — it is no longer part of the request or response.
            CompileRequest.TermInput termInputAdapter = new CompileRequest.TermInput(
                    termInput.termId(), termInput.termDescription(), null);

            TermCompilationResult termResult;
            if (isRegexType) {
                regexTermCounter.increment();
                termResult = compileRegexTerm(termInputAdapter);
            } else {
                naturalLanguageTermCounter.increment();
                termResult = compileService.compileTerm(termInputAdapter); // exact same pipeline as /compile
            }

            if (termResult.isPass()) {
                int termNumber = termNumberByTermId.get(termInput.termId());
                termResult = addExpressions(termResult, termNumber, idAllocator, passingExpressions, includeSom);
            }
            termResults.add(termResult);
        }

        log.info("Bundle compile done rule='{}': {}/{} PASS, {}ms",
                request.getLexiconRuleName(),
                termResults.stream().filter(TermCompilationResult::isPass).count(),
                termResults.size(),
                System.currentTimeMillis() - startTimeMs);

        // ofBundle includes request_id and termType; omits hyperscanVersion and processingTimeMs
        CompileResponse jsonResponse = CompileResponse.ofBundle(
                request.getRequestId(),
                request.getTermType(),
                request.getLexiconRuleName(),
                termResults);

        return buildDatabasePortion(jsonResponse, passingExpressions);
    }

    // ── Term id validation ───────────────────────────────────────────────────────

    /** Matches the platform-wide {@code <rule_name>::<term_number>} termId convention. */
    private static final Pattern TERM_ID_PATTERN = Pattern.compile("^.*::(\\d+)$");

    /**
     * Parses the term number out of every {@code termId} in {@code request}
     * and validates the WHOLE request before returning: every termId must
     * match {@link #TERM_ID_PATTERN}, and every parsed term number must be
     * unique within the request. A downstream Hyperscan id collision (two
     * terms compiled at the same expression id) would silently corrupt the
     * combined database — better to reject clearly here than debug that later.
     *
     * @return termId → term number, one entry per term in the request
     * @throws InvalidTermIdException naming every malformed or duplicate
     *                                 termId found, if any
     */
    private Map<String, Integer> validateTermIds(TypedCompileRequest request) {
        Map<String, Integer> termNumberByTermId = new LinkedHashMap<>();
        Map<Integer, List<String>> termIdsByNumber = new LinkedHashMap<>();
        List<String> malformed = new ArrayList<>();

        for (TypedCompileRequest.TermInput termInput : request.getTerms()) {
            String termId = termInput.termId();
            Matcher matcher = TERM_ID_PATTERN.matcher(termId);
            if (!matcher.matches()) {
                malformed.add(termId);
                continue;
            }
            int termNumber;
            try {
                termNumber = Integer.parseInt(matcher.group(1));
            } catch (NumberFormatException tooLarge) {
                // Digits matched \d+ but overflowed int (e.g. 20+ digits) — still malformed.
                malformed.add(termId);
                continue;
            }
            termNumberByTermId.put(termId, termNumber);
            termIdsByNumber.computeIfAbsent(termNumber, k -> new ArrayList<>()).add(termId);
        }

        if (!malformed.isEmpty()) {
            throw new InvalidTermIdException(
                    "termId must end with '::<n>' where n is a non-negative integer (the platform's "
                    + "term-number convention, e.g. 'lexicon_rule_name::1') — required for /compile/bundle's "
                    + "Hyperscan expression id scheme. Malformed termId(s): " + malformed);
        }

        List<String> duplicateDetails = termIdsByNumber.entrySet().stream()
                .filter(e -> e.getValue().size() > 1)
                .map(e -> "term number " + e.getKey() + " used by " + e.getValue())
                .toList();
        if (!duplicateDetails.isEmpty()) {
            throw new InvalidTermIdException(
                    "Every termId's term number must be unique within a /compile/bundle request — "
                    + "two terms sharing a term number would collide at the same Hyperscan expression id. "
                    + "Duplicate(s): " + duplicateDetails);
        }

        return termNumberByTermId;
    }

    /**
     * The exclusion/combination/decomposition-leaf id ranges must never
     * overlap a real term number, however sparse or large those term
     * numbers are. {@code offset = (largest term number) + 1} is the first
     * id available for every auxiliary expression this request needs; every
     * subsequent auxiliary id is handed out sequentially from there by
     * {@link HyperscanIdAllocator} — see {@link #buildBundle}'s expression
     * construction. Because auxiliary ids start strictly above the largest
     * real term number and are handed out one at a time (never reused),
     * they can never collide with a real term number or with each other,
     * regardless of how many decomposition leaves any given term needs.
     */
    private int computeIdOffset(java.util.Collection<Integer> termNumbers) {
        return termNumbers.stream().mapToInt(Integer::intValue).max().orElse(0) + 1;
    }

    /**
     * Hands out sequentially increasing expression ids for auxiliary
     * (non-term-number) expressions within one bundle request — decomposition
     * leaves, exclusion patterns, and combination expressions. Starting from
     * {@link #computeIdOffset}, every id this allocator returns is
     * guaranteed distinct from every real term number and from every other
     * id it has already handed out.
     */
    private static final class HyperscanIdAllocator {
        private int nextId;
        HyperscanIdAllocator(int startId) { this.nextId = startId; }
        int allocate() { return nextId++; }
    }

    // ── Expression construction ─────────────────────────────────────────────────

    /**
     * Compiles this term's required (and, if present, excluded) side into
     * the combined database, choosing the simplest applicable structure and
     * returning the term result with {@code hyperscanExpressionId} set to
     * the ONE id a downstream consumer should watch.
     *
     * <h2>The flat-formula design, and why it avoids nested combinations</h2>
     * <p>Hyperscan's documented logical-combination syntax and Intel's own
     * official example ({@code "(101 & 102 & 103) | (104 & !105)"}, from
     * "Logical Combinations of Regular Expressions in Hyperscan") show a
     * combination expression's formula referencing plain pattern ids
     * directly, with arbitrary boolean structure and parenthesisation —
     * but never one combination expression referencing another combination
     * expression's id. Rather than rely on nested combinations working
     * (unverified — worth flagging explicitly, not assuming), this method
     * builds AT MOST ONE combination expression per term, whose formula
     * references only plain (non-combination) ids — every decomposition
     * leaf, the required pattern if not decomposed, and the exclusion
     * pattern if not decomposed. Correctness for a decomposed excluded side
     * requires applying De Morgan's law explicitly: decomposition combines
     * leaves with AND ("all parts found" — see {@code PatternDecomposer}),
     * so the negation needed for AND NOT's excluded side is
     * {@code NOT(E1 AND E2 AND ... AND Em) = (NOT E1) OR (NOT E2) OR ... OR (NOT Em)},
     * not a naive AND of negations (which would incorrectly exclude the term
     * even when only ONE decomposed exclusion leaf was absent, rather than ALL of them).
     *
     * <table>
     * <caption>Combination formula by case (R = required id(s), E = excluded id(s))</caption>
     * <tr><td>Plain, not decomposed</td><td>no combination — {@code id = termNumber} directly, as before</td></tr>
     * <tr><td>Plain, decomposed</td><td>{@code (R1&R2&...&Rn)}</td></tr>
     * <tr><td>AND NOT, neither side decomposed</td><td>{@code (R&!E)} — identical to the pre-decomposition format</td></tr>
     * <tr><td>AND NOT, required decomposed</td><td>{@code (R1&R2&...&Rn&!E)}</td></tr>
     * <tr><td>AND NOT, excluded decomposed</td><td>{@code (R&(!E1|!E2|...|!Em))}</td></tr>
     * <tr><td>AND NOT, both decomposed</td><td>{@code (R1&...&Rn&(!E1|...|!Em))}</td></tr>
     * </table>
     *
     * @param includeSom whether to include SOM_LEFTMOST on every sub-expression that
     *                    feeds a combination — see {@link TypedCompileRequest#trackMatchPosition}.
     *                    A plain, non-combination term's single expression always includes it
     *                    regardless (matching pre-existing behaviour) unless this is false.
     */
    private TermCompilationResult addExpressions(TermCompilationResult termResult, int termNumber,
                                                   HyperscanIdAllocator idAllocator,
                                                   List<Expression> passingExpressions, boolean includeSom) {
        boolean needsCombination = termResult.requiresExclusionCheck() || termResult.requiresDecomposedMatching();

        if (!needsCombination) {
            // Simplest, most common case — unchanged from before decomposition existed.
            passingExpressions.add(new Expression(
                    termResult.translatedPattern(),
                    compiler.toExpressionFlags(termResult.hyperscanFlags(), includeSom),
                    termNumber));
            return termResult.withHyperscanExpressionId(termNumber);
        }

        List<Integer> requiredIds = addSide(
                termResult.requiresDecomposedMatching(), termResult.decomposedPatterns(),
                termResult.translatedPattern(), termNumber,
                idAllocator, passingExpressions, termResult.hyperscanFlags(), includeSom);
        String requiredFormula = joinWithAnd(requiredIds);

        String combinationFormula;
        if (termResult.requiresExclusionCheck()) {
            List<Integer> excludedIds = addSide(
                    termResult.excludedRequiresDecomposedMatching(), termResult.excludedDecomposedPatterns(),
                    termResult.exclusionPattern(), null,
                    idAllocator, passingExpressions, termResult.hyperscanFlags(), includeSom);
            String excludedNegated = excludedIds.size() == 1
                    ? "!" + excludedIds.get(0)
                    : "(" + excludedIds.stream().map(id -> "!" + id).collect(java.util.stream.Collectors.joining("|")) + ")";
            combinationFormula = "(" + requiredFormula + "&" + excludedNegated + ")";
        } else {
            combinationFormula = "(" + requiredFormula + ")";
        }

        int combinationId = idAllocator.allocate();
        passingExpressions.add(new Expression(combinationFormula, compiler.toCombinationExpressionFlags(), combinationId));
        return termResult.withHyperscanExpressionId(combinationId);
    }

    /**
     * Compiles one side (required or excluded) into the combined database as
     * either a single QUIET expression (not decomposed — {@code naturalId}
     * if given, e.g. the term number for the required side; an allocated id
     * otherwise) or a set of QUIET leaf expressions (decomposed), returning
     * the id(s) the caller's combination formula should reference.
     *
     * @param naturalId the id to use when not decomposed AND a natural one is
     *                   available (the term number, for the required side);
     *                   null to always allocate (the excluded side never has
     *                   a natural id of its own)
     */
    private List<Integer> addSide(boolean decomposed, List<String> decomposedPatterns,
                                   String singlePattern, Integer naturalId,
                                   HyperscanIdAllocator idAllocator, List<Expression> passingExpressions,
                                   int hyperscanFlags, boolean includeSom) {
        if (!decomposed) {
            int id = naturalId != null ? naturalId : idAllocator.allocate();
            passingExpressions.add(new Expression(
                    singlePattern, compiler.toSubExpressionFlags(hyperscanFlags, includeSom), id));
            return List.of(id);
        }
        List<Integer> ids = new ArrayList<>(decomposedPatterns.size());
        for (String leafPattern : decomposedPatterns) {
            int id = idAllocator.allocate();
            passingExpressions.add(new Expression(
                    leafPattern, compiler.toSubExpressionFlags(hyperscanFlags, includeSom), id));
            ids.add(id);
        }
        return ids;
    }

    private static String joinWithAnd(List<Integer> ids) {
        return ids.stream().map(String::valueOf).collect(java.util.stream.Collectors.joining("&"));
    }

    // ── Regex-type term handling ─────────────────────────────────────────────

    /**
     * Compiles a {@link TermType#REGEX} term: the pattern is the caller's
     * {@code termDescription} verbatim — no operator-language translation.
     *
     * <p>Flags are still derived automatically via {@link ScriptDetector} so
     * a raw non-Latin regex (e.g. a hand-written Korean or Arabic pattern)
     * gets UTF8/UCP without the caller having to know Hyperscan's flag
     * bitmask values. {@code requiresExclusionCheck} is always {@code false}
     * for Regex-type terms — AND NOT is part of the Natural Language operator
     * language's syntax; an arbitrary caller-supplied regex has no such
     * two-pattern exclusion contract to participate in.
     */
    private TermCompilationResult compileRegexTerm(CompileRequest.TermInput termInputAdapter) {
        String pattern = termInputAdapter.termDescription();
        int hyperscanFlags = ScriptDetector.detect(pattern).recommendedHsFlags();

        HyperscanCompiler.ValidationResult validation = compiler.validate(pattern, hyperscanFlags);

        return validation.isPass()
                ? TermCompilationResult.pass(termInputAdapter, pattern, hyperscanFlags)
                : TermCompilationResult.failedHyperscan(
                        termInputAdapter, pattern, validation.errorMessage(), hyperscanFlags);
    }

    // ── Combined database ────────────────────────────────────────────────────

    private CompileBundleResult buildDatabasePortion(CompileResponse jsonResponse,
                                                       List<Expression> passingExpressions) {
        if (passingExpressions.isEmpty()) {
            log.warn("No PASS terms for rule '{}' — no combined database will be built",
                    jsonResponse.lexiconRuleName());
            return new CompileBundleResult(jsonResponse, null,
                    "No Hyperscan database file was produced because zero terms reached "
                  + "PASS status. See the JSON results for per-term compilationStatus and "
                  + "errorLog/translationError details.");
        }

        HyperscanCompiler.CombinedCompileResult combinedResult =
                compiler.compileCombinedDatabase(passingExpressions);

        if (combinedResult.success()) {
            databaseBuiltCounter.increment();
            return new CompileBundleResult(jsonResponse, combinedResult.databaseBytes(), null);
        }

        databaseFailedCounter.increment();
        log.error("Combined database compile FAILED for rule '{}': {} (failedExpressionId={})",
                jsonResponse.lexiconRuleName(), combinedResult.errorMessage(), combinedResult.failedExpressionId());

        String explanation = "No Hyperscan database file was produced.\nReason: "
                + combinedResult.errorMessage()
                + describeFailedExpression(jsonResponse, combinedResult.failedExpressionId());
        return new CompileBundleResult(jsonResponse, null, explanation);
    }

    /**
     * Resolves {@code failedExpressionId} (a term-number-based Hyperscan id —
     * see class Javadoc) back to the specific term that caused it, by
     * matching against {@link TermCompilationResult#hyperscanExpressionId()}
     * rather than treating it as an array position.
     */
    private String describeFailedExpression(CompileResponse jsonResponse, Integer failedExpressionId) {
        if (failedExpressionId == null) {
            return "";
        }
        return jsonResponse.results().stream()
                .filter(r -> failedExpressionId.equals(r.hyperscanExpressionId()))
                .findFirst()
                .map(r -> "\nThe term '" + r.termId() + "' (\"" + r.termDescription() + "\") caused the combined "
                        + "compile to fail at Hyperscan expression id " + failedExpressionId
                        + ", even though it passed individual validation. See the JSON results for that term's details.")
                .orElse("\nThe failing Hyperscan expression id was " + failedExpressionId
                        + ", but no term in this response maps to it — this should not happen and indicates a bug"
                        + " in the id-assignment logic.");
    }

    // ── Result carrier ───────────────────────────────────────────────────────

    /**
     * Carries the two zip-file payloads back to the controller.
     *
     * @param jsonResponse            identical shape to {@code /compile}'s response —
     *                                this is what gets written as the zip's JSON entry
     * @param hyperscanDatabaseBytes  the combined {@code .hdb} file content, or
     *                                {@code null} when no database could be built
     * @param databaseNote            explanation written into {@code NO_DATABASE.txt}
     *                                when {@code hyperscanDatabaseBytes} is null;
     *                                null when a database was built successfully
     */
    public record CompileBundleResult(
            CompileResponse jsonResponse,
            byte[]          hyperscanDatabaseBytes,
            String          databaseNote
    ) {
        /** @return true when a combined Hyperscan database was produced. */
        public boolean hasDatabase() {
            return hyperscanDatabaseBytes != null && hyperscanDatabaseBytes.length > 0;
        }
    }
}
