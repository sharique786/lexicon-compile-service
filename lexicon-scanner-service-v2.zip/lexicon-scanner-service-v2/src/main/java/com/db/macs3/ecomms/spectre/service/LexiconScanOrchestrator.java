package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.client.LexiconCompileClient;
import com.db.macs3.ecomms.spectre.model.DisclaimerSource;
import com.db.macs3.ecomms.spectre.model.Models.CompiledTerm;
import com.db.macs3.ecomms.spectre.model.Models.CompileServiceResponse;
import com.db.macs3.ecomms.spectre.model.Models.DisclaimerSpan;
import com.db.macs3.ecomms.spectre.model.Models.MatchHighlight;
import com.db.macs3.ecomms.spectre.model.Models.MessageScanResult;
import com.db.macs3.ecomms.spectre.model.Models.PatternValidationResult;
import com.db.macs3.ecomms.spectre.model.Models.RawMatch;
import com.db.macs3.ecomms.spectre.model.Models.ScanResponse;
import com.db.macs3.ecomms.spectre.model.Models.StrippedMessage;
import com.db.macs3.ecomms.spectre.model.Models.TermScanResult;
import com.db.macs3.ecomms.spectre.model.MessageSource;
import com.db.macs3.ecomms.spectre.model.TermSource;
import com.db.macs3.ecomms.spectre.model.TermType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Orchestrates the full Lexicon Scanner pipeline for one or more messages,
 * scanned against one shared term set and one shared disclaimer set.
 *
 * <ol>
 *   <li>Resolves lexicon term(s) into {@link CompiledTerm}s ONCE — see
 *       {@link #resolveNaturalLanguageTerms} / {@link #resolveRegexTerms},
 *       unchanged from the single-message design.</li>
 *   <li>Resolves disclaimer text(s) ONCE from {@link DisclaimerSource} — optional;
 *       {@link DisclaimerSource.None} skips disclaimer detection entirely.</li>
 *   <li>Resolves the message(s) to scan from {@link MessageSource} — either the
 *       single pasted-text message, or one message per uploaded file.</li>
 *   <li>For EACH message independently: strips HTML
 *       ({@link HtmlStrippingService}), detects disclaimer occurrences
 *       ({@link DisclaimerDetectionService}), scans Hyperscan, maps matches
 *       back to original-text coordinates, flags each match
 *       {@link MatchHighlight#inDisclaimer()}, and builds one
 *       {@link MessageScanResult}.</li>
 *   <li>Aggregates every message's results into one {@link ScanResponse}.</li>
 * </ol>
 *
 * <h2>Disclaimer exclusion from alerting</h2>
 * <p>A match found ONLY within a detected disclaimer region does not count
 * toward {@link TermScanResult#hasMatches()} (see
 * {@link MatchHighlight#countsTowardAlert()}) — the requirement that
 * boilerplate disclaimer text (e.g. "confidential" in a standard footer)
 * must never trigger a false alert, even when the same word also appears
 * meaningfully elsewhere in the same message. The match is still recorded
 * and shown on the UI (highlighted in a visually distinct style — see
 * {@link MatchHighlightService}) with a "not an alert" note, rather than
 * being silently discarded.
 *
 * <h2>AND / NOT post-filter note</h2>
 * <p>Terms with {@code requiresAndPostFilter=true} use an OR pre-scan pattern
 * (e.g. {@code (?:insider|trading)} for {@code insider AND trading}). The
 * scanner records all OR matches but adds an informational note explaining that
 * full AND/NOT semantics are enforced by the alerting scan engine, not here.
 * This only ever applies to {@code NATURAL_LANGUAGE} terms — {@code REGEX}
 * terms have no operator-language semantics to post-filter.
 */
@Service
public class LexiconScanOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(LexiconScanOrchestrator.class);

    private static final String POST_FILTER_NOTE =
            "AND/NOT semantics: this result shows OR pre-scan matches. "
            + "Full AND/NOT verification is applied by the alerting scan engine at runtime.";

    private static final String SINGLE_TEXT_MESSAGE_ID = "Pasted Message";

    private final LexiconCompileClient compileClient;
    private final HyperscanScanService scanService;
    private final MatchHighlightService highlightService;
    private final HtmlStrippingService htmlStrippingService;
    private final CsvParserService csvParserService;
    private final DisclaimerDetectionService disclaimerDetectionService;

    public LexiconScanOrchestrator(LexiconCompileClient compileClient,
                                    HyperscanScanService scanService,
                                    MatchHighlightService highlightService,
                                    HtmlStrippingService htmlStrippingService,
                                    CsvParserService csvParserService,
                                    DisclaimerDetectionService disclaimerDetectionService) {
        this.compileClient = compileClient;
        this.scanService = scanService;
        this.highlightService = highlightService;
        this.htmlStrippingService = htmlStrippingService;
        this.csvParserService = csvParserService;
        this.disclaimerDetectionService = disclaimerDetectionService;
    }

    /**
     * Runs the full scan pipeline for the given lexicon term source, message
     * source, and (optional) disclaimer source.
     *
     * @param termType         whether the term(s) are Natural Language (translated via
     *                         the Compile Service) or already-valid Regex (compiled directly)
     * @param termSource       the term(s) themselves — typed text or an uploaded CSV file
     * @param messageSource    the message(s) to scan — pasted text, or one or more uploaded files
     * @param disclaimerSource disclaimer text(s) to exclude from alerting — optional
     * @param ruleName         optional rule name for the compile request
     * @return fully populated {@link ScanResponse}, covering every scanned message
     */
    public ScanResponse scan(TermType termType, TermSource termSource, MessageSource messageSource,
                              DisclaimerSource disclaimerSource, String ruleName) {
        String scanId = UUID.randomUUID().toString();
        long startMs = System.currentTimeMillis();
        List<String> warnings = new ArrayList<>();

        try {
            List<MessageSource.NamedMessageText> messages = resolveMessages(messageSource);
            List<String> disclaimerTexts = resolveDisclaimerTexts(disclaimerSource);

            log.info("Starting scan session: scanId={}, termType={}, messageCount={}, disclaimerCount={}",
                    scanId, termType, messages.size(), disclaimerTexts.size());

            // ── Terms are resolved ONCE — shared across every message ──────────────
            TermResolution resolution = (termType == TermType.REGEX)
                    ? resolveRegexTerms(termSource, warnings)
                    : resolveNaturalLanguageTerms(termSource, ruleName, warnings);

            int totalTerms = resolution.allResults.size();
            log.info("scanId={}: {} term(s) ready for Hyperscan (of {} submitted)",
                    scanId, resolution.compiledTerms.size(), totalTerms);

            // ── Scan each message independently against the SAME compiled terms ────
            List<MessageScanResult> messageResults = new ArrayList<>(messages.size());
            for (MessageSource.NamedMessageText message : messages) {
                messageResults.add(scanOneMessage(message, resolution, termType, disclaimerTexts));
            }

            int failedTerms = (int) resolution.allResults.stream().filter(r -> !r.isPass()).count();
            long elapsedMs = System.currentTimeMillis() - startMs;

            log.info("Scan complete: scanId={}, messages={}, elapsed={}ms", scanId, messages.size(), elapsedMs);

            return ScanResponse.success(
                    scanId, elapsedMs, termType.jsonValue(),
                    totalTerms, disclaimerTexts.size(), failedTerms,
                    messageResults, warnings);

        } catch (Exception e) {
            log.error("Scan pipeline failed: scanId={}, error={}", scanId, e.getMessage(), e);
            return ScanResponse.error(scanId, "Scan failed: " + e.getMessage());
        }
    }

    // ── Per-message scanning ─────────────────────────────────────────────────────

    private MessageScanResult scanOneMessage(MessageSource.NamedMessageText message, TermResolution resolution,
                                              TermType termType, List<String> disclaimerTexts) {
        StrippedMessage strippedMessage = htmlStrippingService.strip(message.text());
        log.debug("message='{}': stripped {} chars -> {} chars",
                message.messageId(), message.text().length(), strippedMessage.strippedText().length());

        List<DisclaimerSpan> disclaimerSpans =
                disclaimerDetectionService.detectDisclaimers(strippedMessage, disclaimerTexts);

        List<RawMatch> rawMatches = resolution.compiledTerms.isEmpty()
                ? Collections.emptyList()
                : scanService.compileAndScan(resolution.compiledTerms, strippedMessage.strippedText());

        Map<Integer, List<MatchHighlight>> matchesByIndex =
                highlightService.groupMatchesByTerm(rawMatches, resolution.compiledTerms, strippedMessage);

        // Apply disclaimer flags to every match BEFORE building term results / HTML,
        // so both downstream steps see the final, correct inDisclaimer value.
        Map<Integer, List<MatchHighlight>> flaggedMatchesByIndex = matchesByIndex.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> disclaimerDetectionService.applyDisclaimerFlags(e.getValue(), disclaimerSpans)));

        List<TermScanResult> termResults = buildTermResults(
                resolution.allResults, resolution.compiledTerms, flaggedMatchesByIndex, termType);

        List<MatchHighlight> allHighlights = flaggedMatchesByIndex.values().stream()
                .flatMap(List::stream)
                .toList();
        String htmlHighlighted = highlightService.buildHighlightedHtml(message.text(), allHighlights);

        int matchedTerms = (int) termResults.stream().filter(TermScanResult::hasMatches).count();
        boolean hasMatches = matchedTerms > 0;

        return new MessageScanResult(
                message.messageId(), message.text(), htmlHighlighted,
                disclaimerSpans, termResults, matchedTerms, hasMatches);
    }

    // ── Message resolution ───────────────────────────────────────────────────────

    /**
     * Extracts the resolved message list from {@link MessageSource}. File
     * reading and per-message length validation already happened in
     * {@code ScanController} — see {@link MessageSource} class Javadoc for
     * why that split exists — so this is a plain, exception-free extraction.
     */
    private List<MessageSource.NamedMessageText> resolveMessages(MessageSource source) {
        return switch (source) {
            case MessageSource.SingleText text ->
                    List.of(new MessageSource.NamedMessageText(SINGLE_TEXT_MESSAGE_ID, text.text()));
            case MessageSource.MultipleMessages messages -> messages.messages();
        };
    }

    // ── Disclaimer resolution ────────────────────────────────────────────────────

    /**
     * Resolves disclaimer text(s) into a flat list, reusing
     * {@link CsvParserService} unchanged for the CSV case — a disclaimer CSV
     * is read exactly like a lexicon term CSV (same two-column shape), just
     * interpreted as disclaimer text rather than a term description.
     */
    private List<String> resolveDisclaimerTexts(DisclaimerSource source) {
        return switch (source) {
            case DisclaimerSource.None ignored -> List.of();
            case DisclaimerSource.TextDisclaimers text -> text.disclaimerTexts();
            case DisclaimerSource.CsvFile csv -> csvParserService.parseTermDescriptions(csv.file());
        };
    }

    // ── Term resolution: NATURAL_LANGUAGE ───────────────────────────────────────

    /**
     * Resolves Natural Language terms by calling the Lexicon Compile Service —
     * {@code /compile} for typed text, {@code /compile/csv} for an uploaded
     * CSV file (forwarded as-is, never parsed locally).
     */
    private TermResolution resolveNaturalLanguageTerms(TermSource termSource, String ruleName,
                                                         List<String> warnings) {
        CompileServiceResponse compileResp = switch (termSource) {
            case TermSource.TextTerms text -> compileClient.compile(text.descriptions(), ruleName);
            case TermSource.CsvFile csv -> compileClient.compileCsv(csv.file(), ruleName);
        };

        if (compileResp.hasFailures()) {
            long failedCount = compileResp.results().stream().filter(r -> !r.isPass()).count();
            warnings.add(failedCount + " term(s) failed pattern compilation and were skipped.");
            log.warn("{} Natural Language term(s) failed compilation", failedCount);
        }

        AtomicInteger exprIndex = new AtomicInteger(0);
        List<CompiledTerm> compiledTerms = compileResp.results().stream()
                .filter(CompileServiceResponse.TermResult::isPass)
                .map(r -> new CompiledTerm(
                        r.termId(), r.termDescription(),
                        r.translatedPattern(), r.hsFlags(),
                        r.requiresAndPostFilter(),
                        exprIndex.getAndIncrement()))
                .toList();

        return new TermResolution(compileResp.results(), compiledTerms);
    }

    // ── Term resolution: REGEX ───────────────────────────────────────────────────

    /**
     * Resolves Regex terms directly against Hyperscan — no Compile Service
     * call. Each term is validated INDIVIDUALLY first
     * ({@link HyperscanScanService#validatePattern}) so one bad regex in a
     * CSV batch fails only that term, not the whole scan.
     */
    private TermResolution resolveRegexTerms(TermSource termSource, List<String> warnings) {
        List<String> rawTerms = switch (termSource) {
            case TermSource.TextTerms text -> text.descriptions();
            case TermSource.CsvFile csv -> csvParserService.parseTermDescriptions(csv.file());
        };

        List<CompileServiceResponse.TermResult> allResults = new ArrayList<>(rawTerms.size());
        List<CompiledTerm> compiledTerms = new ArrayList<>(rawTerms.size());
        int exprIndex = 0;

        for (int i = 0; i < rawTerms.size(); i++) {
            String pattern = rawTerms.get(i).strip();
            String termId = "regex::" + (i + 1);

            PatternValidationResult validation =
                    scanService.validatePattern(pattern, HyperscanScanService.HS_FLAGS_REGEX_DEFAULT);

            if (validation.pass()) {
                allResults.add(new CompileServiceResponse.TermResult(
                        termId, pattern, null, "PASS", pattern,
                        HyperscanScanService.HS_FLAGS_REGEX_DEFAULT, false, null, null, Instant.now()));
                compiledTerms.add(new CompiledTerm(
                        termId, pattern, pattern,
                        HyperscanScanService.HS_FLAGS_REGEX_DEFAULT, false, exprIndex++));
            } else {
                allResults.add(new CompileServiceResponse.TermResult(
                        termId, pattern, null, "FAILED", null,
                        0, false, validation.errorMessage(), null, Instant.now()));
                log.warn("Regex term rejected by Hyperscan: '{}' — {}", pattern, validation.errorMessage());
            }
        }

        long failedCount = allResults.stream().filter(r -> !r.isPass()).count();
        if (failedCount > 0) {
            warnings.add(failedCount + " regex term(s) were rejected by Hyperscan and were skipped.");
        }

        return new TermResolution(allResults, compiledTerms);
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /** Bundles the full per-term result list (PASS + FAILED) with the PASS-only compiled subset. */
    private record TermResolution(
            List<CompileServiceResponse.TermResult> allResults,
            List<CompiledTerm> compiledTerms
    ) {}

    /**
     * Builds the final list of {@link TermScanResult} records for ONE
     * message — one per term submitted, regardless of whether it compiled
     * or matched.
     *
     * @param allResults     all term results (PASS and FAILED, from either resolution path)
     * @param compiledTerms  only the PASS terms, with their expression indices
     * @param matchesByIndex disclaimer-flagged highlights keyed by expression index, for THIS message
     * @param termType       the term type this batch was resolved under (affects the AND/NOT note)
     */
    private List<TermScanResult> buildTermResults(
            List<CompileServiceResponse.TermResult> allResults,
            List<CompiledTerm> compiledTerms,
            Map<Integer, List<MatchHighlight>> matchesByIndex,
            TermType termType) {

        Map<String, CompiledTerm> compiledByTermId = compiledTerms.stream()
                .collect(Collectors.toMap(CompiledTerm::termId, ct -> ct));

        return allResults.stream().map(result -> {

            if (!result.isPass()) {
                String error = buildError(result, termType);
                return new TermScanResult(
                        result.termId(), result.termDescription(),
                        null, "FAILED", false,
                        List.of(), false, false, error, null);
            }

            CompiledTerm ct = compiledByTermId.get(result.termId());
            List<MatchHighlight> highlights = ct != null
                    ? matchesByIndex.getOrDefault(ct.expressionIndex(), List.of())
                    : List.of();

            boolean hasAlertWorthyMatches = highlights.stream().anyMatch(MatchHighlight::countsTowardAlert);
            boolean hasDisclaimerOnlyMatches = !highlights.isEmpty() && !hasAlertWorthyMatches;

            String postFilterNote = (termType == TermType.NATURAL_LANGUAGE && result.requiresAndPostFilter())
                    ? POST_FILTER_NOTE : null;

            return new TermScanResult(
                    result.termId(), result.termDescription(),
                    result.translatedPattern(), "PASS",
                    result.requiresAndPostFilter(),
                    highlights, hasAlertWorthyMatches, hasDisclaimerOnlyMatches,
                    null, postFilterNote);
        }).toList();
    }

    private String buildError(CompileServiceResponse.TermResult result, TermType termType) {
        if (termType == TermType.REGEX) {
            return result.errorLog() != null && !result.errorLog().isBlank()
                    ? result.errorLog() : "Unknown Hyperscan validation failure";
        }
        if (result.translationError() != null && !result.translationError().isBlank()) {
            return "Translation error: " + result.translationError();
        }
        if (result.errorLog() != null && !result.errorLog().isBlank()) {
            return "Hyperscan error: " + result.errorLog();
        }
        return "Unknown compilation failure";
    }
}
