package com.db.macs3.ecomms.spectre.engine;

import com.db.macs3.ecomms.spectre.model.FeatureDecisionRow;
import com.db.macs3.ecomms.spectre.model.ScanOutputRow;
import com.db.macs3.ecomms.spectre.model.ScanEngineArgs;
import com.db.macs3.ecomms.spectre.reader.AvroMessageReader;
import com.db.macs3.ecomms.spectre.reader.BigQueryViewReader;
import com.db.macs3.ecomms.spectre.reader.GcsHyperscanDatabaseLoader;
import com.db.macs3.ecomms.spectre.writer.BigQueryOutputWriter;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

import static org.apache.spark.sql.functions.*;

/**
 * Main orchestrator for the Lexicon Scan Engine Spark job.
 *
 * <p>Coordinates the entire pipeline:
 * <ol>
 *   <li>Create / read the BigQuery pre-computed join view</li>
 *   <li>Load Hyperscan .hdb files from GCS and broadcast them to executors</li>
 *   <li>Read and filter AVRO message files from GCS</li>
 *   <li>Join messages with their feature decisions</li>
 *   <li>Run the scan using {@code mapPartitions} with {@link LexiconScanPartitionFunction}</li>
 *   <li>Write results to BigQuery output tables</li>
 * </ol>
 *
 * <h2>Spark job flow (driver)</h2>
 * <pre>
 * featureDecisionDS  ←── BQ view (feature-master ⋈ language-feature-decision)
 *     │
 *     ├── collect featureNames → load .hdb bytes from GCS → Broadcast
 *     ├── collect messageIds  → Broadcast for AVRO filter
 *     │
 * messageDS          ←── AVRO files (filtered by messageIds, projected)
 *     │
 *     ├── group featureDecisionDS by message_id (collect_list)
 *     └── join with messageDS on message_id
 *             │
 *             └── mapPartitions → LexiconScanPartitionFunction
 *                     │
 *                     └── write to BQ
 * </pre>
 *
 * <h2>Memory considerations</h2>
 * <ul>
 *   <li>Feature decisions are collected to driver (small data — typically &lt;1M rows)</li>
 *   <li>Message IDs are broadcast (mid-size set — typically &lt;10M IDs)</li>
 *   <li>HDB bytes are broadcast (large data — may be several hundred MB total;
 *       check {@link GcsHyperscanDatabaseLoader#totalSizeMb} before broadcasting)</li>
 * </ul>
 */
@Service
public class LexiconScanEngine {

    private static final Logger log = LoggerFactory.getLogger(LexiconScanEngine.class);

    private final BigQueryViewReader         bqViewReader;
    private final GcsHyperscanDatabaseLoader hdbLoader;
    private final AvroMessageReader          avroReader;
    private final BigQueryOutputWriter       bqWriter;

    @Autowired
    public LexiconScanEngine(BigQueryViewReader bqViewReader,
                               GcsHyperscanDatabaseLoader hdbLoader,
                               AvroMessageReader avroReader,
                               BigQueryOutputWriter bqWriter) {
        this.bqViewReader = bqViewReader;
        this.hdbLoader    = hdbLoader;
        this.avroReader   = avroReader;
        this.bqWriter     = bqWriter;
    }

    /**
     * Executes the full scan pipeline.
     *
     * @param spark the active SparkSession
     * @param args  parsed runtime arguments from the Airflow DAG
     */
    public void run(SparkSession spark, ScanEngineArgs args) {
        Timestamp jobStart = Timestamp.from(Instant.now());
        log.info("Lexicon Scan Engine starting: {}", args);

        JavaSparkContext jsc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        try {
            // ── Phase 1: Read feature decisions from BigQuery view ───────────
            log.info("Phase 1: Reading feature decisions from BigQuery view");
            Dataset<FeatureDecisionRow> featureDecisionDS =
                    bqViewReader.createViewAndRead(spark, args);
            featureDecisionDS.cache(); // Small dataset — cache to avoid re-reading
            long featureRowCount = featureDecisionDS.count();
            log.info("Feature decisions loaded: {} rows", featureRowCount);

            if (featureRowCount == 0) {
                log.warn("No feature decisions found for process_id={}. Job complete (no-op).",
                         args.getProcessId());
                return;
            }

            // Collect distinct feature names to load the right .hdb files
            Set<String> featureNames = new HashSet<>(
                featureDecisionDS.select("featureName")
                                 .distinct()
                                 .as(Encoders.STRING())
                                 .collectAsList()
            );
            log.info("Distinct features to load: {} ({})", featureNames.size(), featureNames);

            // Collect distinct message IDs for AVRO file filtering
            Set<String> relevantMessageIds = new HashSet<>(
                featureDecisionDS.select("messageId")
                                 .distinct()
                                 .as(Encoders.STRING())
                                 .collectAsList()
            );
            log.info("Distinct message IDs to process: {}", relevantMessageIds.size());

            // ── Phase 2: Load .hdb files from GCS and broadcast ──────────────
            log.info("Phase 2: Loading Hyperscan .hdb files from GCS");
            Map<String, byte[]> hdbBytes = hdbLoader.loadAsBytes(
                    featureNames, args.getHdbGcsBucket(), args.getHdbGcsPrefix());

            double totalHdbMb = hdbLoader.totalSizeMb(hdbBytes);
            log.info("Total HDB size to broadcast: {} MB for {} features",
                     String.format("%.1f", totalHdbMb), hdbBytes.size());

            if (totalHdbMb > 2048) {
                log.warn("HDB combined size ({} MB) is very large. " +
                         "Consider streaming from GCS on executors instead of broadcasting " +
                         "if executor OOM errors occur.", String.format("%.1f", totalHdbMb));
            }

            // Broadcast immutable byte arrays to all executors
            Broadcast<Map<String, byte[]>> broadcastHdb = jsc.broadcast(hdbBytes);
            log.info("HDB broadcast complete: {} databases", hdbBytes.size());

            // ── Phase 3: Read AVRO messages from GCS ─────────────────────────
            log.info("Phase 3: Reading AVRO messages from GCS");
            Broadcast<Set<String>> broadcastMsgIds = jsc.broadcast(relevantMessageIds);

            Dataset<org.apache.spark.sql.Row> messageDS =
                    avroReader.readAndFilter(spark, args, broadcastMsgIds)
                              .toDF(); // convert to Row Dataset for join

            // ── Phase 4: Group feature decisions by message_id ───────────────
            log.info("Phase 4: Grouping features by message_id");
            Dataset<Row> groupedFeatures = featureDecisionDS.toDF()
                    .groupBy(col("messageId"))
                    .agg(
                        first(col("runDate")).alias("run_date_agg"),
                        first(col("sentDate")).alias("sent_date_agg"),
                        collect_list(struct(
                            col("processId").alias("process_id"),
                            col("messageId").alias("message_id"),
                            col("runDate").alias("run_date"),
                            col("sentDate").alias("sent_date"),
                            col("featureType").alias("feature_type"),
                            col("featureId").alias("feature_id"),
                            col("featureName").alias("feature_name"),
                            col("featureOperator").alias("feature_operator"),
                            col("noiseReduction").alias("is_noise_reduction"),
                            col("fmFeatureDefinition").alias("fm_feature_definition")
                        )).alias("features")
                    )
                    .withColumnRenamed("messageId", "msg_id_feat");

            // ── Phase 5: Join messages with their features ───────────────────
            log.info("Phase 5: Joining messages with grouped features");
            Dataset<Row> messageWithFeatures = messageDS
                    .join(groupedFeatures,
                          messageDS.col("message_id")
                                   .equalTo(groupedFeatures.col("msg_id_feat")),
                          "inner")
                    .drop("msg_id_feat");

            // Repartition for even distribution — aim for ~2× executor cores
            int numPartitions = Math.max(
                    spark.sparkContext().defaultParallelism() * 2, 100);
            messageWithFeatures = messageWithFeatures
                    .repartition(numPartitions, col("message_id"));

            log.info("Processing {} partitions", numPartitions);

            // ── Phase 6: mapPartitions — execute the scan ────────────────────
            log.info("Phase 6: Running Hyperscan scan (mapPartitions)");
            Dataset<ScanOutputRow> scanResults = messageWithFeatures.mapPartitions(
                    new LexiconScanPartitionFunction(
                            broadcastHdb, args.getPolicyEngineId(), args.getPipelineExecId()),
                    Encoders.bean(ScanOutputRow.class)
            );

            // Cache scan results — they are written to multiple BQ tables
            scanResults.cache();

            // ── Phase 7: Write results to BigQuery ───────────────────────────
            log.info("Phase 7: Writing results to BigQuery");
            bqWriter.writeHitSummary(scanResults, args);
            bqWriter.writeStageAudit(spark, args, jobStart, featureRowCount);
            bqWriter.writeRecordAudit(scanResults, args);

            // Unpersist after writes complete
            scanResults.unpersist();
            featureDecisionDS.unpersist();
            broadcastHdb.unpersist();
            broadcastMsgIds.unpersist();

            log.info("Lexicon Scan Engine complete. Duration: {}ms",
                     System.currentTimeMillis() - jobStart.getTime());

        } catch (IOException e) {
            log.error("IO error during scan engine execution: {}", e.getMessage(), e);
            throw new RuntimeException("Lexicon Scan Engine failed due to IO error", e);
        } catch (Exception e) {
            log.error("Unexpected error during scan engine execution: {}", e.getMessage(), e);
            throw new RuntimeException("Lexicon Scan Engine failed", e);
        }
    }
}
