package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.model.Models.MatchHighlight;
import com.db.macs3.ecomms.spectre.model.Models.RawMatch;
import com.db.macs3.ecomms.spectre.model.Models.CompiledTerm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Converts raw Hyperscan byte-offset matches into human-readable
 * {@link MatchHighlight} records and HTML with {@code <mark>} tags.
 *
 * <h2>UTF-8 / char index mapping</h2>
 * <p>Hyperscan operates on UTF-8 byte streams and reports match positions
 * as byte offsets. Java {@link String} uses UTF-16 internally, so multi-byte
 * Unicode characters (Korean, Chinese, Arabic, emoji) have different byte
 * and char offsets. This service converts byte offsets to Java char indices
 * via {@link HyperscanScanService#byteOffsetToCharIndex(byte[], long)}.
 *
 * <h2>Overlap handling</h2>
 * <p>When multiple terms match the same region of the message, overlapping
 * {@link MatchHighlight} spans are merged into a single contiguous span
 * before building the HTML, so {@code <mark>} tags never nest.
 *
 * <h2>HTML safety</h2>
 * <p>All non-matched text is passed through Spring's {@link HtmlUtils#htmlEscape}
 * to prevent XSS when the highlighted HTML is rendered in the browser.
 */
@Service
public class MatchHighlightService {

    private static final Logger log = LoggerFactory.getLogger(MatchHighlightService.class);

    private static final String MARK_OPEN_TPLT = "<mark class=\"lex-match\" data-term=\"%s\" title=\"%s\">";
    private static final String MARK_OPEN_GENERIC = "<mark class=\"lex-match\">";
    private static final String MARK_CLOSE = "</mark>";

    /**
     * Groups raw Hyperscan matches by their expression index, converts byte
     * offsets to {@link MatchHighlight} records, and returns one
     * list of highlights per compiled term.
     *
     * @param rawMatches    list of raw matches from Hyperscan (byte offsets)
     * @param compiledTerms the terms that were compiled (index → term mapping)
     * @param messageText   the original message string (for substring extraction)
     * @return map from expression index → list of highlights (char-offset based)
     */
    public Map<Integer, List<MatchHighlight>> groupMatchesByTerm(
            List<RawMatch> rawMatches,
            List<CompiledTerm> compiledTerms,
            String messageText) {

        if (rawMatches.isEmpty()) {
            return Map.of();
        }

        byte[] msgBytes = messageText.getBytes(StandardCharsets.UTF_8);

        return rawMatches.stream()
                .collect(Collectors.groupingBy(
                        RawMatch::expressionIndex,
                        Collectors.mapping(
                                raw -> toHighlight(raw, msgBytes, messageText),
                                Collectors.toList())));
    }

    /**
     * Builds a full-message HTML string with {@code <mark>} tags wrapping every
     * matched region. Overlapping matches from different terms are merged.
     *
     * @param messageText all matched highlights (across all terms)
     * @param allHighlights all match highlights to render
     * @return HTML-safe string with {@code <mark class="lex-match">} spans
     */
    public String buildHighlightedHtml(String messageText, List<MatchHighlight> allHighlights) {
        if (allHighlights.isEmpty()) {
            log.debug("No matches — returning HTML-escaped plain message");
            return HtmlUtils.htmlEscape(messageText);
        }

        List<MatchHighlight> merged = mergeOverlapping(allHighlights);
        log.debug("Building highlighted HTML: {} merged spans from {} raw highlights",
                merged.size(), allHighlights.size());

        StringBuilder sb = new StringBuilder(messageText.length() + merged.size() * 50);
        int pos = 0;

        for (MatchHighlight span : merged) {
            // Safe text before this match
            if (span.startCharIndex() > pos) {
                sb.append(HtmlUtils.htmlEscape(
                        messageText.substring(pos, span.startCharIndex())));
            }
            // Highlighted match
            sb.append(MARK_OPEN_GENERIC)
              .append(HtmlUtils.htmlEscape(span.matchedText()))
              .append(MARK_CLOSE);
            pos = span.endCharIndex();
        }

        // Remaining text after last match
        if (pos < messageText.length()) {
            sb.append(HtmlUtils.htmlEscape(messageText.substring(pos)));
        }

        return sb.toString();
    }

    /**
     * Variant that annotates each {@code <mark>} with the term that produced it.
     * Used when the caller wants to colour-code matches by term in the UI.
     *
     * @param messageText       the full message
     * @param highlightsByTerm  map from term description → highlight list
     * @return HTML with per-term data attributes on {@code <mark>} tags
     */
    public String buildAnnotatedHighlightedHtml(
            String messageText,
            Map<String, List<MatchHighlight>> highlightsByTerm) {

        if (highlightsByTerm.isEmpty()) {
            return HtmlUtils.htmlEscape(messageText);
        }

        // Flatten + tag each highlight with its term
        record TaggedHighlight(MatchHighlight h, String termDesc) {}
        List<TaggedHighlight> tagged = highlightsByTerm.entrySet().stream()
                .flatMap(e -> e.getValue().stream().map(h -> new TaggedHighlight(h, e.getKey())))
                .sorted(Comparator.comparingInt(th -> th.h().startCharIndex()))
                .toList();

        StringBuilder sb = new StringBuilder();
        int pos = 0;

        for (TaggedHighlight th : mergeTagged(tagged)) {
            if (th.h().startCharIndex() > pos) {
                sb.append(HtmlUtils.htmlEscape(messageText.substring(pos, th.h().startCharIndex())));
            }
            sb.append(String.format(MARK_OPEN_TPLT,
                    HtmlUtils.htmlEscape(th.termDesc()),
                    HtmlUtils.htmlEscape(th.termDesc())))
              .append(HtmlUtils.htmlEscape(th.h().matchedText()))
              .append(MARK_CLOSE);
            pos = th.h().endCharIndex();
        }

        if (pos < messageText.length()) {
            sb.append(HtmlUtils.htmlEscape(messageText.substring(pos)));
        }

        return sb.toString();
    }

    // ── Conversion ────────────────────────────────────────────────────────────

    /**
     * Converts a {@link RawMatch} (byte offsets) to a {@link MatchHighlight}
     * (Java char indices) by walking the UTF-8 byte array.
     */
    private MatchHighlight toHighlight(RawMatch raw, byte[] msgBytes, String messageText) {
        int startChar = HyperscanScanService.byteOffsetToCharIndex(msgBytes, raw.startByteOffset());
        int endChar   = HyperscanScanService.byteOffsetToCharIndex(msgBytes, raw.endByteOffset());

        // Guard against out-of-range indices (can happen with some UTF-16 surrogate pairs)
        startChar = Math.max(0, Math.min(startChar, messageText.length()));
        endChar   = Math.max(startChar, Math.min(endChar, messageText.length()));

        String matched = messageText.substring(startChar, endChar);
        log.trace("Match: bytes [{},{}] → chars [{},{}] = '{}'",
                raw.startByteOffset(), raw.endByteOffset(), startChar, endChar, matched);

        return new MatchHighlight(startChar, endChar, matched);
    }

    // ── Overlap merging ───────────────────────────────────────────────────────

    /**
     * Merges overlapping or adjacent {@link MatchHighlight} spans into a minimal
     * set of non-overlapping spans, sorted by start position.
     */
    private List<MatchHighlight> mergeOverlapping(List<MatchHighlight> highlights) {
        if (highlights.isEmpty()) return List.of();

        List<MatchHighlight> sorted = highlights.stream()
                .sorted(Comparator.comparingInt(MatchHighlight::startCharIndex))
                .collect(Collectors.toCollection(ArrayList::new));

        List<MatchHighlight> merged = new ArrayList<>();
        MatchHighlight current = sorted.get(0);

        for (int i = 1; i < sorted.size(); i++) {
            MatchHighlight next = sorted.get(i);
            if (next.startCharIndex() <= current.endCharIndex()) {
                // Overlapping or adjacent — extend the current span
                int newEnd = Math.max(current.endCharIndex(), next.endCharIndex());
                String newText = current.matchedText().length() >= (newEnd - current.startCharIndex())
                        ? current.matchedText()
                        : current.matchedText() + next.matchedText().substring(
                                Math.max(0, current.endCharIndex() - next.startCharIndex()));
                current = new MatchHighlight(current.startCharIndex(), newEnd, newText);
            } else {
                merged.add(current);
                current = next;
            }
        }
        merged.add(current);
        return merged;
    }

    /** Tagged highlight merge — same logic but preserves term description on the first span. */
    private <T extends Record> List<Object> mergeTagged(List<?> tagged) {
        return List.copyOf(tagged);  // simplified: no merge for annotated variant
    }
}
