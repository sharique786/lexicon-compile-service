package com.db.macs3.ecomms.spectre.translator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.regex.Pattern;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * End-to-end tests for {@link LexiconTermTranslator}.
 *
 * Covers all operator types (OR, AND, AND NOT, NEAR, FOLLOWEDBY, wildcard,
 * quoted phrase, literal) in Latin, Arabic, Hebrew, CJK, Korean, and
 * mixed-language configurations.
 */
@DisplayName("LexiconTermTranslator")
class LexiconTermTranslatorTest {

    private LexiconTermTranslator translator;

    @BeforeEach
    void setUp() {
        translator = new LexiconTermTranslator();
    }

    // ── regex test helper ────────────────────────────────────────────────
    private boolean matches(String hsPattern, String message) {
        int jf = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE
               | Pattern.DOTALL | Pattern.UNICODE_CHARACTER_CLASS;
        return Pattern.compile(hsPattern, jf).matcher(message).find();
    }

    // ══════════════════════════════════════════════════════════════════════
    // NEAR operator — multi-language
    // ══════════════════════════════════════════════════════════════════════

    @Nested @DisplayName("NEAR operator")
    class NearOperator {

        @Test @DisplayName("[EN] insider NEAR{3} trading — standard English")
        void englishNear() {
            var r = translator.translate("insider NEAR{3} trading");
            assertThat(r.hsFlags()).isEqualTo(3);
            assertThat(matches(r.pattern(), "the insider was trading")).isTrue();
            assertThat(matches(r.pattern(), "trading by the insider")).isTrue();
            assertThat(matches(r.pattern(), "routine operations")).isFalse();
        }

        @Test @DisplayName("[AR] السعر NEAR{2} التلاعب — Arabic price manipulation")
        void arabicNear() {
            var r = translator.translate("السعر NEAR{2} التلاعب");
            assertThat(r.hsFlags()).isEqualTo(99);   // must have UTF8+UCP
            assertThat(r.pattern()).contains("\\s+"); // word-based gap
            assertThat(matches(r.pattern(), "ارتفاع السعر بسبب التلاعب")).isTrue();
            assertThat(matches(r.pattern(), "التلاعب في السعر")).isTrue();
        }

        @Test @DisplayName("[HE] מידע NEAR{3} פנים — Hebrew insider information")
        void hebrewNear() {
            var r = translator.translate("מידע NEAR{3} פנים");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(matches(r.pattern(), "מסחר עם מידע פנים הוא בלתי חוקי")).isTrue();
        }

        @Test @DisplayName("[ZH] 内幕 NEAR{2} 交易 — Chinese insider trading (no spaces)")
        void chineseNear() {
            var r = translator.translate("内幕 NEAR{2} 交易");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(r.pattern()).contains("[\\s\\S]"); // must be char-based
            assertThat(matches(r.pattern(), "内幕交易")).isTrue();          // no space
            assertThat(matches(r.pattern(), "内幕 交易")).isTrue();         // with space
            assertThat(matches(r.pattern(), "交易内幕")).isTrue();           // reversed
        }

        @Test @DisplayName("[JA] インサイダー NEAR{3} 取引 — Japanese (kana+kanji)")
        void japaneseNear() {
            var r = translator.translate("インサイダー NEAR{3} 取引");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(r.pattern()).contains("[\\s\\S]");
            assertThat(matches(r.pattern(), "インサイダー取引が発覚")).isTrue();
        }

        @Test @DisplayName("[KO] 내부자 NEAR{3} 거래 — Korean with and without spaces")
        void koreanNear() {
            var r = translator.translate("내부자 NEAR{3} 거래");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(r.pattern()).contains("[\\s\\S]");

            assertThat(matches(r.pattern(), "내부자 거래 혐의")).isTrue();    // with space
            assertThat(matches(r.pattern(), "내부자거래혐의")).isTrue();      // no space
            assertThat(matches(r.pattern(), "거래 내부자 정보")).isTrue();    // reversed
        }

        @Test @DisplayName("[MIXED EN+KO] insider NEAR{3} 내부자")
        void mixedEnglishKorean() {
            var r = translator.translate("insider NEAR{3} 내부자");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(r.pattern()).contains("[\\s\\S]"); // char-based wins
            assertThat(matches(r.pattern(), "he is an insider 내부자 suspect")).isTrue();
        }

        @Test @DisplayName("[MIXED EN+AR] price NEAR{3} السعر")
        void mixedEnglishArabic() {
            var r = translator.translate("price NEAR{3} السعر");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(r.pattern()).contains("\\s+"); // word-based (both space-delimited)
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // FOLLOWEDBY operator — multi-language
    // ══════════════════════════════════════════════════════════════════════

    @Nested @DisplayName("FOLLOWEDBY operator")
    class FollowedByOperator {

        @Test @DisplayName("[EN] buy FOLLOWEDBY{3} shares — English directional")
        void englishFollowedBy() {
            var r = translator.translate("buy FOLLOWEDBY{3} shares");
            assertThat(r.hsFlags()).isEqualTo(3);
            assertThat(matches(r.pattern(), "I want to buy 1000 shares")).isTrue();
            assertThat(matches(r.pattern(), "shares were never bought")).isFalse();
        }

        @Test @DisplayName("[AR] معلومات FOLLOWEDBY{2} سرية — pure Arabic, no warning")
        void arabicFollowedBy_pureRtl() {
            var r = translator.translate("معلومات FOLLOWEDBY{2} سرية");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(r.warning()).isNull();  // pure RTL — no direction warning
            assertThat(matches(r.pattern(), "استلم معلومات سرية")).isTrue();
        }

        @Test @DisplayName("[HE] מסחר FOLLOWEDBY{2} פנים — Hebrew directional")
        void hebrewFollowedBy() {
            var r = translator.translate("מסחר FOLLOWEDBY{2} פנים");
            assertThat(matches(r.pattern(), "עסקאות מסחר פנים התגלו")).isTrue();
            assertThat(matches(r.pattern(), "פנים מסחר")).isFalse(); // reversed
        }

        @Test @DisplayName("[ZH] 内幕 FOLLOWEDBY{2} 交易 — CJK directional, no space")
        void chineseFollowedBy() {
            var r = translator.translate("内幕 FOLLOWEDBY{2} 交易");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(r.pattern()).contains("[\\s\\S]");
            assertThat(matches(r.pattern(), "内幕交易被发现")).isTrue();      // no space
            assertThat(matches(r.pattern(), "交易内幕")).isFalse();           // reversed
        }

        @Test @DisplayName("[KO] 내부자 FOLLOWEDBY{2} 거래 — Korean with and without space")
        void koreanFollowedBy() {
            var r = translator.translate("내부자 FOLLOWEDBY{2} 거래");
            assertThat(matches(r.pattern(), "내부자 거래")).isTrue();          // with space
            assertThat(matches(r.pattern(), "내부자거래")).isTrue();           // without space
            assertThat(matches(r.pattern(), "거래 내부자")).isFalse();        // reversed
        }

        @Test @DisplayName("[MIXED EN+AR] insider FOLLOWEDBY{2} معلومات — RTL warning")
        void mixedFollowedBy_rtlWarning() {
            var r = translator.translate("insider FOLLOWEDBY{2} معلومات");
            assertThat(r.warning()).isNotNull();
            assertThat(r.warning()).containsIgnoringCase("RTL");
            // Pattern still functional
            assertThat(r.pattern()).isNotBlank();
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // Other operators — unchanged by this fix, regression check
    // ══════════════════════════════════════════════════════════════════════

    @Nested @DisplayName("Other operators (regression check)")
    class OtherOperators {

        @Test @DisplayName("[EN] OR operator — unchanged")
        void orOperator() {
            var r = translator.translate("pump OR dump");
            assertThat(r.requiresAndPostFilter()).isFalse();
            assertThat(matches(r.pattern(), "pump the stock")).isTrue();
            assertThat(matches(r.pattern(), "dump the positions")).isTrue();
        }

        @Test @DisplayName("[KO] OR — Korean terms")
        void koreanOrOperator() {
            var r = translator.translate("내부자 OR 거래");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(matches(r.pattern(), "내부자 was flagged")).isTrue();
            assertThat(matches(r.pattern(), "거래 was flagged")).isTrue();
        }

        @Test @DisplayName("[AR] OR — Arabic terms")
        void arabicOrOperator() {
            var r = translator.translate("السعر OR التلاعب");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(matches(r.pattern(), "ارتفاع السعر")).isTrue();
            assertThat(matches(r.pattern(), "عملية التلاعب")).isTrue();
        }

        @Test @DisplayName("[EN] AND operator — requiresAndPostFilter=true")
        void andOperator() {
            var r = translator.translate("insider AND trading");
            assertThat(r.requiresAndPostFilter()).isTrue();
            assertThat(r.pattern()).startsWith("(?:");
        }

        @Test @DisplayName("[ZH] AND — Chinese terms")
        void chineseAndOperator() {
            var r = translator.translate("内幕 AND 交易");
            assertThat(r.requiresAndPostFilter()).isTrue();
            assertThat(r.hsFlags()).isEqualTo(99);
        }

        @Test @DisplayName("Quoted phrase — spaces become \\\\s+")
        void quotedPhrase() {
            var r = translator.translate("\"front running\"");
            assertThat(r.pattern()).contains("\\s+");
            assertThat(matches(r.pattern(), "front running scheme")).isTrue();
            assertThat(matches(r.pattern(), "frontrunning")).isFalse();
        }

        @Test @DisplayName("[KO] Quoted phrase — Korean multi-word")
        void koreanQuotedPhrase() {
            var r = translator.translate("\"내부자 거래\"");
            assertThat(r.hsFlags()).isEqualTo(99);
            assertThat(matches(r.pattern(), "내부자 거래 혐의")).isTrue();
        }

        @Test @DisplayName("Wildcard — * becomes \\\\S*")
        void wildcard() {
            var r = translator.translate("trade*");
            assertThat(matches(r.pattern(), "trading")).isTrue();
            assertThat(matches(r.pattern(), "trader")).isTrue();
            assertThat(matches(r.pattern(), "traded")).isTrue();
        }

        @Test @DisplayName("Blank input → TranslationException")
        void blankInput() {
            assertThatThrownBy(() -> translator.translate(""))
                    .isInstanceOf(LexiconTermTranslator.TranslationException.class);
            assertThatThrownBy(() -> translator.translate(null))
                    .isInstanceOf(LexiconTermTranslator.TranslationException.class);
        }
    }
}
