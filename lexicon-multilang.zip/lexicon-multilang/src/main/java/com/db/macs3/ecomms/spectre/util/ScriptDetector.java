package com.db.macs3.ecomms.spectre.util;

import com.db.macs3.ecomms.spectre.model.ScriptType;

import java.util.EnumSet;
import java.util.Set;

/**
 * Detects the dominant Unicode script family in a text string and maps
 * it to a {@link ScriptType} that the pattern builder can use to choose
 * the correct NEAR / FOLLOWEDBY gap strategy.
 *
 * <h2>How it works</h2>
 * <p>Iterates over every code point in the input using
 * {@link Character#UnicodeScript#of(int)}, accumulates a set of detected
 * script categories, then maps the combination to the most conservative
 * {@link ScriptType} (e.g. CJK always wins over Latin in a mixed pair
 * because CJK cannot rely on whitespace separators).
 *
 * <h2>ASCII / regex metacharacters</h2>
 * <p>Input strings may contain regex fragments like {@code \\s+} or
 * {@code \\x{4E00}}.  Only code points above U+007F are considered when
 * categorising scripts; ASCII metacharacters are ignored.
 */
public final class ScriptDetector {

    private ScriptDetector() {}

    // ── Internal script category flags ────────────────────────────────────

    private enum Category { CJK, KANA, HANGUL, ARABIC, HEBREW, THAI, DEVANAGARI, OTHER_RTL, LATIN }

    // ── Public API ────────────────────────────────────────────────────────

    /**
     * Detects the script type of a single text operand.
     *
     * @param text the lexicon term operand (may include regex fragments)
     * @return the dominant {@link ScriptType}; {@link ScriptType#LATIN} if
     *         no non-ASCII characters are found
     */
    public static ScriptType detect(String text) {
        if (text == null || text.isBlank()) return ScriptType.LATIN;
        Set<Category> found = scanCategories(text);
        return resolveType(found);
    }

    /**
     * Determines the combined script type for a NEAR / FOLLOWEDBY pair,
     * applying the most conservative (character-safe) strategy when the
     * two operands belong to different script families.
     *
     * @param termA first operand
     * @param termB second operand
     * @return combined {@link ScriptType} for gap-strategy selection
     */
    public static ScriptType detectCombined(String termA, String termB) {
        Set<Category> found = scanCategories(termA);
        found.addAll(scanCategories(termB));
        return resolveType(found);
    }

    /**
     * Returns {@code true} when at least one of the two operands contains
     * characters from a right-to-left script (Arabic or Hebrew).
     * Used by the FOLLOWEDBY builder to emit a bidirectional-text warning.
     */
    public static boolean hasRtlComponent(String termA, String termB) {
        Set<Category> a = scanCategories(termA);
        Set<Category> b = scanCategories(termB);
        return a.contains(Category.ARABIC) || a.contains(Category.HEBREW)
            || b.contains(Category.ARABIC) || b.contains(Category.HEBREW);
    }

    /**
     * Returns {@code true} when both operands are exclusively from RTL
     * scripts (Arabic or Hebrew) with no LTR script content.
     */
    public static boolean isPurelyRtl(String termA, String termB) {
        Set<Category> a = scanCategories(termA);
        Set<Category> b = scanCategories(termB);
        boolean aRtl = (a.contains(Category.ARABIC) || a.contains(Category.HEBREW))
                    && !a.contains(Category.LATIN) && !a.contains(Category.CJK)
                    && !a.contains(Category.HANGUL) && !a.contains(Category.KANA);
        boolean bRtl = (b.contains(Category.ARABIC) || b.contains(Category.HEBREW))
                    && !b.contains(Category.LATIN) && !b.contains(Category.CJK)
                    && !b.contains(Category.HANGUL) && !b.contains(Category.KANA);
        return aRtl && bRtl;
    }

    // ── Private helpers ───────────────────────────────────────────────────

    /**
     * Walks every Unicode code point in {@code text}, maps each to one of
     * the internal {@link Category} values, and returns the full set of
     * categories found.  ASCII characters (≤ U+007F) are skipped entirely
     * so that regex metacharacters do not pollute the result.
     */
    private static Set<Category> scanCategories(String text) {
        Set<Category> found = EnumSet.noneOf(Category.class);
        if (text == null) return found;

        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);

            // Skip ASCII — regex metacharacters, digits, basic punctuation
            if (cp <= 0x007F) continue;
            // Skip common combining / zero-width characters that appear inside
            // Arabic, Hebrew, and Devanagari text
            if (isInvisible(cp)) continue;

            Character.UnicodeScript script = Character.UnicodeScript.of(cp);
            Category cat = toCategory(script);
            if (cat != null) found.add(cat);
        }
        return found;
    }

    /**
     * Maps a Java {@link Character.UnicodeScript} to one of our internal
     * {@link Category} values.  Returns {@code null} for scripts we don't
     * need to distinguish (e.g. common punctuation).
     */
    private static Category toCategory(Character.UnicodeScript script) {
        return switch (script) {
            // CJK logographic
            case HAN, BOPOMOFO -> Category.CJK;
            // Japanese syllabaries
            case HIRAGANA, KATAKANA -> Category.KANA;
            // Korean
            case HANGUL -> Category.HANGUL;
            // RTL
            case ARABIC -> Category.ARABIC;
            case HEBREW -> Category.HEBREW;
            // South / Southeast Asian
            case THAI, LAO, MYANMAR, TIBETAN -> Category.THAI;
            case DEVANAGARI, BENGALI, GURMUKHI, GUJARATI,
                 ORIYA, TAMIL, TELUGU, KANNADA, MALAYALAM,
                 SINHALA -> Category.DEVANAGARI;
            // Other RTL scripts
            case THAANA, NKO, SAMARITAN, MANDAIC -> Category.OTHER_RTL;
            // Latin-family and related scripts treated as word-based
            case LATIN, GREEK, CYRILLIC, ARMENIAN, GEORGIAN -> Category.LATIN;
            default -> null;
        };
    }

    /**
     * Resolves the full set of detected categories to the most conservative
     * single {@link ScriptType} for gap-strategy selection.
     *
     * <p>Priority order (from most restrictive to least):
     * <ol>
     *   <li>CJK / Kana / Hangul / Thai present → CHAR_BASED</li>
     *   <li>RTL (Arabic / Hebrew) + Latin → MIXED_RTL (word-based)</li>
     *   <li>Pure RTL → ARABIC or HEBREW</li>
     *   <li>Pure Latin → LATIN</li>
     * </ol>
     */
    private static ScriptType resolveType(Set<Category> found) {
        if (found.isEmpty()) return ScriptType.LATIN;

        boolean hasCjk     = found.contains(Category.CJK);
        boolean hasKana    = found.contains(Category.KANA);
        boolean hasHangul  = found.contains(Category.HANGUL);
        boolean hasThai    = found.contains(Category.THAI) || found.contains(Category.DEVANAGARI);
        boolean hasArabic  = found.contains(Category.ARABIC) || found.contains(Category.OTHER_RTL);
        boolean hasHebrew  = found.contains(Category.HEBREW);
        boolean hasLatin   = found.contains(Category.LATIN);
        boolean hasRtl     = hasArabic || hasHebrew;
        boolean hasSpaceFree = hasCjk || hasKana || hasHangul || hasThai;

        // Any space-free script wins — char-based gap is mandatory
        if (hasSpaceFree) {
            return ScriptType.MIXED_CJK;
        }
        // CJK-only variants (no RTL, no Latin)
        if (hasCjk   && !hasRtl && !hasLatin) return ScriptType.CJK;
        if (hasKana  && !hasRtl && !hasLatin) return ScriptType.KANA;
        if (hasHangul&& !hasRtl && !hasLatin) return ScriptType.HANGUL;
        if (hasThai  && !hasRtl && !hasLatin) return ScriptType.THAI;

        // RTL combinations
        if (hasRtl && hasLatin) return ScriptType.MIXED_RTL;
        if (hasArabic && !hasHebrew) return ScriptType.ARABIC;
        if (hasHebrew && !hasArabic) return ScriptType.HEBREW;
        if (hasRtl) return ScriptType.MIXED;

        // Pure Latin
        if (hasLatin) return ScriptType.LATIN;

        return ScriptType.MIXED;
    }

    /**
     * Returns {@code true} for invisible / zero-width Unicode code points
     * that should not influence script detection:
     * <ul>
     *   <li>U+200C ZERO WIDTH NON-JOINER (common in Arabic / Persian)</li>
     *   <li>U+200D ZERO WIDTH JOINER</li>
     *   <li>U+200E/F LTR/RTL marks</li>
     *   <li>U+FEFF BOM / ZERO WIDTH NO-BREAK SPACE</li>
     *   <li>General Unicode combining marks (category Mn, Mc)</li>
     * </ul>
     */
    private static boolean isInvisible(int cp) {
        if (cp == 0x200C || cp == 0x200D || cp == 0x200E || cp == 0x200F || cp == 0xFEFF) {
            return true;
        }
        int type = Character.getType(cp);
        // Mn = NON_SPACING_MARK, Mc = COMBINING_SPACING_MARK
        return type == Character.NON_SPACING_MARK || type == Character.COMBINING_SPACING_MARK;
    }
}
