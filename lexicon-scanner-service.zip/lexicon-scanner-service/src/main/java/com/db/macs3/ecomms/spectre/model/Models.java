package com.db.macs3.ecomms.spectre.model;

import java.time.Instant;
import java.util.List;

/**
 * Shared domain models for the Lexicon Scanner Service.
 *
 * <h2>Request models</h2>
 * <ul>
 *   <li>{@link ScanApiRequest} — JSON body for the REST API</li>
 * </ul>
 *
 * <h2>Lexicon Compile Service wire models</h2>
 * <ul>
 *   <li>{@link CompileServiceRequest} / {@link CompileServiceRequest.TermInput}</li>
 *   <li>{@link CompileServiceResponse} / {@link CompileServiceResponse.TermResult}</li>
 * </ul>
 *
 * <h2>Internal pipeline models</h2>
 * <ul>
 *   <li>{@link CompiledTerm}   — a term that compiled successfully, ready for Hyperscan</li>
 *   <li>{@link RawMatch}       — raw Hyperscan match (byte-offset based)</li>
 *   <li>{@link MatchHighlight} — a single match region mapped to char indices</li>
 *   <li>{@link TermScanResult} — aggregated result for one lexicon term</li>
 *   <li>{@link ScanResponse}   — the full response returned to the UI / caller</li>
 * </ul>
 */
public final class Models {

    private Models() {}

    // ══════════════════════════════════════════════════════════════════════════
    // API Request
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * JSON body accepted by {@code POST /api/scan/json}.
     * Multipart form data uses {@code POST /api/scan} with individual fields.
     *
     * @param inputMode   how lexicon terms are supplied ({@code TERMS} or {@code CSV})
     * @param messageMode how the message is supplied ({@code TEXT} or {@code FILE})
     * @param terms       newline-separated term descriptions (when inputMode=TERMS)
     * @param csvContent  raw CSV text content (when inputMode=CSV, for JSON requests)
     * @param messageText raw message text (when messageMode=TEXT)
     * @param ruleName    optional rule / session name for the compile request
     */
    public record ScanApiRequest(
            String inputMode,
            String messageMode,
            String terms,
            String csvContent,
            String messageText,
            String ruleName
    ) {}

    // ══════════════════════════════════════════════════════════════════════════
    // Lexicon Compile Service wire models
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Request body sent to the Lexicon Compile Service.
     *
     * @param lexiconRuleName logical name for this compilation session
     * @param terms           list of term inputs to compile
     */
    public record CompileServiceRequest(
            String lexiconRuleName,
            List<TermInput> terms
    ) {

        /**
         * One term to compile.
         *
         * @param termId          unique identifier, e.g. {@code scanner::1}
         * @param termDescription the raw operator expression, e.g. {@code insider AND trading}
         * @param riskDriverName  risk category label, e.g. {@code Market Abuse}
         */
        public record TermInput(
                String termId,
                String termDescription,
                String riskDriverName
        ) {}
    }

    /**
     * Full response from the Lexicon Compile Service.
     *
     * @param lexiconRuleName rule name echoed from the request
     * @param totalTerms      total number of terms submitted
     * @param passCount       number that compiled successfully
     * @param failedCount     number that failed compilation or translation
     * @param hasFailures     convenience flag — true when failedCount &gt; 0
     * @param results         per-term compilation outcomes
     */
    public record CompileServiceResponse(
            String lexiconRuleName,
            int totalTerms,
            int passCount,
            int failedCount,
            boolean hasFailures,
            List<TermResult> results
    ) {

        /**
         * Compilation outcome for one term.
         *
         * @param termId                 echoed from the request
         * @param termDescription        echoed from the request
         * @param riskDriverName         echoed from the request
         * @param compilationStatus      {@code "PASS"} or {@code "FAILED"}
         * @param translatedPattern      Hyperscan PCRE pattern (null when FAILED)
         * @param hsFlags                bitmask: 1=CASELESS, 2=DOTALL, 32=UTF8, 64=UCP
         * @param requiresAndPostFilter  true for AND / AND NOT / NOT terms;
         *                               the OR pre-scan pattern must be post-filtered
         *                               by the scan engine to enforce AND semantics
         * @param errorLog               Hyperscan compile error (null when PASS)
         * @param translationError       translator error (null when PASS)
         * @param compiledAt             timestamp of compilation
         */
        public record TermResult(
                String termId,
                String termDescription,
                String riskDriverName,
                String compilationStatus,
                String translatedPattern,
                int hsFlags,
                boolean requiresAndPostFilter,
                String errorLog,
                String translationError,
                Instant compiledAt
        ) {
            /** Returns true when this term compiled successfully and has a usable pattern. */
            public boolean isPass() {
                return "PASS".equalsIgnoreCase(compilationStatus);
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Internal pipeline models
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * A lexicon term that passed Hyperscan compilation and is ready to scan.
     *
     * @param termId               unique identifier
     * @param termDescription      original lexicon expression
     * @param translatedPattern    Hyperscan-valid PCRE pattern
     * @param hsFlags              bitmask of Hyperscan expression flags
     * @param requiresAndPostFilter true when the term uses AND/NOT semantics
     * @param expressionIndex      index in the compiled database (maps Match → term)
     */
    public record CompiledTerm(
            String termId,
            String termDescription,
            String translatedPattern,
            int hsFlags,
            boolean requiresAndPostFilter,
            int expressionIndex
    ) {}

    /**
     * A raw match returned by Hyperscan, using byte offsets into the UTF-8 input.
     *
     * @param startByteOffset start of the matched region (bytes into UTF-8 message)
     * @param endByteOffset   end of the matched region (exclusive, bytes)
     * @param expressionIndex index of the matching expression in the compiled database
     */
    public record RawMatch(
            long startByteOffset,
            long endByteOffset,
            int expressionIndex
    ) {}

    /**
     * A single match region mapped to Java {@code String} character indices.
     *
     * @param startCharIndex  start of the match in the message (Java char index)
     * @param endCharIndex    end of the match in the message (exclusive, Java char index)
     * @param matchedText     the extracted substring from the message
     */
    public record MatchHighlight(
            int startCharIndex,
            int endCharIndex,
            String matchedText
    ) {}

    /**
     * All scan results aggregated for one lexicon term.
     *
     * @param termId                 unique term identifier
     * @param termDescription        original lexicon expression
     * @param translatedPattern      PCRE pattern used for scanning
     * @param compilationStatus      {@code "PASS"}, {@code "FAILED"}, or {@code "SKIPPED"}
     * @param requiresAndPostFilter  true for AND/NOT terms (OR pre-scan semantics)
     * @param matches                match regions found in the message
     * @param hasMatches             convenience flag
     * @param compilationError       error message when compilationStatus is FAILED
     * @param postFilterNote         informational note for AND/NOT terms
     */
    public record TermScanResult(
            String termId,
            String termDescription,
            String translatedPattern,
            String compilationStatus,
            boolean requiresAndPostFilter,
            List<MatchHighlight> matches,
            boolean hasMatches,
            String compilationError,
            String postFilterNote
    ) {}

    /**
     * Complete scan response returned to the UI and REST callers.
     *
     * @param scanId               UUID of this scan session
     * @param scanDurationMs       wall-clock time for the full pipeline
     * @param totalTerms           number of terms submitted
     * @param matchedTerms         number of terms with at least one match
     * @param failedTerms          number of terms that failed compilation
     * @param hasMatches           true when any term matched
     * @param plainMessage         original message text (for the UI text panel)
     * @param htmlHighlightedMessage HTML with {@code <mark>} tags for matched regions
     * @param termResults          per-term scan results
     * @param warnings             non-fatal informational messages
     * @param status               {@code "SUCCESS"} or {@code "ERROR"}
     * @param errorMessage         populated only when status is {@code "ERROR"}
     */
    public record ScanResponse(
            String scanId,
            long scanDurationMs,
            int totalTerms,
            int matchedTerms,
            int failedTerms,
            boolean hasMatches,
            String plainMessage,
            String htmlHighlightedMessage,
            List<TermScanResult> termResults,
            List<String> warnings,
            String status,
            String errorMessage
    ) {

        /** Convenience factory for a successful scan response. */
        public static ScanResponse success(
                String scanId, long durationMs, int total, int matched, int failed,
                String plain, String html, List<TermScanResult> results, List<String> warnings) {
            return new ScanResponse(
                    scanId, durationMs, total, matched, failed,
                    matched > 0 || failed < total,
                    plain, html, results, warnings, "SUCCESS", null
            );
        }

        /** Convenience factory for an error response. */
        public static ScanResponse error(String scanId, String message) {
            return new ScanResponse(
                    scanId, 0, 0, 0, 0, false,
                    null, null, List.of(), List.of(), "ERROR", message
            );
        }
    }
}
