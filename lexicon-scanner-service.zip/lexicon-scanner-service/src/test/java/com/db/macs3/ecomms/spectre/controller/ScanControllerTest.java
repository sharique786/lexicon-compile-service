package com.db.macs3.ecomms.spectre.controller;

import com.db.macs3.ecomms.spectre.model.Models.ScanResponse;
import com.db.macs3.ecomms.spectre.model.Models.TermScanResult;
import com.db.macs3.ecomms.spectre.service.CsvParserService;
import com.db.macs3.ecomms.spectre.service.LexiconScanOrchestrator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Controller-slice tests for {@link ScanController}.
 *
 * <p>Uses Spring's {@link WebMvcTest} to load only the web layer; collaborating
 * services are replaced with Mockito mocks.
 */
@WebMvcTest(ScanController.class)
@DisplayName("ScanController")
class ScanControllerTest {

    @Autowired private MockMvc mvc;

    @MockitoBean private LexiconScanOrchestrator orchestrator;
    @MockitoBean private CsvParserService csvParser;

    // ── GET /api/scan/health ─────────────────────────────────────────────────

    @Test
    @DisplayName("GET /api/scan/health returns 200 with status=UP")
    void health_returns200() throws Exception {
        mvc.perform(get("/api/scan/health"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.status").value("UP"))
           .andExpect(jsonPath("$.service").value("lexicon-scanner-service"));
    }

    // ── POST /api/scan (multipart) ───────────────────────────────────────────

    @Test
    @DisplayName("POST /api/scan with terms + text returns 200 and invokes orchestrator")
    void scanMultipart_termsAndText_returns200() throws Exception {
        when(orchestrator.scan(anyList(), anyString(), anyString()))
                .thenReturn(successResponse(1, 1));

        mvc.perform(multipart("/api/scan")
                .param("inputMode", "TERMS")
                .param("messageMode", "TEXT")
                .param("terms", "insider AND trading")
                .param("messageText", "The insider leaked information.")
                .param("ruleName", "my-test"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.status").value("SUCCESS"))
           .andExpect(jsonPath("$.totalTerms").value(1))
           .andExpect(jsonPath("$.matchedTerms").value(1));

        verify(orchestrator).scan(
                List.of("insider AND trading"),
                "The insider leaked information.",
                "my-test");
    }

    @Test
    @DisplayName("POST /api/scan with CSV file returns 200")
    void scanMultipart_csvFile_returns200() throws Exception {
        String csvContent = "term_id,term_description\nt::1,pump OR dump\n";
        MockMultipartFile csvFile = new MockMultipartFile("csvFile", "terms.csv",
                "text/csv", csvContent.getBytes(StandardCharsets.UTF_8));

        when(csvParser.parseTermDescriptions(any())).thenReturn(List.of("pump OR dump"));
        when(orchestrator.scan(anyList(), anyString(), anyString()))
                .thenReturn(successResponse(1, 0));

        mvc.perform(multipart("/api/scan")
                .file(csvFile)
                .param("inputMode", "CSV")
                .param("messageMode", "TEXT")
                .param("messageText", "buying and selling on news"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.status").value("SUCCESS"));
    }

    @Test
    @DisplayName("POST /api/scan with message file returns 200")
    void scanMultipart_messageFile_returns200() throws Exception {
        MockMultipartFile msgFile = new MockMultipartFile("messageFile", "email.txt",
                "text/plain", "insider trading scheme".getBytes(StandardCharsets.UTF_8));

        when(orchestrator.scan(anyList(), anyString(), anyString()))
                .thenReturn(successResponse(1, 1));

        mvc.perform(multipart("/api/scan")
                .file(msgFile)
                .param("inputMode", "TERMS")
                .param("messageMode", "FILE")
                .param("terms", "insider AND trading"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.status").value("SUCCESS"));
    }

    @Test
    @DisplayName("POST /api/scan with no terms returns 400 with error response")
    void scanMultipart_noTerms_returns400() throws Exception {
        mvc.perform(multipart("/api/scan")
                .param("inputMode", "TERMS")
                .param("messageMode", "TEXT")
                .param("terms", "   ")
                .param("messageText", "some message"))
           .andExpect(status().isBadRequest())
           .andExpect(jsonPath("$.status").value("ERROR"))
           .andExpect(jsonPath("$.errorMessage").isNotEmpty());
    }

    @Test
    @DisplayName("POST /api/scan with no message returns 400")
    void scanMultipart_noMessage_returns400() throws Exception {
        mvc.perform(multipart("/api/scan")
                .param("inputMode", "TERMS")
                .param("messageMode", "TEXT")
                .param("terms", "insider AND trading")
                .param("messageText", ""))
           .andExpect(status().isBadRequest())
           .andExpect(jsonPath("$.status").value("ERROR"));
    }

    @Test
    @DisplayName("POST /api/scan with comment-only terms returns 400")
    void scanMultipart_commentOnlyTerms_returns400() throws Exception {
        mvc.perform(multipart("/api/scan")
                .param("inputMode", "TERMS")
                .param("messageMode", "TEXT")
                .param("terms", "# this is a comment\n# another comment")
                .param("messageText", "some message"))
           .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("POST /api/scan with multiple terms (newline-separated) passes all to orchestrator")
    void scanMultipart_multipleTerms_passedCorrectly() throws Exception {
        when(orchestrator.scan(anyList(), anyString(), anyString()))
                .thenReturn(successResponse(3, 2));

        mvc.perform(multipart("/api/scan")
                .param("inputMode", "TERMS")
                .param("messageMode", "TEXT")
                .param("terms", "insider AND trading\npump OR dump\n\"front running\"")
                .param("messageText", "message text"))
           .andExpect(status().isOk());

        verify(orchestrator).scan(
                List.of("insider AND trading", "pump OR dump", "\"front running\""),
                "message text",
                "scanner-test-run");
    }

    // ── POST /api/scan/json ──────────────────────────────────────────────────

    @Test
    @DisplayName("POST /api/scan/json with valid JSON body returns 200")
    void scanJson_validBody_returns200() throws Exception {
        when(orchestrator.scan(anyList(), anyString(), anyString()))
                .thenReturn(successResponse(1, 1));

        String body = """
            {
              "inputMode": "TERMS",
              "messageMode": "TEXT",
              "terms": "insider AND trading",
              "messageText": "The insider bought shares.",
              "ruleName": "json-test"
            }
            """;

        mvc.perform(post("/api/scan/json")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.status").value("SUCCESS"));
    }

    @Test
    @DisplayName("POST /api/scan/json with empty messageText returns 400")
    void scanJson_emptyMessage_returns400() throws Exception {
        String body = """
            {
              "inputMode": "TERMS",
              "messageMode": "TEXT",
              "terms": "insider AND trading",
              "messageText": ""
            }
            """;

        mvc.perform(post("/api/scan/json")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
           .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("POST /api/scan/json with empty terms returns 400")
    void scanJson_emptyTerms_returns400() throws Exception {
        String body = """
            {
              "inputMode": "TERMS",
              "messageMode": "TEXT",
              "terms": "",
              "messageText": "some message"
            }
            """;

        mvc.perform(post("/api/scan/json")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
           .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Response includes htmlHighlightedMessage and termResults array")
    void scanMultipart_responseStructure_complete() throws Exception {
        when(orchestrator.scan(anyList(), anyString(), anyString()))
                .thenReturn(successResponse(1, 1));

        mvc.perform(multipart("/api/scan")
                .param("inputMode", "TERMS")
                .param("messageMode", "TEXT")
                .param("terms", "insider AND trading")
                .param("messageText", "The insider bought shares"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.scanId").isNotEmpty())
           .andExpect(jsonPath("$.scanDurationMs").isNumber())
           .andExpect(jsonPath("$.htmlHighlightedMessage").isString())
           .andExpect(jsonPath("$.termResults").isArray());
    }

    // ── Fixtures ──────────────────────────────────────────────────────────────

    private ScanResponse successResponse(int total, int matched) {
        List<TermScanResult> terms = List.of(
                new TermScanResult("r::1", "insider AND trading",
                        "(?:insider|trading)", "PASS", true,
                        List.of(), matched > 0, null, null));

        return ScanResponse.success(
                UUID.randomUUID().toString(), 42L, total, matched, 0,
                "test message",
                "<mark class=\"lex-match\">insider</mark> trading",
                terms, List.of());
    }
}
