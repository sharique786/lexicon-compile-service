package com.db.macs3.ecomms.spectre.translator;

import java.util.ArrayList;
import java.util.List;

/**
 * Recursive-descent parser: {@code List<Token>} → {@link Ast}.
 *
 * <h2>Grammar (highest precedence last, i.e. tightest-binding first)</h2>
 * <pre>
 * orExpr        := andNotExpr ( OR andNotExpr )*
 * andNotExpr    := andExpr ( AND_NOT andExpr )*
 * andExpr       := proximityExpr ( AND proximityExpr )*
 * proximityExpr := notExpr ( (NEAR | FOLLOWEDBY) notExpr )*      [left-associative]
 * notExpr       := NOT? atom
 * atom          := '(' innerContent ')' | QUOTED_PHRASE | WORD
 * </pre>
 *
 * <p>Because every level of this grammar recurses into {@code atom}, and
 * {@code atom}'s parenthesised form recurses straight back into
 * {@code orExpr}, parentheses are resolved at whatever depth they actually
 * appear at — there is no separate "strip the outer parens first" pass to
 * get subtly wrong for multiply-nested or redundant wrapping. A term like
 * {@code (((me) OR (cking)))} is handled by ordinary recursion: the outer
 * two parens are pure grouping around a single atom, so each is consumed by
 * exactly one non-branching pass through {@code atom} → {@code orExpr} →
 * ... → {@code atom} before the actual {@code (me) OR (cking)} content is reached.
 *
 * <h2>Unwrapped multi-word phrase detection (requirement: "must be wrapped in a bracket")</h2>
 * <p>After parsing any atom via the normal grammar recursion, if another
 * atom-starting token ({@code WORD}, {@code QUOTED_PHRASE}, or {@code '('})
 * immediately follows with no operator in between, that is a syntax error —
 * see {@link #parseAtomWithWrapCheck}. This is what turns a bare
 * {@code bomb this place} into a clear "wrap it in parentheses" message
 * instead of silently mis-parsing.
 *
 * <h2>Bare multi-word phrase INSIDE parens</h2>
 * <p>{@code (bomb this place)} — no operator anywhere inside — is
 * recognised by {@link #parseParenGroup} via a look-ahead check
 * ({@link #hasTopLevelOperator}) BEFORE deciding whether to recurse into
 * {@code orExpr} or collect a flat {@link Ast.Phrase}.
 */
final class ExpressionParser {

    private final List<Token> tokens;
    private final String originalTerm;
    private int pos = 0;

    private ExpressionParser(List<Token> tokens, String originalTerm) {
        this.tokens = tokens;
        this.originalTerm = originalTerm;
    }

    /**
     * Parses a fully-tokenized lexicon term into an {@link Ast}.
     *
     * @param tokens       token stream from {@link Tokenizer#tokenize}
     * @param originalTerm the original (preprocessed) term text, for error messages
     * @return the root AST node
     * @throws TranslationException on any grammatical/structural validation failure
     */
    static Ast parse(List<Token> tokens, String originalTerm) {
        if (tokens.isEmpty()) {
            throw new TranslationException("Lexicon term is empty: '" + originalTerm + "'.");
        }
        ExpressionParser parser = new ExpressionParser(tokens, originalTerm);
        Ast result = parser.parseOr();
        if (parser.pos != tokens.size()) {
            throw parser.unexpectedTokenError("after '" + parser.describe(result) + "'");
        }
        return result;
    }

    // ── Grammar levels ───────────────────────────────────────────────────────

    private Ast parseOr() {
        List<Ast> parts = new ArrayList<>();
        parts.add(parseAndNot());
        while (peekIs(Token.Or.class)) {
            advance();
            parts.add(parseAndNot());
        }
        return parts.size() == 1 ? parts.get(0) : new Ast.Or(parts);
    }

    private Ast parseAndNot() {
        Ast required = parseAnd();
        List<Ast> excluded = new ArrayList<>();
        while (peekIs(Token.AndNot.class)) {
            advance();
            excluded.add(parseAnd());
        }
        return excluded.isEmpty() ? required : new Ast.AndNot(required, excluded);
    }

    private Ast parseAnd() {
        List<Ast> parts = new ArrayList<>();
        parts.add(parseProximity());
        while (peekIs(Token.And.class)) {
            advance();
            parts.add(parseProximity());
        }
        return parts.size() == 1 ? parts.get(0) : new Ast.And(parts);
    }

    private Ast parseProximity() {
        Ast left = parseNot();
        while (peekIsNearOrFollowedBy()) {
            Token op = advance();
            Ast right = parseNot();
            left = (op instanceof Token.Near near)
                    ? new Ast.Near(left, right, near.distance())
                    : new Ast.FollowedBy(left, right, ((Token.FollowedBy) op).distance());
        }
        return left;
    }

    private Ast parseNot() {
        if (peekIs(Token.Not.class)) {
            advance();
            return new Ast.Not(parseAtomWithWrapCheck());
        }
        return parseAtomWithWrapCheck();
    }

    /**
     * Parses one atom, then checks that another atom does not immediately
     * follow without an operator — see class Javadoc.
     */
    private Ast parseAtomWithWrapCheck() {
        Ast atom = parseAtom();
        if (peekStartsAtom()) {
            String shown = describe(atom);
            throw new TranslationException(
                    "Multi-word phrase must be wrapped in parentheses in term: '" + originalTerm + "'."
                    + " Found content immediately after '" + shown + "' with no operator"
                    + " (OR / AND / AND NOT / NEAR{n} / FOLLOWEDBY{n}) between them."
                    + " If this is meant to be one literal phrase, wrap it in parentheses,"
                    + " e.g. \"(" + shown + " ...)\".");
        }
        return atom;
    }

    private Ast parseAtom() {
        if (pos >= tokens.size()) {
            throw unexpectedTokenError("expected a term");
        }
        Token t = tokens.get(pos);
        if (t instanceof Token.LParen) {
            return parseParenGroup();
        }
        if (t instanceof Token.QuotedPhrase qp) {
            advance();
            return new Ast.QuotedPhrase(qp.text());
        }
        if (t instanceof Token.Word w) {
            advance();
            return new Ast.Word(w.text());
        }
        throw unexpectedTokenError("expected a term, parenthesis, or quoted phrase");
    }

    /**
     * Handles {@code '(' ... ')'}. Looks ahead to the matching close paren
     * FIRST to decide whether the content is an operator-expression (recurse
     * into {@link #parseOr}) or a bare, operator-free run of words (collect
     * as a single {@link Ast.Word} or {@link Ast.Phrase}).
     */
    private Ast parseParenGroup() {
        int lparenIdx = pos;
        advance(); // consume '('
        int matchingRParen = findMatchingRParen(lparenIdx);

        if (hasTopLevelOperator(pos, matchingRParen)) {
            Ast inner = parseOr();
            expectRParen();
            return inner;
        }

        // No operator visible AT THIS DEPTH — but that can also mean this
        // whole group is PURE REDUNDANT WRAPPING around exactly one more
        // parenthesized group, e.g. the middle "(" in "(((me) OR (cking)))":
        // the OR is there, just one level deeper than this scan looked.
        // Detect that case — the entire content between pos and
        // matchingRParen IS just one single '(' ... ')' spanning the whole
        // range — and recurse, so ANY number of redundant wrapping layers
        // resolves correctly, not just exactly one.
        if (pos < matchingRParen
                && tokens.get(pos) instanceof Token.LParen
                && findMatchingRParen(pos) == matchingRParen - 1) {
            Ast inner = parseParenGroup();
            expectRParen();
            return inner;
        }

        // Genuinely no operator and not pure re-wrapping — a single word, a
        // single quoted phrase, or a bare multi-word phrase.
        if (pos == matchingRParen) {
            throw new TranslationException("Empty parentheses '()' are not allowed in term: '" + originalTerm + "'.");
        }

        if (pos + 1 == matchingRParen && tokens.get(pos) instanceof Token.QuotedPhrase qp) {
            advance();
            expectRParen();
            return new Ast.QuotedPhrase(qp.text());
        }

        List<String> words = new ArrayList<>();
        while (pos < matchingRParen) {
            Token inner = advance();
            if (inner instanceof Token.Word w) {
                words.add(w.text());
            } else if (inner instanceof Token.QuotedPhrase qp) {
                words.add(qp.text()); // quoted chunk mixed with bare words — folded in literally
            } else {
                throw unexpectedTokenError("inside parentheses");
            }
        }
        expectRParen();

        return words.size() == 1 ? new Ast.Word(words.get(0)) : new Ast.Phrase(words);
    }

    // ── Look-ahead helpers ────────────────────────────────────────────────────

    /**
     * Finds the index of the {@code ')'} matching the {@code '('} at
     * {@code lparenIdx}. The {@link Tokenizer} already guarantees overall
     * balance, so a match is always found.
     */
    private int findMatchingRParen(int lparenIdx) {
        int depth = 0;
        for (int i = lparenIdx; i < tokens.size(); i++) {
            Token t = tokens.get(i);
            if (t instanceof Token.LParen) {
                depth++;
            } else if (t instanceof Token.RParen) {
                depth--;
                if (depth == 0) return i;
            }
        }
        throw new TranslationException(
                "Internal parser error: no matching ')' found for '(' in term: '" + originalTerm + "'.");
    }

    /** True if any operator token appears at depth 0 within {@code [from, to)}. */
    private boolean hasTopLevelOperator(int from, int to) {
        int depth = 0;
        for (int i = from; i < to; i++) {
            Token t = tokens.get(i);
            if (t instanceof Token.LParen) {
                depth++;
            } else if (t instanceof Token.RParen) {
                depth--;
            } else if (depth == 0 && isOperator(t)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isOperator(Token t) {
        return t instanceof Token.Or || t instanceof Token.And || t instanceof Token.AndNot
                || t instanceof Token.Near || t instanceof Token.FollowedBy || t instanceof Token.Not;
    }

    private boolean peekStartsAtom() {
        if (pos >= tokens.size()) return false;
        Token t = tokens.get(pos);
        return t instanceof Token.Word || t instanceof Token.QuotedPhrase || t instanceof Token.LParen;
    }

    private boolean peekIsNearOrFollowedBy() {
        if (pos >= tokens.size()) return false;
        Token t = tokens.get(pos);
        return t instanceof Token.Near || t instanceof Token.FollowedBy;
    }

    private boolean peekIs(Class<? extends Token> type) {
        return pos < tokens.size() && type.isInstance(tokens.get(pos));
    }

    private Token advance() {
        return tokens.get(pos++);
    }

    private void expectRParen() {
        if (pos >= tokens.size() || !(tokens.get(pos) instanceof Token.RParen)) {
            throw new TranslationException(
                    "Expected closing ')' in term: '" + originalTerm + "'.");
        }
        pos++;
    }

    private TranslationException unexpectedTokenError(String context) {
        return new TranslationException(
                "Could not parse term: '" + originalTerm + "' (" + context + ")."
                + " Check for missing operators between adjacent parts, unwrapped multi-word"
                + " phrases (must be in parentheses), or unbalanced parentheses.");
    }

    /** Best-effort human-readable rendering of an AST node for error messages. */
    private String describe(Ast ast) {
        return switch (ast) {
            case Ast.Word w -> w.text();
            case Ast.Phrase p -> String.join(" ", p.words());
            case Ast.QuotedPhrase q -> "\"" + q.text() + "\"";
            default -> "(...)";
        };
    }
}
