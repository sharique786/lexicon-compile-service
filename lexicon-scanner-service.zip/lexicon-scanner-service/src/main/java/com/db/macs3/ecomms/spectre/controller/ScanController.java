package com.db.macs3.ecomms.spectre.controller;

import com.db.macs3.ecomms.spectre.config.AppProperties;
import com.db.macs3.ecomms.spectre.model.Models.ScanApiRequest;
import com.db.macs3.ecomms.spectre.model.Models.ScanResponse;
import com.db.macs3.ecomms.spectre.service.CsvParserService;
import com.db.macs3.ecomms.spectre.service.LexiconScanOrchestrator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * REST controller exposing the Lexicon Scanner API.
 *
 * <h2>Endpoints</h2>
 * <pre>
 * POST /api/scan            — multipart/form-data  (UI form submission)
 * POST /api/scan/json       — application/json     (programmatic / GZIP clients)
 * GET  /api/scan/health     — liveness check
 * </pre>
 *
 * <h2>Input modes</h2>
 * <ul>
 *   <li>{@code inputMode=TERMS} + {@code terms}   — newline-separated term descriptions</li>
 *   <li>{@code inputMode=CSV}   + {@code csvFile}  — uploaded CSV file (term_id, term_desc, risk)</li>
 * </ul>
 *
 * <h2>Message modes</h2>
 * <ul>
 *   <li>{@code messageMode=TEXT} + {@code messageText} — raw text pasted in the UI</li>
 *   <li>{@code messageMode=FILE} + {@code messageFile} — uploaded text/email/chat file</li>
 * </ul>
 *
 * <p>Both request types are validated before the scan pipeline runs.
 * Validation errors return HTTP 400 with a descriptive JSON body.
 */
@RestController
@RequestMapping("/api/scan")
public class ScanController {

    private static final Logger log = LoggerFactory.getLogger(ScanController.class);

    private final LexiconScanOrchestrator orchestrator;
    private final CsvParserService csvParser;
    private final AppProperties props;

    public ScanController(LexiconScanOrchestrator orchestrator,
                          CsvParserService csvParser,
                          AppProperties props) {
        this.orchestrator = orchestrator;
        this.csvParser = csvParser;
        this.props = props;
    }

    /**
     * Multipart form-data endpoint — the primary entry point from the web UI.
     *
     * @param inputMode   {@code TERMS} or {@code CSV}
     * @param messageMode {@code TEXT} or {@code FILE}
     * @param terms       (optional) newline-separated terms when inputMode=TERMS
     * @param csvFile     (optional) CSV file when inputMode=CSV
     * @param messageText (optional) message text when messageMode=TEXT
     * @param messageFile (optional) message file when messageMode=FILE
     * @param ruleName    (optional) name for this scan session
     * @return HTTP 200 with {@link ScanResponse}, or HTTP 400 on validation failure
     */
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ScanResponse> scanMultipart(
            @RequestParam(defaultValue = "TERMS") String inputMode,
            @RequestParam(defaultValue = "TEXT")  String messageMode,
            @RequestParam(required = false) String terms,
            @RequestParam(required = false) MultipartFile csvFile,
            @RequestParam(required = false) String messageText,
            @RequestParam(required = false) MultipartFile messageFile,
            @RequestParam(required = false) String ruleName) throws IOException {

        log.info("POST /api/scan (multipart): inputMode={}, messageMode={}", inputMode, messageMode);

        // ── Parse terms ────────────────────────────────────────────────────
        List<String> termList = resolveTerms(inputMode, terms, csvFile);
        if (termList.isEmpty()) {
            return badRequest("No lexicon terms provided. "
                    + "Enter at least one term or upload a non-empty CSV.");
        }
        if (termList.size() > props.getScanner().getMaxTerms()) {
            return badRequest("Too many terms: " + termList.size()
                    + " exceeds the limit of " + props.getScanner().getMaxTerms() + ".");
        }

        // ── Parse message ───────────────────────────────────────────────────
        String message = resolveMessage(messageMode, messageText, messageFile);
        if (message.isBlank()) {
            return badRequest("No message text provided. "
                    + "Enter message text or upload a message file.");
        }
        if (message.length() > props.getScanner().getMaxMessageLength()) {
            return badRequest("Message too long: " + message.length()
                    + " chars exceeds limit of " + props.getScanner().getMaxMessageLength() + ".");
        }

        ScanResponse response = orchestrator.scan(termList, message, ruleName);
        return ResponseEntity.ok(response);
    }

    /**
     * JSON endpoint for programmatic clients and GZIP-compressed requests.
     * The body is {@link ScanApiRequest} which supports both TERMS and CSV (inline text) modes.
     *
     * @param request scan request body
     * @return HTTP 200 with {@link ScanResponse}
     */
    @PostMapping(path = "/json",
                 consumes = MediaType.APPLICATION_JSON_VALUE,
                 produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ScanResponse> scanJson(@RequestBody ScanApiRequest request) {
        log.info("POST /api/scan/json: inputMode={}, messageMode={}",
                request.inputMode(), request.messageMode());

        List<String> termList = resolveTermsFromJson(request);
        if (termList.isEmpty()) {
            return badRequest("No lexicon terms provided in the JSON request body.");
        }

        String message = "FILE".equalsIgnoreCase(request.messageMode())
                ? "" // JSON callers must provide text, not a file
                : (request.messageText() != null ? request.messageText().strip() : "");
        if (message.isBlank()) {
            return badRequest("messageText is required in the JSON request body.");
        }

        ScanResponse response = orchestrator.scan(termList, message, request.ruleName());
        return ResponseEntity.ok(response);
    }

    /**
     * Health check — returns service status and key configuration values.
     * Used by GKE/Compute Engine liveness probes and the Lexicon Scanner UI header.
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", "lexicon-scanner-service",
                "compileServiceUrl", props.getCompileService().getBaseUrl(),
                "maxTerms", props.getScanner().getMaxTerms()
        ));
    }

    // ── Input resolution helpers ──────────────────────────────────────────────

    private List<String> resolveTerms(String inputMode, String terms, MultipartFile csvFile)
            throws IOException {
        if ("CSV".equalsIgnoreCase(inputMode)) {
            if (csvFile != null && !csvFile.isEmpty()) {
                return csvParser.parseTermDescriptions(csvFile);
            }
            log.warn("inputMode=CSV but no file was uploaded");
            return List.of();
        }
        // TERMS mode — split on newlines, strip blanks
        if (terms != null && !terms.isBlank()) {
            return Arrays.stream(terms.split("[\r\n]+"))
                    .map(String::strip)
                    .filter(s -> !s.isBlank() && !s.startsWith("#"))
                    .collect(Collectors.toList());
        }
        return List.of();
    }

    private List<String> resolveTermsFromJson(ScanApiRequest request) {
        if ("CSV".equalsIgnoreCase(request.inputMode()) && request.csvContent() != null) {
            return csvParser.parseTermDescriptionsFromText(request.csvContent());
        }
        if (request.terms() != null && !request.terms().isBlank()) {
            return Arrays.stream(request.terms().split("[\r\n]+"))
                    .map(String::strip)
                    .filter(s -> !s.isBlank() && !s.startsWith("#"))
                    .collect(Collectors.toList());
        }
        return List.of();
    }

    private String resolveMessage(String messageMode, String messageText, MultipartFile messageFile)
            throws IOException {
        if ("FILE".equalsIgnoreCase(messageMode)) {
            if (messageFile != null && !messageFile.isEmpty()) {
                return new String(messageFile.getBytes(), StandardCharsets.UTF_8).strip();
            }
            log.warn("messageMode=FILE but no file was uploaded");
            return "";
        }
        return (messageText != null) ? messageText.strip() : "";
    }

    private ResponseEntity<ScanResponse> badRequest(String errorMessage) {
        log.warn("Bad request: {}", errorMessage);
        return ResponseEntity
                .badRequest()
                .body(ScanResponse.error("validation-error", errorMessage));
    }
}
