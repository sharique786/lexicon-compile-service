# Lexicon Compile Service
### Spring Boot 4.0.6 · JDK 21 · Intel Hyperscan (com.gliwka.hyperscan 5.4.0-2.0.0) · GCP Cloud Run

**Base package:** `com.db.macs3.ecomms.spectre`

---

## What This Service Does

Accepts lexicon rule definitions (as JSON, CSV, or a typed bundle request), translates each term description into a Hyperscan-compatible PCRE pattern, validates it via `Database.compile()`, and returns per-term compilation results. Used by compliance surveillance systems before scanning millions of communication messages at runtime.

---

## Supported Term Description Features

| Feature | Syntax | PCRE output |
|---|---|---|
| **OR** | `price OR spread OR stock` | `(?:price\|spread\|stock)` |
| **AND** | `A AND B AND C` | Every ordering of A/B/C joined by an unbounded gap — see [AND](#and-co-occurrence-any-order-no-distance-limit) below |
| **AND NOT** | `insider AND NOT disclaimer` | TWO separate patterns — see [AND NOT](#and-not-a-two-pattern-contract-not-a-single-regex) below |
| **NEAR{n}** | `manipulate NEAR{5} price` | Bidirectional, bounded gap: `(?:A{gap}B\|B{gap}A)` |
| **FOLLOWEDBY{n}** | `don't FOLLOWEDBY{3} compliance` | Directional, bounded gap: `A{gap}B` only |
| **Wildcard trailing** | `manipulate*` | `manipulate\S*` |
| **Wildcard leading** | `*running` | `\S*running` |
| **Literal `?`** | `he?d kill` | `he\?d kill` — always literal, never the PCRE "optional" quantifier |
| **Quoted phrase** | `"please don't forward"` | PCRE-escaped literal (`*`/`?` inside quotes are also literal) |
| **CSV double-quote** | `""please don't forward""` | Unescaped → `"please don't forward"` |
| **Unwrapped multi-word phrase** | `bomb this place OR blow this place up` | Each run of bare words with no operator between them is treated as one literal phrase automatically — wrapping in parentheses is optional, not required |
| **Emoji** | `💰 OR 🤫` | `(?:\x{1F4B0}\|\x{1F92B})` + UTF8+UCP |
| **Korean / Japanese / Chinese / Arabic / Hebrew / German / Turkish** | e.g. `비밀 OR 내부자 거래` | Literal + UTF8+UCP flags |
| **Leet-speak** | `1ns1d3r* OR fr0nt*` | Literal (intentional — matches obfuscated text) |
| **Mixed language** | `insider OR 내부자 OR 💰` | OR group + UTF8+UCP |

> **There is no independent `NOT` operator.** `NOT` (and the legacy `!` shorthand) previously worked as a standalone prefix negation; it no longer does. `NOT` is only ever valid immediately after `AND`, as `AND NOT`. A bare `NOT some text` is rejected at compile time with an explicit error telling you to write `AND NOT` instead. `!` has no special meaning any more — it is now ordinary literal text.

---

## AND: co-occurrence, any order, no distance limit

`price AND rigging` means: both words must appear **somewhere** in the message, in **any order**, with **no limit** on how far apart they are — the same relationship `FOLLOWEDBY{n}` expresses, just without `FOLLOWEDBY`'s distance cap. This is genuinely compiled into a single Hyperscan pattern using the same bidirectional-alternation technique `NEAR`/`FOLLOWEDBY` already use for a *bounded* gap, just with the gap made unbounded:

```
price AND rigging
  → (?:price[\s\S]*rigging|rigging[\s\S]*price)
```

`[\s\S]*` matches any character, any number of times — ordinary PCRE alternation and repetition, nothing Hyperscan can't compile. For three or more operands, every ordering (permutation) is enumerated the same way: `A AND B AND C` produces all six A/B/C orderings joined by `|`. **A term can have at most 5 AND operands at one level** — each additional operand multiplies the pattern's permutation count (5! = 120), and beyond that the resulting pattern reliably becomes too large for Hyperscan to compile; split a larger requirement into multiple simpler lexicon terms instead.

Worked example, matching the exact scenario this fix addresses:

| Message | `price AND rigging` |
|---|---|
| *"There's price change and market rigging is going on"* | **Matches** — both words present, in that order, with other words between them |
| *"There's price change"* | **Does not match** — "rigging" never appears |

### An earlier version of this document was wrong about this

A previous revision documented AND as `(?=.*A)(?=.*B)(?=.*C).*` — a chain of positive lookaheads. **Hyperscan does not support lookahead of any kind** (it is a linear-time, DFA/NFA-based multi-pattern matcher, not a backtracking engine), so that pattern was never something Hyperscan could actually compile and use as documented. In practice, terms using AND degraded silently to matching on *any single* operand — `price AND rigging` behaved like `price OR rigging`. The fix above removes lookahead from the picture entirely.

---

## AND NOT: a two-pattern contract, not a single regex

`price AND NOT change` means: `price` must appear, and `change` must **not** appear anywhere in the same message. Unlike AND, this cannot be compiled into one Hyperscan pattern — "absent from the whole text" is exactly what negative lookaround exists to express, and Hyperscan has none. There is no regex trick that works around this for arbitrary sub-patterns.

An earlier version of this document also documented `insider AND NOT disclaimer` as `(?=.*insider)(?!.*disclaimer).*` — a positive lookahead plus a *negative* lookahead. Same problem, worse: Hyperscan supports neither.

Instead, the service returns **two independent, separately Hyperscan-validated patterns**, and it is the caller's responsibility to combine them:

```json
{
  "translatedPattern":       "price",
  "requiresExclusionCheck":  true,
  "exclusionPattern":        "(?:change)"
}
```

A term is correctly matched only when:

```
translatedPattern  DOES match the message      AND
exclusionPattern   does NOT match the message
```

Worked example — `price AND NOT change` against both messages from the AND example above:

| Message | `translatedPattern` ("price") matches? | `exclusionPattern` ("change") matches? | Term matches? |
|---|---|---|---|
| *"There's price change and market rigging is going on"* | yes | yes | **No** — "change" is present |
| *"There's price change"* | yes | yes | **No** — "change" is present |

Both patterns are validated by `Database.compile()` independently at compile time — if either one is rejected by Hyperscan, the whole term is reported `FAILED` (an AND NOT term whose exclusion pattern can't even compile can't honour its own exclusion guarantee, so it is not reported as usable). Chained exclusions (`A AND NOT B AND NOT C`) combine B and C into one `exclusionPattern` via OR — the term is excluded if *either* is present.

### Applying this in your own scan code

```java
boolean requiredMatch  = hyperscanFoundAMatchFor(translatedPattern, message);
boolean excludedMatch  = requiresExclusionCheck
                          && hyperscanFoundAMatchFor(exclusionPattern, message);
boolean termMatches    = requiredMatch && !excludedMatch;
```

### `/compile/bundle`: the exclusion pattern is in the combined database too

The typed bundle endpoint (below) compiles every PASS term into one combined Hyperscan `.hdb` file. For a term at index `i` in the request with `requiresExclusionCheck=true`, its exclusion pattern is compiled into the **same** database at expression id `terms.size() + i` — a separate, predictable id space from the main terms' ids (`0` to `terms.size()-1`). A consumer working directly from the `.hdb` file (without the JSON) applies the identical rule: term `i` is matched only when Hyperscan reports a hit on id `i` and does **not** report a hit on id `terms.size() + i`.

---

## Validation: no chained NEAR/FOLLOWEDBY at the same level

A term like:

```
((termA OR termB OR termC) FOLLOWEDBY{5} (termD OR termE) FOLLOWEDBY{6} (termF OR termG))
```

chains two `FOLLOWEDBY` operators at the same grammar level. Each proximity operator's bidirectional pattern construction multiplies pattern size on its own; chaining two of them compounds that, and terms shaped like this reliably fail Hyperscan compilation with `Pattern Too Long` even though the term description itself parses without error. This is now rejected explicitly at translation time, before Hyperscan is ever invoked:

```
Cannot have multiple NEAR or FOLLOWEDBY operators at the same level in term: '...'
(found a second FOLLOWEDBY chained directly after the first). Wrap one side in
parentheses to nest them explicitly instead, e.g. '(A FOLLOWEDBY{n} B) FOLLOWEDBY{m} C'
```

If a term genuinely needs two proximity relationships, say so explicitly with parentheses — each side is then parsed at its own, separate grammar level, which both resolves the ambiguity and keeps the resulting pattern's size bounded:

```
(termA FOLLOWEDBY{5} termD) FOLLOWEDBY{6} termF     ✓ valid — explicit nesting
termA FOLLOWEDBY{5} termD FOLLOWEDBY{6} termF        ✗ rejected — chained, same level
```

The same rule applies to `NEAR`, and to any mix of `NEAR`/`FOLLOWEDBY` chained together.

---

## Hyperscan Flag Bitmask

| Flag | Value | Applied when |
|---|---|---|
| `HS_FLAG_CASELESS` | 1 | Always |
| `HS_FLAG_UTF8` | 32 | Any non-ASCII character present |
| `HS_FLAG_UCP` | 64 | Alongside UTF8, for Unicode property support |

Example: a Korean term → flags = 1 + 32 + 64 = 97.

> `HS_FLAG_DOTALL` is intentionally never set. DOTALL only changes what the bare `.` metacharacter matches — every gap this service generates (NEAR/FOLLOWEDBY's bounded gap, AND's unbounded gap) is built from the `\s`/`\S`/`[\s\S]` character classes, never from `.`, so DOTALL has no effect on anything this service produces.

---

## REST API

### `POST /api/lexicon/compile`

**Content-Type:** `application/json`
**Content-Encoding:** `gzip` *(recommended)*
**Accept-Encoding:** `gzip` *(recommended)*

#### Request
```json
{
  "lexiconRuleName": "lexicon_research_1",
  "terms": [
    {
      "termId": "lexicon_research_1::1",
      "termDescription": "(manipulate) NEAR{5} ((price) OR (spread) OR (stock))",
      "riskDriverName": "Research Based Front Running"
    },
    {
      "termId": "lexicon_research_1::2",
      "termDescription": "price AND NOT change",
      "riskDriverName": "Selective Disclosure"
    }
  ]
}
```

#### Response
```json
{
  "lexiconRuleName": "lexicon_research_1",
  "totalTerms": 2,
  "passCount": 2,
  "failedCount": 0,
  "hasFailures": false,
  "engineMode": "HYPERSCAN_NATIVE",
  "hyperscanVersion": "5.4.0-2.0.0",
  "compiledAt": "2026-01-15T10:23:45.123Z",
  "processingTimeMs": 12,
  "results": [
    {
      "termId": "lexicon_research_1::1",
      "termDescription": "(manipulate) NEAR{5} ((price) OR (spread) OR (stock))",
      "riskDriverName": "Research Based Front Running",
      "compilationStatus": "PASS",
      "translatedPattern": "(?:manipulate(?:\\s+\\S+){0,5}\\s+(?:price|spread|stock)|(?:price|spread|stock)(?:\\s+\\S+){0,5}\\s+manipulate)",
      "hyperscanFlags": 1,
      "requiresExclusionCheck": false,
      "compiledAt": "2026-01-15T10:23:45.124Z"
    },
    {
      "termId": "lexicon_research_1::2",
      "termDescription": "price AND NOT change",
      "riskDriverName": "Selective Disclosure",
      "compilationStatus": "PASS",
      "translatedPattern": "price",
      "hyperscanFlags": 1,
      "requiresExclusionCheck": true,
      "exclusionPattern": "(?:change)",
      "compiledAt": "2026-01-15T10:23:45.125Z"
    }
  ]
}
```

### `POST /api/lexicon/compile/csv`

**Content-Type:** `multipart/form-data`
Fields: `file` (CSV, columns `term_id, term_description[, risk_driver]`), `ruleName` (optional)

Same response shape as `/compile`.

### `POST /api/lexicon/compile/bundle`

**Content-Type:** `application/json`
Root-level `termType`: `"Natural Language"` (operator-language terms, translated as above) or `"Regex"` (caller-supplied PCRE, compiled verbatim — no translation, but still Hyperscan-validated and still script-aware for flags). One request, one term type, applied to every term in it.

**Response:** a zip containing the same JSON shape as `/compile` (plus `request_id` and `termType`) alongside a combined Hyperscan `.hdb` database file compiled from every `PASS` term — see [the AND NOT bundle note above](#compilebundle-the-exclusion-pattern-is-in-the-combined-database-too) for how exclusion patterns are represented in it.

### `GET /api/lexicon/health`

Returns engine mode, version, supported operators and languages.

### `GET /actuator/health`

Spring Boot Actuator health — includes the Hyperscan self-test component.

---

## Project Structure

```
lexicon-compile-service/
├── pom.xml                              Spring Boot 4, JDK 21, Hyperscan, Checkstyle, JaCoCo
├── Dockerfile                           2-stage JDK 21 build; no native compile step
│
├── src/main/java/com/db/macs3/ecomms/spectre/
│   ├── LexiconCompileServiceApp.java    @SpringBootApplication
│   │
│   ├── translator/
│   │   ├── Tokenizer.java               Raw text → token stream; ALL lexical validation lives here
│   │   ├── Token.java                   Sealed token types
│   │   ├── ExpressionParser.java        Token stream → AST; grammar-level validation (chained
│   │   │                                proximity, AND operand ceiling, no standalone NOT)
│   │   ├── Ast.java                     Sealed AST node types
│   │   ├── PatternCodeGenerator.java    AST → PCRE pattern(s); the AND/AND-NOT construction lives here
│   │   ├── MultiLanguagePatternBuilder.java  NEAR/FOLLOWEDBY bounded-gap construction, script-aware
│   │   ├── ParseContext.java            Mutable flag + exclusion-pattern accumulator during codegen
│   │   ├── TermSyntaxTranslator.java    Orchestrates the pipeline above; @Component entry point
│   │   ├── TranslationResult.java       Sealed interface: Success | Error (JDK 21)
│   │   └── TranslationException.java    Thrown for any lexical/grammatical validation failure
│   │
│   ├── hyperscan/
│   │   └── HyperscanCompiler.java       com.gliwka.hyperscan wrapper; @PostConstruct self-test
│   │
│   ├── model/
│   │   ├── CompileRequest.java          /compile request (with riskDriverName)
│   │   ├── CompileResponse.java         /compile and /compile/bundle response
│   │   ├── TypedCompileRequest.java     /compile/bundle request (root-level termType, no riskDriverName)
│   │   ├── TermType.java                NATURAL_LANGUAGE | REGEX
│   │   ├── TermCompilationResult.java   Per-term result; carries exclusionPattern for AND NOT terms
│   │   ├── CompilationStatus.java       PASS | FAILED
│   │   └── ScriptType.java              Unicode script classification for flag selection
│   │
│   ├── service/
│   │   ├── LexiconCompileService.java       Translate → validate (incl. exclusion pattern) → build response
│   │   ├── CsvCompileService.java           CSV parsing + BOM stripping; delegates to above
│   │   └── LexiconCompileBundleService.java Typed bundle endpoint; builds the combined .hdb
│   │
│   ├── controller/
│   │   ├── LexiconCompileController.java  POST /compile, /compile/csv, /compile/bundle, GET /health
│   │   └── GlobalExceptionHandler.java    @RestControllerAdvice — 400/413/500 responses
│   │
│   ├── util/
│   │   ├── ScriptDetector.java          Per-codepoint Unicode script detection → recommended flags
│   │   └── TikaLanguageSupport.java     Optional language-detection complement
│   │
│   └── config/
│       ├── GzipRequestFilter.java       jakarta.servlet.Filter — decompresses GZIP requests
│       ├── LexiconProperties.java       @ConfigurationProperties prefix: lexicon
│       └── LexiconCompileConfig.java    CORS, Hyperscan health indicator
│
├── src/main/resources/
│   ├── application.yml                  local / test / cloud-run profiles (no dup spring: keys)
│   └── checkstyle/
│       ├── checkstyle.xml               Google Java Style, 120-char limit, SLF4J enforcement
│       └── suppressions.xml
│
└── src/test/java/com/db/macs3/ecomms/spectre/
    ├── translator/TermSyntaxTranslatorTest.java       All operators, all languages, edge cases,
    │                                                   the exact AND/AND-NOT worked examples above
    ├── hyperscan/HyperscanCompilerTest.java            Live Hyperscan compile validation + thread safety
    ├── service/LexiconCompileServiceTest.java          End-to-end translate→compile pipeline
    ├── service/LexiconCompileBundleServiceTest.java    Typed bundle endpoint, Natural Language + Regex
    ├── service/CsvCompileServiceTest.java               CSV parsing: header, BOM, quotes, multi-lang
    ├── controller/LexiconCompileControllerTest.java    MockMvc: JSON, GZIP, CSV, validation, health
    └── integration/MultiLanguageIntegrationTest.java   Real messages in 8 languages + emoji
```

---

## curl Examples

### Plain JSON request
```bash
curl -X POST http://localhost:8080/api/lexicon/compile \
  -H "Content-Type: application/json" \
  -H "Accept-Encoding: gzip" \
  -d @src/test/resources/sample-request.json \
  --compressed | python3 -m json.tool
```

### GZIP request + response
```bash
gzip -c src/test/resources/sample-request.json | \
curl -X POST http://localhost:8080/api/lexicon/compile \
  -H "Content-Type: application/json" \
  -H "Content-Encoding: gzip" \
  -H "Accept-Encoding: gzip" \
  --data-binary @- \
  --compressed | python3 -m json.tool
```

### CSV upload
```bash
curl -X POST http://localhost:8080/api/lexicon/compile/csv \
  -F "file=@src/test/resources/sample-lexicon.csv" \
  -F "ruleName=lexicon_research_1" \
  -H "Accept-Encoding: gzip" \
  --compressed | python3 -m json.tool
```

### Typed bundle request (Natural Language)
```bash
curl -X POST http://localhost:8080/api/lexicon/compile/bundle \
  -H "Content-Type: application/json" \
  -d '{
        "request_id": "550e8400-e29b-41d4-a716-446655440000",
        "lexiconRuleName": "lexicon_research_1",
        "termType": "Natural Language",
        "terms": [
          {"termId": "lexicon_research_1::1", "termDescription": "price AND NOT change"}
        ]
      }' \
  -o bundle.zip
```

---

## Running Tests

```bash
# All tests (Hyperscan native lib auto-extracted from JAR)
mvn test

# Specific test class
mvn test -Dtest=TermSyntaxTranslatorTest
mvn test -Dtest=MultiLanguageIntegrationTest
mvn test -Dtest=LexiconCompileControllerTest

# Coverage report (target/site/jacoco/index.html)
mvn verify
```

---

## Cloud Run Deployment

```bash
export PROJECT_ID=my-gcp-project
export REGION=us-central1
export IMAGE=gcr.io/${PROJECT_ID}/lexicon-compile-service

gcloud builds submit --tag ${IMAGE} .

gcloud run deploy lexicon-compile-service \
  --image=${IMAGE} \
  --region=${REGION} \
  --memory=2Gi \
  --cpu=2 \
  --min-instances=1 \
  --max-instances=10 \
  --concurrency=80 \
  --set-env-vars="SPRING_PROFILES_ACTIVE=cloud-run" \
  --allow-unauthenticated
```
