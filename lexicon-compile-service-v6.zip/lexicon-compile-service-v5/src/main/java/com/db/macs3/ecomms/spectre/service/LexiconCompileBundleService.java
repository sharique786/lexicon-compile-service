package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.hyperscan.HyperscanCompiler;
import com.db.macs3.ecomms.spectre.model.CompileRequest;
import com.db.macs3.ecomms.spectre.model.CompileResponse;
import com.db.macs3.ecomms.spectre.model.TermCompilationResult;
import com.db.macs3.ecomms.spectre.model.TermType;
import com.db.macs3.ecomms.spectre.model.TypedCompileRequest;
import com.db.macs3.ecomms.spectre.util.ScriptDetector;
import com.gliwka.hyperscan.wrapper.Expression;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Orchestrates {@code POST /api/lexicon/compile/bundle}.
 *
 * <p>Each request carries one root-level {@link TermType}:
 * <ul>
 *   <li>{@link TermType#NATURAL_LANGUAGE} — translated via the existing
 *       {@code TermSyntaxTranslator} pipeline, by delegating straight to
 *       {@link LexiconCompileService#compileTerm}. Identical behaviour to
 *       {@code /compile} for every Natural Language term.</li>
 *   <li>{@link TermType#REGEX} — the caller's {@code termDescription} is already
 *       a PCRE pattern. No translation step runs; the pattern is compiled
 *       as-is. Flags are still derived from the pattern's script content
 *       via {@link ScriptDetector} so non-Latin Regex-type patterns (e.g. a raw
 *       Korean or Arabic regex) get the correct UTF8/UCP flags.</li>
 * </ul>
 *
 * <p>After every term is resolved to PASS or FAILED, all PASS terms are
 * compiled into <b>one combined multi-pattern Hyperscan database</b> via
 * {@link HyperscanCompiler#compileCombinedDatabase}. The JSON summary
 * returned by {@link #buildBundle} is the same {@link CompileResponse}
 * / {@link TermCompilationResult} shape that {@code /compile} returns, with
 * one addition specific to this endpoint: {@code hyperscanExpressionId} —
 * see below and {@link TermCompilationResult} class Javadoc.
 *
 * <h2>Hyperscan expression id scheme</h2>
 * <p>A term with no AND NOT exclusion gets one {@link Expression} at
 * {@code id = i}, its 0-based index in the request's {@code terms} array —
 * the same convention as before. FAILED terms are simply absent from the
 * combined database.
 *
 * <p><b>AND NOT terms are different: three expressions, one reportable id.</b>
 * Hyperscan cannot express "the exclusion pattern is absent from the whole
 * message" in a single pattern — there is no negative lookaround. What CAN
 * be expressed natively is a Hyperscan 5.0+ <i>logical combination</i>
 * ({@code HS_FLAG_COMBINATION}): a compiled expression whose text is a
 * boolean formula over OTHER expressions' ids (operators {@code &}/{@code |}/
 * {@code !}), which Hyperscan itself evaluates during the scan and reports
 * as a match only when the formula is true. For a term at index {@code i}
 * with an exclusion pattern, this method compiles THREE expressions into the
 * combined database:
 * <ul>
 *   <li>{@code id = i} — the required pattern, flagged
 *       {@link HyperscanCompiler#toSubExpressionFlags QUIET} so it never
 *       reports a match on its own</li>
 *   <li>{@code id = terms.size() + i} — the exclusion pattern, also QUIET</li>
 *   <li>{@code id = 2*terms.size() + i} — the combination expression
 *       {@code "(i&!(terms.size()+i))"}: matches only when {@code i}
 *       matched AND {@code terms.size()+i} did not</li>
 * </ul>
 * <p>The THIRD id is this term's {@code hyperscanExpressionId} — the ONLY id
 * a downstream consumer needs to watch. Because the required/exclusion
 * sub-expressions are QUIET, a consumer that merely counts "any match on
 * this database = an alert" is automatically correct with no per-term
 * special-casing: AND NOT terms simply never raise their sub-expression ids.
 * This is what makes the {@code .hdb} file alone — with no JSON in the loop —
 * correct for a consumer like the Lexicon Scan Engine's Dataproc job, which
 * loads the database and scans directly against it.
 *
 * <p>See {@link HyperscanCompiler} class Javadoc for the underlying Hyperscan
 * combination mechanism and the wrapper-version dependency note, and the
 * project README's "AND NOT in the combined database" section for a worked example.
 */
@Service
public class LexiconCompileBundleService {

    private static final Logger log = LoggerFactory.getLogger(LexiconCompileBundleService.class);

    private final LexiconCompileService compileService;
    private final HyperscanCompiler     compiler;
    private final Counter               naturalLanguageTermCounter;
    private final Counter               regexTermCounter;
    private final Counter               databaseBuiltCounter;
    private final Counter               databaseFailedCounter;

    public LexiconCompileBundleService(LexiconCompileService compileService,
                                        HyperscanCompiler compiler,
                                        MeterRegistry meterRegistry) {
        this.compileService             = compileService;
        this.compiler                    = compiler;
        this.naturalLanguageTermCounter = meterRegistry.counter("lexicon.compile.bundle.natural_language");
        this.regexTermCounter            = meterRegistry.counter("lexicon.compile.bundle.regex");
        this.databaseBuiltCounter       = meterRegistry.counter("lexicon.compile.bundle.database.built");
        this.databaseFailedCounter      = meterRegistry.counter("lexicon.compile.bundle.database.failed");
    }

    /**
     * Compiles every term in the request and builds the combined Hyperscan
     * database from the PASS subset.
     *
     * <p>{@link TypedCompileRequest#getTermType()} is at the request root
     * level — all terms in a single request share the same term type. The
     * {@link TypedCompileRequest#isRegexType()} check is therefore performed
     * once on the request, not per-term.
     *
     * @param request validated typed-compile request
     * @return {@link CompileBundleResult} — JSON summary + optional database bytes
     */
    public CompileBundleResult buildBundle(TypedCompileRequest request) {
        long startTimeMs = System.currentTimeMillis();
        log.info("Compiling bundle: {} {} term(s) for rule '{}' (request_id={})",
                request.getTerms().size(), request.getTermType(),
                request.getLexiconRuleName(), request.getRequestId());

        // termType is at the request root — the same branch applies to all terms.
        boolean isRegexType = request.isRegexType();

        List<TermCompilationResult> termResults      = new ArrayList<>(request.getTerms().size());
        List<Expression> passingExpressions          = new ArrayList<>(request.getTerms().size());
        int totalTermCount = request.getTerms().size();

        int expressionIndex = 0;
        for (TypedCompileRequest.TermInput termInput : request.getTerms()) {

            // Adapter: TermCompilationResult factories still require CompileRequest.TermInput.
            // riskDriverName is null — it is no longer part of the request or response.
            CompileRequest.TermInput termInputAdapter = new CompileRequest.TermInput(
                    termInput.termId(), termInput.termDescription(), null);

            TermCompilationResult termResult;
            if (isRegexType) {
                regexTermCounter.increment();
                termResult = compileRegexTerm(termInputAdapter);
            } else {
                naturalLanguageTermCounter.increment();
                termResult = compileService.compileTerm(termInputAdapter); // exact same pipeline as /compile
            }

            if (termResult.isPass()) {
                termResult = termResult.requiresExclusionCheck()
                        ? addAndNotCombination(termResult, expressionIndex, totalTermCount, passingExpressions)
                        : addPlainExpression(termResult, expressionIndex, passingExpressions);
            }
            termResults.add(termResult);
            expressionIndex++;
        }

        log.info("Bundle compile done rule='{}': {}/{} PASS, {}ms",
                request.getLexiconRuleName(),
                termResults.stream().filter(TermCompilationResult::isPass).count(),
                termResults.size(),
                System.currentTimeMillis() - startTimeMs);

        // ofBundle includes request_id and termType; omits hyperscanVersion and processingTimeMs
        CompileResponse jsonResponse = CompileResponse.ofBundle(
                request.getRequestId(),
                request.getTermType(),
                request.getLexiconRuleName(),
                termResults);

        return buildDatabasePortion(jsonResponse, passingExpressions);
    }

    // ── Expression construction ─────────────────────────────────────────────────

    /**
     * A term with no AND NOT exclusion: one ordinary {@link Expression} at
     * {@code id = expressionIndex}, reported normally. Its
     * {@code hyperscanExpressionId} is simply that same index.
     */
    private TermCompilationResult addPlainExpression(TermCompilationResult termResult, int expressionIndex,
                                                       List<Expression> passingExpressions) {
        passingExpressions.add(new Expression(
                termResult.translatedPattern(),
                compiler.toExpressionFlags(termResult.hyperscanFlags()),
                expressionIndex));
        return termResult.withHyperscanExpressionId(expressionIndex);
    }

    /**
     * An AND NOT term: three expressions compiled into the combined database
     * (required pattern, exclusion pattern, and the native Hyperscan logical
     * combination over both) — see class Javadoc for the full id scheme and
     * {@link HyperscanCompiler} for the underlying mechanism. Returns the
     * term result with {@code hyperscanExpressionId} set to the combination
     * expression's id — the one id a downstream consumer should watch.
     */
    private TermCompilationResult addAndNotCombination(TermCompilationResult termResult, int expressionIndex,
                                                         int totalTermCount, List<Expression> passingExpressions) {
        int requiredId    = expressionIndex;
        int exclusionId   = totalTermCount + expressionIndex;
        int combinationId = 2 * totalTermCount + expressionIndex;

        passingExpressions.add(new Expression(
                termResult.translatedPattern(),
                compiler.toSubExpressionFlags(termResult.hyperscanFlags()),
                requiredId));
        passingExpressions.add(new Expression(
                termResult.exclusionPattern(),
                compiler.toSubExpressionFlags(termResult.hyperscanFlags()),
                exclusionId));
        passingExpressions.add(new Expression(
                "(%d&!%d)".formatted(requiredId, exclusionId),
                compiler.toCombinationExpressionFlags(),
                combinationId));

        return termResult.withHyperscanExpressionId(combinationId);
    }

    // ── Regex-type term handling ─────────────────────────────────────────────

    /**
     * Compiles a {@link TermType#REGEX} term: the pattern is the caller's
     * {@code termDescription} verbatim — no operator-language translation.
     *
     * <p>Flags are still derived automatically via {@link ScriptDetector} so
     * a raw non-Latin regex (e.g. a hand-written Korean or Arabic pattern)
     * gets UTF8/UCP without the caller having to know Hyperscan's flag
     * bitmask values. {@code requiresExclusionCheck} is always {@code false}
     * for Regex-type terms — AND NOT is part of the Natural Language operator
     * language's syntax; an arbitrary caller-supplied regex has no such
     * two-pattern exclusion contract to participate in.
     */
    private TermCompilationResult compileRegexTerm(CompileRequest.TermInput termInputAdapter) {
        String pattern = termInputAdapter.termDescription();
        int hyperscanFlags = ScriptDetector.detect(pattern).recommendedHsFlags();

        HyperscanCompiler.ValidationResult validation = compiler.validate(pattern, hyperscanFlags);

        return validation.isPass()
                ? TermCompilationResult.pass(termInputAdapter, pattern, hyperscanFlags)
                : TermCompilationResult.failedHyperscan(
                        termInputAdapter, pattern, validation.errorMessage(), hyperscanFlags);
    }

    // ── Combined database ────────────────────────────────────────────────────

    private CompileBundleResult buildDatabasePortion(CompileResponse jsonResponse,
                                                       List<Expression> passingExpressions) {
        if (passingExpressions.isEmpty()) {
            log.warn("No PASS terms for rule '{}' — no combined database will be built",
                    jsonResponse.lexiconRuleName());
            return new CompileBundleResult(jsonResponse, null,
                    "No Hyperscan database file was produced because zero terms reached "
                  + "PASS status. See the JSON results for per-term compilationStatus and "
                  + "errorLog/translationError details.");
        }

        HyperscanCompiler.CombinedCompileResult combinedResult =
                compiler.compileCombinedDatabase(passingExpressions);

        if (combinedResult.success()) {
            databaseBuiltCounter.increment();
            return new CompileBundleResult(jsonResponse, combinedResult.databaseBytes(), null);
        }

        databaseFailedCounter.increment();
        log.error("Combined database compile FAILED for rule '{}': {} (failedExpressionId={})",
                jsonResponse.lexiconRuleName(), combinedResult.errorMessage(), combinedResult.failedExpressionId());

        String explanation = "No Hyperscan database file was produced.\nReason: "
                + combinedResult.errorMessage()
                + (combinedResult.failedExpressionId() != null
                        ? "\nThe term at results[" + combinedResult.failedExpressionId()
                          + "] (0-based index) caused the combined compile to fail, even though "
                          + "it passed individual validation. See the JSON results for that term's details."
                        : "");
        return new CompileBundleResult(jsonResponse, null, explanation);
    }

    // ── Result carrier ───────────────────────────────────────────────────────

    /**
     * Carries the two zip-file payloads back to the controller.
     *
     * @param jsonResponse            identical shape to {@code /compile}'s response —
     *                                this is what gets written as the zip's JSON entry
     * @param hyperscanDatabaseBytes  the combined {@code .hdb} file content, or
     *                                {@code null} when no database could be built
     * @param databaseNote            explanation written into {@code NO_DATABASE.txt}
     *                                when {@code hyperscanDatabaseBytes} is null;
     *                                null when a database was built successfully
     */
    public record CompileBundleResult(
            CompileResponse jsonResponse,
            byte[]          hyperscanDatabaseBytes,
            String          databaseNote
    ) {
        /** @return true when a combined Hyperscan database was produced. */
        public boolean hasDatabase() {
            return hyperscanDatabaseBytes != null && hyperscanDatabaseBytes.length > 0;
        }
    }
}
