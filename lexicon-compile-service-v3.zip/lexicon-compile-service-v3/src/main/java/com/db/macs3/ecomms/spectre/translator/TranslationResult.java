package com.db.macs3.ecomms.spectre.translator;

import java.util.List;

/**
 * Sealed result type for one {@link TermSyntaxTranslator#translate} call.
 *
 * <p>JDK 21 sealed interface with two permitted records. Use pattern matching switch:
 * <pre>
 * switch (result) {
 *   case TranslationResult.Success s -> use(s.hsPattern(), s.hsFlags());
 *   case TranslationResult.Error   e -> log(e.message());
 * }
 * </pre>
 */
public sealed interface TranslationResult
        permits TranslationResult.Success, TranslationResult.Error {

    /** Returns true when translation succeeded. */
    boolean isSuccess();

    /**
     * Successful translation.
     *
     * @param hsPattern            Hyperscan PCRE pattern string
     * @param hsFlags              Bitmask: 1=CASELESS, 2=DOTALL, 32=UTF8, 64=UCP
     * @param requiresAndPostFilter true when AND / AND NOT / NOT was used —
     *                              caller must apply a scan-time post-filter
     * @param requiredOperands     patterns that must ALL be present (from AND,
     *                             and the positive side of AND NOT)
     * @param excludedOperands     patterns that must ALL be absent (from the
     *                             NOT side(s) of AND NOT). Previously this
     *                             information was parsed for validation and
     *                             then discarded — see {@link ParseContext}
     *                             class Javadoc for why that was a real gap,
     *                             not just an internal refactor.
     */
    record Success(
            String       hsPattern,
            int          hsFlags,
            boolean      requiresAndPostFilter,
            List<String> requiredOperands,
            List<String> excludedOperands
    ) implements TranslationResult {

        /** @return true always */
        public boolean isSuccess() { return true; }
    }

    /**
     * Failed translation.
     *
     * @param message human-readable error
     */
    record Error(String message) implements TranslationResult {

        /** @return false always */
        public boolean isSuccess() { return false; }
    }

    /** Factory: successful translation. */
    static TranslationResult success(String pattern, int flags, boolean requiresPost,
                                      List<String> requiredOperands, List<String> excludedOperands) {
        return new Success(pattern, flags, requiresPost,
                List.copyOf(requiredOperands), List.copyOf(excludedOperands));
    }

    /** Factory: failed translation. */
    static TranslationResult error(String message) {
        return new Error(message);
    }
}
