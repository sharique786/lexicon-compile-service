package com.db.macs3.ecomms.spectre.service;

import com.db.macs3.ecomms.spectre.client.LexiconCompileClient;
import com.db.macs3.ecomms.spectre.model.DisclaimerSource;
import com.db.macs3.ecomms.spectre.model.Models.CompiledTerm;
import com.db.macs3.ecomms.spectre.model.Models.CompileServiceResponse;
import com.db.macs3.ecomms.spectre.model.Models.DisclaimerSpan;
import com.db.macs3.ecomms.spectre.model.Models.MatchHighlight;
import com.db.macs3.ecomms.spectre.model.Models.MessageScanResult;
import com.db.macs3.ecomms.spectre.model.Models.PatternValidationResult;
import com.db.macs3.ecomms.spectre.model.Models.RawMatch;
import com.db.macs3.ecomms.spectre.model.Models.ScanResponse;
import com.db.macs3.ecomms.spectre.model.Models.StrippedMessage;
import com.db.macs3.ecomms.spectre.model.Models.TermScanResult;
import com.db.macs3.ecomms.spectre.model.MessageSource;
import com.db.macs3.ecomms.spectre.model.TermSource;
import com.db.macs3.ecomms.spectre.model.TermType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Orchestrates the full Lexicon Scanner pipeline for one or more messages,
 * scanned against one shared term set and one shared disclaimer set.
 *
 * <ol>
 *   <li>Resolves lexicon term(s) into {@link CompiledTerm}s ONCE, with every
 *       required/excluded expression id assigned ONCE for the whole session
 *       — see {@link #resolveNaturalLanguageTerms} / {@link #resolveRegexTerms}
 *       and {@link CompiledTerm} class Javadoc.</li>
 *   <li>Resolves disclaimer text(s) ONCE from {@link DisclaimerSource} — optional;
 *       {@link DisclaimerSource.None} skips disclaimer detection entirely.</li>
 *   <li>Resolves the message(s) to scan from {@link MessageSource} — either the
 *       single pasted-text message, or one message per uploaded file.</li>
 *   <li>For EACH message independently: strips HTML
 *       ({@link HtmlStrippingService}), detects disclaimer occurrences
 *       ({@link DisclaimerDetectionService}), scans Hyperscan ONCE (see
 *       below), maps matches back to original-text coordinates, flags each
 *       match {@link MatchHighlight#inDisclaimer()}, and builds one
 *       {@link MessageScanResult}.</li>
 *   <li>Aggregates every message's results into one {@link ScanResponse}.</li>
 * </ol>
 *
 * <h2>Disclaimer exclusion from alerting</h2>
 * <p>A match found ONLY within a detected disclaimer region does not count
 * toward {@link TermScanResult#hasMatches()} (see
 * {@link MatchHighlight#countsTowardAlert()}) — the requirement that
 * boilerplate disclaimer text (e.g. "confidential" in a standard footer)
 * must never trigger a false alert, even when the same word also appears
 * meaningfully elsewhere in the same message. The match is still recorded
 * and shown on the UI (highlighted in a visually distinct style — see
 * {@link MatchHighlightService}) with a "not an alert" note, rather than
 * being silently discarded.
 *
 * <h2>AND NOT: no longer uses native Hyperscan COMBINATION — confirmed broken</h2>
 * <p>An earlier version of this design compiled AND NOT terms as a single
 * native {@code HS_FLAG_COMBINATION} formula and resolved the boolean
 * condition natively inside Hyperscan. This mirrored the Lexicon Compile
 * Service's own earlier design, which is confirmed BROKEN by Hyperscan's own
 * documented evaluation model — see {@link CompiledTerm} class Javadoc for
 * the full explanation. The observed failure mode: an AND NOT term could
 * incorrectly count as matched when its required pattern appeared BEFORE its
 * excluded pattern in the same message, since Hyperscan evaluates a
 * combination formula eagerly and progressively, and a formula mixing a
 * positive requirement with a negation does not qualify for the "purely
 * negative combinations deferred to end-of-data" treatment Hyperscan gives
 * combinations that could otherwise be satisfied by nothing having matched yet.
 *
 * <p>Every required and excluded pattern of an AND NOT term now compiles as
 * its own plain, individually reportable Hyperscan expression — see
 * {@link HyperscanScanService} class Javadoc "Expression building". This
 * class evaluates the boolean condition itself, directly, from the complete
 * set of matched expression ids ONE scan returns — see {@link #evaluateTerm}.
 *
 * <h2>A simplification this fix enables — no more secondary Java-regex check</h2>
 * <p>The earlier, combination-based design could only ever directly observe
 * whether the WHOLE AND NOT condition fired as one native event — never
 * whether the required side matched on its own when the combination didn't
 * fire. That forced a separate, secondary Java-regex check
 * ({@code detectAndNotExclusions}, now removed) purely to tell "excluded"
 * apart from "never matched at all" for the UI. Now that both sides are
 * independently, reliably reported by Hyperscan itself (or by the Java-regex
 * fallback path, which mirrors the same id shape — see
 * {@link HyperscanScanService#compileAndScan}), {@link #evaluateTerm} computes
 * both outcomes directly from one scan's match-id set, with no secondary
 * scan, no secondary regex pass, and no risk of the two diverging.
 */
@Service
public class LexiconScanOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(LexiconScanOrchestrator.class);

    private static final String EXCLUSION_NOTE_TEMPLATE =
            "AND NOT: excluded — the exclusion condition was also found in this message, "
            + "so this term does not count as an alert even though its required pattern matched.";

    private static final String SINGLE_TEXT_MESSAGE_ID = "Pasted Message";

    private final LexiconCompileClient compileClient;
    private final HyperscanScanService scanService;
    private final MatchHighlightService highlightService;
    private final HtmlStrippingService htmlStrippingService;
    private final CsvParserService csvParserService;
    private final DisclaimerDetectionService disclaimerDetectionService;

    public LexiconScanOrchestrator(LexiconCompileClient compileClient,
                                    HyperscanScanService scanService,
                                    MatchHighlightService highlightService,
                                    HtmlStrippingService htmlStrippingService,
                                    CsvParserService csvParserService,
                                    DisclaimerDetectionService disclaimerDetectionService) {
        this.compileClient = compileClient;
        this.scanService = scanService;
        this.highlightService = highlightService;
        this.htmlStrippingService = htmlStrippingService;
        this.csvParserService = csvParserService;
        this.disclaimerDetectionService = disclaimerDetectionService;
    }

    /**
     * Runs the full scan pipeline for the given lexicon term source, message
     * source, and (optional) disclaimer source.
     *
     * @param termType         whether the term(s) are Natural Language (translated via
     *                         the Compile Service) or already-valid Regex (compiled directly)
     * @param termSource       the term(s) themselves — typed text or an uploaded CSV file
     * @param messageSource    the message(s) to scan — pasted text, or one or more uploaded files
     * @param disclaimerSource disclaimer text(s) to exclude from alerting — optional
     * @param ruleName         optional rule name for the compile request
     * @return fully populated {@link ScanResponse}, covering every scanned message
     */
    public ScanResponse scan(TermType termType, TermSource termSource, MessageSource messageSource,
                              DisclaimerSource disclaimerSource, String ruleName) {
        String scanId = UUID.randomUUID().toString();
        long startMs = System.currentTimeMillis();
        List<String> warnings = new ArrayList<>();

        try {
            List<MessageSource.NamedMessageText> messages = resolveMessages(messageSource);
            List<String> disclaimerTexts = resolveDisclaimerTexts(disclaimerSource);

            log.info("Starting scan session: scanId={}, termType={}, messageCount={}, disclaimerCount={}",
                    scanId, termType, messages.size(), disclaimerTexts.size());

            // ── Terms are resolved ONCE — shared across every message ──────────────
            TermResolution resolution = (termType == TermType.REGEX)
                    ? resolveRegexTerms(termSource, warnings)
                    : resolveNaturalLanguageTerms(termSource, ruleName, warnings);

            int totalTerms = resolution.allResults.size();
            long andNotCount = resolution.compiledTerms.stream().filter(CompiledTerm::requiresExclusionCheck).count();
            log.info("scanId={}: {} term(s) ready for Hyperscan ({} with AND NOT exclusion), of {} submitted",
                    scanId, resolution.compiledTerms.size(), andNotCount, totalTerms);

            // ── Scan each message independently against the SAME compiled terms ────
            List<MessageScanResult> messageResults = new ArrayList<>(messages.size());
            for (MessageSource.NamedMessageText message : messages) {
                messageResults.add(scanOneMessage(message, resolution, termType, disclaimerTexts));
            }

            int failedTerms = (int) resolution.allResults.stream().filter(r -> !r.isPass()).count();
            long elapsedMs = System.currentTimeMillis() - startMs;

            log.info("Scan complete: scanId={}, messages={}, elapsed={}ms", scanId, messages.size(), elapsedMs);

            return ScanResponse.success(
                    scanId, elapsedMs, termType.jsonValue(),
                    totalTerms, disclaimerTexts.size(), failedTerms,
                    messageResults, warnings);

        } catch (Exception e) {
            log.error("Scan pipeline failed: scanId={}, error={}", scanId, e.getMessage(), e);
            return ScanResponse.error(scanId, "Scan failed: " + e.getMessage());
        }
    }

    // ── Per-message scanning ─────────────────────────────────────────────────────

    private MessageScanResult scanOneMessage(MessageSource.NamedMessageText message, TermResolution resolution,
                                              TermType termType, List<String> disclaimerTexts) {
        StrippedMessage strippedMessage = htmlStrippingService.strip(message.text());
        log.debug("message='{}': stripped {} chars -> {} chars",
                message.messageId(), message.text().length(), strippedMessage.strippedText().length());

        List<DisclaimerSpan> disclaimerSpans =
                disclaimerDetectionService.detectDisclaimers(strippedMessage, disclaimerTexts);

        List<RawMatch> rawMatches = resolution.compiledTerms.isEmpty()
                ? Collections.emptyList()
                : scanService.compileAndScan(resolution.compiledTerms, strippedMessage.strippedText());

        // The complete set of every expression id that matched anywhere in this message,
        // by the time the (synchronous) scan call returned. This is the ONLY thing
        // evaluateTerm() needs to correctly resolve every term's boolean condition —
        // no secondary scan, no secondary regex pass. See class Javadoc.
        Set<Integer> matchedIds = rawMatches.stream()
                .map(RawMatch::expressionIndex)
                .collect(Collectors.toSet());

        Map<Integer, List<MatchHighlight>> matchesByIndex =
                highlightService.groupMatchesByTerm(rawMatches, resolution.compiledTerms, strippedMessage);

        // Apply disclaimer flags to every match BEFORE building term results / HTML,
        // so both downstream steps see the final, correct inDisclaimer value.
        Map<Integer, List<MatchHighlight>> flaggedMatchesByIndex = matchesByIndex.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> disclaimerDetectionService.applyDisclaimerFlags(e.getValue(), disclaimerSpans)));

        List<TermScanResult> termResults = buildTermResults(
                resolution.allResults, resolution.compiledTerms, flaggedMatchesByIndex, matchedIds, termType);

        List<MatchHighlight> allHighlights = flaggedMatchesByIndex.values().stream()
                .flatMap(List::stream)
                .toList();
        String htmlHighlighted = highlightService.buildHighlightedHtml(message.text(), allHighlights);

        int matchedTerms = (int) termResults.stream().filter(TermScanResult::hasMatches).count();
        boolean hasMatches = matchedTerms > 0;

        return new MessageScanResult(
                message.messageId(), message.text(), htmlHighlighted,
                disclaimerSpans, termResults, matchedTerms, hasMatches);
    }

    /**
     * Evaluates one term's boolean condition directly from the complete
     * match-id set one scan returned — see class Javadoc "no more secondary
     * Java-regex check". Applies the same AND convention to both sides,
     * exactly mirroring the documented {@code /compile}/{@code /compile/csv}
     * contract on the Compile Service side: the required side is satisfied
     * only when EVERY entry of {@code requiredExpressionIds} is present, and
     * (for an AND NOT term) the excluded side is satisfied only when EVERY
     * entry of {@code excludedExpressionIds} is present — not merely one.
     */
    private TermEvaluation evaluateTerm(CompiledTerm term, Set<Integer> matchedIds) {
        boolean requiredSatisfied = !term.requiredExpressionIds().isEmpty()
                && matchedIds.containsAll(term.requiredExpressionIds());
        boolean excludedSatisfied = term.requiresExclusionCheck()
                && term.excludedExpressionIds() != null
                && !term.excludedExpressionIds().isEmpty()
                && matchedIds.containsAll(term.excludedExpressionIds());
        return new TermEvaluation(requiredSatisfied, excludedSatisfied);
    }

    /**
     * @param requiredSatisfied true iff every entry of the term's requiredExpressionIds matched
     * @param excludedSatisfied true iff (this is an AND NOT term AND) every entry of
     *                          excludedExpressionIds matched — always false for a non-AND-NOT term
     */
    private record TermEvaluation(boolean requiredSatisfied, boolean excludedSatisfied) {
        /** True iff the term counts as matched: required satisfied AND NOT excluded. */
        boolean matched() { return requiredSatisfied && !excludedSatisfied; }
        /** True iff required matched but the term was excluded — see {@link TermScanResult#excludedByAndNot()}. */
        boolean excludedByAndNot() { return requiredSatisfied && excludedSatisfied; }
    }

    // ── Message resolution ───────────────────────────────────────────────────────

    /**
     * Extracts the resolved message list from {@link MessageSource}. File
     * reading and per-message length validation already happened in
     * {@code ScanController} — see {@link MessageSource} class Javadoc for
     * why that split exists — so this is a plain, exception-free extraction.
     */
    private List<MessageSource.NamedMessageText> resolveMessages(MessageSource source) {
        return switch (source) {
            case MessageSource.SingleText text ->
                    List.of(new MessageSource.NamedMessageText(SINGLE_TEXT_MESSAGE_ID, text.text()));
            case MessageSource.MultipleMessages messages -> messages.messages();
        };
    }

    // ── Disclaimer resolution ────────────────────────────────────────────────────

    /**
     * Resolves disclaimer text(s) into a flat list, reusing
     * {@link CsvParserService} unchanged for the CSV case — a disclaimer CSV
     * is read exactly like a lexicon term CSV (same two-column shape), just
     * interpreted as disclaimer text rather than a term description.
     */
    private List<String> resolveDisclaimerTexts(DisclaimerSource source) {
        return switch (source) {
            case DisclaimerSource.None ignored -> List.of();
            case DisclaimerSource.TextDisclaimers text -> text.disclaimerTexts();
            case DisclaimerSource.CsvFile csv -> csvParserService.parseTermDescriptions(csv.file());
        };
    }

    // ── Term resolution: NATURAL_LANGUAGE ───────────────────────────────────────

    /**
     * Resolves Natural Language terms by calling the Lexicon Compile Service —
     * {@code /compile} for typed text, {@code /compile/csv} for an uploaded
     * CSV file (forwarded as-is, never parsed locally). Every PASS term
     * becomes exactly one {@link CompiledTerm}, with expression ids assigned
     * ONCE here for the whole scan session — see {@link #nextExpressionIds}.
     */
    private TermResolution resolveNaturalLanguageTerms(TermSource termSource, String ruleName,
                                                         List<String> warnings) {
        CompileServiceResponse compileResp = switch (termSource) {
            case TermSource.TextTerms text -> compileClient.compile(text.descriptions(), ruleName);
            case TermSource.CsvFile csv -> compileClient.compileCsv(csv.file(), ruleName);
        };

        if (compileResp.hasFailures()) {
            long failedCount = compileResp.results().stream().filter(r -> !r.isPass()).count();
            warnings.add(failedCount + " term(s) failed pattern compilation and were skipped.");
            log.warn("{} Natural Language term(s) failed compilation", failedCount);
        }

        int[] nextId = {0};
        List<CompiledTerm> compiledTerms = new ArrayList<>();

        for (CompileServiceResponse.TermResult r : compileResp.results()) {
            if (!r.isPass()) {
                continue;
            }
            compiledTerms.add(buildCompiledTerm(
                    r.termId(), r.termDescription(), r.translatedPattern(), r.exclusionPattern(),
                    r.hyperscanFlags(), r.requiresExclusionCheck(), nextId));
        }

        return new TermResolution(compileResp.results(), compiledTerms);
    }

    // ── Term resolution: REGEX ───────────────────────────────────────────────────

    /**
     * Resolves Regex terms directly against Hyperscan — no Compile Service
     * call. Each term is validated INDIVIDUALLY first
     * ({@link HyperscanScanService#validatePattern}) so one bad regex in a
     * CSV batch fails only that term, not the whole scan. Regex-type terms
     * are raw caller-supplied patterns with no operator-language syntax, so
     * they never have an AND NOT exclusion.
     */
    private TermResolution resolveRegexTerms(TermSource termSource, List<String> warnings) {
        List<String> rawTerms = switch (termSource) {
            case TermSource.TextTerms text -> text.descriptions();
            case TermSource.CsvFile csv -> csvParserService.parseTermDescriptions(csv.file());
        };

        List<CompileServiceResponse.TermResult> allResults = new ArrayList<>(rawTerms.size());
        List<CompiledTerm> compiledTerms = new ArrayList<>(rawTerms.size());
        int[] nextId = {0};

        for (int i = 0; i < rawTerms.size(); i++) {
            String pattern = rawTerms.get(i).strip();
            String termId = "regex::" + (i + 1);

            PatternValidationResult validation =
                    scanService.validatePattern(pattern, HyperscanScanService.HS_FLAGS_REGEX_DEFAULT);

            if (validation.pass()) {
                allResults.add(new CompileServiceResponse.TermResult(
                        termId, pattern, "PASS", List.of(pattern),
                        HyperscanScanService.HS_FLAGS_REGEX_DEFAULT, false, null, null, null, Instant.now()));
                compiledTerms.add(buildCompiledTerm(
                        termId, pattern, List.of(pattern), null,
                        HyperscanScanService.HS_FLAGS_REGEX_DEFAULT, false, nextId));
            } else {
                allResults.add(new CompileServiceResponse.TermResult(
                        termId, pattern, "FAILED", null,
                        0, false, null, validation.errorMessage(), null, Instant.now()));
                log.warn("Regex term rejected by Hyperscan: '{}' — {}", pattern, validation.errorMessage());
            }
        }

        long failedCount = allResults.stream().filter(r -> !r.isPass()).count();
        if (failedCount > 0) {
            warnings.add(failedCount + " regex term(s) were rejected by Hyperscan and were skipped.");
        }

        return new TermResolution(allResults, compiledTerms);
    }

    /**
     * Builds one {@link CompiledTerm}, assigning it fresh expression id(s)
     * from {@code nextId} — shared, mutable, sequential state across every
     * term resolved in one call to {@link #resolveNaturalLanguageTerms} /
     * {@link #resolveRegexTerms}, so no two terms (or sides of the same
     * term) in one scan session ever collide.
     *
     * <p>A non-AND-NOT term consumes exactly one id (for
     * {@code requiredExpressionIds}) — whether it ends up compiling as a
     * plain expression or a native combination is decided later, inside
     * {@code HyperscanScanService}, and doesn't change how many ids are
     * needed here. An AND NOT term consumes one id per entry of
     * {@code requiredPatterns}, then one per entry of {@code exclusionPatterns}
     * — see {@link CompiledTerm} class Javadoc for why every AND NOT pattern
     * needs its own individually-reportable id now.
     */
    private CompiledTerm buildCompiledTerm(String termId, String termDescription,
                                            List<String> requiredPatterns, List<String> exclusionPatterns,
                                            int hsFlags, boolean requiresExclusionCheck, int[] nextId) {
        if (requiresExclusionCheck) {
            List<Integer> requiredIds = nextExpressionIds(requiredPatterns.size(), nextId);
            List<Integer> excludedIds = nextExpressionIds(exclusionPatterns.size(), nextId);
            return new CompiledTerm(termId, termDescription, requiredPatterns, exclusionPatterns,
                    hsFlags, true, requiredIds, excludedIds);
        }
        List<Integer> requiredIds = nextExpressionIds(1, nextId);
        return new CompiledTerm(termId, termDescription, requiredPatterns, exclusionPatterns,
                hsFlags, false, requiredIds, null);
    }

    private List<Integer> nextExpressionIds(int count, int[] nextId) {
        List<Integer> ids = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            ids.add(nextId[0]++);
        }
        return ids;
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /**
     * Bundles the full per-term result list (PASS + FAILED) and the PASS-only
     * compiled subset ready for the scan pass.
     */
    private record TermResolution(
            List<CompileServiceResponse.TermResult> allResults,
            List<CompiledTerm> compiledTerms
    ) {}

    /**
     * Builds the final list of {@link TermScanResult} records for ONE
     * message — one per term submitted, regardless of whether it compiled
     * or matched.
     *
     * @param allResults    all term results (PASS and FAILED, from either resolution path)
     * @param compiledTerms only the PASS terms, with their expression id(s)
     * @param matchesByIndex disclaimer-flagged highlights keyed by RAW expression id, for THIS message
     * @param matchedIds    every expression id that matched anywhere in THIS message —
     *                      see {@link #evaluateTerm}
     * @param termType      the term type this batch was resolved under
     */
    private List<TermScanResult> buildTermResults(
            List<CompileServiceResponse.TermResult> allResults,
            List<CompiledTerm> compiledTerms,
            Map<Integer, List<MatchHighlight>> matchesByIndex,
            Set<Integer> matchedIds,
            TermType termType) {

        Map<String, CompiledTerm> compiledByTermId = compiledTerms.stream()
                .collect(Collectors.toMap(CompiledTerm::termId, ct -> ct));

        return allResults.stream().map(result -> {

            if (!result.isPass()) {
                String error = buildError(result, termType);
                return new TermScanResult(
                        result.termId(), result.termDescription(),
                        null, "FAILED", false,
                        List.of(), false, false, false, error, null);
            }

            CompiledTerm ct = compiledByTermId.get(result.termId());
            if (ct == null) {
                // Should not happen — every PASS result has a corresponding CompiledTerm —
                // but fail safe rather than throw, matching this method's existing tolerance.
                return new TermScanResult(
                        result.termId(), result.termDescription(),
                        result.translatedPattern(), "PASS", result.requiresExclusionCheck(),
                        List.of(), false, false, false, null, null);
            }

            TermEvaluation evaluation = evaluateTerm(ct, matchedIds);

            // Highlights are shown ONLY when the required side is FULLY satisfied (every
            // entry of requiredExpressionIds matched) — otherwise, for an AND NOT term with
            // a decomposed required side, SOME but not all leaves could have matched,
            // producing partial highlights for a term that did not actually satisfy its
            // required condition. Shown regardless of excludedByAndNot: an excluded term's
            // required-side highlights are exactly what lets an analyst see WHY it fired
            // before being excluded — see class Javadoc "no more secondary Java-regex check".
            List<MatchHighlight> highlights = evaluation.requiredSatisfied()
                    ? ct.requiredExpressionIds().stream()
                            .flatMap(id -> matchesByIndex.getOrDefault(id, List.of()).stream())
                            .toList()
                    : List.of();

            boolean hasAlertWorthyMatches = evaluation.matched()
                    && highlights.stream().anyMatch(MatchHighlight::countsTowardAlert);
            boolean hasDisclaimerOnlyMatches = evaluation.matched()
                    && !highlights.isEmpty() && !hasAlertWorthyMatches;
            boolean excludedByAndNot = evaluation.excludedByAndNot();

            String exclusionNote = excludedByAndNot ? EXCLUSION_NOTE_TEMPLATE : null;

            return new TermScanResult(
                    result.termId(), result.termDescription(),
                    result.translatedPattern(), "PASS",
                    result.requiresExclusionCheck(),
                    highlights, hasAlertWorthyMatches, hasDisclaimerOnlyMatches, excludedByAndNot,
                    null, exclusionNote);
        }).toList();
    }

    private String buildError(CompileServiceResponse.TermResult result, TermType termType) {
        if (termType == TermType.REGEX) {
            return result.errorLog() != null && !result.errorLog().isBlank()
                    ? result.errorLog() : "Unknown Hyperscan validation failure";
        }
        if (result.translationError() != null && !result.translationError().isBlank()) {
            return "Translation error: " + result.translationError();
        }
        if (result.errorLog() != null && !result.errorLog().isBlank()) {
            return "Hyperscan error: " + result.errorLog();
        }
        return "Unknown compilation failure";
    }
}
