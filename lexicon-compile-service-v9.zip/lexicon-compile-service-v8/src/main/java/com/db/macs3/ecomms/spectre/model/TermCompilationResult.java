package com.db.macs3.ecomms.spectre.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.List;

/**
 * Compilation outcome for a single lexicon term.
 *
 * <p>{@code riskDriverName} has been removed from this record. It was
 * previously echoed back from the request but is no longer part of the
 * request structure.
 *
 * <h2>Null field semantics</h2>
 * <ul>
 *   <li>{@code translatedPattern} — null when translation failed before a
 *       pattern could even be produced (see {@code translationError}), OR
 *       when {@code requiresDecomposedMatching} is true (see below)</li>
 *   <li>{@code errorLog} — non-null only for Hyperscan-stage failures</li>
 *   <li>{@code translationError} — non-null only for translation-stage failures</li>
 *   <li>{@code exclusionPattern} — non-null only when {@code requiresExclusionCheck}
 *       is true AND {@code excludedRequiresDecomposedMatching} is false</li>
 *   <li>{@code hyperscanExpressionId} — non-null only on a {@code /compile/bundle}
 *       response (see below); always null for {@code /compile} and {@code /compile/csv},
 *       which never build a combined Hyperscan database</li>
 * </ul>
 * At most one of {@code errorLog} / {@code translationError} is non-null.
 * Both are null when {@code compilationStatus} is {@code PASS}.
 *
 * <h2>AND NOT has two different correct implementations, for two different callers</h2>
 * <p>{@code translatedPattern} and {@code exclusionPattern} are two
 * independently Hyperscan-valid patterns (Hyperscan cannot express "absent
 * from the whole message" in a single pattern — no negative lookaround
 * support). What a caller does with them differs by which endpoint it used:
 *
 * <ul>
 *   <li><b>{@code /compile} and {@code /compile/csv}</b> — the caller (e.g.
 *       the Lexicon Scanner Service) reads the JSON, compiles BOTH patterns
 *       itself, and combines the two boolean results in application code:
 *       matched iff {@code translatedPattern} matches AND {@code exclusionPattern}
 *       does not.</li>
 *   <li><b>{@code /compile/bundle}</b> — the returned {@code .hdb} file is
 *       often the ONLY artifact a consumer reads (e.g. the Lexicon Scan
 *       Engine's Dataproc job loads the database and scans messages against
 *       it directly, with no JSON in the loop at all). For this endpoint,
 *       {@code translatedPattern} and {@code exclusionPattern} are compiled
 *       into the combined database as a native Hyperscan LOGICAL COMBINATION
 *       ({@code HS_FLAG_COMBINATION}) — Hyperscan itself evaluates "required
 *       matched AND excluded did not" during the scan and reports a match
 *       ONLY at {@code hyperscanExpressionId}, with no separate application-level
 *       combination step needed downstream. See {@code LexiconCompileBundleService}.</li>
 * </ul>
 *
 * <h2>Decomposition: when a side is too structurally complex for one pattern</h2>
 * <p>Either side (the required side always; the excluded side only for an
 * AND NOT term) can independently be too complex for Hyperscan to compile
 * as a single pattern — see {@code PatternComplexityAnalyzer} and
 * {@code PatternDecomposer}. When this happens, that side is DECOMPOSED
 * into independent leaf patterns instead of the term being rejected:
 * {@code translatedPattern} (or {@code exclusionPattern}) is {@code null},
 * {@code requiresDecomposedMatching} (or {@code excludedRequiresDecomposedMatching})
 * is {@code true}, and {@code decomposedPatterns} (or
 * {@code excludedDecomposedPatterns}) carries the independent leaf patterns —
 * every one of which is itself independently Hyperscan-validated.
 *
 * <p><b>This is a real precision trade-off — always check {@code warnings}.</b>
 * Decomposition discards the original NEAR/FOLLOWEDBY proximity and ordering
 * constraints entirely: the leaf patterns are combined with pure boolean AND
 * ("all of these appear somewhere in the message"), not with any positional
 * relationship. A term originally written as {@code (A FOLLOWEDBY{4} B) FOLLOWEDBY{4} C}
 * — "these in this order, this close together" — becomes, once decomposed,
 * "A and B and C all appear somewhere in this message, in any order, any
 * distance apart". {@code warnings} always carries an explicit entry
 * whenever this trade-off applies to either side, so no caller can silently
 * treat a decomposed match as a genuine proximity match. A caller for
 * {@code /compile} / {@code /compile/csv} that needs to actually SCAN a
 * decomposed term must compile every entry in {@code decomposedPatterns}
 * (or {@code excludedDecomposedPatterns}) and treat that side as matched
 * only when EVERY entry is found in the message. For {@code /compile/bundle},
 * this combination is instead built natively into the combined database —
 * see {@code LexiconCompileBundleService}.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record TermCompilationResult(

        @JsonProperty("termId")
        String termId,

        @JsonProperty("termDescription")
        String termDescription,

        @JsonProperty("compilationStatus")
        CompilationStatus compilationStatus,

        @JsonProperty("translatedPattern")
        String translatedPattern,

        /**
         * Hyperscan error message when a pattern was syntactically valid
         * PCRE but Hyperscan's compiler still rejected it — the main pattern,
         * the exclusion pattern, or a decomposed leaf pattern for either side
         * (the message says which). Null for PASS terms and for
         * translation-stage failures.
         */
        @JsonProperty("errorLog")
        String errorLog,

        /**
         * Error from the operator-language translator, when the term's text
         * could not be converted into a PCRE pattern at all (e.g. missing
         * operand for NEAR{n}), OR when a side was over budget AND had no
         * NEAR/FOLLOWEDBY structure left to decompose, OR when even a
         * decomposed leaf was itself over budget on its own — see
         * {@code PatternDecomposer}. Null for PASS terms and for
         * Hyperscan-stage failures.
         */
        @JsonProperty("translationError")
        String translationError,

        /**
         * Hyperscan compile-flag bitmask applied to the pattern(s).
         * {@code 1}=CASELESS, {@code 32}=UTF8, {@code 64}=UCP.
         * {@code 0} indicates translation never completed.
         */
        @JsonProperty("hyperscanFlags")
        int hyperscanFlags,

        /**
         * {@code true} when the term used {@code AND NOT} — see the
         * two-implementations note in class Javadoc for what the caller
         * does with this depending on which endpoint produced this result.
         * Always {@code false} for failed terms and for terms using only
         * {@code AND} (which is fully expressed by {@code translatedPattern}
         * alone — see {@code PatternCodeGenerator} class Javadoc).
         */
        @JsonProperty("requiresExclusionCheck")
        boolean requiresExclusionCheck,

        /**
         * Independently Hyperscan-valid pattern that must NOT match the same
         * message for this term to be considered matched. Non-null iff
         * {@code requiresExclusionCheck} is true AND
         * {@code excludedRequiresDecomposedMatching} is false.
         */
        @JsonProperty("exclusionPattern")
        String exclusionPattern,

        /**
         * {@code true} when the REQUIRED side was too structurally complex
         * to compile as a single pattern and was decomposed instead — see
         * class Javadoc's "Decomposition" section. When true,
         * {@code translatedPattern} is null and {@code decomposedPatterns}
         * carries the independent leaf patterns instead.
         */
        @JsonProperty("requiresDecomposedMatching")
        boolean requiresDecomposedMatching,

        /**
         * The required side's independent, individually Hyperscan-validated
         * leaf patterns. Non-null and non-empty iff
         * {@code requiresDecomposedMatching} is true; null otherwise.
         */
        @JsonProperty("decomposedPatterns")
        List<String> decomposedPatterns,

        /**
         * {@code true} when the EXCLUDED side (only meaningful if
         * {@code requiresExclusionCheck}) was too structurally complex to
         * compile as a single pattern and was decomposed instead. When true,
         * {@code exclusionPattern} is null and {@code excludedDecomposedPatterns}
         * carries the independent leaf patterns instead.
         */
        @JsonProperty("excludedRequiresDecomposedMatching")
        boolean excludedRequiresDecomposedMatching,

        /**
         * The excluded side's independent, individually Hyperscan-validated
         * leaf patterns. Non-null and non-empty iff
         * {@code excludedRequiresDecomposedMatching} is true; null otherwise.
         */
        @JsonProperty("excludedDecomposedPatterns")
        List<String> excludedDecomposedPatterns,

        /**
         * Non-fatal issues worth surfacing to the caller — never null, may
         * be empty. Always includes an explicit entry whenever decomposition
         * applied to either side (see class Javadoc), and whenever the term
         * relied on chained NEAR/FOLLOWEDBY without explicit parentheses
         * (see {@code ExpressionParser}). Present regardless of
         * {@code compilationStatus}, though in practice only PASS terms
         * currently produce any.
         */
        @JsonProperty("warnings")
        List<String> warnings,

        /**
         * On a {@code /compile/bundle} response only: the ONE expression id
         * a downstream consumer of the combined {@code .hdb} file should
         * watch for to know this term matched — already accounts for AND NOT
         * and decomposition (see class Javadoc and {@code LexiconCompileBundleService}).
         * For a plain term with neither this is simply its term number
         * (parsed from its {@code termId}'s {@code ::<n>} suffix); otherwise
         * it is the id of a native Hyperscan combination expression, never
         * the id of a QUIET sub-expression compiled only to feed one.
         * Always null outside {@code /compile/bundle}, and always null for
         * FAILED terms (nothing was compiled into the database for them).
         */
        @JsonProperty("hyperscanExpressionId")
        Integer hyperscanExpressionId,

        @JsonProperty("compiledAt")
        @JsonFormat(shape = JsonFormat.Shape.STRING)
        Instant compiledAt

) {
    // ── Factory methods ───────────────────────────────────────────────────────

    /**
     * Creates a PASS result with no AND-NOT exclusion, no decomposition, no warnings.
     */
    public static TermCompilationResult pass(CompileRequest.TermInput input,
                                              String translatedPattern,
                                              int hyperscanFlags) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.PASS,
                translatedPattern, null, null,
                hyperscanFlags, false, null,
                false, null, false, null, List.of(),
                null, Instant.now());
    }

    /**
     * Creates a PASS result for an AND NOT term — both {@code translatedPattern}
     * and {@code exclusionPattern} have already been independently Hyperscan-validated.
     * No decomposition on either side, no warnings.
     */
    public static TermCompilationResult passWithExclusion(CompileRequest.TermInput input,
                                                            String translatedPattern,
                                                            int hyperscanFlags,
                                                            String exclusionPattern) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.PASS,
                translatedPattern, null, null,
                hyperscanFlags, true, exclusionPattern,
                false, null, false, null, List.of(),
                null, Instant.now());
    }

    /**
     * Creates a PASS result with full generality — required/excluded sides
     * each either a single pattern OR a decomposed leaf list, plus warnings.
     * Used by {@code LexiconCompileService} whenever either side was
     * decomposed (see class Javadoc), or whenever there are warnings to
     * carry (e.g. chained-proximity) even without decomposition.
     */
    public static TermCompilationResult passGeneral(CompileRequest.TermInput input,
                                                      String translatedPattern,
                                                      int hyperscanFlags,
                                                      boolean requiresExclusionCheck,
                                                      String exclusionPattern,
                                                      boolean requiresDecomposedMatching,
                                                      List<String> decomposedPatterns,
                                                      boolean excludedRequiresDecomposedMatching,
                                                      List<String> excludedDecomposedPatterns,
                                                      List<String> warnings) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.PASS,
                translatedPattern, null, null,
                hyperscanFlags, requiresExclusionCheck, exclusionPattern,
                requiresDecomposedMatching, decomposedPatterns,
                excludedRequiresDecomposedMatching, excludedDecomposedPatterns,
                warnings == null ? List.of() : List.copyOf(warnings),
                null, Instant.now());
    }

    /**
     * Creates a FAILED result where Hyperscan rejected a pattern — the main
     * pattern, the exclusion pattern, or a decomposed leaf of either side
     * (the message says which).
     *
     * @param translatedPattern the pattern that was attempted, for visibility —
     *                          may be null if the failure was in a decomposed leaf
     *                          or the exclusion side
     */
    public static TermCompilationResult failedHyperscan(CompileRequest.TermInput input,
                                                         String translatedPattern,
                                                         String errorLog,
                                                         int hyperscanFlags) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.FAILED,
                translatedPattern, errorLog, null,
                hyperscanFlags, false, null,
                false, null, false, null, List.of(),
                null, Instant.now());
    }

    /**
     * Creates a FAILED result where the term's syntax could not be translated
     * into a PCRE pattern at all — including the narrower decomposition-failure
     * cases (no proximity structure left to decompose; a leaf itself over
     * budget) — see {@code TermSyntaxTranslator}. Hyperscan was never invoked.
     */
    public static TermCompilationResult failedTranslation(CompileRequest.TermInput input,
                                                           String translationError) {
        return new TermCompilationResult(
                input.termId(), input.termDescription(),
                CompilationStatus.FAILED,
                null, null, translationError,
                0, false, null,
                false, null, false, null, List.of(),
                null, Instant.now());
    }

    /**
     * Returns a copy of this (PASS) result with {@link #hyperscanExpressionId}
     * set — used only by {@code LexiconCompileBundleService}, once it has
     * decided the id a downstream consumer should watch for this term in the
     * combined database (see class Javadoc).
     */
    public TermCompilationResult withHyperscanExpressionId(int id) {
        return new TermCompilationResult(
                termId, termDescription, compilationStatus,
                translatedPattern, errorLog, translationError,
                hyperscanFlags, requiresExclusionCheck, exclusionPattern,
                requiresDecomposedMatching, decomposedPatterns,
                excludedRequiresDecomposedMatching, excludedDecomposedPatterns, warnings,
                id, compiledAt);
    }

    public boolean isPass()   { return CompilationStatus.PASS   == compilationStatus; }
    public boolean isFailed() { return CompilationStatus.FAILED == compilationStatus; }
}
