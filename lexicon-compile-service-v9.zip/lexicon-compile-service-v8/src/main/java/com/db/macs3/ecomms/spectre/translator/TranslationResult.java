package com.db.macs3.ecomms.spectre.translator;

import java.util.List;

/**
 * Sealed result type for one {@link TermSyntaxTranslator#translate} call.
 *
 * <p>JDK 21 sealed interface with two permitted records. Use pattern matching switch:
 * <pre>
 * switch (result) {
 *   case TranslationResult.Success s -> use(s.hsPattern(), s.hsFlags());
 *   case TranslationResult.Error   e -> log(e.message());
 * }
 * </pre>
 *
 * <h2>AND NOT: the two-pattern contract</h2>
 * <p>When a term uses {@code AND NOT}, {@link Success#hsPattern()} alone is
 * NOT the full picture — Hyperscan cannot express "absent from the whole
 * message" in a single pattern (no negative lookaround support). A term
 * with {@link Success#requiresExclusionCheck()} true carries a SECOND,
 * independently Hyperscan-valid pattern in {@link Success#exclusionPattern()}.
 * The term is correctly matched only when:
 * <pre>
 *   hsPattern DOES match the message   AND
 *   exclusionPattern does NOT match the message
 * </pre>
 * Both patterns are Hyperscan-validated at compile time (see
 * {@code HyperscanCompiler}), so a caller can compile and scan them exactly
 * like any other pattern — the only extra step is combining the two
 * boolean results with AND-NOT logic after scanning, in application code.
 * See the project README for a concrete example.
 *
 * <h2>Decomposition: when a required or excluded side is too complex to compile as one pattern</h2>
 * <p>Either side of a term (the required side always; the excluded side only
 * for an AND NOT term) can independently be too structurally complex for
 * Hyperscan to compile as a single pattern — see
 * {@code PatternComplexityAnalyzer} and {@code PatternDecomposer}. When this
 * happens, that side's single pattern field ({@link Success#hsPattern()} or
 * {@link Success#exclusionPattern()}) is {@code null}, and the corresponding
 * {@code requires*DecomposedMatching} flag is {@code true} with the decomposed
 * leaf patterns available in {@link Success#decomposedPatterns()} /
 * {@link Success#excludedDecomposedPatterns()}.
 *
 * <p><b>This is a real precision trade-off, not a lossless rewrite.</b>
 * Decomposition discards the DISTANCE and ORDER constraints a nested
 * NEAR/FOLLOWEDBY structure expressed — the leaf patterns are combined with
 * pure boolean AND ("all of these appear somewhere in the message"), not
 * with any positional relationship, because Hyperscan's logical-combination
 * mechanism (used by {@code /compile/bundle} — see
 * {@code LexiconCompileBundleService}) has no concept of position at all,
 * only whole-buffer existence. A term originally written as
 * {@code (A FOLLOWEDBY{4} B) FOLLOWEDBY{4} C} — "these in this order, this
 * close together" — becomes, once decomposed, "A and B and C all appear
 * somewhere in this message, in any order, any distance apart": the same
 * class of semantic widening that made the old lookahead-based {@code AND}
 * implementation silently behave like {@code OR}. This trade-off exists
 * specifically so a term that would otherwise be REJECTED outright still
 * produces a usable (if less precise) result — see {@link #warnings()},
 * which always carries an explicit warning whenever this trade-off applies,
 * so no caller can silently treat a decomposed match as a genuine proximity
 * match without realizing precision was reduced.
 */
public sealed interface TranslationResult
        permits TranslationResult.Success, TranslationResult.Error {

    /** Returns true when translation succeeded. */
    boolean isSuccess();

    /**
     * Successful translation.
     *
     * @param hsPattern                          the required side's Hyperscan PCRE pattern.
     *                                            {@code null} iff {@code requiresDecomposedMatching} is true —
     *                                            see {@link #decomposedPatterns()} instead.
     * @param hsFlags                            bitmask: 1=CASELESS, 32=UTF8, 64=UCP
     * @param requiresExclusionCheck             true when this term used AND NOT — the
     *                                            caller MUST also check the excluded side
     * @param exclusionPattern                   the excluded side's Hyperscan PCRE pattern.
     *                                            Non-null iff {@code requiresExclusionCheck} is
     *                                            true AND {@code excludedRequiresDecomposedMatching}
     *                                            is false.
     * @param requiresDecomposedMatching         true when the REQUIRED side was too structurally
     *                                            complex to compile as one pattern and was decomposed —
     *                                            see class Javadoc's precision-trade-off note
     * @param decomposedPatterns                 the required side's independent QUIET leaf patterns.
     *                                            Non-null and non-empty iff {@code requiresDecomposedMatching}.
     *                                            A caller (or, for {@code /compile/bundle}, this service's own
     *                                            combined-database builder) must treat the term as matched only
     *                                            when EVERY entry is found — pure conjunction, no distance/order.
     * @param excludedRequiresDecomposedMatching true when the EXCLUDED side (only meaningful if
     *                                            {@code requiresExclusionCheck}) was too structurally
     *                                            complex to compile as one pattern and was decomposed
     * @param excludedDecomposedPatterns         the excluded side's independent QUIET leaf patterns.
     *                                            Non-null and non-empty iff {@code excludedRequiresDecomposedMatching}.
     * @param warnings                           non-fatal issues worth surfacing to the caller — never null,
     *                                            may be empty. Always includes an explicit entry whenever
     *                                            decomposition applied to either side, and whenever the term
     *                                            relied on chained NEAR/FOLLOWEDBY without explicit parentheses
     *                                            (see {@code ExpressionParser}).
     */
    record Success(
            String       hsPattern,
            int          hsFlags,
            boolean      requiresExclusionCheck,
            String       exclusionPattern,
            boolean      requiresDecomposedMatching,
            List<String> decomposedPatterns,
            boolean      excludedRequiresDecomposedMatching,
            List<String> excludedDecomposedPatterns,
            List<String> warnings
    ) implements TranslationResult {

        /** @return true always */
        public boolean isSuccess() { return true; }
    }

    /**
     * Failed translation.
     *
     * @param message human-readable error
     */
    record Error(String message) implements TranslationResult {

        /** @return false always */
        public boolean isSuccess() { return false; }
    }

    // ── Factories: the common, non-decomposed cases (unchanged behaviour) ──────

    /** Factory: successful translation with no AND-NOT exclusion, no warnings. */
    static TranslationResult success(String pattern, int flags) {
        return new Success(pattern, flags, false, null, false, null, false, null, List.of());
    }

    /** Factory: successful translation with no AND-NOT exclusion, carrying warnings. */
    static TranslationResult successWithWarnings(String pattern, int flags, List<String> warnings) {
        return new Success(pattern, flags, false, null, false, null, false, null, List.copyOf(warnings));
    }

    /** Factory: successful translation WITH an AND-NOT exclusion pattern, no warnings. */
    static TranslationResult successWithExclusion(String pattern, int flags, String exclusionPattern) {
        return new Success(pattern, flags, true, exclusionPattern, false, null, false, null, List.of());
    }

    /** Factory: successful translation WITH an AND-NOT exclusion pattern, carrying warnings. */
    static TranslationResult successWithExclusionAndWarnings(
            String pattern, int flags, String exclusionPattern, List<String> warnings) {
        return new Success(pattern, flags, true, exclusionPattern, false, null, false, null, List.copyOf(warnings));
    }

    /** Factory: failed translation. */
    static TranslationResult error(String message) {
        return new Error(message);
    }
}
